package com.json.mapping.parse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.json.mapping.bo.BOC;
import com.json.mapping.bo.StandardizedTran;
import com.json.mapping.bo.StandardizedTranInfo;
import com.json.mapping.util.JsonUtil;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 中行pdf交易流水解析
 * @author anyspa
 * @since 2022/08/23
 */
public class BOCMappingParser {
	public String parseBOCTrans(String json) {
		String standardizedJson = "";
		try {
			BOC boc = JsonUtil.json2Object(json, BOC.class);
			standardizedJson = convertBOC2StandardizedJson(boc);
		} catch (Exception e) {
			System.out.println("parseBOCTrans failed, error:" + e);
		}
		return standardizedJson;
	}

	private String convertBOC2StandardizedJson(BOC boc) throws JsonProcessingException {
		StandardizedTran standardizedTran = new StandardizedTran();
		String transDetailPeriod = boc.getTradeRange();
		if (transDetailPeriod != null && transDetailPeriod.contains("至")) {
			standardizedTran.setStartDate(transDetailPeriod.split("至")[0].trim());
			standardizedTran.setExpirationDate(transDetailPeriod.split("至")[1].trim());
		}
		standardizedTran.setAccountName(boc.getCustomerName());
		standardizedTran.setAccountNumber(boc.getAccountNumber());

		List<StandardizedTranInfo> standardizedTranInfoList = boc.getBocTrans().stream().map(bocTran -> {
			StandardizedTranInfo standardizedTranInfo = new StandardizedTranInfo();
			standardizedTranInfo.setTransactionDate(bocTran.getBookkeepingDate());
			standardizedTranInfo.setTransactionTime(bocTran.getBookkeepingTime());
			standardizedTranInfo.setCurrency(bocTran.getCurrency());
			standardizedTranInfo.setAccountBalance(bocTran.getBalance());
			standardizedTranInfo.setSummary(bocTran.getTransactionName());
			if (bocTran.getAmount() != null) {
				if (bocTran.getAmount().startsWith("-")) {
					standardizedTranInfo.setExpense(bocTran.getAmount().replace("-", ""));
				} else {
					standardizedTranInfo.setRevenue(bocTran.getAmount());
				}
			}

			standardizedTranInfo.setCounterPartyAccountName(bocTran.getOppositeAccountName());
			standardizedTranInfo.setCounterPartyAccountNumber(bocTran.getOppositeCardNo());
			return standardizedTranInfo;
		}).collect(Collectors.toList());

		standardizedTran.setStandardizedTrans(standardizedTranInfoList);
		return JsonUtil.object2Json(standardizedTran);
	}

	public static void main(String[] args) {
		BOCMappingParser bocMappingParser = new BOCMappingParser();
		String bocJson = "{\"交易区间\":\"2021-11-19 至 2022-05-18\",\"客户姓名\":\"张**\",\"打印时间\":\"2022/05/18 17:21:02\",\"借记卡号\":\"6217857500009163681\",\"账号\":\"606761903191\",\"按收支筛选\":\"全部\",\"按币种筛选\":\"全部\",\"交易明细\":[{\"记账日期\":\"2022-05-12\",\"记账时间\":\"13:51:28\",\"币别\":\"人民币\",\"金额\":\"-605.00\",\"余额\":\"0.80\",\"交易名称\":\"跨行转账\",\"渠道\":\"手机银行\",\"网点名称\":\"-------------------\",\"附言\":\"----------\",\"对方账户名\":\"张**\",\"对方卡号/账号\":\"6236330014122171412\",\"对方开户行\":\"深圳前海微众银行股份有限公司\"},{\"记账日期\":\"2022-05-12\",\"记账时间\":\"13:15:22\",\"币别\":\"人民币\",\"金额\":\"604.80\",\"余额\":\"605.80\",\"交易名称\":\"网上快捷提现\",\"渠道\":\"银企对接\",\"网点名称\":\"-------------------\",\"附言\":\"平安付科技-平安付科技服务有限公司-理赔赔款\",\"对方账户名\":\"平安付科技服务有限公司\",\"对方卡号/账号\":\"243300139\",\"对方开户行\":\"平安付科技\"},{\"记账日期\":\"2022-05-11\",\"记账时间\":\"13:53:48\",\"币别\":\"人民币\",\"金额\":\"-599.00\",\"余额\":\"1.00\",\"交易名称\":\"网上快捷支付\",\"渠道\":\"银企对接\",\"网点名称\":\"-------------------\",\"附言\":\"财付通-微信转账\",\"对方账户名\":\"财付通-微信转账\",\"对方卡号/账号\":\"-------------------\",\"对方开户行\":\"-------------------\"},{\"记账日期\":\"2022-05-11\",\"记账时间\":\"13:51:41\",\"币别\":\"人民币\",\"金额\":\"600.00\",\"余额\":\"600.00\",\"交易名称\":\"跨行转账\",\"渠道\":\"网上银行\",\"网点名称\":\"-------------------\",\"附言\":\"----------\",\"对方账户名\":\"张**\",\"对方卡号/账号\":\"6236330014122171412\",\"对方开户行\":\"深圳前海微众银行股份有限公司\"},{\"记账日期\":\"2022-05-08\",\"记账时间\":\"15:44:12\",\"币别\":\"人民币\",\"金额\":\"-87,293.16\",\"余额\":\"0.00\",\"交易名称\":\"跨行转账\",\"渠道\":\"手机银行\",\"网点名称\":\"-------------------\",\"附言\":\"----------\",\"对方账户名\":\"张**\",\"对方卡号/账号\":\"6236330014122171412\",\"对方开户行\":\"深圳前海微众银行股份有限公司\"},{\"记账日期\":\"2022-05-06\",\"记账时间\":\"08:41:30\",\"币别\":\"人民币\",\"金额\":\"20,000.00\",\"余额\":\"87,293.16\",\"交易名称\":\"跨行转账\",\"渠道\":\"网上银行\",\"网点名称\":\"-------------------\",\"附言\":\"跨行转出\",\"对方账户名\":\"周金艳\",\"对方卡号/账号\":\"6217001860007250558\",\"对方开户行\":\"中国建设银行股份有限公司顺昌县中意储蓄所\"}]}";
		String bocTrans = bocMappingParser.parseBOCTrans(bocJson);
		System.out.println(bocTrans);
	}
}
