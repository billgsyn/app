package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * 平安
 * @author anyspa
 * @since 2022/08/22
 */
public class PAB {
	/**
	 * 户名
	 */
	@JsonProperty("户名")
	private String name;

	/**
	 * 账号
	 */
	@JsonProperty("账号")
	private String accountNo;

	/**
	 * 卡号
	 */
	@JsonProperty("卡号")
	private String cardNo;

	/**
	 * 币种
	 */
	@JsonProperty("币种")
	private String currency;

	/**
	 * 存款类型
	 */
	@JsonProperty("存款类型")
	private String depositType;

	/**
	 * 交易日期
	 */
	@JsonProperty("交易日期")
	private String transactionDate;

	/**
	 * 开户行
	 */
	@JsonProperty("开户行")
	private String accountBank;

	/**
	 * 受理行
	 */
	@JsonProperty("受理行")
	private String receivingBank;

	/**
	 * 打印日期
	 */
	@JsonProperty("打印日期")
	private String printDate;

	/**
	 * 流水范围
	 */
	@JsonProperty("流水范围")
	private String transactionRange;

	/**
	 * 交易明细
	 */
	@JsonProperty("交易明细")
	private List<PABTran> pabTrans;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDepositType() {
		return depositType;
	}

	public void setDepositType(String depositType) {
		this.depositType = depositType;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getAccountBank() {
		return accountBank;
	}

	public void setAccountBank(String accountBank) {
		this.accountBank = accountBank;
	}

	public String getReceivingBank() {
		return receivingBank;
	}

	public void setReceivingBank(String receivingBank) {
		this.receivingBank = receivingBank;
	}

	public String getPrintDate() {
		return printDate;
	}

	public void setPrintDate(String printDate) {
		this.printDate = printDate;
	}

	public String getTransactionRange() {
		return transactionRange;
	}

	public void setTransactionRange(String transactionRange) {
		this.transactionRange = transactionRange;
	}

	public List<PABTran> getPabTrans() {
		return pabTrans;
	}

	public void setPabTrans(List<PABTran> pabTrans) {
		this.pabTrans = pabTrans;
	}
}
