package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * 招商
 * @author anyspa
 * @since 2022/08/23
 */
public class CMB {
	/**
	 * "交易流水对应的期间
	 */
	@JsonProperty("交易流水对应的期间")
	private String transDetailPeriod;

	/**
	 * 户名
	 */
	@JsonProperty("户名")
	private String name;

	/**
	 * 账号
	 */
	@JsonProperty("账号")
	private String accountNo;

	/**
	 * 账户类型
	 */
	@JsonProperty("账户类型")
	private String accountType;

	/**
	 * 开户行
	 */
	@JsonProperty("开户行")
	private String subBranch;

	/**
	 * 申请时间
	 */
	@JsonProperty("申请时间")
	private String date;

	/**
	 * 验证码
	 */
	@JsonProperty("验证码")
	private String verificationCode;

	/**
	 * 交易明细
	 */
	@JsonProperty("交易明细")
	private List<CMBTran> cmbTrans;

	public String getTransDetailPeriod() {
		return transDetailPeriod;
	}

	public void setTransDetailPeriod(String transDetailPeriod) {
		this.transDetailPeriod = transDetailPeriod;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getSubBranch() {
		return subBranch;
	}

	public void setSubBranch(String subBranch) {
		this.subBranch = subBranch;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getVerificationCode() {
		return verificationCode;
	}

	public void setVerificationCode(String verificationCode) {
		this.verificationCode = verificationCode;
	}

	public List<CMBTran> getCmbTrans() {
		return cmbTrans;
	}

	public void setCmbTrans(List<CMBTran> cmbTrans) {
		this.cmbTrans = cmbTrans;
	}
}
