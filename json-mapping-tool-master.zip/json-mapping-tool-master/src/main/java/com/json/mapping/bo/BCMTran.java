package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author anyspa
 * @since 2022/08/24
 */
public class BCMTran {
	/**
	 * 序号
	 */
	@JsonProperty("序号")
	private String serialNum;

	/**
	 * 交易日期
	 */
	@JsonProperty("交易日期")
	private String transDate;

	/**
	 * 交易时间
	 */
	@JsonProperty("交易时间")
	private String transTime;

	/**
	 * 交易类型
	 */
	@JsonProperty("交易类型")
	private String tradingType;

	/**
	 * 借贷
	 */
	@JsonProperty("借贷")
	private String dcFlg;

	/**
	 * 交易金额
	 */
	@JsonProperty("交易金额")
	private String transAmt;

	/**
	 * 余额
	 */
	@JsonProperty("余额")
	private String balance;

	/**
	 * 对方账户
	 */
	@JsonProperty("对方账户")
	private String paymentReceiptAccount;

	/**
	 * 对方户名
	 */
	@JsonProperty("对方户名")
	private String paymentReceiptAccountName;

	/**
	 * 交易地点
	 */
	@JsonProperty("交易地点")
	private String tradingPlace;

	/**
	 * 会计流水号
	 */
	@JsonProperty("会计流水号")
	private String accountingFluidNumber;

	/**
	 * 摘要
	 */
	@JsonProperty("摘要")
	private String summary;

	public String getSerialNum() {
		return serialNum;
	}

	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}

	public String getTradingType() {
		return tradingType;
	}

	public void setTradingType(String tradingType) {
		this.tradingType = tradingType;
	}

	public String getDcFlg() {
		return dcFlg;
	}

	public void setDcFlg(String dcFlg) {
		this.dcFlg = dcFlg;
	}

	public String getTransAmt() {
		return transAmt;
	}

	public void setTransAmt(String transAmt) {
		this.transAmt = transAmt;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getPaymentReceiptAccount() {
		return paymentReceiptAccount;
	}

	public void setPaymentReceiptAccount(String paymentReceiptAccount) {
		this.paymentReceiptAccount = paymentReceiptAccount;
	}

	public String getPaymentReceiptAccountName() {
		return paymentReceiptAccountName;
	}

	public void setPaymentReceiptAccountName(String paymentReceiptAccountName) {
		this.paymentReceiptAccountName = paymentReceiptAccountName;
	}

	public String getTradingPlace() {
		return tradingPlace;
	}

	public void setTradingPlace(String tradingPlace) {
		this.tradingPlace = tradingPlace;
	}

	public String getAccountingFluidNumber() {
		return accountingFluidNumber;
	}

	public void setAccountingFluidNumber(String accountingFluidNumber) {
		this.accountingFluidNumber = accountingFluidNumber;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}
}
