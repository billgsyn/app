package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author anyspa
 * @since 2022/08/23
 */
public class BOCTran {
	/**
	 * 记账日期
	 */
	@JsonProperty("记账日期")
	private String bookkeepingDate;

	/**
	 * 记账时间
	 */
	@JsonProperty("记账时间")
	private String bookkeepingTime;

	/**
	 * 币别
	 */
	@JsonProperty("币别")
	private String currency;

	/**
	 * 金额
	 */
	@JsonProperty("金额")
	private String amount;

	/**
	 * 余额
	 */
	@JsonProperty("余额")
	private String balance;

	/**
	 * 交易名称
	 */
	@JsonProperty("交易名称")
	private String transactionName;

	/**
	 * 渠道
	 */
	@JsonProperty("渠道")
	private String channel;

	/**
	 * 网点名称
	 */
	@JsonProperty("网点名称")
	private String outletName;

	/**
	 * 附言
	 */
	@JsonProperty("附言")
	private String postscript;

	/**
	 * 对方账户名
	 */
	@JsonProperty("对方账户名")
	private String oppositeAccountName;

	/**
	 * 对方卡号/账号
	 */
	@JsonProperty("对方卡号/账号")
	private String OppositeCardNo;

	/**
	 * 对方开户行
	 */
	@JsonProperty("对方开户行")
	private String OppositeBankOfDeposit;

	public String getBookkeepingDate() {
		return bookkeepingDate;
	}

	public void setBookkeepingDate(String bookkeepingDate) {
		this.bookkeepingDate = bookkeepingDate;
	}

	public String getBookkeepingTime() {
		return bookkeepingTime;
	}

	public void setBookkeepingTime(String bookkeepingTime) {
		this.bookkeepingTime = bookkeepingTime;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getOutletName() {
		return outletName;
	}

	public void setOutletName(String outletName) {
		this.outletName = outletName;
	}

	public String getPostscript() {
		return postscript;
	}

	public void setPostscript(String postscript) {
		this.postscript = postscript;
	}

	public String getOppositeAccountName() {
		return oppositeAccountName;
	}

	public void setOppositeAccountName(String oppositeAccountName) {
		this.oppositeAccountName = oppositeAccountName;
	}

	public String getOppositeCardNo() {
		return OppositeCardNo;
	}

	public void setOppositeCardNo(String oppositeCardNo) {
		OppositeCardNo = oppositeCardNo;
	}

	public String getOppositeBankOfDeposit() {
		return OppositeBankOfDeposit;
	}

	public void setOppositeBankOfDeposit(String oppositeBankOfDeposit) {
		OppositeBankOfDeposit = oppositeBankOfDeposit;
	}
}
