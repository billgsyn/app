package com.json.mapping.bo;

import java.util.List;

/**
 * @author anyspa
 * @since 2022/04/06
 */

public class StandardizedTran {

	/**
	 * 卡号/账号
	 */
	private String accountNumber = "";

	/**
	 * 户名
	 */
	private String accountName = "";

	/**
	 * 起始日期
	 */
	private String startDate = "";

	/**
	 * 结束日期
	 */
	private String expirationDate = "";

	/**
	 * 交易明细
	 */
	private List<StandardizedTranInfo>  standardizedTrans;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public List<StandardizedTranInfo> getStandardizedTrans() {
		return standardizedTrans;
	}

	public void setStandardizedTrans(List<StandardizedTranInfo> standardizedTrans) {
		this.standardizedTrans = standardizedTrans;
	}
}
