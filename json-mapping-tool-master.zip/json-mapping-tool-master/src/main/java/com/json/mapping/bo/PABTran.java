package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author anyspa
 * @since 2022/08/22
 */
public class PABTran {
	/**
	 * 序号
	 */
	@JsonProperty("序号")
	private String id;

	/**
	 * 交易时间
	 */
	@JsonProperty("交易时间")
	private String transactionTime;

	/**
	 * 交易金额
	 */
	@JsonProperty("交易金额")
	private String transactionAmount;

	/**
	 * 账户余额
	 */
	@JsonProperty("账户余额")
	private String balance;

	/**
	 * 摘要
	 */
	@JsonProperty("摘要")
	private String transactionType;

	/**
	 * 交易对手信息
	 */
	@JsonProperty("交易对手信息")
	private String counterParty;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getCounterParty() {
		return counterParty;
	}

	public void setCounterParty(String counterParty) {
		this.counterParty = counterParty;
	}
}
