package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * 邮储
 * @author anyspa
 * @since 2022/08/23
 */
public class PSBC {
	/**
	 * 账号/卡号
	 */
	@JsonProperty("账号/卡号")
	private String accountNumber;

	/**
	 * 交易类型
	 */
	@JsonProperty("交易类型")
	private String transactionType;

	/**
	 * 转入账号/卡号
	 */
	@JsonProperty("转入账号/卡号")
	private String transferInAccountNumber;

	/**
	 * 收入/支出
	 */
	@JsonProperty("收入/支出")
	private String incomeExpense;

	/**
	 * 起始日期
	 */
	@JsonProperty("起始日期")
	private String startDate;

	/**
	 * 截止日期
	 */
	@JsonProperty("截止日期")
	private String expirationDate;

	/**
	 * 总收入
	 */
	@JsonProperty("总收入")
	private String totalIncome;

	/**
	 * 总支出
	 */
	@JsonProperty("总支出")
	private String totalExpense;

	/**
	 * 交易明细
	 */
	@JsonProperty("交易明细")
	private List<PSBCTran> psbcTrans;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransferInAccountNumber() {
		return transferInAccountNumber;
	}

	public void setTransferInAccountNumber(String transferInAccountNumber) {
		this.transferInAccountNumber = transferInAccountNumber;
	}

	public String getIncomeExpense() {
		return incomeExpense;
	}

	public void setIncomeExpense(String incomeExpense) {
		this.incomeExpense = incomeExpense;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getTotalIncome() {
		return totalIncome;
	}

	public void setTotalIncome(String totalIncome) {
		this.totalIncome = totalIncome;
	}

	public String getTotalExpense() {
		return totalExpense;
	}

	public void setTotalExpense(String totalExpense) {
		this.totalExpense = totalExpense;
	}

	public List<PSBCTran> getPsbcTrans() {
		return psbcTrans;
	}

	public void setPsbcTrans(List<PSBCTran> psbcTrans) {
		this.psbcTrans = psbcTrans;
	}
}
