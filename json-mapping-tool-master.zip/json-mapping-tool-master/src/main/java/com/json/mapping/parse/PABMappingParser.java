package com.json.mapping.parse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.json.mapping.bo.PAB;
import com.json.mapping.bo.StandardizedTran;
import com.json.mapping.bo.StandardizedTranInfo;
import com.json.mapping.util.DateUtil;
import com.json.mapping.util.JsonUtil;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 平安银行pdf流水解析
 * @author anyspa
 * @since 2022/08/22
 */
public class PABMappingParser {
	public String parsePABTrans(String json) {
		String standardizedJson = "";
		try {
			PAB pab = JsonUtil.json2Object(json, PAB.class);
			standardizedJson = convertPAB2StandardizedJson(pab);
		} catch (JsonProcessingException e) {
			System.out.println("parsePABTrans failed, error:" + e);
		}
		return standardizedJson;
	}

	private String convertPAB2StandardizedJson(PAB pab) throws JsonProcessingException {
		StandardizedTran standardizedTran = new StandardizedTran();
		standardizedTran.setAccountName(pab.getName());
		standardizedTran.setAccountNumber(pab.getAccountNo());
		String transactionDate = pab.getTransactionDate();
		if (transactionDate != null && transactionDate.contains("-")) {
			String[] date = transactionDate.split("-");
			standardizedTran.setStartDate(DateUtil.convertDate(date[0]));
			standardizedTran.setExpirationDate(DateUtil.convertDate(date[1]));
		}
		String currency = pab.getCurrency();

		List<StandardizedTranInfo> standardizedTrans = pab.getPabTrans().stream().map(pabTran -> {
			StandardizedTranInfo standardizedTranInfo = new StandardizedTranInfo();
			if (pabTran.getTransactionTime() != null && !pabTran.getTransactionTime().equals("")) {
				standardizedTranInfo.setTransactionDate(DateUtil.convertDate(pabTran.getTransactionTime()));
			}
			standardizedTranInfo.setSummary(pabTran.getTransactionType());
			if (pabTran.getTransactionAmount() != null) {
				if (pabTran.getTransactionAmount().startsWith("-")) {
					standardizedTranInfo.setExpense(pabTran.getTransactionAmount().replace("-", ""));
				} else if (pabTran.getTransactionAmount().startsWith("+")){
					standardizedTranInfo.setRevenue(pabTran.getTransactionAmount().replace("+", ""));
				}
			}
			standardizedTranInfo.setAccountBalance(pabTran.getBalance());
			standardizedTranInfo.setCurrency(currency);
			parseCounterParty(standardizedTranInfo, pabTran.getCounterParty());

			return standardizedTranInfo;
		}).collect(Collectors.toList());
		standardizedTran.setStandardizedTrans(standardizedTrans);

		return JsonUtil.object2Json(standardizedTran);
	}

	private void parseCounterParty(StandardizedTranInfo standardizedTranInfo, String counterParty) {
		try {
			if (counterParty != null && !"".equals(counterParty)) {
				// 招商银行股份有限公司-张三-6214861021778877
				if (counterParty.contains("-")) {
					String counterPartySecondHalf = counterParty.substring(counterParty.lastIndexOf("-") + 1);
					if (counterPartySecondHalf.matches("\\d+")) {
						String counterPartyAccountName = counterParty.substring(0, counterParty.lastIndexOf("-"));
						standardizedTranInfo.setCounterPartyAccountNumber(counterPartySecondHalf);
						standardizedTranInfo.setCounterPartyAccountName(counterPartyAccountName);
					} else {
						standardizedTranInfo.setCounterPartyAccountName(counterParty);
					}
				} else {
					standardizedTranInfo.setCounterPartyAccountName(counterParty);
				}
			}
		} catch (Exception e) {
			System.out.println("parseCounterParty failed, error:" + e);
		}
	}

	public static void main(String[] args) {
		PABMappingParser pabMappingParser = new PABMappingParser();
		String pabJson = "{\"户名\":\"张**\",\"账号\":\"2000093213084\",\"卡号\":\"6230582000030038791\",\"币种\":\"CNY\",\"存款类型\":\"活期\",\"交易日期\":\"20211013-20220413\",\"开户行\":\"平安银行深圳分行香蜜湖支行\",\"受理行\":\"平安银行总行\",\"打印日期\":\"2022.04.13 11:20:53\",\"流水范围\":\"全部交易\",\"交易明细\":[{\"序号\":\"1\",\"交易时间\":\"20220413\",\"交易金额\":\"-2,000.00\",\"账户余额\":\"659.66\",\"摘要\":\"转账\",\"交易对手信息\":\"交通银行股份有限公司-张**-6222623710009479028\"},{\"序号\":\"2\",\"交易时间\":\"20220412\",\"交易金额\":\"-4,000.00\",\"账户余额\":\"2,659.66\",\"摘要\":\"转账\",\"交易对手信息\":\"招商银行股份有限公司-张**-6214854513961259\"},{\"序号\":\"3\",\"交易时间\":\"20220412\",\"交易金额\":\"-640.93\",\"账户余额\":\"6,659.66\",\"摘要\":\"还信用卡\",\"交易对手信息\":\"平安银行-张**-6221550928013568\"},{\"序号\":\"4\",\"交易时间\":\"20220412\",\"交易金额\":\"+5,300.00\",\"账户余额\":\"7,300.59\",\"摘要\":\"转账\",\"交易对手信息\":\"中国银行总行-张**-6217902000005191476\"},{\"序号\":\"5\",\"交易时间\":\"20220412\",\"交易金额\":\"-93.98\",\"账户余额\":\"2,000.59\",\"摘要\":\"银联代收\",\"交易对手信息\":\"广发电话跨行还款-4060507\"},{\"序号\":\"6\",\"交易时间\":\"20220410\",\"交易金额\":\"-940.98\",\"账户余额\":\"2,094.57\",\"摘要\":\"支付宝\",\"交易对手信息\":\"支付宝（中国）网络技术有限公司-支付宝（中国）网络技术有限公司-215500690\"},{\"序号\":\"7\",\"交易时间\":\"20220407\",\"交易金额\":\"-379.68\",\"账户余额\":\"3,035.55\",\"摘要\":\"第三方支付\",\"交易对手信息\":\"裕福支付有限公司-裕福支付有限公司-210401417\"},{\"序号\":\"8\",\"交易时间\":\"20220406\",\"交易金额\":\"-540.71\",\"账户余额\":\"3,415.23\",\"摘要\":\"银联无卡\",\"交易对手信息\":\"（特约）美团\"},{\"序号\":\"9\",\"交易时间\":\"20220404\",\"交易金额\":\"-7,099.00\",\"账户余额\":\"3,955.94\",\"摘要\":\"转账\",\"交易对手信息\":\"中国建设银行股份有限公司总行-谭秋秋-6217007200062494680\"},{\"序号\":\"10\",\"交易时间\":\"20220404\",\"交易金额\":\"-926.00\",\"账户余额\":\"11,054.94\",\"摘要\":\"转账\",\"交易对手信息\":\"中国建设银行股份有限公司总行-张**-6259653512645319\"}]}";
		String pabTrans = pabMappingParser.parsePABTrans(pabJson);
		System.out.println(pabTrans);
	}
}
