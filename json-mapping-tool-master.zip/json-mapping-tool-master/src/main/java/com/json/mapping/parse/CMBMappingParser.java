package com.json.mapping.parse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.json.mapping.bo.CMB;
import com.json.mapping.bo.StandardizedTran;
import com.json.mapping.bo.StandardizedTranInfo;
import com.json.mapping.util.JsonUtil;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 招行pdf交易流水解析
 * @author anyspa
 * @since 2022/08/23
 */
public class CMBMappingParser {
	public String parseCMBTrans(String json) {
		String standardizedJson = "";
		try {
			CMB cmb = JsonUtil.json2Object(json, CMB.class);
			standardizedJson = convertCMB2StandardizedJson(cmb);
		} catch (Exception e) {
			System.out.println("parseCMBTrans failed, error:" + e);
		}
		return standardizedJson;
	}

	private String convertCMB2StandardizedJson(CMB cmb) throws JsonProcessingException {
		StandardizedTran standardizedTran = new StandardizedTran();
		standardizedTran.setAccountNumber(cmb.getAccountNo());
		standardizedTran.setAccountName(cmb.getName());
		String transDetailPeriod = cmb.getTransDetailPeriod();
		if (transDetailPeriod != null && transDetailPeriod.contains("--")) {
			standardizedTran.setStartDate(transDetailPeriod.split("--")[0]);
			standardizedTran.setExpirationDate(transDetailPeriod.split("--")[1]);
		}

		List<StandardizedTranInfo> standardizedTranInfoList = cmb.getCmbTrans().stream().map(cmbTran -> {
			StandardizedTranInfo standardizedTranInfo = new StandardizedTranInfo();

			standardizedTranInfo.setTransactionDate(cmbTran.getDate());
			standardizedTranInfo.setCurrency(cmbTran.getCurrency());
			if (cmbTran.getTransactionAmount() != null) {
				if (cmbTran.getTransactionAmount().startsWith("-")) {
					standardizedTranInfo.setExpense(cmbTran.getTransactionAmount().replace("-", ""));
				} else {
					standardizedTranInfo.setRevenue(cmbTran.getTransactionAmount());
				}
			}
			standardizedTranInfo.setAccountBalance(cmbTran.getBalance());
			standardizedTranInfo.setSummary(cmbTran.getTransactionType());
			parseCounterParty(standardizedTranInfo, cmbTran.getCounterParty());

			return standardizedTranInfo;
		}).collect(Collectors.toList());

		standardizedTran.setStandardizedTrans(standardizedTranInfoList);
		return JsonUtil.object2Json(standardizedTran);
	}

	private void parseCounterParty(StandardizedTranInfo standardizedTranInfo, String counterParty) {
		try {
			if (counterParty != null && !"".equals(counterParty)) {
				// 应付利息-应付个人活期存款利息(自动计提)（新)973157320611009110
				Pattern pattern = Pattern.compile("(\\d+)$");
				Matcher matcher = pattern.matcher(counterParty.trim());
				if (matcher.find()) {
					standardizedTranInfo.setCounterPartyAccountNumber(matcher.group());
					standardizedTranInfo.setCounterPartyAccountName(counterParty.substring(0, matcher.start()));
				} else {
					standardizedTranInfo.setCounterPartyAccountName(counterParty);
				}
			}
		} catch (Exception e) {
			System.out.println("parseCounterParty failed, error:" + e);
		}
	}

	public static void main(String[] args) {
		CMBMappingParser cmbMappingParser = new CMBMappingParser();
		String cmbJson = "{\"交易流水对应的期间\":\"2020-09-20 -- 2021-09-20\",\"户名\":\"张**\",\"账号\":\"6214837217492903\",\"账户类型\":\"ALL/全币种\",\"开户行\":\"长沙大河西先导区支行\",\"申请时间\":\"2021-09-22 08:08:06\",\"验证码\":\"R9AEAK7T\",\"交易明细\":[{\"记账日期\":\"2020-09-21\",\"货币\":\"人民币\",\"交易金额\":\"0.00\",\"联机余额\":\"1.77\",\"交易摘要\":\"账户结息\",\"对手信息\":\"应付利息-应付个人活期存款利息(自动计提)（新)973157320611009110\"},{\"记账日期\":\"2020-12-21\",\"货币\":\"人民币\",\"交易金额\":\"0.00\",\"联机余额\":\"1.77\",\"交易摘要\":\"账户结息\",\"对手信息\":\"应付利息-应付个人活期存款利息(自动计提)（新)973157320611009110\"},{\"记账日期\":\"2021-03-21\",\"货币\":\"人民币\",\"交易金额\":\"0.00\",\"联机余额\":\"1.77\",\"交易摘要\":\"账户结息\",\"对手信息\":\"应付利息-应付个人活期存款利息(自动计提)（新)973157320611009110\"},{\"记账日期\":\"2021-06-21\",\"货币\":\"人民币\",\"交易金额\":\"0.00\",\"联机余额\":\"1.77\",\"交易摘要\":\"账户结息\",\"对手信息\":\"应付利息-应付个人活期存款利息(自动计提)（新)973157320611009110\"},{\"记账日期\":\"2021-09-05\",\"货币\":\"人民币\",\"交易金额\":\"1677.00\",\"联机余额\":\"1678.77\",\"交易摘要\":\"网联收款\",\"对手信息\":\"支付宝（中国）网络技术有限公司215500690\"},{\"记账日期\":\"2021-09-05\",\"货币\":\"人民币\",\"交易金额\":\"-1676.22\",\"联机余额\":\"2.55\",\"交易摘要\":\"信用卡还款\",\"对手信息\":\"张**6225768832379737\"},{\"记账日期\":\"2021-09-14\",\"货币\":\"人民币\",\"交易金额\":\"50.00\",\"联机余额\":\"52.55\",\"交易摘要\":\"网联收款\",\"对手信息\":\"支付宝（中国）网络技术有限公司215500690\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-1.00\",\"联机余额\":\"51.55\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.55\",\"联机余额\":\"51.00\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.40\",\"联机余额\":\"50.60\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.60\",\"联机余额\":\"50.00\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-1.20\",\"联机余额\":\"48.80\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-1.60\",\"联机余额\":\"47.20\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.80\",\"联机余额\":\"46.40\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-1.80\",\"联机余额\":\"44.60\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-1.90\",\"联机余额\":\"42.70\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.90\",\"联机余额\":\"41.80\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.09\",\"联机余额\":\"41.71\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.90\",\"联机余额\":\"40.81\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.60\",\"联机余额\":\"40.21\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.70\",\"联机余额\":\"39.51\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.11\",\"联机余额\":\"39.40\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6222621310042733523\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.06\",\"联机余额\":\"39.34\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6212254000001730025\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.06\",\"联机余额\":\"39.28\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6212254000001730025\"},{\"记账日期\":\"2021-09-16\",\"货币\":\"人民币\",\"交易金额\":\"-0.08\",\"联机余额\":\"39.20\",\"交易摘要\":\"RI网银贷记发起付款\",\"对手信息\":\"张**6212254000001730025\"}]}";
		String cmbTrans = cmbMappingParser.parseCMBTrans(cmbJson);
		System.out.println(cmbTrans);
	}
}
