package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * 交行 (无对手信息版本)
 * @author anyspa
 * @since 2022/08/24
 */
public class BCMNoCounterPartyInfo {
	/**
	 * 账号/卡号
	 */
	@JsonProperty("账号/卡号")
	private String accountNo;

	/**
	 * 户名
	 */
	@JsonProperty("户名")
	private String accountName;

	/**
	 * 查询起日
	 */
	@JsonProperty("查询起日")
	private String queryStartingDate;

	/**
	 * 查询止日
	 */
	@JsonProperty("查询止日")
	private String queryEndingDate;

	/**
	 * 打印时间
	 */
	@JsonProperty("打印时间")
	private String printingTime;

	/**
	 * 柜员号
	 */
	@JsonProperty("柜员号")
	private String searchTeller;

	/**
	 * 币种
	 */
	@JsonProperty("币种")
	private String currency;


	/**
	 * 交易明细
	 */
	@JsonProperty("交易明细")
	private List<BCMNoCounterPartyInfoTran> bcmTrans;

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getQueryStartingDate() {
		return queryStartingDate;
	}

	public void setQueryStartingDate(String queryStartingDate) {
		this.queryStartingDate = queryStartingDate;
	}

	public String getQueryEndingDate() {
		return queryEndingDate;
	}

	public void setQueryEndingDate(String queryEndingDate) {
		this.queryEndingDate = queryEndingDate;
	}

	public String getPrintingTime() {
		return printingTime;
	}

	public void setPrintingTime(String printingTime) {
		this.printingTime = printingTime;
	}

	public String getSearchTeller() {
		return searchTeller;
	}

	public void setSearchTeller(String searchTeller) {
		this.searchTeller = searchTeller;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<BCMNoCounterPartyInfoTran> getBcmTrans() {
		return bcmTrans;
	}

	public void setBcmTrans(List<BCMNoCounterPartyInfoTran> bcmTrans) {
		this.bcmTrans = bcmTrans;
	}
}
