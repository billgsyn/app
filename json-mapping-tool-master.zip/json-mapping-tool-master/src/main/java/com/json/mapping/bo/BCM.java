package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * 交行 (有对手信息版本)
 * @author anyspa
 * @since 2022/08/24
 */
public class BCM {
	/**
	 * 部门
	 */
	@JsonProperty("部门")
	private String department;

	/**
	 * 柜员
	 */
	@JsonProperty("柜员")
	private String teller;

	/**
	 * 打印日期
	 */
	@JsonProperty("打印日期")
	private String printingDate;

	/**
	 * 打印时间
	 */
	@JsonProperty("打印时间")
	private String printingTime;

	/**
	 * 账号/卡号
	 */
	@JsonProperty("账号/卡号")
	private String accountNo;

	/**
	 * 户名
	 */
	@JsonProperty("户名")
	private String accountName;

	/**
	 * 查询起日
	 */
	@JsonProperty("查询起日")
	private String queryStartingDate;

	/**
	 * 查询止日
	 */
	@JsonProperty("查询止日")
	private String queryEndingDate;

	/**
	 * 查询时间
	 */
	@JsonProperty("查询时间")
	private String queryTime;

	/**
	 * 查询柜员
	 */
	@JsonProperty("查询柜员")
	private String searchTeller;

	/**
	 * 币种
	 */
	@JsonProperty("币种")
	private String currency;

	/**
	 * 交易明细
	 */
	@JsonProperty("交易明细")
	private List<BCMTran> bcmTrans;

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getTeller() {
		return teller;
	}

	public void setTeller(String teller) {
		this.teller = teller;
	}

	public String getPrintingDate() {
		return printingDate;
	}

	public void setPrintingDate(String printingDate) {
		this.printingDate = printingDate;
	}

	public String getPrintingTime() {
		return printingTime;
	}

	public void setPrintingTime(String printingTime) {
		this.printingTime = printingTime;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getQueryStartingDate() {
		return queryStartingDate;
	}

	public void setQueryStartingDate(String queryStartingDate) {
		this.queryStartingDate = queryStartingDate;
	}

	public String getQueryEndingDate() {
		return queryEndingDate;
	}

	public void setQueryEndingDate(String queryEndingDate) {
		this.queryEndingDate = queryEndingDate;
	}

	public String getQueryTime() {
		return queryTime;
	}

	public void setQueryTime(String queryTime) {
		this.queryTime = queryTime;
	}

	public String getSearchTeller() {
		return searchTeller;
	}

	public void setSearchTeller(String searchTeller) {
		this.searchTeller = searchTeller;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<BCMTran> getBcmTrans() {
		return bcmTrans;
	}

	public void setBcmTrans(List<BCMTran> bcmTrans) {
		this.bcmTrans = bcmTrans;
	}
}
