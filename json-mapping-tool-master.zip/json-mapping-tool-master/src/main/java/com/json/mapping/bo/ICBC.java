package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * 工商
 * @author anyspa
 * @since 2022/06/02
 */
public class ICBC {
	/**
	 * 卡号
	 */
	@JsonProperty("卡号")
	private String cardNo;

	/**
	 * 户名
	 */
	@JsonProperty("户名")
	private String name;

	/**
	 * 起止日期
	 */
	@JsonProperty("起止日期")
	private String transDetailPeriod;

	/**
	 * 交易明细
	 */
	@JsonProperty("交易明细")
	private List<ICBCTran> icbcTrans;

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTransDetailPeriod() {
		return transDetailPeriod;
	}

	public void setTransDetailPeriod(String transDetailPeriod) {
		this.transDetailPeriod = transDetailPeriod;
	}

	public List<ICBCTran> getIcbcTrans() {
		return icbcTrans;
	}

	public void setIcbcTrans(List<ICBCTran> icbcTrans) {
		this.icbcTrans = icbcTrans;
	}
}
