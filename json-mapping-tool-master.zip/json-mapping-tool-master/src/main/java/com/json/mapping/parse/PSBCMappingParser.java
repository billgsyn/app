package com.json.mapping.parse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.json.mapping.bo.PSBC;
import com.json.mapping.bo.StandardizedTran;
import com.json.mapping.bo.StandardizedTranInfo;
import com.json.mapping.util.JsonUtil;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 邮储银行Excel流水解析
 * @author anyspa
 * @since 2022/08/23
 */
public class PSBCMappingParser {
	public String parsePSBCTrans(String json) {
		String standardizedJson = "";
		try {
			PSBC psbc = JsonUtil.json2Object(json, PSBC.class);
			standardizedJson = convertPSBC2StandardizedJson(psbc);
		} catch (JsonProcessingException e) {
			System.out.println("parsePSBCTrans failed, error:" + e);
		}
		return standardizedJson;
	}

	private String convertPSBC2StandardizedJson(PSBC psbc) throws JsonProcessingException {
		StandardizedTran standardizedTran = new StandardizedTran();
		standardizedTran.setAccountNumber(psbc.getAccountNumber());
		standardizedTran.setStartDate(psbc.getStartDate());
		standardizedTran.setExpirationDate(psbc.getExpirationDate());

		List<StandardizedTranInfo> standardizedTrans = psbc.getPsbcTrans().stream().map(psbcTran -> {
			StandardizedTranInfo standardizedTranInfo = new StandardizedTranInfo();
			standardizedTranInfo.setTransactionDate(psbcTran.getTransactionDate());
			// 明细类型为收入时，counterPartyAccountName：付款户名
			if (Objects.equals("收入", psbcTran.getIncomeExpense())) {
				standardizedTranInfo.setRevenue(psbcTran.getTransactionAmount());
				standardizedTranInfo.setCounterPartyAccountName(psbcTran.getPaymentAccountName());
			}
			// 明细类型为支出时，counterPartyAccountName：收款户名
			else if (Objects.equals("支出", psbcTran.getIncomeExpense())) {
				standardizedTranInfo.setExpense(psbcTran.getTransactionAmount());
				standardizedTranInfo.setCounterPartyAccountName(psbcTran.getPayeeAccountNumber());
			}
			standardizedTranInfo.setSummary(psbcTran.getSummary());
			standardizedTranInfo.setAccountBalance(psbcTran.getBalance());

			return standardizedTranInfo;
		}).collect(Collectors.toList());
		standardizedTran.setStandardizedTrans(standardizedTrans);

		return JsonUtil.object2Json(standardizedTran);
	}

	public static void main(String[] args) {
		PSBCMappingParser psbcMappingParser = new PSBCMappingParser();
		String psbcJson = "{\"账号/卡号\":\"6221805840005194982\",\"交易类型\":\"交易明细查询\",\"转入账号/卡号\":\"\",\"收入/支出\":\"全部\",\"起始日期\":\"2021-05-29\",\"截止日期\":\"2021-11-29\",\"总收入\":\"1.51\",\"总支出\":\"0.10\",\"交易明细\":[{\"交易日期\":\"2021-09-29 20:18\",\"付款户名\":\"张**\",\"收款户名\":\"张**\",\"收入/支出\":\"支出\",\"交易金额\":\"0.1\",\"余额\":\"1.41\",\"摘要\":\"汇款\",\"备注\":\"无附言\"},{\"交易日期\":\"2021-07-01 11:16\",\"付款户名\":\"\",\"收款户名\":\"\",\"收入/支出\":\"收入\",\"交易金额\":\"1.51\",\"余额\":\"1.51\",\"摘要\":\"转账汇入\",\"备注\":\"无附言\"},{\"交易日期\":\"2021-07-01 11:08\",\"付款户名\":\"\",\"收款户名\":\"\",\"收入/支出\":\"收入\",\"交易金额\":\"0.0\",\"余额\":\"0.0\",\"摘要\":\"开卡\",\"备注\":\"高新园支行\"}]}";
		String psbcTrans = psbcMappingParser.parsePSBCTrans(psbcJson);
		System.out.println(psbcTrans);
	}
}
