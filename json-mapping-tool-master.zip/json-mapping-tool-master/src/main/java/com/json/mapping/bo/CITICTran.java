package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author anyspa
 * @since 2022/08/23
 */
public class CITICTran {
	/**
	 * 交易日期
	 */
	@JsonProperty("交易日期")
	private String transactionDate;

	/**
	 * 账户序号
	 */
	@JsonProperty("账户序号")
	private String accountSeqNo;

	/**
	 * 收入金额
	 */
	@JsonProperty("收入金额")
	private String accountReceivable;

	/**
	 * 支出金额
	 */
	@JsonProperty("支出金额")
	private String accountPaid;

	/**
	 * 账户余额
	 */
	@JsonProperty("账户余额")
	private String accountBalance;

	/**
	 * 交易摘要
	 */
	@JsonProperty("交易摘要")
	private String description;

	/**
	 * 对方户名
	 */
	@JsonProperty("对方户名")
	private String recipient;

	/**
	 * 被冲账标识
	 */
	@JsonProperty("被冲账标识")
	private String reversalFlag;

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getAccountSeqNo() {
		return accountSeqNo;
	}

	public void setAccountSeqNo(String accountSeqNo) {
		this.accountSeqNo = accountSeqNo;
	}

	public String getAccountReceivable() {
		return accountReceivable;
	}

	public void setAccountReceivable(String accountReceivable) {
		this.accountReceivable = accountReceivable;
	}

	public String getAccountPaid() {
		return accountPaid;
	}

	public void setAccountPaid(String accountPaid) {
		this.accountPaid = accountPaid;
	}

	public String getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(String accountBalance) {
		this.accountBalance = accountBalance;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRecipient() {
		return recipient;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}

	public String getReversalFlag() {
		return reversalFlag;
	}

	public void setReversalFlag(String reversalFlag) {
		this.reversalFlag = reversalFlag;
	}
}
