package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author anyspa
 * @since 2022/08/23
 */
public class PSBCTran {
	/**
	 * 交易日期
	 */
	@JsonProperty("交易日期")
	private String transactionDate;

	/**
	 * 付款户名
	 */
	@JsonProperty("付款户名")
	private String paymentAccountName;

	/**
	 * 收款户名
	 */
	@JsonProperty("收款户名")
	private String payeeAccountNumber;

	/**
	 * 收入/支出
	 */
	@JsonProperty("收入/支出")
	private String incomeExpense;

	/**
	 * 交易金额
	 */
	@JsonProperty("交易金额")
	private String transactionAmount;

	/**
	 * 余额
	 */
	@JsonProperty("余额")
	private String balance;


	/**
	 * 摘要
	 */
	@JsonProperty("摘要")
	private String summary;

	/**
	 * 备注
	 */
	@JsonProperty("备注")
	private String comment;

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getPaymentAccountName() {
		return paymentAccountName;
	}

	public void setPaymentAccountName(String paymentAccountName) {
		this.paymentAccountName = paymentAccountName;
	}

	public String getPayeeAccountNumber() {
		return payeeAccountNumber;
	}

	public void setPayeeAccountNumber(String payeeAccountNumber) {
		this.payeeAccountNumber = payeeAccountNumber;
	}

	public String getIncomeExpense() {
		return incomeExpense;
	}

	public void setIncomeExpense(String incomeExpense) {
		this.incomeExpense = incomeExpense;
	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
