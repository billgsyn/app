package com.json.mapping.parse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.json.mapping.bo.BCM;
import com.json.mapping.bo.StandardizedTran;
import com.json.mapping.bo.StandardizedTranInfo;
import com.json.mapping.util.JsonUtil;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 交行pdf流水解析 (有对手信息版本)
 * @author anyspa
 * @since 2022/08/24
 */
public class BCMMappingParser1 {
	public String parseBCMTrans(String json) {
		String standardizedJson = "";
		try {
			BCM bcm = JsonUtil.json2Object(json, BCM.class);
			standardizedJson = convertBCM2StandardizedJson(bcm);
		} catch (JsonProcessingException e) {
			System.out.println("parseBCMTrans failed, error:" + e);
		}
		return standardizedJson;
	}

	private String convertBCM2StandardizedJson(BCM bcm) throws JsonProcessingException {
		StandardizedTran standardizedTran = new StandardizedTran();
		standardizedTran.setAccountNumber(bcm.getAccountNo());
		standardizedTran.setAccountName(bcm.getAccountName());
		standardizedTran.setStartDate(bcm.getQueryStartingDate());
		standardizedTran.setExpirationDate(bcm.getQueryEndingDate());
		String currency = bcm.getCurrency();

		List<StandardizedTranInfo> standardizedTrans = bcm.getBcmTrans().stream().map(bcmTran -> {
			StandardizedTranInfo standardizedTranInfo = new StandardizedTranInfo();
			standardizedTranInfo.setTransactionDate(bcmTran.getTransDate());
			standardizedTranInfo.setTransactionTime(bcmTran.getTransTime());
			if (Objects.equals("贷 Cr", bcmTran.getDcFlg())) {
				standardizedTranInfo.setRevenue(bcmTran.getTransAmt());
			} else if (Objects.equals("借 Dr", bcmTran.getDcFlg())) {
				standardizedTranInfo.setExpense(bcmTran.getTransAmt());
			}
			standardizedTranInfo.setAccountBalance(bcmTran.getBalance());
			standardizedTranInfo.setSummary(bcmTran.getSummary());
			standardizedTranInfo.setCurrency(currency);
			standardizedTranInfo.setCounterPartyAccountName(bcmTran.getPaymentReceiptAccountName());
			standardizedTranInfo.setCounterPartyAccountNumber(bcmTran.getPaymentReceiptAccount());

			return standardizedTranInfo;
		}).collect(Collectors.toList());
		standardizedTran.setStandardizedTrans(standardizedTrans);

		return JsonUtil.object2Json(standardizedTran);
	}

	public static void main(String[] args) {
		BCMMappingParser1 bcmMappingParser = new BCMMappingParser1();
		String bcmJson = "{\"部门\":\"01443036999\",\"柜员\":\"EFC0002\",\"打印日期\":\"2022-06-21 14:06:12\",\"打印时间\":\"2022-06-21 14:06:12\",\"账号/卡号\":\"6222621310042733523\",\"户名\":\"张**\",\"查询起日\":\"2021-06-21\",\"查询止日\":\"2022-06-21\",\"查询时间\":\"2022年06月21日  14:06:47\",\"查询柜员\":\"EFC0002\",\"币种\":\"人民币 CNY\",\"交易明细\":[{\"序号\":\"1\",\"交易日期\":\"2021-07-01\",\"交易时间\":\"10:19:48\",\"交易类型\":\"其他交易\",\"借贷\":\"贷 Cr\",\"交易金额\":\"10.00\",\"余额\":\"10.00\",\"对方账户\":\"9915840000495800\",\"对方户名\":\"财付通支付科技有限公司\",\"交易地点\":\"财付通支付科技有限公司-\",\"会计流水号\":\"EFC0002803298512\",\"摘要\":\"银联入账(财付通支付科技有限公司/其它)微信零钱提现\"},{\"序号\":\"2\",\"交易日期\":\"2021-07-02\",\"交易时间\":\"04:08:57\",\"交易类型\":\"借记卡工本费\",\"借贷\":\"借 Dr\",\"交易金额\":\"5.00\",\"余额\":\"5.00\",\"对方账户\":\"\",\"对方户名\":\"\",\"交易地点\":\"批处理\",\"会计流水号\":\"315PD2B901533369\",\"摘要\":\"\"},{\"序号\":\"3\",\"交易日期\":\"2021-07-25\",\"交易时间\":\"12:09:34\",\"交易类型\":\"网上支付\",\"借贷\":\"借 Dr\",\"交易金额\":\"5.00\",\"余额\":\"0.00\",\"对方账户\":\"1494356552\",\"对方户名\":\"广东美宜佳\",\"交易地点\":\"财付通支付科技有限公司\",\"会计流水号\":\"EER0002806383982\",\"摘要\":\"242107253222014768516 广东美宜佳 交易流水号\"},{\"序号\":\"4\",\"交易日期\":\"2021-09-07\",\"交易时间\":\"19:56:30\",\"交易类型\":\"跨行汇款\",\"借贷\":\"贷 Cr\",\"交易金额\":\"0.66\",\"余额\":\"0.66\",\"对方账户\":\"6217710312185648\",\"对方户名\":\"张**\",\"交易地点\":\"网上银行\",\"会计流水号\":\"EFC0002823064732\",\"摘要\":\"手机银行转账\"},{\"序号\":\"5\",\"交易日期\":\"2021-09-07\",\"交易时间\":\"20:00:36\",\"交易类型\":\"跨行汇款\",\"借贷\":\"贷 Cr\",\"交易金额\":\"0.16\",\"余额\":\"0.82\",\"对方账户\":\"6217710312185648\",\"对方户名\":\"张**\",\"交易地点\":\"网上银行\",\"会计流水号\":\"EFC0003823292213\",\"摘要\":\"手机银行转账\"},{\"序号\":\"6\",\"交易日期\":\"2021-09-07\",\"交易时间\":\"20:02:14\",\"交易类型\":\"跨行汇款\",\"借贷\":\"贷 Cr\",\"交易金额\":\"0.13\",\"余额\":\"0.95\",\"对方账户\":\"6217710312185648\",\"对方户名\":\"张**\",\"交易地点\":\"网上银行\",\"会计流水号\":\"EFC0002823332077\",\"摘要\":\"手机银行转账\"},{\"序号\":\"7\",\"交易日期\":\"2021-09-16\",\"交易时间\":\"15:51:46\",\"交易类型\":\"汇兑\",\"借贷\":\"借 Dr\",\"交易金额\":\"0.10\",\"余额\":\"0.85\",\"对方账户\":\"6230584000002283985\",\"对方户名\":\"李**\",\"交易地点\":\"手机银行\",\"会计流水号\":\"EFC0002814469322\",\"摘要\":\"转账\"},{\"序号\":\"8\",\"交易日期\":\"2021-09-16\",\"交易时间\":\"15:52:13\",\"交易类型\":\"汇兑\",\"借贷\":\"借 Dr\",\"交易金额\":\"0.01\",\"余额\":\"0.84\",\"对方账户\":\"6230584000002283985\",\"对方户名\":\"李**\",\"交易地点\":\"手机银行\",\"会计流水号\":\"EFC0003814528304\",\"摘要\":\"转账\"},{\"序号\":\"9\",\"交易日期\":\"2021-09-16\",\"交易时间\":\"15:52:37\",\"交易类型\":\"汇兑\",\"借贷\":\"借 Dr\",\"交易金额\":\"0.02\",\"余额\":\"0.82\",\"对方账户\":\"6230584000002283985\",\"对方户名\":\"李**\",\"交易地点\":\"手机银行\",\"会计流水号\":\"EFC0003814643454\",\"摘要\":\"转账\"},{\"序号\":\"10\",\"交易日期\":\"2021-09-16\",\"交易时间\":\"15:53:02\",\"交易类型\":\"汇兑\",\"借贷\":\"借 Dr\",\"交易金额\":\"0.03\",\"余额\":\"0.79\",\"对方账户\":\"6230584000002283985\",\"对方户名\":\"李**\",\"交易地点\":\"手机银行\",\"会计流水号\":\"EFC0003814623668\",\"摘要\":\"转账\"}]}";
		String bcmTrans = bcmMappingParser.parseBCMTrans(bcmJson);
		System.out.println(bcmTrans);
	}
}
