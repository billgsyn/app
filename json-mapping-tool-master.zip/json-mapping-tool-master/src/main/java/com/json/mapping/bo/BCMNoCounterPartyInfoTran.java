package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author anyspa
 * @since 2022/08/24
 */
public class BCMNoCounterPartyInfoTran {
	/**
	 * 交易日期
	 */
	@JsonProperty("交易日期")
	private String transDate;

	/**
	 * 交易地点
	 */
	@JsonProperty("交易地点")
	private String tradingPlace;

	/**
	 * 交易方式
	 */
	@JsonProperty("交易方式")
	private String transType;

	/**
	 * 借贷状态
	 */
	@JsonProperty("借贷状态")
	private String dcFlg;

	/**
	 * 交易金额
	 */
	@JsonProperty("交易金额")
	private String transAmt;

	/**
	 * 余额
	 */
	@JsonProperty("余额")
	private String balance;

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public String getTradingPlace() {
		return tradingPlace;
	}

	public void setTradingPlace(String tradingPlace) {
		this.tradingPlace = tradingPlace;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getDcFlg() {
		return dcFlg;
	}

	public void setDcFlg(String dcFlg) {
		this.dcFlg = dcFlg;
	}

	public String getTransAmt() {
		return transAmt;
	}

	public void setTransAmt(String transAmt) {
		this.transAmt = transAmt;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}
}
