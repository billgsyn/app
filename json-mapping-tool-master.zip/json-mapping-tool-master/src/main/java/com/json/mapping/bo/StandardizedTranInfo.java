package com.json.mapping.bo;

/**
 * @author anyspa
 * @since 2022/04/06
 */

public class StandardizedTranInfo {

	/**
	 * 摘要
	 */
	private String summary = "";

	/**
	 * 币别
	 */
	private String currency = "";

	/**
	 * 钞汇
	 */
	private String cashExchange = "";

	/**
	 * 交易日期
	 */
	private String transactionDate;

	/**
	 * 交易时间
	 */
	private String transactionTime = "";

	/**
	 * 收入金额
	 */
	private String revenue = "";

	/**
	 * 支出金额
	 */
	private String expense = "";

	/**
	 * 账户余额
	 */
	private String accountBalance = "";

	/**
	 * 对方户名
	 */
	private String counterPartyAccountName = "";

	/**
	 * 对方账号
	 */
	private String counterPartyAccountNumber = "";

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCashExchange() {
		return cashExchange;
	}

	public void setCashExchange(String cashExchange) {
		this.cashExchange = cashExchange;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	public String getRevenue() {
		return revenue;
	}

	public void setRevenue(String revenue) {
		this.revenue = revenue;
	}

	public String getExpense() {
		return expense;
	}

	public void setExpense(String expense) {
		this.expense = expense;
	}

	public String getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(String accountBalance) {
		this.accountBalance = accountBalance;
	}

	public String getCounterPartyAccountName() {
		return counterPartyAccountName;
	}

	public void setCounterPartyAccountName(String counterPartyAccountName) {
		this.counterPartyAccountName = counterPartyAccountName;
	}

	public String getCounterPartyAccountNumber() {
		return counterPartyAccountNumber;
	}

	public void setCounterPartyAccountNumber(String counterPartyAccountNumber) {
		this.counterPartyAccountNumber = counterPartyAccountNumber;
	}
}
