package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * 农行
 * @author anyspa
 * @since 2022/08/22
 */
public class ABC {
	/**
	 * 户名
	 */
	@JsonProperty("户名")
	private String name;

	/**
	 * 账户
	 */
	@JsonProperty("账户")
	private String account;

	/**
	 * 币种
	 */
	@JsonProperty("币种")
	private String currency;

	/**
	 * 钞汇标识
	 */
	@JsonProperty("钞汇标识")
	private String cashExchangeIndicator;

	/**
	 * 起止日期
	 */
	@JsonProperty("起止日期")
	private String transDetailPeriod;

	/**
	 * 电子流水号
	 */
	@JsonProperty("电子流水号")
	private String serialNo;

	/**
	 * 交易明细
	 */
	@JsonProperty("交易明细")
	private List<ABCTran> abcTrans;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCashExchangeIndicator() {
		return cashExchangeIndicator;
	}

	public void setCashExchangeIndicator(String cashExchangeIndicator) {
		this.cashExchangeIndicator = cashExchangeIndicator;
	}

	public String getTransDetailPeriod() {
		return transDetailPeriod;
	}

	public void setTransDetailPeriod(String transDetailPeriod) {
		this.transDetailPeriod = transDetailPeriod;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public List<ABCTran> getAbcTrans() {
		return abcTrans;
	}

	public void setAbcTrans(List<ABCTran> abcTrans) {
		this.abcTrans = abcTrans;
	}
}
