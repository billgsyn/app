package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author anyspa
 * @since 2022/08/23
 */
public class CMBTran {
	/**
	 * 记账日期
	 */
	@JsonProperty("记账日期")
	private String date;

	/**
	 * 货币
	 */
	@JsonProperty("货币")
	private String currency;

	/**
	 * 交易金额
	 */
	@JsonProperty("交易金额")
	private String transactionAmount;

	/**
	 * 联机余额
	 */
	@JsonProperty("联机余额")
	private String balance;

	/**
	 * 交易摘要
	 */
	@JsonProperty("交易摘要")
	private String transactionType;

	/**
	 * 对手信息
	 */
	@JsonProperty("对手信息")
	private String counterParty;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getCounterParty() {
		return counterParty;
	}

	public void setCounterParty(String counterParty) {
		this.counterParty = counterParty;
	}
}
