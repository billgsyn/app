package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * 中行
 * @author anyspa
 * @since 2022/08/23
 */
public class BOC {
    /**
     * 交易区间
     */
    @JsonProperty("交易区间")
    private String tradeRange;

    /**
     * 客户姓名
     */
    @JsonProperty("客户姓名")
    private String customerName;

    /**
     * 打印时间
     */
    @JsonProperty("打印时间")
    private String printTime;

    /**
     * 借记卡号
     */
    @JsonProperty("借记卡号")
    private String debitCardNo;

    /**
     * 账号
     */
    @JsonProperty("账号")
    private String accountNumber;

    /**
     * 按收支筛选
     */
    @JsonProperty("按收支筛选")
    private String filterByRevenueAndExpense;

    /**
     * 按币种筛选
     */
    @JsonProperty("按币种筛选")
    private String filterByCurrency;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<BOCTran> bocTrans;

    public String getTradeRange() {
        return tradeRange;
    }

    public void setTradeRange(String tradeRange) {
        this.tradeRange = tradeRange;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPrintTime() {
        return printTime;
    }

    public void setPrintTime(String printTime) {
        this.printTime = printTime;
    }

    public String getDebitCardNo() {
        return debitCardNo;
    }

    public void setDebitCardNo(String debitCardNo) {
        this.debitCardNo = debitCardNo;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getFilterByRevenueAndExpense() {
        return filterByRevenueAndExpense;
    }

    public void setFilterByRevenueAndExpense(String filterByRevenueAndExpense) {
        this.filterByRevenueAndExpense = filterByRevenueAndExpense;
    }

    public String getFilterByCurrency() {
        return filterByCurrency;
    }

    public void setFilterByCurrency(String filterByCurrency) {
        this.filterByCurrency = filterByCurrency;
    }

    public List<BOCTran> getBocTrans() {
        return bocTrans;
    }

    public void setBocTrans(List<BOCTran> bocTrans) {
        this.bocTrans = bocTrans;
    }
}