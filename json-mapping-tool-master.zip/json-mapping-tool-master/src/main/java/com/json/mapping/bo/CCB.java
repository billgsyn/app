package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * 建行
 * @author anyspa
 * @since 2022/04/06
 */

public class CCB {
	/**
	 * 卡号/账号
	 */
	@JsonProperty("卡号/账号")
	private String accountNo;

	/**
	 * 客户名称
	 */
	@JsonProperty("客户名称")
	private String name;

	/**
	 * 起始日期
	 */
	@JsonProperty("起始日期")
	private String startDate;

	/**
	 * 结束日期
	 */
	@JsonProperty("结束日期")
	private String endDate;

	/**
	 * 交易明细
	 */
	@JsonProperty("交易明细")
	private List<CCBTran> ccbTrans;

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public List<CCBTran> getCcbTrans() {
		return ccbTrans;
	}

	public void setCcbTrans(List<CCBTran> ccbTrans) {
		this.ccbTrans = ccbTrans;
	}
}
