package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * 中信
 * @author anyspa
 * @since 2022/08/23
 */
public class CITIC {
	/**
	 * 户名
	 */
	@JsonProperty("户名")
	private String accountName;

	/**
	 * 证件类型
	 */
	@JsonProperty("证件类型")
	private String idType;

	/**
	 * 证件号码
	 */
	@JsonProperty("证件号码")
	private String idNumber;

	/**
	 * 账号
	 */
	@JsonProperty("账号")
	private String accountNo;

	/**
	 * 时间段
	 */
	@JsonProperty("时间段")
	private String inquiryPeriod;

	/**
	 * 开立日期
	 */
	@JsonProperty("开立日期")
	private String issuanceDate;

	/**
	 * 查询最低限额
	 */
	@JsonProperty("查询最低限额")
	private String inquireTheMinimumLimit;

	/**
	 * 币种
	 */
	@JsonProperty("币种")
	private String currency;

	/**
	 * 交易明细
	 */
	@JsonProperty("交易明细")
	private List<CITICTran> citicTrans;

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getInquiryPeriod() {
		return inquiryPeriod;
	}

	public void setInquiryPeriod(String inquiryPeriod) {
		this.inquiryPeriod = inquiryPeriod;
	}

	public String getIssuanceDate() {
		return issuanceDate;
	}

	public void setIssuanceDate(String issuanceDate) {
		this.issuanceDate = issuanceDate;
	}

	public String getInquireTheMinimumLimit() {
		return inquireTheMinimumLimit;
	}

	public void setInquireTheMinimumLimit(String inquireTheMinimumLimit) {
		this.inquireTheMinimumLimit = inquireTheMinimumLimit;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<CITICTran> getCiticTrans() {
		return citicTrans;
	}

	public void setCiticTrans(List<CITICTran> citicTrans) {
		this.citicTrans = citicTrans;
	}
}
