package com.json.mapping.parse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.json.mapping.bo.ABC;
import com.json.mapping.bo.StandardizedTran;
import com.json.mapping.bo.StandardizedTranInfo;
import com.json.mapping.util.DateUtil;
import com.json.mapping.util.JsonUtil;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 农行pdf交易流水解析
 * @author anyspa
 * @since 2022/08/22
 */
public class ABCMappingParser {
	public String parseABCTrans(String json) {
		String standardizedJson = "";
		try {
			ABC abc = JsonUtil.json2Object(json, ABC.class);
			standardizedJson = convertABC2StandardizedJson(abc);
		} catch (JsonProcessingException e) {
			System.out.println("parseABCTrans failed, error:" + e);
		}
		return standardizedJson;
	}

	private String convertABC2StandardizedJson(ABC abc) throws JsonProcessingException {
		StandardizedTran standardizedTran = new StandardizedTran();
		standardizedTran.setAccountName(abc.getName());
		standardizedTran.setAccountNumber(abc.getAccount());
		String transDetailPeriod = abc.getTransDetailPeriod();
		if (transDetailPeriod != null && transDetailPeriod.contains("-")) {
			String[] date = transDetailPeriod.split("-");
			standardizedTran.setStartDate(DateUtil.convertDate(date[0]));
			standardizedTran.setExpirationDate(DateUtil.convertDate(date[1]));
		}
		String currency = abc.getCurrency();
		String cashExchangeIndicator = abc.getCashExchangeIndicator();

		List<StandardizedTranInfo> standardizedTrans = abc.getAbcTrans().stream().map(abcTran -> {
			StandardizedTranInfo standardizedTranInfo = new StandardizedTranInfo();
			if (abcTran.getTranDate() != null && !abcTran.getTranDate().equals("")) {
				standardizedTranInfo.setTransactionDate(DateUtil.convertDate(abcTran.getTranDate()));
			}
			standardizedTranInfo.setTransactionTime(abcTran.getTranTime());
			standardizedTranInfo.setSummary(abcTran.getTranSummary());
			if (abcTran.getTranAmt() != null) {
				if (abcTran.getTranAmt().startsWith("-")) {
					standardizedTranInfo.setExpense(abcTran.getTranAmt().replace("-", ""));
				} else if (abcTran.getTranAmt().startsWith("+")){
					standardizedTranInfo.setRevenue(abcTran.getTranAmt().replace("+", ""));
				}
			}
			standardizedTranInfo.setAccountBalance(abcTran.getBalance());
			standardizedTranInfo.setCurrency(currency);
			standardizedTranInfo.setCashExchange(cashExchangeIndicator);
			standardizedTranInfo.setCounterPartyAccountName(abcTran.getCounterPartyInfo());

			return standardizedTranInfo;
		}).collect(Collectors.toList());
		standardizedTran.setStandardizedTrans(standardizedTrans);

		return JsonUtil.object2Json(standardizedTran);
	}

	public static void main(String[] args) {
		ABCMappingParser abcMappingParser = new ABCMappingParser();
		String abcJson = "{\"户名\":\"张**\",\"账户\":\"6228480128813807772\",\"币种\":\"⼈⺠币\",\"钞汇标识\":\"本币\",\"起止日期\":\"20210319-20210917\",\"电子流水号\":\"2109171027416342638\",\"交易明细\":[{\"交易日期\":\"20210427\",\"交易时间\":\"154158\",\"交易摘要\":\"转开\",\"交易金额\":\"+0.00\",\"本次余额\":\"0.00\",\"对手信息\":\"张**\",\"交易渠道\":\"\",\"交易附言\":\"零余额开⼾\"},{\"交易日期\":\"20210427\",\"交易时间\":\"162949\",\"交易摘要\":\"代付\",\"交易金额\":\"+10.00\",\"本次余额\":\"10.00\",\"对手信息\":\"⽀付宝（中国）⽹络技术有限公司\",\"交易渠道\":\"电⼦商务\",\"交易附言\":\"NG2021042740533382830236200311306余额宝提现;余额宝 提现\"},{\"交易日期\":\"20210428\",\"交易时间\":\"110200\",\"交易摘要\":\"⼯本费\",\"交易金额\":\"-5.00\",\"本次余额\":\"5.00\",\"对手信息\":\"借记卡开卡⼯本费\",\"交易渠道\":\"\",\"交易附言\":\"借记卡新开卡⼯本费-个⼈\"},{\"交易日期\":\"20210428\",\"交易时间\":\"131524\",\"交易摘要\":\"转存\",\"交易金额\":\"+0.99\",\"本次余额\":\"5.99\",\"对手信息\":\"张**\",\"交易渠道\":\"超级⽹银\",\"交易附言\":\"跨⾏转出\"},{\"交易日期\":\"20210621\",\"交易时间\":\"\",\"交易摘要\":\"结息\",\"交易金额\":\"+0.00\",\"本次余额\":\"5.99\",\"对手信息\":\"--\",\"交易渠道\":\"\",\"交易附言\":\"个⼈活期结息\"},{\"交易日期\":\"20210621\",\"交易时间\":\"\",\"交易摘要\":\"利息税\",\"交易金额\":\"+0.00\",\"本次余额\":\"5.99\",\"对手信息\":\"--\",\"交易渠道\":\"\",\"交易附言\":\"\"},{\"交易日期\":\"20210808\",\"交易时间\":\"102728\",\"交易摘要\":\"代付\",\"交易金额\":\"+0.10\",\"本次余额\":\"6.09\",\"对手信息\":\"⽀付宝（中国）⽹络技术有限公司\",\"交易渠道\":\"电⼦商务\",\"交易附言\":\"NG2021080846562711570236420313304余额宝提现;余额宝 提现\"},{\"交易日期\":\"20210917\",\"交易时间\":\"102434\",\"交易摘要\":\"转⽀\",\"交易金额\":\"-0.03\",\"本次余额\":\"12.7\",\"对手信息\":\"张**\",\"交易渠道\":\"超级⽹银\",\"交易附言\":\"\"},{\"交易日期\":\"20210917\",\"交易时间\":\"102446\",\"交易摘要\":\"转⽀\",\"交易金额\":\"-0.7\",\"本次余额\":\"12\",\"对手信息\":\"张**\",\"交易渠道\":\"超级⽹银\",\"交易附言\":\"\"},{\"交易日期\":\"20210917\",\"交易时间\":\"102459\",\"交易摘要\":\"转⽀\",\"交易金额\":\"-0.06\",\"本次余额\":\"11.94\",\"对手信息\":\"张**\",\"交易渠道\":\"超级⽹银\",\"交易附言\":\"\"},{\"交易日期\":\"20210917\",\"交易时间\":\"102516\",\"交易摘要\":\"转⽀\",\"交易金额\":\"-0.04\",\"本次余额\":\"11.9\",\"对手信息\":\"张**\",\"交易渠道\":\"超级⽹银\",\"交易附言\":\"\"}]}";
		String abcTrans = abcMappingParser.parseABCTrans(abcJson);
		System.out.println(abcTrans);
	}
}
