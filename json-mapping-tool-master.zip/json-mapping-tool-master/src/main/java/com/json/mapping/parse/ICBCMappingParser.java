package com.json.mapping.parse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.json.mapping.bo.ICBC;
import com.json.mapping.bo.StandardizedTran;
import com.json.mapping.bo.StandardizedTranInfo;
import com.json.mapping.util.JsonUtil;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 工行pdf交易流水解析
 * @author anyspa
 * @since 2022/06/06
 */

public class ICBCMappingParser {

    public String parseICBCTrans(String json) {
        String standardizedJson = "";
        try {
            ICBC icbc = JsonUtil.json2Object(json, ICBC.class);
            standardizedJson = convertICBC2StandardizedJson(icbc);
        } catch (Exception e) {
            System.out.println("parseICBCTrans failed, error:" + e);
        }
        return standardizedJson;
    }

    private String convertICBC2StandardizedJson(ICBC icbc) throws JsonProcessingException {
        StandardizedTran standardizedTran = new StandardizedTran();
        standardizedTran.setAccountNumber(icbc.getCardNo());
        standardizedTran.setAccountName(icbc.getName());
        String transDetailPeriod = icbc.getTransDetailPeriod();
        if (transDetailPeriod != null && transDetailPeriod.contains("—")) {
            standardizedTran.setStartDate(transDetailPeriod.split("—")[0].trim());
            standardizedTran.setExpirationDate(transDetailPeriod.split("—")[1].trim());
        }

        List<StandardizedTranInfo> standardizedTranInfoList = icbc.getIcbcTrans().stream().map(icbcTran -> {
            StandardizedTranInfo standardizedTranInfo = new StandardizedTranInfo();
            String tranDate = icbcTran.getTranDate();
            if (tranDate != null && !tranDate.equals("")) {
                standardizedTranInfo.setTransactionDate(tranDate.substring(0, 10));
                standardizedTranInfo.setTransactionTime(tranDate.substring(10));
            }
            standardizedTranInfo.setCurrency(icbcTran.getCurrency());
            standardizedTranInfo.setCashExchange(icbcTran.getCashExchange());
            standardizedTranInfo.setSummary(icbcTran.getComment());
            if (icbcTran.getIncomeExpenseAmt() != null) {
                if (icbcTran.getIncomeExpenseAmt().startsWith("-")) {
                    standardizedTranInfo.setExpense(icbcTran.getIncomeExpenseAmt().replace("-", ""));
                } else if (icbcTran.getIncomeExpenseAmt().startsWith("+")){
                    standardizedTranInfo.setRevenue(icbcTran.getIncomeExpenseAmt().replace("+", ""));
                }
            }
            standardizedTranInfo.setAccountBalance(icbcTran.getBalance());

            standardizedTranInfo.setCounterPartyAccountName(icbcTran.getCounterpartyName());
            standardizedTranInfo.setCounterPartyAccountNumber(icbcTran.getConterpartyAccountNo());
            return standardizedTranInfo;
        }).collect(Collectors.toList());

        standardizedTran.setStandardizedTrans(standardizedTranInfoList);
        return JsonUtil.object2Json(standardizedTran);
    }

    public static void main(String[] args) {
        ICBCMappingParser icbcMappingParser = new ICBCMappingParser();
        String icbcJson = "{\"卡号\":\"6212883202002754926\",\"户名\":\"朱**\",\"起止日期\":\"2022-05-25 — 2022-06-02\",\"交易明细\":[{\"交易日期\":\"2022-05-2810:40:28\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"银联入账\",\"地区\":\"3202\",\"收入支出金额\":\"+3,678.54\",\"余额\":\"12,034.73\",\"对方户名\":\"银盛支付服务股份有限公司备付金\",\"对方账号\":\"991584000207\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-05-2810:42:12\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"银联入账\",\"地区\":\"3202\",\"收入支出金额\":\"+946.39\",\"余额\":\"12,981.12\",\"对方户名\":\"嘉联支付有限公司备付金\",\"对方账号\":\"991584001126\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-05-2810:45:49\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"银联入账\",\"地区\":\"3202\",\"收入支出金额\":\"+3,559.23\",\"余额\":\"16,540.35\",\"对方户名\":\"银盛支付服务股份有限公司备付金\",\"对方账号\":\"991584000207\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-05-2810:47:05\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"银联入账\",\"地区\":\"3202\",\"收入支出金额\":\"+9,845.55\",\"余额\":\"26,385.90\",\"对方户名\":\"嘉联支付有限公司备付金\",\"对方账号\":\"991584001126\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-05-2810:48:47\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"银联入账\",\"地区\":\"3202\",\"收入支出金额\":\"+3,181.44\",\"余额\":\"29,567.34\",\"对方户名\":\"银盛支付服务股份有限公司备付金\",\"对方账号\":\"991584000207\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-05-2810:49:32\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"银联入账\",\"地区\":\"3202\",\"收入支出金额\":\"+16,110.90\",\"余额\":\"45,678.24\",\"对方户名\":\"嘉联支付有限公司备付金\",\"对方账号\":\"991584001126\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-05-2811:09:10\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"无卡支付\",\"地区\":\"4600\",\"收入支出金额\":\"-10,600.00\",\"余额\":\"35,078.24\",\"对方户名\":\"中国银联无卡快捷支付业务专户\",\"对方账号\":\"3602001111200515565\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-05-2818:22:13\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"消费\",\"地区\":\"3202\",\"收入支出金额\":\"-66.00\",\"余额\":\"35,012.24\",\"对方户名\":\"中国银联无卡快捷支付业务专户\",\"对方账号\":\"3602001111200515565\",\"渠道\":\"快捷支付\"},{\"交易日期\":\"2022-05-2914:07:04\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"无卡支付\",\"地区\":\"4600\",\"收入支出金额\":\"-1,880.90\",\"余额\":\"33,131.34\",\"对方户名\":\"中国银联无卡快捷支付业务专户\",\"对方账号\":\"3602001111200515565\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-05-2914:07:24\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"信用卡还款\",\"地区\":\"1201\",\"收入支出金额\":\"-19,778.08\",\"余额\":\"13,353.26\",\"对方户名\":\"光大卡中心信用卡\",\"对方账号\":\"000133100001\",\"渠道\":\"中间业务后台方式\"},{\"交易日期\":\"2022-05-2914:07:44\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"信用卡还款\",\"地区\":\"1201\",\"收入支出金额\":\"-12,170.62\",\"余额\":\"1,182.64\",\"对方户名\":\"中信银行信用卡\",\"对方账号\":\"000133100001\",\"渠道\":\"中间业务后台方式\"},{\"交易日期\":\"2022-05-2914:49:47\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"银联入账\",\"地区\":\"3202\",\"收入支出金额\":\"+4,375.80\",\"余额\":\"5,558.44\",\"对方户名\":\"嘉联支付有限公司备付金\",\"对方账号\":\"991584001126\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-05-2915:02:46\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"银联入账\",\"地区\":\"3202\",\"收入支出金额\":\"+4,573.32\",\"余额\":\"10,131.76\",\"对方户名\":\"银盛支付服务股份有限公司备付金\",\"对方账号\":\"991584000207\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-05-2915:03:45\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"银联入账\",\"地区\":\"3202\",\"收入支出金额\":\"+944.77\",\"余额\":\"11,076.53\",\"对方户名\":\"嘉联支付有限公司备付金\",\"对方账号\":\"991584001126\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-05-2915:04:37\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"银联入账\",\"地区\":\"3202\",\"收入支出金额\":\"+7,458.75\",\"余额\":\"18,535.28\",\"对方户名\":\"嘉联支付有限公司备付金\",\"对方账号\":\"991584001126\",\"渠道\":\"网上银行\"},{\"交易日期\":\"2022-06-0209:07:21\",\"账号\":\"3202105801009634289\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"理财\",\"地区\":\"3202\",\"收入支出金额\":\"-156.00\",\"余额\":\"18,379.28\",\"对方户名\":\"快钱支付清算信息有限公司\",\"对方账号\":\"215500684\",\"渠道\":\"快捷支付\"}]}";
        String icbcTrans = icbcMappingParser.parseICBCTrans(icbcJson);
        System.out.println(icbcTrans);
    }
}
