package com.json.mapping.parse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.json.mapping.bo.CCB;
import com.json.mapping.bo.StandardizedTran;
import com.json.mapping.bo.StandardizedTranInfo;
import com.json.mapping.util.DateUtil;
import com.json.mapping.util.JsonUtil;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 建行pdf交易流水解析
 * @author anyspa
 * @since 2022/06/02
 */

public class CCBMappingParser {

    public String parseCCBTrans(String json) {
        String standardizedJson = "";
        try {
            CCB ccb = JsonUtil.json2Object(json, CCB.class);
            standardizedJson = convertCCB2StandardizedJson(ccb);
        } catch (Exception e) {
            System.out.println("parseCCBTrans failed, error:" + e);
        }
        return standardizedJson;
    }

    private String convertCCB2StandardizedJson(CCB ccb) throws JsonProcessingException {
        StandardizedTran standardizedTran = new StandardizedTran();
        standardizedTran.setAccountNumber(ccb.getAccountNo());
        standardizedTran.setAccountName(ccb.getName());
        standardizedTran.setStartDate(DateUtil.convertDate(ccb.getStartDate()));
        standardizedTran.setExpirationDate(DateUtil.convertDate(ccb.getEndDate()));

        List<StandardizedTranInfo> standardizedTranInfoList = ccb.getCcbTrans().stream().map(ccbTran -> {
            StandardizedTranInfo standardizedTranInfo = new StandardizedTranInfo();
            standardizedTranInfo.setSummary(ccbTran.getTransactionType());
            standardizedTranInfo.setCurrency(ccbTran.getCurrency());
            standardizedTranInfo.setCashExchange(ccbTran.getCashRemit());
            standardizedTranInfo.setTransactionDate(DateUtil.convertDate(ccbTran.getTransactionDate()));
            if (ccbTran.getTransactionAmount() != null) {
                if (ccbTran.getTransactionAmount().startsWith("-")) {
                    standardizedTranInfo.setExpense(ccbTran.getTransactionAmount().replace("-", ""));
                } else {
                    standardizedTranInfo.setRevenue(ccbTran.getTransactionAmount());
                }
            }
            standardizedTranInfo.setAccountBalance(ccbTran.getBalance());

            String counterPartyAccountName = "";
            String counterPartyAccountNumber = "";
            String counterParty = ccbTran.getCounterParty();
            if (counterParty != null && !counterParty.equals("") && counterParty.contains("/")) {
                counterPartyAccountNumber = counterParty.substring(0, counterParty.indexOf("/"));
                counterPartyAccountName = counterParty.substring(counterParty.indexOf("/") + 1);
            }

            standardizedTranInfo.setCounterPartyAccountName(counterPartyAccountName);
            standardizedTranInfo.setCounterPartyAccountNumber(counterPartyAccountNumber);
            return standardizedTranInfo;
        }).collect(Collectors.toList());

        standardizedTran.setStandardizedTrans(standardizedTranInfoList);
        return JsonUtil.object2Json(standardizedTran);
    }

    public static void main(String[] args) {
        CCBMappingParser ccbMappingParser = new CCBMappingParser();
        String ccbJson = "{\"卡号/账号\":\"6217002870088479298\",\"客户名称\":\"朱**\",\"起始日期\":\"20220430\",\"结束日期\":\"20220530\",\"交易明细\":[{\"序号\":\"1\",\"摘要\":\"银联入账\",\"币别\":\"人民币元\",\"钞汇\":\"钞\",\"交易日期\":\"20220521\",\"交易金额\":\"100.00\",\"账户余额\":\"101.66\",\"交易地点/附言\":\"（云闪付APP）\",\"对方账号与户名\":\"6214835734747353/朱**\"},{\"序号\":\"2\",\"摘要\":\"ETC欠费补扣\",\"币别\":\"人民币元\",\"钞汇\":\"钞\",\"交易日期\":\"20220521\",\"交易金额\":\"-2.85\",\"账户余额\":\"98.81\",\"交易地点/附言\":\"高速ETC记账卡批量扣款\",\"对方账号与户名\":\"034201420000000000001/湖北记账卡清算户\"}]}";
        String ccbTrans = ccbMappingParser.parseCCBTrans(ccbJson);
        System.out.println(ccbTrans);
    }
}
