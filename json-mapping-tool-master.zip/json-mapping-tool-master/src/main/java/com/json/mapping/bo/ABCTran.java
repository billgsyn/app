package com.json.mapping.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author anyspa
 * @since 2022/08/22
 */
public class ABCTran {
	/**
	 * 交易日期
	 */
	@JsonProperty("交易日期")
	private String tranDate;

	/**
	 * 交易时间
	 */
	@JsonProperty("交易时间")
	private String tranTime;

	/**
	 * 交易摘要
	 */
	@JsonProperty("交易摘要")
	private String tranSummary;

	/**
	 * 交易金额
	 */
	@JsonProperty("交易金额")
	private String tranAmt;

	/**
	 * 本次余额
	 */
	@JsonProperty("本次余额")
	private String balance;

	/**
	 * 对手信息
	 */
	@JsonProperty("对手信息")
	private String counterPartyInfo;

	/**
	 * 交易渠道
	 */
	@JsonProperty("交易渠道")
	private String tranChannel;

	/**
	 * 交易附言
	 */
	@JsonProperty("交易附言")
	private String tranComment;

	public String getTranDate() {
		return tranDate;
	}

	public void setTranDate(String tranDate) {
		this.tranDate = tranDate;
	}

	public String getTranTime() {
		return tranTime;
	}

	public void setTranTime(String tranTime) {
		this.tranTime = tranTime;
	}

	public String getTranSummary() {
		return tranSummary;
	}

	public void setTranSummary(String tranSummary) {
		this.tranSummary = tranSummary;
	}

	public String getTranAmt() {
		return tranAmt;
	}

	public void setTranAmt(String tranAmt) {
		this.tranAmt = tranAmt;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getCounterPartyInfo() {
		return counterPartyInfo;
	}

	public void setCounterPartyInfo(String counterPartyInfo) {
		this.counterPartyInfo = counterPartyInfo;
	}

	public String getTranChannel() {
		return tranChannel;
	}

	public void setTranChannel(String tranChannel) {
		this.tranChannel = tranChannel;
	}

	public String getTranComment() {
		return tranComment;
	}

	public void setTranComment(String tranComment) {
		this.tranComment = tranComment;
	}
}
