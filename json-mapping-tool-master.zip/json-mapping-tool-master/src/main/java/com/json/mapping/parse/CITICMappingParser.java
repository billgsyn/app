package com.json.mapping.parse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.json.mapping.bo.CITIC;
import com.json.mapping.bo.StandardizedTran;
import com.json.mapping.bo.StandardizedTranInfo;
import com.json.mapping.util.DateUtil;
import com.json.mapping.util.JsonUtil;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 中信银行pdf流水解析
 * @author anyspa
 * @since 2022/08/23
 */
public class CITICMappingParser {
	public String parseCITICTrans(String json) {
		String standardizedJson = "";
		try {
			CITIC citic = JsonUtil.json2Object(json, CITIC.class);
			standardizedJson = convertCITIC2StandardizedJson(citic);
		} catch (JsonProcessingException e) {
			System.out.println("parseCITICTrans failed, error:" + e);
		}
		return standardizedJson;
	}

	private String convertCITIC2StandardizedJson(CITIC citic) throws JsonProcessingException {
		StandardizedTran standardizedTran = new StandardizedTran();
		standardizedTran.setAccountName(citic.getAccountName());
		standardizedTran.setAccountNumber(citic.getAccountNo());
		String transDetailPeriod = citic.getInquiryPeriod();
		if (transDetailPeriod != null && transDetailPeriod.contains("-")) {
			String[] date = transDetailPeriod.split("-");
			standardizedTran.setStartDate(DateUtil.convertDate(date[0]));
			standardizedTran.setExpirationDate(DateUtil.convertDate(date[1]));
		}
		String currency = citic.getCurrency();

		List<StandardizedTranInfo> standardizedTrans = citic.getCiticTrans().stream().filter(citicTran -> (
				citicTran.getAccountBalance() != null && citicTran.getAccountBalance().contains("RMB"))
		).map(citicTran -> {
			StandardizedTranInfo standardizedTranInfo = new StandardizedTranInfo();
//			standardizedTranInfo.setTransactionDate(citicTran.getTransactionDate());
			if (citicTran.getTransactionDate().contains("-")) {
				standardizedTranInfo.setTransactionDate(citicTran.getTransactionDate());
			} else {
				if (citicTran.getTransactionDate().trim().matches("\\d{8}")) {
					StringBuilder stringBuilder = new StringBuilder(citicTran.getTransactionDate());
					stringBuilder.insert(4, "-").insert(7, "-");
					standardizedTranInfo.setTransactionDate(stringBuilder.toString());
				}
			}
			if (citicTran.getAccountReceivable() != null && citicTran.getAccountReceivable().contains("RMB")) {
				standardizedTranInfo.setRevenue(citicTran.getAccountReceivable().replace("RMB", "").trim());
			} else {
				standardizedTranInfo.setRevenue(citicTran.getAccountReceivable());
			}

			if (citicTran.getAccountPaid() != null && citicTran.getAccountPaid().contains("RMB")) {
				standardizedTranInfo.setExpense(citicTran.getAccountPaid().replace("RMB", "").trim());
			} else {
				standardizedTranInfo.setExpense(citicTran.getAccountPaid());
			}

			standardizedTranInfo.setAccountBalance(citicTran.getAccountBalance().replace("RMB", "").trim());
			standardizedTranInfo.setSummary(citicTran.getDescription());
			standardizedTranInfo.setCurrency(currency);
			standardizedTranInfo.setCounterPartyAccountName(citicTran.getRecipient());

			return standardizedTranInfo;
		}).collect(Collectors.toList());
		standardizedTran.setStandardizedTrans(standardizedTrans);

		return JsonUtil.object2Json(standardizedTran);
	}

	public static void main(String[] args) {
		CITICMappingParser citicMappingParser = new CITICMappingParser();
		// String citicJson = "{\"户名\":\"张**\",\"证件类型\":\"居民身份证\",\"证件号码\":\"350721199501281826\",\"账号\":\"6217710312185648\",\"时间段\":\"20210929-20220328\",\"开立日期\":\"2022-03-29\",\"查询最低限额\":\"0\",\"币种\":\"人民币\",\"交易明细\":[{\"交易日期\":\"2021-12-03\",\"账户序号\":\"000001\",\"收入金额\":\"\",\"支出金额\":\"RMB 512.00\",\"账户余额\":\"RMB 0.58\",\"交易摘要\":\"网银互联跨行转出\",\"对方户名\":\"张**\",\"被冲账标识\":\"N\"},{\"交易日期\":\"2021-12-21\",\"账户序号\":\"000001\",\"收入金额\":\"RMB 0.31\",\"支出金额\":\"\",\"账户余额\":\"RMB 0.89\",\"交易摘要\":\"批量结息入账\",\"对方户名\":\"\",\"被冲账标识\":\"N\"},{\"交易日期\":\"2021-12-22\",\"账户序号\":\"000001\",\"收入金额\":\"RMB 85.00\",\"支出金额\":\"\",\"账户余额\":\"RMB 85.89\",\"交易摘要\":\"支付宝\",\"对方户名\":\"支付宝（中国）网络技术有限公司\",\"被冲账标识\":\"N\"},{\"交易日期\":\"2021-12-22\",\"账户序号\":\"000001\",\"收入金额\":\"\",\"支出金额\":\"RMB 84.06\",\"账户余额\":\"RMB 1.83\",\"交易摘要\":\"支付宝\",\"对方户名\":\"\",\"被冲账标识\":\"N\"}]}";
		String citicJson = "{\"户名\":\"张三\",\"证件类型\":\"居民身份证\",\"证件号码\":\"4***************1\",\"账号\":\"60000000000000001\",\"时间段\":\"20220101-20230101\",\"开立日期\":\"2023-02-25\",\"查询最低限额\":\"0\",\"币种\":\"全部\",\"交易明细\":[{\"交易日期\":\"20220103\",\"账户序号\":\"000001\",\"收入金额\":\"RMB 400.00\",\"支出金额\":\"\",\"账户余额\":\"RMB 404.37\",\"交易摘要\":\"行外转账转入\",\"对方户名\":\"财付通支付科技有限公司\",\"被冲账标识\":\"N\"},{\"交易日期\":\"20220103\",\"账户序号\":\"000001\",\"收入金额\":\"\",\"支出金额\":\"RMB 376.40\",\"账户余额\":\"RMB 27.97\",\"交易摘要\":\"辅助无密\",\"对方户名\":\"\",\"被冲账标识\":\"N\"}]}";
		String citicTrans = citicMappingParser.parseCITICTrans(citicJson);
		System.out.println(citicTrans);
	}
}
