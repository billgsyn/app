# file-parse-demo

#### 介绍
此工程为个人开发者对当前的一些类型的用户文件提供文件结构化解析为json的功能。

#### 特别说明
1.  因为新版的社保加入了水印，会影响解析的准确率，所以在调用解析代码解析社保文件前需先调用去除水印的函数对解析文件做预处理
    具体调用文件是RemoveWaterMark.java里的removeWaterMark方法。

#### 使用说明
1.  可直接copy对应类型的文件及其依赖到所需的工程中使用解析的功能
2.  改代码只针对现在版本的文件解析经过测试，当遇到文件改版或新的格式案例集，可以自己调整代码进行适配，该项目也会做定期的代码维护和更新。
3.  已验证可用的解析数据类型及其对应的解析类如下
4.  gradle版本可使用6.8.0

|  数据类型  | site取值 |  解析类 | 文件类型 |
|---|--|---|---|
|  农业银行丰巢流水 | beehive-abc |  ABCPdfParser  | PDF  |
|  支付宝理财资产证明流水 | beehive-alipay-asset  |  AlipayAssetPdfParser  | PDF  |
|  支付宝账单流水 | beehive-alipay | AlipayPdfParser  | PDF  |
|  支付宝APP-芝麻分| app-alipay-cr |  AppAlipayCrXmlParser  | XML  |
|  支付宝APP-花呗 | app-alipay-huabei |  AppAlipayHuaBeiXmlParser  | XML  |
|  支付宝APP-借呗 | app-alipay-jiebei |   AppAlipayJieBeiXmlParser | XML  |
|  支付宝APP-网商贷 | app-alipay-wsd |  AppAlipayWsdXmlParser  | XML  |
|  支付宝APP-N合1 | app-alipay-any |  AppAlipayXmlParser  | XML  |
|  国家政务APP-公积金 | app-gjzwfw-gjj | AppGjzwfwGjjXmlParser  | XML  |
|  国家政务APP-驾驶证 | app-gjzwfw-jsz |   AppGjzwfwJszHtmlParser | HTML  |
|  江苏政务服务APP-江苏不动产| app-jszwfw |  AppJszwfwHtmlParser  | HTML  |
|  个税APP-个税收入明细 | app-tax-detail |  AppTaxIncomeDetailHtmlParser  | HTML  |
|  个税APP—个税纳税收入| app-tax-income  |  AppTaxIncomeHtmlParser  | HTML  |
|  12123APP-机动车 |  app-tmri-xsz |  AppTmriXszXmlParser  | XML  |
|  交通银行丰巢流水 | beehive-bcm |  BCMPdfParser  | PDF  |
|  北京市社保 | bjsb |  BjSocialInsurancePdfParser  | PDF  |
|  中国银行（网银登录下载） | boc |  BOCCsvParser  | CSV  |
|  中国银行丰巢流水 | beehive-boc |   BOCPdfParser | PDF  |
|  建设银行PC网银银行流水| ccb |  CCBExcelParser  | EXCEL  |
|  建设银行丰巢流水 | beehive-ccb |  CCBPdfParser  | PDF  |
|  成都不动产PC网页 | chrome-cdzjryb-bdc |  CDBDCPdfParser | PDF |
|  光大银行PC网银银行流水 | ceb |  CEBExcelParser | EXCEL |
|  广发银行丰巢流水 | beehive-gdb |  CGBPdfParser | PDF  |
|  学信网学历查询 | chsi |  ChsiHtmlParser | HTML |
|  学信网学籍查询  | chsixj | ChsixjHtmlParser  |  HTML |
|  学信网学位查询 | chrome-chsi-xw |  ChsixwHtmlParser | HTML  |
|  兴业银行PC网银银行流水 | cib |  CIBExcelParser  | EXCEL  |
|  中信银行丰巢流水 | beehive-citicb |  CITICdfParser  | PDF  |
|  招商银行企业版丰巢流水| beehive-cmb-corp |  CMBCorpExcelParser  | EXCEL  |
|  民生银行丰巢流水 |  beehive-cmbc | CMBCPdfParser  | PDF  |
|  招商银行丰巢流水 | beehive-cmb |  CMBPdfParser  | PDF  |
|  海外文凭（教留服） | cscse |  CscseHtmlParser  | HTML  |
|  浙商银行丰巢流水 | beehive-czb |  CZBPdfParser  | PDF  |
|  恒丰银行PC网银银行流水 | hfb |  HFBExcelParser  | EXCEL  |
|  工商银行企业版丰巢流水 | beehive-icbc-corp |   ICBCCorpPdfParser  | PDF  |
|  工商银行丰巢流水 | beehive-icbc | ICBCPdfParser  | PDF  |
|  自然人电子税务局PC网页 | tax |  IITPdfParser  | PDF  |
|  抖音电商PC网页流水 | chrome-jinritemai-bill |  JinritemaiBillHtmlParser  | HTML  |
|  南昌不动产 | chrome-ncsbdc-bdc |  NCBDCPdfParser | PDF |
|  平安银行丰巢流水 | beehive-pabc |  PABPdfParser | PDF |
|  邮政储蓄PC网银银行流水 | psbc |  PSBCExcelParser | EXCEL  |
|  上海不动产 | shbdc |  SHBDCPdfParser | PDF  |
|  浦发银行丰巢流水 | beehive-spdb |  SPDPdfParser | PDF  |
|  深圳社保PC网页 | sipub |  SzSocialInsurancePdfParser | PDF  |
|  个税 + 任职单位 | taxeat | TaxeatPdfAndHtmlParser | HTML  |
|  个税网站任职单位 | taxe |  TaxeHtmlParser | HTML  |
|  个税网站个税申报收入明细 |  taxi |  TaxiHtmlParser | HTML  |
|  天津不动产 | chrome-tjbdc |  TJBDCPdfParser | PDF  |
|  微众银行理财类资产证明 | beehive-webank-asset | WebankAssetPdfParser | PDF  |
|  微信支付丰巢流水 | beehive-wechatpay |  WechatPayPdfParser | PDF  |
|  学信网学历零散查询 | xlcx |  XlcxHtmlParser | HTML  |
| 全国电子社保 | app-gjzwfw-dzsb | SocialSecurityPdfParser | PDF |
| 江苏银行丰巢流水 | beehive-jsbank | JsBankPdfParser | PDF |
| 邮储银行丰巢流水 | beehive-psbc | PSBCPdfParser| PDF |
| 四川农信 | beehive-scrcu | SCRCUPdfParser| PDF |
| 江苏银行交易明细 | beehive-jsbank | JsBankPdfParser| PDF |
| 南京银行丰巢流水 | beehive-njcb | NJCBPdfParser| PDF |
| 婚姻证件 | app-gjzwfw-hyzj | AppGjzwfwHyzjXmlParser| XML |
| 公积金信息 | chrome-gjj-any | ChromeGjjAnyHtmlParser| HTML |





