package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 交管12123APP电子驾驶证
 * @author anyspa
 */

@Data
public class AppTmriJsz {

    @JsonProperty("正页")
    private AppTmriJszPositivePage appTmriJszPositivePage;

    @JsonProperty("副页")
    private AppTmriJszSecondaryPage appTmriJszSecondaryPage;

    @Data
    public static class AppTmriJszPositivePage {
        @JsonProperty("姓名")
        private String name;

        @JsonProperty("准驾车型")
        private String quasiDrivingModel;

        @JsonProperty("累积记分")
        private String score;

        @JsonProperty("初次领证日期")
        private String initialApplicationDate;

        @JsonProperty("状态")
        private String status;

        @JsonProperty("证号")
        private String certificateNumber;

        @JsonProperty("性别")
        private String sex;

        @JsonProperty("出生日期")
        private String birthDay;

        @JsonProperty("国籍")
        private String nationality;

        @JsonProperty("档案编号")
        private String archivesNo;

        @JsonProperty("有效期限")
        private String validityPeriod;

        @JsonProperty("生成时间")
        private String generationTime;

        @JsonProperty("当前时间")
        private String currentTime;

        @JsonProperty("证芯编号")
        private String coreNumber;
    }

    @Data
    public static class AppTmriJszSecondaryPage {
        @JsonProperty("住址")
        private String address;

        @JsonProperty("发证机关")
        private String issuingAuthority;

        @JsonProperty("记录")
        private String record;
    }
}