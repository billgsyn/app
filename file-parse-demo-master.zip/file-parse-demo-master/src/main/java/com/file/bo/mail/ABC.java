package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;


/**
 * 农业银行qq邮箱pdf版流水
 * @author v_wbhwliu
 */
@Data
public class ABC {

    /**
     * 户名
     */
    @JsonProperty("户名")
    private String name;

    /**
     * 账户
     */
    @JsonProperty("账户")
    private String account;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 钞汇标识
     */
    @JsonProperty("钞汇标识")
    private String cashExchangeIndicator;

    /**
     * 起止日期
     */
    @JsonProperty("起止日期")
    private String transDetailPeriod;

    /**
     * 电子流水号
     */
    @JsonProperty("电子流水号")
    private String serialNo;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<ABCTran> abcTrans;
}
