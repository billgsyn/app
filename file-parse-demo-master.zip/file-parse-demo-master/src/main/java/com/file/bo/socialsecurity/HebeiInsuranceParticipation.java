package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class HebeiInsuranceParticipation {
    @JsonProperty("险种（养老）")
    EndowmentInsurance endowmentInsurance;

    @JsonProperty("险种（工伤）")
    WorkInjuryInsurance workInjuryInsurance;

    @JsonProperty("险种（失业）")
    UnemploymentInsurance unemploymentInsurance;

    @Data
    @NoArgsConstructor
    public static class UnemploymentInsurance {

        @JsonProperty("经办机构代码")
        private String agencyCode = "";

        @JsonProperty("参保人姓名")
        private String insuredName = "";

        @JsonProperty("社会保障号码")
        private String socialSecurityNumber = "";

        @JsonProperty("个人社保编号")
        private String personalSocSecNum = "";

        @JsonProperty("经办机构名称")
        private String agencyName = "";

        @JsonProperty("个人身份")
        private String personalIdentity = "";

        @JsonProperty("参保单位名称")
        private String enrolledCompanyName = "";

        @JsonProperty("首次参保日期")
        private String firstEnrollmentDate = "";

        @JsonProperty("本地登记日期")
        private String localRegistrationDate = "";

        @JsonProperty("个人参保状态")
        private String individualEnrollmentStatus = "";

        @JsonProperty("累计缴费年限")
        private String accumulatedPaymentYears = "";

        @JsonProperty("证明日期")
        private String ParticipationDate = "";

        @JsonProperty("参保人缴费明细")
        private List<UnemploymentInsuranceInsuranceDetail> insuranceDetails;
    }

    @Data
    @NoArgsConstructor
    public static class WorkInjuryInsurance {
        @JsonProperty("经办机构代码")
        private String agencyCode = "";
        @JsonProperty("参保人姓名")
        private String insuredName = "";

        @JsonProperty("社会保障号码")
        private String socialSecurityNumber = "";

        @JsonProperty("个人社保编号")
        private String personalSocSecNum = "";

        @JsonProperty("经办机构名称")
        private String agencyName = "";

        @JsonProperty("首次参保日期")
        private String firstEnrollmentDate = "";

        @JsonProperty("参保单位名称")
        private String enrolledCompanyName = "";

        @JsonProperty("个人参保状态")
        private String individualEnrollmentStatus = "";

        @JsonProperty("本地登记日期")
        private String localRegistrationDate = "";

        @JsonProperty("证明日期")
        private String ParticipationDate = "";

        @JsonProperty("参保人缴费明细")
        private List<WorkInjuryInsuranceInsuranceDetail> insuranceDetails;
    }

    @Data
    @NoArgsConstructor
    public static class UnemploymentInsuranceInsuranceDetail {

        @JsonProperty("参保险种")
        private String insuranceType;

        @JsonProperty("起止年月")
        private String startDateAndEndDate;

        @JsonProperty("缴费基数")
        private String contributionBase;

        @JsonProperty("应缴月数")
        private String dueMonths;

        @JsonProperty("实缴月数")
        private String actualMonths;

        @JsonProperty("参保单位")
        private String enrolledCompany;
    }


    @Data
    public static class WorkInjuryInsuranceInsuranceDetail {

        @JsonProperty("参保险种")
        private String insuranceType;

        @JsonProperty("起止年月")
        private String startDateAndEndDate;

        @JsonProperty("缴费基数")
        private String contributionBase;

        @JsonProperty("参保单位")
        private String enrolledCompany;
    }

    @Data
    @NoArgsConstructor
    public static class EndowmentInsurance {
        @JsonProperty("经办机构代码")
        private String agencyCode = "";

        @JsonProperty("参保人姓名")
        private String insuredName = "";

        @JsonProperty("社会保障号码")
        private String socialSecurityNumber = "";

        @JsonProperty("个人社保编号")
        private String personalSocSecNum = "";

        @JsonProperty("经办机构名称")
        private String agencyName = "";

        @JsonProperty("个人身份")
        private String personalIdentity = "";

        @JsonProperty("参保单位名称")
        private String enrolledCompanyName = "";

        @JsonProperty("首次参保日期")
        private String firstEnrollmentDate = "";

        @JsonProperty("本地登记日期")
        private String localRegistrationDate = "";

        @JsonProperty("个人参保状态")
        private String individualEnrollmentStatus = "";

        @JsonProperty("累计缴费年限")
        private String accumulatedPaymentYears = "";

        @JsonProperty("证明日期")
        private String ParticipationDate = "";

        @JsonProperty("参保人缴费明细")
        private List<EndowmentInsuranceInsuranceDetail> insuranceDetails;
    }

    @Data
    public static class EndowmentInsuranceInsuranceDetail {

        @JsonProperty("参保险种")
        private String insuranceType;

        @JsonProperty("起止年月")
        private String startDateAndEndDate;

        @JsonProperty("缴费基数")
        private String contributionBase;

        @JsonProperty("应缴月数")
        private String dueMonths;

        @JsonProperty("实缴月数")
        private String actualMonths;

        @JsonProperty("参保单位")
        private String enrolledCompany;
    }
}
