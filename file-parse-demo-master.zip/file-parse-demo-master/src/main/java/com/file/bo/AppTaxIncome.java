package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.file.bo.AppTaxIncomeTran;
import lombok.Data;

import java.util.List;

@Data
public class AppTaxIncome {

    @JsonProperty("收入合计")
    private String totalIncome;

    @JsonProperty("已申报税额合计")
    private String totalDeclaredTax;

    @JsonProperty("收入纳税明细")
    private List<AppTaxIncomeTran> appTaxIncomeTrans;

}
