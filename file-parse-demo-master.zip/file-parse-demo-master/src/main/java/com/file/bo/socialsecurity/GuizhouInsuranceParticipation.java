package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class GuizhouInsuranceParticipation {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("个人编号")
    private String PersonalNumber;

    @JsonProperty("身份证号")
    private String idNo;

    @JsonProperty("参保缴费情况")
    private List<InsuranceParticipationRecord> insuranceParticipationRecordList;

    @JsonProperty("打印日期")
    private String printTime;


    @JsonProperty("提示")
    private String prompt;


    @Data
    public static class InsuranceParticipationRecord {

        @JsonProperty("参保险种")
        private String insured;

        @JsonProperty("现参保地社保经办机构")
        private String currentInsuranceAgency;

        @JsonProperty("缴费状态")
        private String paymentStatus;

        @JsonProperty("参保单位名称")
        private String unit;

        @JsonProperty("缴费起止时间")
        private String insuranceParticipationStartAndEndTime;

        @JsonProperty("实际缴费月数")
        private String actualPaymentMonths;

        @JsonProperty("中断月数")
        private String InterruptionMonths;
    }
}
