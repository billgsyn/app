package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author anyspa
 */
@Data
public class BCMTran {

    /**
     * 序号
     */
    @JsonProperty("序号")
    private String serialNum;

    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String transDate;

    /**
     * 交易时间
     */
    @JsonProperty("交易时间")
    private String transTime;

    /**
     * 交易类型
     */
    @JsonProperty("交易类型")
    private String tradingType;

    /**
     * 借贷
     */
    @JsonProperty("借贷")
    private String dcFlg;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String transAmt;

    /**
     * 余额
     */
    @JsonProperty("余额")
    private String balance;

    /**
     * 对方账户
     */
    @JsonProperty("对方账户")
    private String paymentReceiptAccount;

    /**
     * 对方户名
     */
    @JsonProperty("对方户名")
    private String paymentReceiptAccountName;

    /**
     * 交易地点
     */
    @JsonProperty("交易地点")
    private String tradingPlace;

    /**
     * 摘要
     */
    @JsonProperty("摘要")
    private String summary;








}
