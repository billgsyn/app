package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 农行PC端Excel版流水文件
 * @author v_wbhwliu
 */
@Data
public class ABC {

    /**
     * 账号
     */
    @JsonProperty("账号")
    private String accountNumber;

    /**
     * 户名
     */
    @JsonProperty("户名")
    private String accountName;

    /**
     * 起始日期
     */
    @JsonProperty("起始日期")
    private String startDate;

    /**
     * 截止日期
     */
    @JsonProperty("截止日期")
    private String expirationDate;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<ABCTran> abcTrans;

}
