package com.file.bo;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 丰巢北京银行交易明细流水字段
 * @author anyspa
 */
@Data
public class BOB {

    /**
     * 客户名称
     */
    @JsonProperty("客户名称")
    private String name;
    /**
     * 账号
     */
    @JsonProperty("日期范围")
    private String dateRange;

    /**
     * 卡/账号
     */
    @JsonProperty("卡/账号")
    private String accountNumber;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 流水单号
     */
    @JsonProperty("流水单号")
    private String serialNo;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<BOBTran> bobTrans;
}
