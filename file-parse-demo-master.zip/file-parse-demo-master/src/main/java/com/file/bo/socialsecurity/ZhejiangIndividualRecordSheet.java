package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 浙江省社会保险个人权益记录单
 *
 * @author anyspa
 */

@Data
public class ZhejiangIndividualRecordSheet {
    @JsonProperty("基本养老保险")
    private BasicEndowmentInsurance basicEndowmentInsurance;

    @JsonProperty("机关事业养老保险")
    private InstitutionalEndowmentInsurance institutionalEndowmentInsurance;

    @JsonProperty("城乡居民养老保险")
    private UrbanAndRuralResidentsEndowmentInsurance urbanAndRuralResidentsEndowmentInsurance;

    @JsonProperty("失业保险")
    private UnemploymentInsurance unemploymentInsurance;

    @JsonProperty("工伤保险")
    private EmploymentInjuryInsurance employmentInjuryInsurance;

    @Data
    public static class BasicEndowmentInsurance {
        @JsonProperty("在职参保人员基础信息")
        private InsuredPersonBaseInfo insuredPersonBaseInfo;

        @JsonProperty("在职年度个人账户")
        private PersonalAccountOfOnServerYear personalAccountOfOnServerYear;

        @JsonProperty("个人缴费信息")
        private List<BasicEndowmentPersonalPaymentInfo> personalPaymentInfoList;

        @JsonProperty("养老金待遇人员基础信息")
        private PensionBenefitsPersonBaseInfo pensionBenefitsPersonBaseInfo;

        @JsonProperty("养老金待遇发放信息")
        private List<PensionPaymentInfo> pensionPaymentInfoList;
    }

    @Data
    public static class InstitutionalEndowmentInsurance {
        @JsonProperty("在职参保人员基础信息")
        private String insuredPersonBaseInfo;

        @JsonProperty("基本养老金个人账户缴纳额")
        private String pensionPersonalPaymentAmount;

        @JsonProperty("职业年金个人账户缴纳额")
        private String occupationalAnnuityPersonalPaymentAmount;

        @JsonProperty("个人缴费信息")
        private List<InstitutionalEndowmentPersonalPaymentInfo> personalPaymentInfoList;

        @JsonProperty("养老金待遇人员基础信息")
        private PensionBenefitsPersonBaseInfo pensionBenefitsPersonBaseInfo;

        @JsonProperty("养老金待遇发放信息")
        private List<PensionPaymentInfo> pensionPaymentInfoList;
    }

    @Data
    @NoArgsConstructor
    public static class InsuredPersonBaseInfo {
        @JsonProperty("社会保障号")
        private String socialSecurityNumber = "";

        @JsonProperty("姓名")
        private String name = "";

        @JsonProperty("参保状态")
        private String insuranceStatus = "";

        @JsonProperty("参保单位")
        private String unitName = "";
    }

    @Data
    @NoArgsConstructor
    public static class PersonalAccountOfOnServerYear {
        @JsonProperty("年度")
        private String year = "";

        @JsonProperty("截至上年末个人账户累计储存额")
        private String accumulatedSavingsInPersonalAccountsLastYear = "";

        @JsonProperty("本年实际缴费月数")
        private String currentYearActualPaymentMonths = "";

        @JsonProperty("当年记账金额")
        private String currentAccountAmount = "";

        @JsonProperty("当年本金利息")
        private String currentPrincipalInterest = "";

        @JsonProperty("上年末累计在当年利息")
        private String interestAccruedUntilLastYear = "";

        @JsonProperty("至本年末账户累计储存额")
        private String accumulatedSavingsInAccountsThisYear = "";

        @JsonProperty("至本年末实际缴费月数")
        private String actualPaymentMonthsUntilThisYear = "";
    }

    @Data
    public static class BasicEndowmentPersonalPaymentInfo {
        @JsonProperty("应征年月")
        private String recruitmentYear;

        @JsonProperty("缴费单位")
        private String payer;

        @JsonProperty("缴费类型")
        private String paymentType;

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("个人缴费金额")
        private String personalPaymentAmount;

        @JsonProperty("到账情况")
        private String arrivalStatus;
    }

    @Data
    @NoArgsConstructor
    public static class PensionBenefitsPersonBaseInfo {
        @JsonProperty("社会保障号")
        private String socialSecurityNumber = "";

        @JsonProperty("姓名")
        private String name = "";

        @JsonProperty("发放状态")
        private String paymentStatus = "";

    }

    @Data
    public static class PensionPaymentInfo {
        @JsonProperty("发放年月")
        private String paymentYear;

        @JsonProperty("发放金额")
        private String paymentAmount;
    }

    @Data
    public static class InstitutionalEndowmentPersonalPaymentInfo {
        @JsonProperty("缴费年月")
        private String paymentYear;

        @JsonProperty("月缴费基数")
        private String paymentBaseOfMonth;

        @JsonProperty("个人缴费金额")
        private String personalPaymentAmount;

        @JsonProperty("险种")
        private String type;

        @JsonProperty("到账情况")
        private String arrivalStatus;
    }

    @Data
    public static class UrbanAndRuralResidentsEndowmentInsurance {
        @JsonProperty("参保缴费人员基础信息")
        private String insurancePayerBaseInfo;

        @JsonProperty("养老金待遇人员基础信息")
        private String pensionerBaseInfo;

        @JsonProperty("个人缴费信息")
        private List<PersonalPaymentInfo> personalPaymentInfoList;

        @JsonProperty("养老金待遇发放信息")
        private List<PensionPaymentInformation> pensionPaymentInformationList;
    }

    @Data
    public static class PersonalPaymentInfo {
        @JsonProperty("缴费年度")
        private String paymentYear;

        @JsonProperty("个人缴费金额")
        private String personalPaymentAmount;

        @JsonProperty("到账情况")
        private String arrivalStatus;
    }

    @Data
    public static class PensionPaymentInformation {
        @JsonProperty("发放年月")
        private String paymentYear;

        @JsonProperty("待遇发放金额")
        private String paymentAmount;
    }

    @Data
    public static class UnemploymentInsurance {
        @JsonProperty("参保人员基础信息")
        private InsuredPersonBaseInfo insuredPersonBaseInfo;
    }

    @Data
    public static class EmploymentInjuryInsurance {
        @JsonProperty("参保人员基础信息")
        private InsuredPersonBaseInfo insuredPersonBaseInfo;
    }
}
