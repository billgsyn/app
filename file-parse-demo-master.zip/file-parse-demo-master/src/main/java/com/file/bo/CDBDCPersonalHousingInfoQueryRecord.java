package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 成都不动产-个人住房信息查询记录
 * @author anyspa
 */

@Data
public class CDBDCPersonalHousingInfoQueryRecord {
    @JsonProperty("文件信息")
    private FileInfo fileInfo;

    @JsonProperty("申请信息")
    private List<ApplicationInfo> applicationInfoList;

    @JsonProperty("查询结果")
    private List<QueryResult> queryResultList;

    @Data
    public static class ApplicationInfo {
        @JsonProperty("被查询人")
        private String respondent;

        @JsonProperty("证件号码")
        private String idNo;
    }

    @Data
    public static class FileInfo {
        @JsonProperty("文件名")
        private String fileName;

        @JsonProperty("申请人")
        private String applicant;

        @JsonProperty("验证码")
        private String verificationCode;

        @JsonProperty("查询编号")
        private String queryNumber;

        @JsonProperty("查询范围")
        private String queryRange;

        @JsonProperty("查询平台")
        private String queryPlatform;

        @JsonProperty("打印机构")
        private String printingMechanism;

        @JsonProperty("查询时点")
        private String queryTimePoint;

        @JsonProperty("特别提示")
        private String specialSuggestion;
    }

    @Data
    public static class QueryResult {
        @JsonProperty("业务件号(合同备案号)")
        private String itemNumber;

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("房屋地址")
        private String houseAddress;

        @JsonProperty("取得方式")
        private String gainingMethod;

        @JsonProperty("房屋结构")
        private String buildingStructure;

        @JsonProperty("房屋用途")
        private String houseUsage;

        @JsonProperty("房屋面积")
        private String floorSpace;

        @JsonProperty("登记(或备案)时间")
        private String registrationTime;

        @JsonProperty("状态")
        private String state;

        @JsonProperty("备注")
        private String comment;
    }
}
