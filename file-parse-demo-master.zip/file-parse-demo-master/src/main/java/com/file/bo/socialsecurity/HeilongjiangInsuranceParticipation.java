package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class HeilongjiangInsuranceParticipation {

    @JsonProperty("黑龙江省企业职工基本养老保险个人参保证明")
    private EnterpriseEmployeesBasicEndowmentInsurance enterpriseEmployeesBasicEndowmentInsurance;

    @JsonProperty("黑龙江省工伤保险个人参保证明")
    private WorkInjuryInsurance workInjuryInsurance;

    @JsonProperty("黑龙江省失业保险参保证明（个人）")
    private UnemploymentInsurance unemploymentInsurance;

    @Data
    public static class EnterpriseEmployeesBasicEndowmentInsurance {

        @JsonProperty("社会保险机构名称")
        private String insuranceAgencyName;

        @JsonProperty("所在单位名称")
        private String unitName;

        @JsonProperty("单位编号")
        private String unitNumber;

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("性别")
        private String gender;

        @JsonProperty("个人编号")
        private String personalNumber;

        @JsonProperty("参保日期")
        private String enrollmentDate;

        @JsonProperty("参保状态")
        private String enrollmentStatus;

        @JsonProperty("社会保障号码")
        private String socialSecurityNumber;

        @JsonProperty("打印日期")
        private String printDate;

        @JsonProperty("单位")
        private String unit;

        @JsonProperty("缴费详情")
        private List<EnterpriseEmployeesBasicEndowmentInsurancePaymentDetail> enterpriseEmployeesBasicEndowmentInsurancePaymentDetailList;

        @JsonProperty("说明")
        private String description;

    }

    @Data
    public static class EnterpriseEmployeesBasicEndowmentInsurancePaymentDetail{

        @JsonProperty("缴费年度")
        private String paymentYear;

        @JsonProperty("本年缴费月数")
        private String paymentMonthCount;

        @JsonProperty("当年缴费基数和")
        private String paymentBaseTotal;

        @JsonProperty("本年度个人账户缴费到账金额")
        private String personalAccountPaymentAmount;

        @JsonProperty("至本年末账户累计储存额")
        private String accountBalance;

        @JsonProperty("年度缴费标识")
        private String[] paymentStatus;

    }

    @Data
    public static class WorkInjuryInsurance {

        @JsonProperty("工伤保险机构名称")
        private String agencyName;

        @JsonProperty("所在单位名称")
        private String unitName;

        @JsonProperty("单位编号")
        private String unitNumber;

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("性别")
        private String gender;

        @JsonProperty("个人编号")
        private String personalNumber;

        @JsonProperty("参保日期")
        private String enrollmentDate;

        @JsonProperty("参保状态")
        private String enrollmentStatus;

        @JsonProperty("社会保障号码")
        private String socialSecurityNumber;

        @JsonProperty("打印日期")
        private String printDate;

        @JsonProperty("单位")
        private String unit;

        @JsonProperty("缴费详情")
        private List<WorkInjuryInsurancePaymentDetail> workInjuryInsurancePaymentDetailList;

        @JsonProperty("说明")
        private String description;

    }

    @Data
    public static class WorkInjuryInsurancePaymentDetail {

        @JsonProperty("缴费年度")
        private String paymentYear;

        @JsonProperty("本年缴费月数")
        private String paymentMonthCount;

        @JsonProperty("当年缴费基数和")
        private String paymentBaseTotal;

        @JsonProperty("年度缴费标识")
        private String[] paymentStatus;

    }

    @Data
    public static class UnemploymentInsurance {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("性别")
        private String gender;

        @JsonProperty("社会保障号码")
        private String socialSecurityNumber;

        @JsonProperty("参保日期")
        private String enrollmentDate;

        @JsonProperty("当前参保单位")
        private String currentUnit;

        @JsonProperty("缴费状态")
        private String paymentStatus;

        @JsonProperty("当前参保属地")
        private String currentLocation;

        @JsonProperty("查询打印日期")
        private String queryPrintDate;

        @JsonProperty("历年参保缴费情况")
        private List<UnemploymentInsurancePaymentDetail> unemploymentInsurancePaymentDetailList;

    }

    @Data
    public static class UnemploymentInsurancePaymentDetail {

        @JsonProperty("缴费年度")
        private String paymentYear;

        @JsonProperty("年度缴费基数总和(元)")
        private String annualPaymentBaseTotal;

        @JsonProperty("年度个人缴费标识")
        private String[] paymentStatus;

    }

}
