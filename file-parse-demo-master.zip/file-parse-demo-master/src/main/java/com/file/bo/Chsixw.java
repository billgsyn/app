package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 学位查询
 * @author anyspa
 */

@Data
public class Chsixw {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("性别")
    private String sex;

    @JsonProperty("出生日期")
    private String dateOfBirth;

    @JsonProperty("获学位日期")
    private String dateOfDegreeAwarded;

    @JsonProperty("学位授予单位")
    private String degreeAwardingUnit;

    @JsonProperty("所授学位")
    private String degreeAwarded;

    @JsonProperty("学科专业")
    private String major;

    @JsonProperty("学位证书编号")
    private String degreeCertificateNo;

    @JsonProperty("在线验证码")
    private String onlineVerificationCode;

    @JsonProperty("更新日期")
    private String updateDate;
}
