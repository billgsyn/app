package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ChromeGjjAnyRepaymentInfo {

    @JsonProperty("还贷明细")
    private List<RepaymentDetail> repaymentDetailList;

    @Data
    public static class RepaymentDetail {

        @JsonProperty("序号")
        private String serialNumber;

        @JsonProperty("时间")
        private String time;

        @JsonProperty("还款期次")
        private String repaymentPeriod;

        @JsonProperty("还款金额(元)")
        private String repaymentAmount;

        @JsonProperty("本金(元)")
        private String principal;

        @JsonProperty("利息(元)")
        private String interest;

        @JsonProperty("罚息(元)")
        private String penaltyInterest;

    }

}
