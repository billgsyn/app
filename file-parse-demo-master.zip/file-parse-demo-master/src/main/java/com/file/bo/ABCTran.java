package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 农行PC端Excel版流水文件交易明细
 * @author v_wbhwliu
 *
 */
@Data
public class ABCTran {

	/**
	 * 交易日期
	 */
	@JsonProperty("交易日期")
	private String transactionDate;
	
	/**
	 * 交易时间
	 */
	@JsonProperty("交易时间")
	private String transactionTime;
	
	/**
	 * 交易金额
	 */
	@JsonProperty("交易金额")
	private String transactionAmount;
	
	/**
	 * 本次余额
	 */
	@JsonProperty("本次余额")
	private String currentBalance;

	/**
	 * 对方户名
	 */
	@JsonProperty("对方户名")
	private String counterPartyAccountName;

	/**
	 * 对方账号
	 */
	@JsonProperty("对方账号")
	private String counterPartyAccountNumber;

	/**
	 * 交易行
	 */
	@JsonProperty("交易行")
	private String transactionBank;
	
	/**
	 * 交易渠道
	 */
	@JsonProperty("交易渠道")
	private String transactionChannel;
	
	/**
	 * 交易类型
	 */
	@JsonProperty("交易类型")
	private String transactionType;
	
	/**
	 * 交易用途
	 */
	@JsonProperty("交易用途")
	private String tradingPlace;

	/**
	 * 交易摘要
	 */
	@JsonProperty("交易摘要")
	private String tradingSummary;
}
