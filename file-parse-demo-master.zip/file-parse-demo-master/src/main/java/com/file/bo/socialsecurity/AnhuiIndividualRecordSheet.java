package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 安徽省个人权益记录单
 */

@Data
public class AnhuiIndividualRecordSheet {

    @JsonProperty("姓名")
    private String name;

}
