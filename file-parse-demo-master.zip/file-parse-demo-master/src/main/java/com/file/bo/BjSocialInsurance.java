package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.file.bo.BjSocialInsuranceTran;
import lombok.Data;

import java.util.List;

/**
 * 北京市社保
 * @author anyspa
 */
@Data
public class BjSocialInsurance {

    @JsonProperty("参保人姓名")
    private String name;

    @JsonProperty("校验码")
    private String verifyCode;

    @JsonProperty("社会保障号码")
    private String socialInsuranceNo;

    @JsonProperty("查询流水号")
    private String queryFlowingNo;

    @JsonProperty("单位名称")
    private String companyName;

    @JsonProperty("查询日期")
    private String queryDate;

    @JsonProperty("养老保险单位变动记录")
    private List<PensionUnitChangeRecord> pensionUnitChangeRecords;

    @JsonProperty("养老保险累计实际缴费年限")
    private String pensionActualTotalPaymentYears;

    @JsonProperty("医疗保险累计实际缴费年限")
    private String medicalActualTotalPaymentYears;

    @JsonProperty("养老保险个人账户本息合计金额")
    private String pensionPersonalAccountBalance;

    @JsonProperty("五险缴费明细")
    private List<BjSocialInsuranceTran> socialInsuranceTranList;

    // 养老保险单位变动记录
    @Data
    public static class PensionUnitChangeRecord {

        @JsonProperty("缴费起始年月")
        private String paymentStartDate;

        @JsonProperty("缴费截止年月")
        private String paymentEndDate;

        @JsonProperty("实际缴费月数")
        private String actualPaymentMonths;

        @JsonProperty("单位名称")
        private String companyName;

        @JsonProperty("缴费区县")
        private String paymentDistrict;
    }
}

