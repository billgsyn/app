package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CGBTran {

	@JsonProperty("交易时间")
	private String tranDate;

	@JsonProperty("币种")
	private String currency;

	@JsonProperty("交易金额")
	private String tranAmt;

	@JsonProperty("账户余额")
	private String accountBalance;

	@JsonProperty("对方姓名")
	private String counterPartyAccountName;

	@JsonProperty("对方账号")
	private String conterPartyAccountNo;

	@JsonProperty("摘要")
	private String summary;

	@JsonProperty("附言")
	private String postscript;

}
