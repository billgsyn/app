package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 国家政务APP-婚姻证件详情
 * @author anyspa
 */

@Data
public class AppGjzwfwHyzjDetail {

    @JsonProperty("证件名称")
    private String certificateName;

    @JsonProperty("证件编号/证照号码")
    private String certificateNo;

    @JsonProperty("持有人名称")
    private String ownerName;

    @JsonProperty("持有人身份证件号码")
    private String ownerIdNo;

    @JsonProperty("签发机构")
    private String issuingAuthority;

    @JsonProperty("发证机构唯一标识")
    private String issuingAuthorityUniqueIdentification;

    @JsonProperty("发证机构所属行政区划代码")
    private String issuingAuthorityAdministrativeRegionCode;

    @JsonProperty("发证日期")
    private String issuingDate;

}
