package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.*;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 北京市社会保险个人权益记录单
 * @author anyspa
 */

@Data
public class BeijingIndividualRecordSheet {
    @JsonIgnore
    private String year;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("电脑序号")
    private String computerSerialNo;

    @JsonProperty("社会保障号码")
    private String socialInsuranceNo;

    @JsonProperty("人员类别")
    private String personalCategory;

    @JsonProperty("单位")
    private String unit;

    @JsonProperty("缴费情况")
    private List<PaymentRecord> paymentRecords;

    @JsonProperty("养老保险个人账户上年结转")
    private String pensionPersonalAccountPreviousYearTotal;

    @JsonProperty("养老保险本年计入个人账户部分合计")
    private String pensionPersonalAccountThisYearTotal;

    @JsonProperty("养老保险本年补缴计入个人账户部分")
    private String pensionRepayThisYearTotal;

    @JsonProperty("本年利息")
    private String currentYearInterest;

    @JsonProperty("养老保险个人账户本息合计(仅限本市)")
    private String pensionPersonalAccountTotal;

    @Setter(AccessLevel.NONE)
    private Map<String, String> data = new HashMap<>();

    @JsonAnyGetter
    public Map<String, String> getData() {
        return data;
    }

    @JsonAnySetter
    public void setData(String key, String value) {
        this.data.put(key, value);
    }

    @Data
    public static class PaymentRecord {
        @JsonProperty("年月")
        private String yearAndMonth;

        @JsonProperty("申报的月缴费工资")
        private String declaredMonthlySalary;

        @JsonProperty("养老保险缴费信息")
        private PensionPaymentInfo pensionPaymentInfo;

        @JsonProperty("失业保险缴费信息")
        private UnemploymentInsurancePaymentInfo unemploymentInsurancePaymentInfo;

        @JsonProperty("工伤保险缴费信息")
        private InjuryInsurancePaymentInfo injuryInsurancePaymentInfo;

        @JsonProperty("医疗（生育）保险缴费信息")
        private MedicalInsurancePaymentInfo medicalInsurancePaymentInfo;
    }

    @Data
    public static class PensionPaymentInfo {
        @JsonProperty("月缴费基数")
        private String paymentBase;

        @JsonProperty("单位缴费")
        private String unitPayment;

        @JsonProperty("个人缴费")
        private String personalPayment;
    }

    @Data
    public static class UnemploymentInsurancePaymentInfo {
        @JsonProperty("月缴费基数")
        private String paymentBase;

        @JsonProperty("单位缴费")
        private String unitPayment;

        @JsonProperty("个人缴费")
        private String personalPayment;
    }

    @Data
    public static class InjuryInsurancePaymentInfo {
        @JsonProperty("月缴费基数")
        private String paymentBase;

        @JsonProperty("单位缴费个人不缴费")
        private String unitPayment;
    }

    @Data
    public static class MedicalInsurancePaymentInfo {
        @JsonProperty("月缴费基数")
        private String paymentBase;

        @JsonProperty("单位缴费")
        private String unitPayment;

        @JsonProperty("个人缴费")
        private String personalPayment;
    }
}
