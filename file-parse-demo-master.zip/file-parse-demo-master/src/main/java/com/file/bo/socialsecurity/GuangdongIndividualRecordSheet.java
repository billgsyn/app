package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * 个人权益记录单
 */
@Data
public class GuangdongIndividualRecordSheet {

    @JsonProperty("记录期间")
    private String recordPeriod;

    @JsonProperty("单位")
    private String unit;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("社会保障号码")
    private String socialSecurityNumber;

    @JsonProperty("个人编号")
    private String personalNumber;

    @JsonProperty("参保缴费记录")
    private List<InsurancePaymentRecord> insurancePaymentRecords;

    @JsonProperty("当年缴费月数合计")
    private List<String> totalNumberOfMonthsPaidInTheCurrentYear;

    @JsonProperty("截至本年末累计缴费月数")
    private List<String> accumulatedPaymentMonthsByTheEndOfTheCurrentYear;

    @JsonProperty("个人账户(本金)记录")
    private Map<String, String> personalAccountRecordMap;

    @JsonProperty("备注")
    private String comment;

    @Data
    public static class InsurancePaymentRecord {
        @JsonProperty("年月")
        private String yearAndMonth;

        @JsonProperty("养老保险")
        private Pension pension;

        @JsonProperty("失业保险")
        private UnemploymentInsurance unemploymentInsurance;

        @JsonProperty("工伤保险")
        private InjuryInsurance injuryInsurance;

    }

    @Data
    public static class Pension {
        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("单位缴费")
        private String unitPayment;

        @JsonProperty("个人缴费")
        private String personalPayment;
    }

    @Data
    public static class UnemploymentInsurance {
        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("单位缴费")
        private String unitPayment;

        @JsonProperty("个人缴费")
        private String personalPayment;
    }

    @Data
    public static class InjuryInsurance {
        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("单位缴费")
        private String unitPayment;
    }

}
