package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 平安银行流水字段
 * @author v_wbhwliu
 */
@Data
public class PAB2 {
    /**
     * 清单编号
     */
    @JsonProperty("清单编号")
    private String inventoryNumber;

    /**
     * 开立日期
     */
    @JsonProperty("开立日期")
    private String issuanceDate;

    /**
     * 户名
     */
    @JsonProperty("户名")
    private String name;

    /**
     * 卡号/账号
     */
    @JsonProperty("卡号/账号")
    private String accountNumber;

    /**
     * 存款类型
     */
    @JsonProperty("存款类型")
    private String depositType;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 开户行
     */
    @JsonProperty("开户行")
    private String accountBank;

    /**
     * 受理行
     */
    @JsonProperty("受理行")
    private String receivingBank;

    /**
     * 交易起止日期
     */
    @JsonProperty("交易起止日期")
    private String transactionDate;

    /**
     * 明细范围
     */
    @JsonProperty("明细范围")
    private String detailRange;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<PABTran2> pabTrans;
}