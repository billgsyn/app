package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class HunanInsuranceParticipation {

    @JsonProperty("当前单位名称")
    private String currentUnitName;

    @JsonProperty("分支单位")
    private String branchUnit;

    @JsonProperty("当前单位编号")
    private String currentUnitNumber;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("建账时间")
    private String accountOpeningTime;

    @JsonProperty("性别")
    private String gender;

    @JsonProperty("经办机构名称")
    private String handlingInstitutionName;

    @JsonProperty("身份证号码")
    private String idCardNumber;

    @JsonProperty("有效期至")
    private String validUntil;

    @JsonProperty("用途")
    private String purpose;

    @JsonProperty("参保关系")
    private List<InsuranceRelation> insuranceRelations;

    @JsonProperty("缴费明细")
    private List<PaymentDetail> paymentDetails;

    @JsonProperty("个人姓名")
    private String PersonName;

    @JsonProperty("个人编号")
    private String PersonID;

    @JsonProperty("备注")
    private String Remark;

    @Data
    public static class InsuranceRelation {
        @JsonProperty("统一社会信用代码")
        private String unifiedCreditCode;

        @JsonProperty("单位名称")
        private String unitName;

        @JsonProperty("险种")
        private String insuranceType;

        @JsonProperty("起止时间")
        private String startEndTime;

    }

    @Data
    public static class PaymentDetail {

        @JsonProperty("费款所属期")
        private String feePeriod;

        @JsonProperty("险种类型")
        private String insuranceType;

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("单位应缴")
        private String unitShouldPay;

        @JsonProperty("个人应缴")
        private String individualShouldPay;

        @JsonProperty("缴费标志")
        private String paymentFlag;

        @JsonProperty("到账日期")
        private String paymentDate;

        @JsonProperty("缴费类型")
        private String paymentType;

        @JsonProperty("经办机构")
        private String handlingInstitution;

    }

}
