package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 支付宝理财资产交易
 * @author anyspa
 */

@Data
public class AlipayAssetTransaction {
    @JsonProperty("姓名")
    private String name;

    @JsonProperty("身份证号码")
    private String idNo;

    @JsonProperty("编号")
    private String number;

    @JsonProperty("开具公司")
    private String issuingCompany;

    @JsonProperty("开具日期")
    private String issuingDate;

    @JsonProperty("交易明细列表")
    private List<AlipayAssetTransactionInfo> alipayAssetTransactionInfos;
}
