package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 个税申报收入明细(老版)
 * @author anyspa
 */

@Data
public class TaxiTran {
    @JsonProperty("所得项目")
    private String incomeItem;

    @JsonProperty("税款所属期")
    private String taxPeriod;

    @JsonProperty("申报日期")
    private String declarationDate;

    @JsonProperty("申报表类别")
    private String declarationFormType;

    @JsonProperty("收入(元)")
    private String income;

    @JsonProperty("应补（退）税额(元)")
    private String taxPayableRefundable;

    @JsonProperty("扣缴义务人")
    private String withholdAgent;

    @JsonProperty("操作")
    private String operate;
}
