package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * @author v_wbhwliu
 */
@Data
public class SPDTran {
    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String date;

    /**
     * 交易时间
     */
    @JsonProperty("交易时间")
    private String time;

    /**
     * 交易账号
     */
    @JsonProperty("交易账号")
    private String transactionAccount;

    /**
     * 交易名称
     */
    @JsonProperty("交易名称")
    private String transactionName;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String transactionAmount;

    /**
     * 账户余额
     */
    @JsonProperty("可用余额")
    private String balance;

    /**
     * 对手姓名
     */
    @JsonProperty("对手姓名")
    private String counterParty;

    /**
     * 对方账号
     */
    @JsonProperty("对手账号")
    private String opponentAccount;

    /**
     * 摘要
     */
    @JsonProperty("交易摘要")
    private String summary;
}
