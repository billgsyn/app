package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 成都不动产-交易房屋信息核实记录
 * @author anyspa
 */

@Data
public class CDBDCTradeHousingInfoVerificationRecord {
    @JsonProperty("文件信息")
    private FileInfo fileInfo;

    @JsonProperty("基本信息")
    private BasicInfo basicInfo;

    @JsonProperty("其他信息")
    private OtherInfo otherInfo;

    @Data
    public static class FileInfo {
        @JsonProperty("文件名")
        private String fileName;

        @JsonProperty("核实申请人")
        private String verificationApplicant;

        @JsonProperty("业务件号")
        private String itemNumber;

        @JsonProperty("验证码")
        private String verificationCode;

        @JsonProperty("查询编号")
        private String queryNumber;

        @JsonProperty("核实平台")
        private String verificationPlatform;

        @JsonProperty("打印机构")
        private String printingMechanism;

        @JsonProperty("核实时点")
        private String verificationTimePoint;

        @JsonProperty("特别提示")
        private String specialSuggestion;
    }

    @Data
    public static class BasicInfo {
        @JsonProperty("所在区")
        private String hostDistrict;

        @JsonProperty("街道")
        private String street;

        @JsonProperty("门牌")
        private String doorPlate;

        @JsonProperty("附号")
        private String attachedNumber;

        @JsonProperty("栋号")
        private String buildingNumber;

        @JsonProperty("单元")
        private String unit;

        @JsonProperty("楼层")
        private String floor;

        @JsonProperty("房号")
        private String roomNumber;

        @JsonProperty("规划用途")
        private String planningUsage;

        @JsonProperty("结构")
        private String structure;

        @JsonProperty("建筑面积")
        private String structureArea;

        @JsonProperty("所有方式")
        private String owningMethod;

        @JsonProperty("取得方式")
        private String gainingMethod;

        @JsonProperty("取得时间")
        private String gainingTime;

        @JsonProperty("签约备案时间")
        private String recordSigningTime;

        @JsonProperty("所有权人信息")
        private List<OwnerInfo> ownerInfoList;

        @JsonProperty("备注")
        private String comment;
    }

    @Data
    public static class OwnerInfo {

        @JsonProperty("所有权人")
        private String owner;

        @JsonProperty("证书编号")
        private String certificateNumber;
    }

    @Data
    public static class OtherInfo {
        @JsonProperty("是否抵押")
        private String isPledge;

        @JsonProperty("是否限制")
        private String isRestrict;

        @JsonProperty("是否征收")
        private String isLevy;

        @JsonProperty("是否是保障住房")
        private String isSubsidizedHousing;

        @JsonProperty("是否缴纳维修资金")
        private String isPayMaintenanceFund;

        @JsonProperty("是否租赁备案")
        private String isLeaseFiling;

        @JsonProperty("提示信息")
        private String promptMessage;
    }
}
