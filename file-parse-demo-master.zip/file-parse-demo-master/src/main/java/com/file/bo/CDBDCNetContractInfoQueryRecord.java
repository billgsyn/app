package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 成都不动产-网签合同信息查询记录
 * @author anyspa
 */

@Data
public class CDBDCNetContractInfoQueryRecord {
    @JsonProperty("文件信息")
    private FileInfo fileInfo;

    @JsonProperty("基本信息")
    private BasicInfo basicInfo;

    @JsonProperty("房屋信息")
    private HousingInfo housingInfo;

    @JsonProperty("出卖人")
    private Seller seller;

    @JsonProperty("买受人")
    private Buyer buyer;

    @JsonProperty("付款信息")
    private PaymentInfo paymentInfo;

    @JsonProperty("限制登记信息")
    private String restrictedRegistrationInfo;

    @JsonProperty("抵押信息")
    private List<MortgageInfo> mortgageInfoList;

    @Data
    public static class FileInfo {
        @JsonProperty("文件名")
        private String fileName;

        @JsonProperty("验证码")
        private String verificationCode;

        @JsonProperty("查询编号")
        private String queryNumber;

        @JsonProperty("查询平台")
        private String queryPlatform;

        @JsonProperty("查询时点")
        private String queryTimePoint;

        @JsonProperty("打印机构")
        private String printingMechanism;

        @JsonProperty("特别提示")
        private String specialSuggestion;
    }

    @Data
    public static class BasicInfo {
        @JsonProperty("网签（或备案）号")
        private String signedOnlineNo;

        @JsonProperty("网签（或备案）类型")
        private String signedOnlineType;

        @JsonProperty("网签（或备案）时间")
        private String signedOnlineTime;
    }

    @Data
    public static class HousingInfo {
        @JsonProperty("房屋地址")
        private String houseAddress;

        @JsonProperty("栋号")
        private String buildingNumber;

        @JsonProperty("单元")
        private String unit;

        @JsonProperty("楼层")
        private String floor;

        @JsonProperty("房号")
        private String roomNumber;

        @JsonProperty("结构")
        private String structure;

        @JsonProperty("用途")
        private String usage;

        @JsonProperty("建筑面积")
        private FloorArea floorArea;

        @JsonProperty("成交价")
        private String transactionPrice;
    }

    @Data
    public static class FloorArea {
        @JsonProperty("套内")
        private String insideArea;

        @JsonProperty("公摊")
        private String residentialPoolArea;

        @JsonProperty("合计")
        private String totalArea;
    }

    @Data
    public static class Buyer {
        @JsonProperty("买受人信息")
        private List<BuyerInfo> buyerInfoList;

        @JsonProperty("合同备注")
        private String contractComment;
    }

    @Data
    public static class BuyerInfo {
        @JsonProperty("名称")
        private String name;

        @JsonProperty("证件类型")
        private String idType;

        @JsonProperty("证件号码")
        private String idNo;

        @JsonProperty("份额")
        private String share;
    }

    @Data
    public static class Seller {
        @JsonProperty("出卖人信息")
        private List<SellerInfo> sellerInfoList;
    }

    @Data
    public static class SellerInfo {
        @JsonProperty("名称")
        private String name;

        @JsonProperty("证件类型")
        private String idType;

        @JsonProperty("证件号码")
        private String idNo;
    }

    @Data
    public static class PaymentInfo {
        @JsonProperty("付款类型")
        private String paymentType;

        @JsonProperty("贷款银行")
        private String lendingBank;

        @JsonProperty("贷款年限")
        private String loanPeriod;
    }

    @Data
    public static class MortgageInfo {
        @JsonProperty("抵押件号")
        private String mortgageNo;

        @JsonProperty("抵押权人")
        private String mortgagee;

        @JsonProperty("债务人")
        private String debtor;

        @JsonProperty("抵押面积（平方米）")
        private String mortgagedArea;

        @JsonProperty("被担保债权数额（元）")
        private String securedClaimAmount;

        @JsonProperty("债务履行期限")
        private String debtPerformancePeriod;

        @JsonProperty("状态")
        private String status;

        @JsonProperty("权利设定时间")
        private String rightEstablishmentTime;
    }

}
