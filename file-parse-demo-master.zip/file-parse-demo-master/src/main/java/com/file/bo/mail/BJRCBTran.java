package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 北京农商银行流水明细字段
 * @author anyspa
 */
@Data
public class BJRCBTran {

    /**
     * 交易时间
     */
    @JsonProperty("交易时间")
    private String transactionTime;

    /**
     * 交易流水号
     */
    @JsonProperty("交易流水号")
    private String tranSerialNo;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String transactionAmount;

    /**
     * 账户余额
     */
    @JsonProperty("账户余额")
    private String balance;

    /**
     * 摘要
     */
    @JsonProperty("摘要")
    private String summary;

    /**
     * 附言
     */
    @JsonProperty("附言")
    private String postscript;

    /**
     * 对方户名
     */
    @JsonProperty("对方户名")
    private String counterPartyAccountName;

    /**
     * 对方账号
     */
    @JsonProperty("对方账号")
    private String counterPartyAccountNumber;

    /**
     * 对方银行名称
     */
    @JsonProperty("对方银行名称")
    private String counterPartyBankName;
}
