package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class JiangxiInsuranceParticipation {

    @JsonProperty("个人基本信息")
    private PersonalBasicInformation personalBasicInformation;

    @JsonProperty("当前参保情况")
    private List<CurrentInsuranceStatus> currentInsuranceStatusList;

    @JsonProperty("社会保险缴费明细")
    private List<SocialInsurancePaymentDetails> socialInsurancePaymentDetailsList;

    @JsonProperty("申请查询日期")
    private String applicationQueryDate;

    @Data
    public static class PersonalBasicInformation {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("性别")
        private String gender;

        @JsonProperty("身份证号")
        private String idNo;

    }

    @Data
    public static class CurrentInsuranceStatus {

        @JsonProperty("个人社保编码")
        private String personalSocialSecurityNumber;

        @JsonProperty("险种名称")
        private String insuranceTypeName;

        @JsonProperty("参保状态")
        private String insuredStatus;

        @JsonProperty("参保地")
        private String insuredPlace;

        @JsonProperty("参保单位名称")
        private String insuredUnitName;

    }

    @Data
    public static class SocialInsurancePaymentDetails {

        @JsonProperty("个人社保编码")
        private String personalSocialSecurityNumber;

        @JsonProperty("险种名称")
        private String insuranceTypeName;

        @JsonProperty("缴费起止时间")
        private String paymentStartAndEndTime;

        @JsonProperty("月缴费基数")
        private String monthlyPaymentBase;

        @JsonProperty("是否到账")
        private String isPaymentReceived;

        @JsonProperty("缴费单位名称")
        private String paymentUnitName;

    }

}
