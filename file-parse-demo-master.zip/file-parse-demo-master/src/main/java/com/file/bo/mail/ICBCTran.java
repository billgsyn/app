package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * @author v_wbhwliu
 */
@Data
public class ICBCTran {
    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String tranDate;

    /**
     * 账号
     */
    @JsonProperty("账号")
    private String accountNo;

    /**
     * 储种
     */
    @JsonProperty("储种")
    private String accountType;

    /**
     * 序号
     */
    @JsonProperty("序号")
    private String sequenceNo;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 钞汇
     */
    @JsonProperty("钞汇")
    private String cashExchange;

    /**
     * 摘要
     */
    @JsonProperty("摘要")
    private String comment;

    /**
     * 地区
     */
    @JsonProperty("地区")
    private String zone;

    /**
     * 收入支出金额
     */
    @JsonProperty("收入支出金额")
    private String incomeExpenseAmt;

    /**
     * 余额
     */
    @JsonProperty("余额")
    private String balance;

    /**
     * 对方户名
     */
    @JsonProperty("对方户名")
    private String counterpartyName;

    /**
     * 对方账号
     */
    @JsonProperty("对方账号")
    private String conterpartyAccountNo;

    /**
     * 渠道
     */
    @JsonProperty("渠道")
    private String channel;
}
