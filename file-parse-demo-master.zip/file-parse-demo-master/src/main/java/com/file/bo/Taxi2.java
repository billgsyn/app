package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.file.bo.TaxiTran2;
import lombok.Data;

import java.util.List;

/**
 * 个税申报收入明细(新版)
 * @author anyspa
 */

@Data
public class Taxi2 {
    @JsonProperty("收入合计")
    private String incomeTotal;

    @JsonProperty("已申报税额合计")
    private String declaredTaxTotal;

    @JsonProperty("个税申报收入明细")
    private List<TaxiTran2> taxiTrans;

}
