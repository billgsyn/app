package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;


/**
 * 南京银行流水字段
 * @author v_wbhwliu
 */
@Data
public class NJCB {
    /**
     * 户名
     */
    @JsonProperty("户名")
    private String accountName;
    /**
     * 账号
     */
    @JsonProperty("账号")
    private String accountNo;

    /**
     * 账户类型
     */
    @JsonProperty("账户类型")
    private String accountType;

    /**
     * 开户行
     */
    @JsonProperty("开户行")
    private String subBranch;

    /**
     * 起止日期
     */
    @JsonProperty("起止日期")
    private String transDetailPeriod;

    /**
     * 申请时间
     */
    @JsonProperty("申请时间")
    private String applyDateTime;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<NJCBTran> njcbTrans;
}
