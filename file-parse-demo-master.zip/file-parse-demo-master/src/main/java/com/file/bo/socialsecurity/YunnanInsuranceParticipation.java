package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class YunnanInsuranceParticipation {

    @JsonProperty("城镇职工基本养老保险参保证明")
    PensionInsuranceCertificate pensionInsuranceCertificate;

    @JsonProperty("机关事业单位养老保险参保证明")
    PensionInsuranceCertificate institutionsPensionInsuranceCertificate;

    @JsonProperty("职工工伤保险参保证明")
    WorkersInjuryInsuranceCertificate workersInjuryInsuranceCertificate;

    @JsonProperty("失业保险参保证明")
    UnemploymentInsuranceCertificate unemploymentInsuranceCertificate;

    @Data
    public static class PensionInsuranceCertificate {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("性别")
        private String gender;

        @JsonProperty("个人编号")
        private String personalId;

        @JsonProperty("身份证号")
        private String idCardNumber;

        @JsonProperty("当前参保缴费状态")
        private String currentInsuranceStatus;

        @JsonProperty("实际缴费月数")
        private String paymentMonths;

        @JsonProperty("现参保单位")
        private String currentInsuranceCompany;

        @JsonProperty("个人参保缴费情况")
        private InsuranceDetail insuranceDetail;

        @JsonProperty("缴费明细")
        private List<FeeDetail> feeDetails;

        @JsonProperty("说明")
        private String explanation;

        @JsonProperty("制表人")
        private String tableCreator;

        @JsonProperty("打印日期")
        private String printDate;

    }

    @Data
    public static class InsuranceDetail {

        @JsonProperty("参保时间起止日期")
        private String insurancePeriod;

        @JsonProperty("参保单位")
        private String insuredCompany;

        @JsonProperty("经办机构")
        private String handlingAgency;

        @JsonProperty("险种")
        private String insuranceType;
    }

    @Data
    public static class FeeDetail {

        @JsonProperty("缴费年份")
        private String paymentYear;

        @JsonProperty("缴费月份")
        private String paymentMonth;

        @JsonProperty("消费基数")
        private String consumptionBase;

        @JsonProperty("单位缴纳")
        private String companyContribution;

        @JsonProperty("个人缴纳")
        private String individualContribution;

        @JsonProperty("缴费状态")
        private String paymentStatus;
    }


    @Data
    public static class WorkersInjuryInsuranceCertificate {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("性别")
        private String gender;

        @JsonProperty("个人编号")
        private String personalId;

        @JsonProperty("身份证号")
        private String idCardNumber;

        @JsonProperty("出生日期")
        private String dateOfBirth;

        @JsonProperty("参保单位")
        private String insuranceCompany;

        @JsonProperty("参保时间")
        private String insuranceDate;
    }


    @Data
    public static class UnemploymentInsuranceCertificate {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("性别")
        private String gender;

        @JsonProperty("个人编号")
        private String personalId;

        @JsonProperty("身份证号")
        private String idCardNumber;

        @JsonProperty("当前缴费状态")
        private String currentPaymentStatus;

        @JsonProperty("现参保单位")
        private String currentInsuranceCompany;

        @JsonProperty("参保机构")
        private String insuranceInstitution;
    }

}
