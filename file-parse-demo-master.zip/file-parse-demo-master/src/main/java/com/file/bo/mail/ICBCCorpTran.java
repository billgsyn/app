package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 工商银行企业版 交易明细
 */
@Data
public class ICBCCorpTran {

    @JsonProperty("交易时间")
    private String tranTime;

    @JsonProperty("本方账号")
    private String accountNo;

    @JsonProperty("对方户名")
    private String counterpartyAccountName;

    @JsonProperty("对方账号")
    private String counterpartyAccountNo;

    @JsonProperty("对方账号开户行")
    private String counterpartyBank;

    @JsonProperty("凭证号")
    private String voucherNo;

    @JsonProperty("借/贷")
    private String debitCredit;

    @JsonProperty("借方发生额")
    private String debitAmt;

    @JsonProperty("贷方发生额")
    private String creditAmt;

    @JsonProperty("摘要")
    private String summary;

    @JsonProperty("用途")
    private String purpose;

    @JsonProperty("余额")
    private String balance;

}
