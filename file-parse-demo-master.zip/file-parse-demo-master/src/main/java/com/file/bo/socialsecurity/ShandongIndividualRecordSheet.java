package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ShandongIndividualRecordSheet {

    @JsonProperty("记录期间")
    private String recordPeriod;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("单位名称")
    private String unitName;

    @JsonProperty("社会保障（身份证）号码")
    private String socialSecurityNumber;

    @JsonProperty("本人首次缴费年月")
    private MyFirstPaymentDate myFirstPaymentDate;

    @JsonProperty("缴费情况")
    private PaymentStatus paymentStatus;

    @JsonProperty("温馨提示")
    private String tips;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class MyFirstPaymentDate {

        @JsonProperty("养老保险")
        private String endowmentInsurance;

        @JsonProperty("工伤保险")
        private String employmentInjuryInsurance;

        @JsonProperty("失业保险")
        private String unemploymentInsurance;

        @JsonProperty("居民养老保险")
        private String residentPensionInsurance;

    }

    @Data
    public static class PaymentStatus {

        @JsonProperty("个人缴费基数")
        private IndividualPaymentBase individualPaymentBase;

        @JsonProperty("养老缴费信息")
        private PensionPaymentInformation pensionPaymentInformation;

        @JsonProperty("失业缴费信息")
        private UnemploymentPaymentInformation unemploymentPaymentInformation;

        @JsonProperty("工伤缴费信息")
        private EmploymentInjuryPaymentInformation employmentInjuryPaymentInformation;

        @JsonProperty("居民养老保险")
        private ResidentPensionInsurance residentPensionInsurance;

        @JsonProperty("养老保险截至本年末实际缴费月数")
        private String actualPaymentMonthsForPensionInsuranceByEndOfThisYear;

        @JsonProperty("居民养老保险截至本年末实际缴费年数")
        private String actualPaymentYearsForResidentPensionInsuranceByEndOfThisYear;

        @JsonProperty("养老保险截至本年末个人账户累计余额")
        private String accumulatedBalanceOfPersonalAccountForPensionInsuranceByEndOfThisYear;

    }

    @Data
    public static class IndividualPaymentBase {

        @JsonProperty("养老")
        private String endowment;

        @JsonProperty("工伤")
        private String employmentInjury;

        @JsonProperty("失业")
        private String unemployment;

    }

    @Data
    public static class PensionPaymentInformation {

        @JsonProperty("单位缴费额")
        private String unitPaymentAmount;

        @JsonProperty("个人缴费额")
        private String individualPaymentAmount;

    }

    @Data
    public static class UnemploymentPaymentInformation {

        @JsonProperty("单位缴费额")
        private String unitPaymentAmount;

        @JsonProperty("个人缴费额")
        private String individualPaymentAmount;

    }

    @Data
    public static class EmploymentInjuryPaymentInformation {

        @JsonProperty("单位缴费额")
        private String unitPaymentAmount;

    }

    @Data
    public static class ResidentPensionInsurance {

        @JsonProperty("年缴费额")
        private String annualPaymentAmount;

    }

}
