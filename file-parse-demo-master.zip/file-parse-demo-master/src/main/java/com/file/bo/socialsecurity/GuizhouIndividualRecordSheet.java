package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class GuizhouIndividualRecordSheet {

    @JsonProperty("记录期间")
    private String recordPeriod;

    @JsonProperty("个人基本信息")
    private PersonalInformation personalInformation;

    @JsonProperty("缴费情况")
    private PaymentStatus paymentStatus;

    @JsonProperty("个人账户情况")
    private PersonalAccountStatus personalAccountStatus;

    @Data
    public static class PersonalInformation {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("单位名称")
        private String unit;

        @JsonProperty("社会保障号")
        private String socialSecurityNumber;

        @JsonProperty("首次参保日期")
        private FirstEnrollmentDate firstEnrollmentDate;
    }
    @Data
    public static class FirstEnrollmentDate{

        @JsonProperty("养老")
        private String insuredPension;

        @JsonProperty("失业")
        private String insuredUnemployment;

        @JsonProperty("工伤")
        private String insuredWorkRelatedInjury;
    }

    @Data
    public static class PaymentStatus {

        @JsonProperty("个人月缴费基数")
        private MonthlyPersonalInsuranceBase monthlyPersonalInsuranceBase;

        @JsonProperty("工伤缴费信息")
        private WorkInjuryInsurancePayment workInjuryInsurancePayment;

        @JsonProperty("养老缴费信息")
        private PensionInsurancePayment pensionInsurancePayment;

        @JsonProperty("失业缴费信息")
        private UnemploymentPaymentInfo unemploymentPaymentInfo;

        @JsonProperty("截至本年末实际缴费月数")
        private ActualPaymentMonths actualPaymentMonths;
    }

    @Data
    public static class MonthlyPersonalInsuranceBase{

        @JsonProperty("养老")
        private String insuredPension;

        @JsonProperty("失业")
        private String insuredUnemployment;

        @JsonProperty("工伤")
        private String insuredWorkRelatedInjury;
    }

    @Data
    public static class WorkInjuryInsurancePayment {

        @JsonProperty("单位缴费")
        private String unitPayment;
    }

    @Data
    public static class UnemploymentPaymentInfo {

        @JsonProperty("单位缴费")
        private String unitPayment;

        @JsonProperty("个人缴费")
        private String personalPayment;
    }
    @Data
    public static class PensionInsurancePayment {

        @JsonProperty("单位缴费")
        private String unitPayment;

        @JsonProperty("个人缴费")
        private String personalPayment;
    }


    @Data
    public static class ActualPaymentMonths{

        @JsonProperty("养老")
        private String insuredPension;

        @JsonProperty("失业")
        private String insuredUnemployment;
    }

    @Data
    public static class PersonalAccountStatus {
        @JsonProperty("基本养老保险")
        private BasicPensionInsurance basicPensionInsurance;
    }

    @Data
    public static class BasicPensionInsurance {

        @JsonProperty("截至上年末个人账户累计储存额")
        private String basicPensionInsuranceAccumulation;

        @JsonProperty("当年记账金额")
        private String currentYearPensionInsuranceRecord;

        @JsonProperty("当年个人个账户支出金额")
        private String currentYearPensionInsuranceExpenditure;

        @JsonProperty("当年记账利息")
        private String currentYearPensionInsuranceInterest;

        @JsonProperty("至本年末账户累计储存额")
        private String pensionInsuranceAccumulationByYearEnd;
    }
}
