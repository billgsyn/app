package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 辽宁省社会保险个人权益信息表
 * @author anyspa
 */
@Data
public class LiaoningIndividualRecordSheet {

    @JsonProperty("记录期间")
    private String recordPeriod;

    @JsonProperty("个人基本信息")
    private PersonalInformation personalInformation;

    @JsonProperty("年度个人缴费情况")
    private PersonalPaymentRecordsOfYear personalPaymentRecordsOfYear;

    @JsonProperty("个人账户累计情况")
    private PersonalAccountAccumulate personalAccountAccumulate;

    @JsonProperty("温馨提示")
    private String tips;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class PersonalInformation {
        @JsonProperty("姓名")
        private String name;
        @JsonProperty("证件类型")
        private String idType;
        @JsonProperty("证件号码")
        private String idNo;
        @JsonProperty("企业职工养老保险参保时间")
        private String enterpriseWorkPensionInsurancePeriod;
        @JsonProperty("机关事业养老保险参保时间")
        private String causeWorkPensionInsurancePeriod;
        @JsonProperty("城乡居民养老保险参保时间")
        private String urbanResidentsPensionInsurancePeriod;
        @JsonProperty("工伤保险参保时间")
        private String injuryInsuranceInsurancePeriod;
        @JsonProperty("失业保险参保时间")
        private String unemploymentInsurancePeriod;
    }

    @Data
    public static class PersonalPaymentRecordsOfYear {
        @JsonProperty("企业职工养老保险")
        private EnterpriseWorkPension enterpriseWorkPension;
        @JsonProperty("机关事业养老保险")
        private CauseWorkPension causeWorkPension;
        @JsonProperty("城乡居民养老保险")
        private UrbanResidentsPension urbanResidentsPension;
        @JsonProperty("工伤保险")
        private InjuryInsurance injuryInsurance;
        @JsonProperty("失业保险")
        private UnemploymentInsurance unemploymentInsurance;

    }

    @Data
    public static class EnterpriseWorkPension {
        @JsonProperty("缴费月数")
        private String paymentMonths;
        @JsonProperty("缴费基数金额合计")
        private String paymentBaseTotal;
        @JsonProperty("个人缴费金额合计")
        private String personalPaymentBaseTotal;
    }

    @Data
    public static class CauseWorkPension {
        @JsonProperty("缴费月数")
        private String paymentMonths;
        @JsonProperty("缴费基数金额合计")
        private String paymentBaseTotal;
        @JsonProperty("个人缴费金额合计")
        private String personalPaymentBaseTotal;
        @JsonProperty("职业年金个人缴费金额合计")
        private String personalPaymentBaseTotalOfWorkYear;
    }

    @Data
    public static class UrbanResidentsPension {
        @JsonProperty("缴费月数")
        private String paymentMonths;
        @JsonProperty("缴费基数金额合计")
        private String paymentBaseTotal;
        @JsonProperty("个人缴费金额合计")
        private String personalPaymentBaseTotal;
    }

    @Data
    public static class InjuryInsurance {
        @JsonProperty("缴费月数")
        private String paymentMonths;
        @JsonProperty("缴费基数金额合计")
        private String paymentBaseTotal;
        @JsonProperty("个人缴费金额合计")
        private String personalPaymentBaseTotal;
    }

    @Data
    public static class UnemploymentInsurance {
        @JsonProperty("缴费月数")
        private String paymentMonths;
        @JsonProperty("缴费基数金额合计")
        private String paymentBaseTotal;
        @JsonProperty("个人缴费金额合计")
        private String personalPaymentBaseTotal;
    }

    @Data
    public static class PersonalAccountAccumulate {
        @JsonProperty("企业职工养老保险截至到上年度末个人账户本息合计")
        private String enterpriseWorkPensionBalance;
        @JsonProperty("机关事业养老保险截至到上年度末个人账户本息合计")
        private String causeWorkPensionBalance;
        @JsonProperty("机关事业职业年金截至到当前个人账户本息合计")
        private String causeWorkCareerPensionBalance;
        @JsonProperty("城乡居民养老年保险截至到上年度末个人账户本息合计")
        private String urbanResidentsPensionBalance;
        @JsonProperty("社会保险经办机构名称")
        private String socialInsuranceAgencyName;
    }

}
