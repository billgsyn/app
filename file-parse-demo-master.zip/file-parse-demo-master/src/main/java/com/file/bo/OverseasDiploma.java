package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class OverseasDiploma {
	
	@JsonProperty("姓名")
	private String name;
	
	@JsonProperty("认证书编号")
	private String certificateNo;
	
	@JsonProperty("性别")
	private String sex;
	
	@JsonProperty("国籍")
	private String nationality;
	
	@JsonProperty("毕业学校(留学地)")
	private String graduateSchool;
	
	@JsonProperty("学位")
	private String academicDegree;
	
	@JsonProperty("专业")
	private String major;
	
	@JsonProperty("入学日期")
	private String dateOfEnrollment;
	
	@JsonProperty("颁证日期")
	private String dateOfCertificateIssuance;
	
	@JsonProperty("认证日期")
	private String dateOfAuthentication;

}