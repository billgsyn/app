package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 民生银行（表头字段包含中英文, 交易字段不包含"凭证类型"、"凭证号码"、"对方户名/账号"、"对方行名"、"交易机构"字段版本）
 * @author anyspa
 */
@Data
public class CMBCTran2 {

    /**
     * 交易时间
     */
    @JsonProperty("交易时间")
    private String transactionTime;

    /**
     * 摘要
     */
    @JsonProperty("摘要")
    private String summary;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String transactionAmount;

    /**
     * 账户余额
     */
    @JsonProperty("账户余额")
    private String balance;

    /**
     * 现转标志
     */
    @JsonProperty("现转标志")
    private String cashTransfer;

    /**
     * 交易渠道
     */
    @JsonProperty("交易渠道")
    private String transactionChannel;

}
