package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 恒丰银行流水明细
 * @author anyspa
 */

@Data
public class HFBTran {

    @JsonProperty("记账日")
    private String bookkeepingDate;

    @JsonProperty("交易日期")
    private String transactionDate;

    @JsonProperty("交易时间")
    private String transactionTime;

    @JsonProperty("支出")
    private String expense;

    @JsonProperty("收入")
    private String income;

    @JsonProperty("账户余额")
    private String accountBalance;

    @JsonProperty("币种")
    private String currency;

    @JsonProperty("摘要")
    private String summary;

    @JsonProperty("对方账号")
    private String counterPartyAccountNumber;

    @JsonProperty("对方户名")
    private String counterPartyAccountName;

    @JsonProperty("交易地点")
    private String tradingPlace;
}
