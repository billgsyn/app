package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 四川省社会保险个人参保证明
 * @author anyspa
 */

@Data
public class SichuangInsuranceParticipation {

    @JsonProperty("参保人姓名")
    private String name;

    @JsonProperty("性别")
    private String gender;

    @JsonProperty("社会保障号码")
    private String socialSecurityNumber;

    @JsonProperty("历年参保基本情况")
    private List<CalendarYearInsuranceParticipationRecord> calendarYearInsuranceParticipationRecordList;

    @JsonProperty("参保缴费明细")
    private List<PastTwoYearInsuranceParticipationRecord> pastTwoYearInsuranceParticipationRecordList;

    @JsonProperty("说明")
    private String verifyDescription;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class CalendarYearInsuranceParticipationRecord {
        @JsonProperty("险种")
        private String type;

        @JsonProperty("当前缴费状态")
        private String currentPaymentStatus;

        @JsonProperty("累计月数")
        private String totalMonth;
    }

    @Data
    public static class PastTwoYearInsuranceParticipationRecord {
        @JsonProperty("缴费月份")
        private String paymentMonth;

        @JsonProperty("参保单位编号")
        private String insuredUnitCode;

        @JsonProperty("二级单位编码")
        private String secondaryUnitCode;

        @JsonProperty("养老保险")
        private EndowmentInsurance endowmentInsurance;

        @JsonProperty("失业保险")
        private UnemploymentInsurance unemploymentInsurance;

        @JsonProperty("工伤保险")
        private EmploymentInjuryInsurance employmentInjuryInsurance;

        @JsonProperty("参保地")
        private String paymentLocation;

    }

    @Data
    public static class EndowmentInsurance {
        @JsonProperty("类型")
        private String type;

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("单位缴纳")
        private String unitPayment;

        @JsonProperty("个人缴纳")
        private String personalPayment;
    }

    @Data
    public static class UnemploymentInsurance {

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("单位缴纳")
        private String unitPayment;

        @JsonProperty("个人缴纳")
        private String personalPayment;
    }

    @Data
    public static class EmploymentInjuryInsurance {

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("单位缴纳")
        private String unitPayment;
    }


}
