package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class HenanInsuranceParticipation {

    @JsonProperty("表单验证号码")
    private String formVerifyNo;

    @JsonProperty("年份")
    private String year;

    @JsonProperty("证件类型")
    private String idType;

    @JsonProperty("证件号码")
    private String idNo;

    @JsonProperty("社会保障号码")
    private String socialSecurityNumber;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("性别")
    private String gender;

    @JsonProperty("参保起止时间")
    private List<ParticipationInSocialInsurance> participationInSocialInsuranceList;

    @JsonProperty("缴费明细情况")
    private PaymentDetails paymentDetails;

    @JsonProperty("说明")
    private String description;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class ParticipationInSocialInsurance {

        @JsonProperty("单位名称")
        private String unitName;

        @JsonProperty("险种类型")
        private String insuranceType;

        @JsonProperty("起始年月")
        private String startDate;

        @JsonProperty("截止年月")
        private String endDate;

    }

    @Data
    public static class PaymentDetails {

        @JsonProperty("基本养老保险")
        private BasicEndowmentInsurance basicEndowmentInsurance;

        @JsonProperty("失业保险")
        private UnemploymentInsurance unemploymentInsurance;

        @JsonProperty("工伤保险")
        private EmploymentInjuryInsurance employmentInjuryInsurance;

    }

    @Data
    public static class BasicEndowmentInsurance {

        @JsonProperty("参保时间")
        private String insurancePeriod;

        @JsonProperty("缴费状态")
        private String paymentStatus;

        @JsonProperty("缴费记录")
        private List<PaymentRecord> paymentRecordList;

    }

    @Data
    public static class UnemploymentInsurance {

        @JsonProperty("参保时间")
        private String insurancePeriod;

        @JsonProperty("缴费状态")
        private String paymentStatus;

        @JsonProperty("缴费记录")
        private List<PaymentRecord> paymentRecordList;

    }

    @Data
    public static class EmploymentInjuryInsurance {

        @JsonProperty("参保时间")
        private String insurancePeriod;

        @JsonProperty("缴费状态")
        private String paymentStatus;

        @JsonProperty("缴费记录")
        private List<PaymentRecord> paymentRecordList;

    }

    @Data
    public static class PaymentRecord {

        @JsonProperty("年月")
        private String yearMonth;

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("缴费情况")
        private String paymentStatus;

    }

}
