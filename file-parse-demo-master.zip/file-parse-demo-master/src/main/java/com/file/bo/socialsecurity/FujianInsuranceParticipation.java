package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;


@Data
public class FujianInsuranceParticipation {

    @JsonProperty("个人编号")
    private String personalId;

    @JsonProperty("身份证号")
    private String idNo;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("缴费情况")
    private List<FujianInsuranceParticipation.PaymentStatus> paymentStatusList;

    @JsonProperty("注")
    private String notes;

    @JsonProperty("经办人")
    private String operator;

    @JsonProperty("打印机构")
    private String printMechanism;

    @JsonProperty("打印日期")
    private String printTime;

    @Data
    public static class PaymentStatus {

        @JsonProperty("序号")
        private String serialNumber;

        @JsonProperty("参保地经办机构")
        private String insuranceAgencyInTheInsuredArea;

        @JsonProperty("单位编号")
        private String unitNumber;

        @JsonProperty("单位名称")
        private String unitName;

        @JsonProperty("建账年月")
        private String accountEstablishmentYearMonth;

        @JsonProperty("缴费对应起始至截止")
        private String paymentCorrespondsToTheStartToEndPeriod;

        @JsonProperty("月数")
        private String monthNumber;

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("缴费性质")
        private String paymentNature;

    }

}
