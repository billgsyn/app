package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 南昌不动产
 * @author anyspa
 */

@Data
public class NCBDC {

    @JsonProperty("受理编号")
    private String acceptNo;

    @JsonProperty("使用账号")
    private String account;

    @JsonProperty("查询时间")
    private String queryDate;

    @JsonProperty("权利人")
    private String obligee;

    @JsonProperty("证件号码")
    private String idNo;

    @JsonProperty("不动产权证号")
    private String realEstateOwnershipCertificateNo;

    @JsonProperty("不动产单元号")
    private String realEstateUnitNo;

    @JsonProperty("土地证号")
    private String landCertificateNo;

    @JsonProperty("状态")
    private String status;

    @JsonProperty("登记时间")
    private String registrationDate;

    @JsonProperty("权利类型")
    private String rightType;

    @JsonProperty("权利性质")
    private String natureOfRights;

    @JsonProperty("不动产面积（m²）")
    private String area;

    @JsonProperty("用途")
    private String use;

    @JsonProperty("共有情况")
    private String coOwnership;

    @JsonProperty("使用期限（年）")
    private String serviceLife;

    @JsonProperty("坐落")
    private String location;

    @JsonProperty("附记")
    private String supplement;

    @JsonProperty("抵押信息")
    private List<MortgageInfo> mortgageInfoList;

    @JsonProperty("查封信息")
    private List<SealUpInfo> sealUpInfoList;

    // 抵押信息
    @Data
    public static class MortgageInfo {
        @JsonProperty("序号")
        private String serialNo;

        @JsonProperty("抵押权人")
        private String mortgagee;

        @JsonProperty("不动产证明号")
        private String realEstateCertificateNo;

        @JsonProperty("抵押金额")
        private String mortgageAmount;

        @JsonProperty("权利起始时间")
        private String rightStartDate;

        @JsonProperty("权利结束时间")
        private String rightEndDate;

        @JsonProperty("抵押期限（年）")
        private String mortgagePeriod;

        @JsonProperty("登记时间")
        private String registrationDate;
    }

    // 查封信息
    @Data
    public static class SealUpInfo {
        @JsonProperty("序号")
        private String serialNo;

        @JsonProperty("查封机关")
        private String sealUpAuthority;

        @JsonProperty("查封文号")
        private String sealUpDocument;

        @JsonProperty("查封类型")
        private String sealUpType;

        @JsonProperty("查封起始时间")
        private String sealUpStartDate;

        @JsonProperty("查封截止时间")
        private String sealUpEndDate;

        @JsonProperty("查封期限（年）")
        private String sealUpPeriod;

        @JsonProperty("送达时间")
        private String serviceDate;
    }

}
