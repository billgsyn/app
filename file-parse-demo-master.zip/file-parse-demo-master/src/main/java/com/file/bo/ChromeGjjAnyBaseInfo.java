package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 公积金PC html的缴存基本信息详情页
 * @author anyspa
 * @date 2024-04-12
 */
@Data
public class ChromeGjjAnyBaseInfo {


    @JsonProperty("个人信息")
    private PersonalInfo personalInfo;
    @JsonProperty("缴存信息")
    private DepositInfo depositInfo;
    @JsonProperty("中心信息")
    private CenterInfo centerInfo;

    /**
     * 个人信息
     */
    @Data
    public static class PersonalInfo {
        @JsonProperty("姓名")
        private String name;
        @JsonProperty("证件类型")
        private String idType;
        @JsonProperty("证件号码")
        private String idNo;
        @JsonProperty("手机号码")
        private String phoneNumber;
        @JsonProperty("个人账号")
        private String personalAccount;
        @JsonProperty("个人账户状态")
        private String personalAccountStatus;
        @JsonProperty("个人账户余额")
        private String personalAccountBalance;
    }

    /**
     * 缴存信息
     */
    @Data
    public static class DepositInfo {
        @JsonProperty("个人缴存基数")
        private String personalDepositBase;
        @JsonProperty("单位缴存比例")
        private String companyDepositRatio;
        @JsonProperty("个人缴存比例")
        private String personalDepositRatio;
        @JsonProperty("单位月缴存额")
        private String companyMonthlyDeposit;
        @JsonProperty("个人月缴存额")
        private String personalMonthlyDeposit;
    }

    /**
     * 中心信息
     */
    @Data
    public static class CenterInfo {
        @JsonProperty("中心名称")
        private String centerName;
        @JsonProperty("中心编号")
        private String centerNumber;
        @JsonProperty("单位名称")
        private String companyName;
    }

}
