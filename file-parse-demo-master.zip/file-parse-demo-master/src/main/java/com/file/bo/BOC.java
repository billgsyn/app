package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * @author v_wbhwliu
 */
@Data
public class BOC {

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<BOCTran> bocTrans;
}
