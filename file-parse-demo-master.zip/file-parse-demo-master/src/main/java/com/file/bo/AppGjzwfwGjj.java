package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 国家政务服务平台-住房公积金
 * @author anyspa
 */

@Data
public class AppGjzwfwGjj {

    @JsonProperty("个人信息")
    private PersonalInfo personalInfo;

    @JsonProperty("中心信息")
    private CenterInfo centerInfo;

    @JsonProperty("缴存信息")
    private DepositInfo depositInfo;

    // 个人信息
    @Data
    public static class PersonalInfo {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("手机号码")
        private String phoneNumber;

        @JsonProperty("个人账号")
        private String personalAccount;

        @JsonProperty("个人账户状态")
        private String personalAccountStatus;

        @JsonProperty("个人账户余额")
        private String personalAccountBalance;
    }

    // 中心信息
    @Data
    public static class CenterInfo {

        @JsonProperty("中心编号")
        private String centerNumber;

        @JsonProperty("中心名称")
        private String centerName;

        @JsonProperty("单位名称")
        private String companyName;
    }

    // 缴存信息
    @Data
    public static class DepositInfo {

        @JsonProperty("个人缴存比例")
        private String personalDepositRatio;

        @JsonProperty("单位缴存比例")
        private String companyDepositRatio;

        @JsonProperty("个人缴存基数")
        private String personalDepositBase;

        @JsonProperty("个人月缴存额")
        private String personalMonthlyDeposit;

        @JsonProperty("单位月缴存额")
        private String companyMonthlyDeposit;
    }
}
