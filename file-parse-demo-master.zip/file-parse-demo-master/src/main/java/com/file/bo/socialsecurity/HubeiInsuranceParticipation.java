package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 湖北省个人参保证明
 * @author anyspa
 */

@Data
public class HubeiInsuranceParticipation {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("性别")
    private String gender;

    @JsonProperty("个人编号")
    private String personalNumber;

    @JsonProperty("社会保障号")
    private String socialSecurityNumber;

    @JsonProperty("参保缴费地")
    private String insurancePaymentLocation;

    @JsonProperty("本地缴费月数")
    private String localPaymentMonths;

    @JsonProperty("参保险种")
    private String typesOfInsurance;

    @JsonProperty("缴费地最末所在单位")
    private UnitOfLastPaymentPlace unitOfLastPaymentPlace;

    @JsonProperty("缴费情况")
    private List<InsuranceParticipationRecord> insuranceParticipationRecordList;

    @JsonProperty("备注")
    private String comment;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class UnitOfLastPaymentPlace {
        @JsonProperty("单位编号")
        private String unitNo;

        @JsonProperty("单位名称")
        private String unitName;
    }

    @Data
    public static class InsuranceParticipationRecord {
        @JsonProperty("记录月份")
        private String recordMonth;

        @JsonProperty("单位名称")
        private String unitName;

        @JsonProperty("缴费基数(元)")
        private String paymentBase;

        @JsonProperty("缴费类型")
        private String paymentType;
    }
}
