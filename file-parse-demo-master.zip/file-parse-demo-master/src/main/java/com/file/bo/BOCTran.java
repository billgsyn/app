package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 中行csv交易流水
 * @author v_wbhwliu
 */
@Data
public class BOCTran {
    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String transactionDate;

    /**
     * 业务摘要
     */
    @JsonProperty("业务摘要")
    private String businessSummary;

    /**
     * 对方账户名称
     */
    @JsonProperty("对方账户名称")
    private String counterPartyAccountName;

    /**
     * 对方账户账号
     */
    @JsonProperty("对方账户账号")
    private String counterPartyAccountNumber;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 钞/汇
     */
    @JsonProperty("钞/汇")
    private String cashExchange;

    /**
     * 收入金额
     */
    @JsonProperty("收入金额")
    private String revenueAmount;

    /**
     * 支出金额
     */
    @JsonProperty("支出金额")
    private String expenseAmount;

    /**
     * 余额
     */
    @JsonProperty("余额")
    private String balance;

    /**
     * 交易渠道
     */
    @JsonProperty("交易渠道")
    private String transactionChannel;

    /**
     * 网点名称
     */
    @JsonProperty("网点名称")
    private String outletName;

    /**
     * 附言
     */
    @JsonProperty("附言")
    private String additionalComments;
}
