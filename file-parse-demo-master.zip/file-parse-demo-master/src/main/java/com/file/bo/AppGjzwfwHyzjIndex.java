package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 国家政务APP-婚姻证件详情
 * @author anyspa
 */

@Data
public class AppGjzwfwHyzjIndex {

    @JsonProperty("证件名称")
    private String certificateName;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("证件号")
    private String certificateNumber;

    @JsonProperty("证照颁发机构")
    private String certificateIssuingAgency;

    @JsonProperty("证照颁发日期")
    private String certificateIssuingDate;

}
