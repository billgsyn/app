package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 机动车检验合格标志
 * @author anyspa
 */

@Data
public class AppTmriXszDzxsz {

    @JsonProperty("正页")
    private MainPage mainPage;

    @JsonProperty("副页")
    private SupplementaryPage supplementaryPage;

    @Data
    public static class MainPage {

        @JsonProperty("车辆类型")
        private String vehicleType;

        @JsonProperty("号牌号码")
        private String numberPlate;

        @JsonProperty("使用性质")
        private String usageNature;

        @JsonProperty("状态")
        private String status;

        @JsonProperty("所有人")
        private String owner;

        @JsonProperty("品牌型号")
        private String brandModel;

        @JsonProperty("车辆识别代号")
        private String vehicleIdentificationNumber;

        @JsonProperty("发动机号码")
        private String engineNumber;

        @JsonProperty("注册日期")
        private String registrationDate;

        @JsonProperty("发证日期")
        private String certificateIssueDate;

        @JsonProperty("检验有效期")
        private String inspectionValidityPeriod;

        @JsonProperty("生成时间")
        private String generationTime;

        @JsonProperty("证芯编号")
        private String certificateCoreNumber;

    }

    @Data
    public static class SupplementaryPage {

        @JsonProperty("强制报废期止")
        private String forcedScrapDate;

        @JsonProperty("车身颜色")
        private String bodyColor;

        @JsonProperty("能源种类")
        private String energyType;

        @JsonProperty("核定载人数")
        private String ratedPassengerCapacity;

        @JsonProperty("外廓尺寸")
        private String dimensions;

        @JsonProperty("总质量")
        private String totalMass;

        @JsonProperty("整备质量")
        private String curbWeight;

        @JsonProperty("核定载质量")
        private String ratedLoadCapacity;

        @JsonProperty("准牵引总质量")
        private String towingCapacity;

        @JsonProperty("住址")
        private String address;

        @JsonProperty("发证机关")
        private String issuingAuthority;

        @JsonProperty("备注")
        private String remarks;

    }

}
