package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
  * 微信流水交易明细
 * @author lingfenghe
 *
 */
@Data
public class WechatPayTran {
	
	@JsonProperty("交易单号")
	private String tranOrderId;
	
	@JsonProperty("交易时间")
	private String tranDate;
	
	@JsonProperty("交易类型")
	private String tranType;
	
	@JsonProperty("收/支/其它")
	private String incomeOrExpense;
	
	@JsonProperty("交易方式")
	private String tranMethod;
	
	@JsonProperty("金额(元)")
	private String tranAmt;
	
	@JsonProperty("交易对方")
	private String tranConterParty;
	
	@JsonProperty("商户单号")
	private String merchantOrderId;
	
}
