package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 支付宝理财资产交易明细
 * @author anyspa
 */

@Data
public class AlipayAssetTransactionInfo {
    @JsonProperty("订单号")
    private String orderNum;

    @JsonProperty("交易时间")
    private String transDate;

    @JsonProperty("交易类型")
    private String transType;

    @JsonProperty("基金名称")
    private String fundName;

    @JsonProperty("组合基金名称")
    private String mutualFundName;

    @JsonProperty("基金代码")
    private String fundCode;

    @JsonProperty("申请金额")
    private String appliedAmount;

    @JsonProperty("申请份额")
    private String appliedShare;

    @JsonProperty("确认金额")
    private String confirmedAmount;

    @JsonProperty("确认份额")
    private String confirmedShare;

    @JsonProperty("手续费")
    private String commission;

    @JsonProperty("确认日期")
    private String confirmedDate;
}
