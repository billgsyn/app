package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 机动车检验合格标志
 * @author anyspa
 */

@Data
public class AppTmriXszJyhgbz {

    @JsonProperty("检验有效期至")
    private String expiryDateOfInspection;

    @JsonProperty("号牌号码")
    private String numberPlate;

    @JsonProperty("号牌种类")
    private String plateType;

    @JsonProperty("车辆识别代码")
    private String vehicleIdentificationCode;

    @JsonProperty("使用性质")
    private String natureOfUse;

    @JsonProperty("车辆类型")
    private String vehicleType;

    @JsonProperty("检验机构")
    private String inspectionAgency;

    @JsonProperty("合格标志号")
    private String conformityMarkNo;
}
