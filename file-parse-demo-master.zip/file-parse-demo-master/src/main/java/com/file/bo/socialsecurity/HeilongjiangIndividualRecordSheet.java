package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class HeilongjiangIndividualRecordSheet {

    @JsonProperty("年度")
    private String year;

    @JsonProperty("个人基本信息")
    private PersonalInfo personalInfo;

    @JsonProperty("缴费情况")
    private ContributionDetails contributionDetails;

    @JsonProperty("个人账户情况")
    private AccountDetails accountDetails;

    @JsonProperty("养老金领取情况")
    private PensionDetails pensionDetails;

    @JsonProperty("社会保险经办机构名称")
    private String insuranceOfficeName;

    @JsonProperty("联系电话")
    private String contactPhone;

    @JsonProperty("地址")
    private String address;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class PersonalInfo {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("单位名称")
        private String companyName;

        @JsonProperty("首次参保日期")
        private String firstEnrollmentDate;

        @JsonProperty("社会保障号码")
        private String socialSecurityNumber;

    }

    @Data
    public static class ContributionDetails {

        @JsonProperty("个人月缴费基数")
        private String monthlyContributionBase;

        @JsonProperty("单位缴费")
        private String companyContribution;

        @JsonProperty("个人缴费")
        private String personalContribution;

        @JsonProperty("本年个人补缴欠费金额")
        private String annualArrearsPayment;

        @JsonProperty("补历年缴费月数")
        private String monthsOfArrearsCompensation;

        @JsonProperty("截至本年末实际缴费月数")
        private String actualPaidMonthsByYearEnd;

        @JsonProperty("累计欠缴月数")
        private String accumulatedUnpaidMonths;

    }

    @Data
    public static class AccountDetails {

        @JsonProperty("截至上年末个人账户累计储存额")
        private String cumulativeBalanceAtLastYearEnd;

        @JsonProperty("当年记账金额")
        private String currentYearBookkeepingAmount;

        @JsonProperty("当年个人账户支出金额")
        private String currentYearAccountExpenditure;

        @JsonProperty("当年记账利息")
        private String currentYearInterest;

        @JsonProperty("至本年末账户累计储存额")
        private String cumulativeBalanceAtThisYearEnd;

    }

    @Data
    public static class PensionDetails {

        @JsonProperty("月养老金水平")
        private String monthlyPensionLevel;

        @JsonProperty("当年调待金额")
        private String currentYearAdjustmentAmount;

    }

}
