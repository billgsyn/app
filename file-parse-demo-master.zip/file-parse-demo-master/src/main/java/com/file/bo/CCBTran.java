package com.file.bo;

import lombok.Data;

/**
  * 建行PC端Excel版流水文件交易明细
 * @author lingfenghe
 *
 */
@Data
public class CCBTran {
	
	/**
	  * 记账日
	 */
	private String bookkeepingDate;
	
	/**
	  * 交易日期
	 */
	private String transactionDate;
	
	/**
	  * 交易时间
	 */
	private String transactionTime;
	
	/**
	  * 支出
	 */
	private String expense;
	
	/**
	  * 收入
	 */
	private String revenue;
	
	/**
	  * 账户余额
	 */
	private String accountbalance;
	
	/**
	  * 币种
	 */
	private String currency;
	
	/**
	  * 摘要
	 */
	private String summary;
	
	/**
	  * 对方账号
	 */
	private String counterPartyAccountNumber;
	
	/**
	  * 对方户名
	 */
	private String counterPartyAccountName;
	
	/**
	  * 交易地点
	 */
	private String tradingPlace;

}
