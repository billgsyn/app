package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 深圳市社保
 * @author v_wbhwliu
 */
@Data
public class SzSocialInsurance {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("社保电脑号")
    private String computerNo;

    @JsonProperty("身份证号码")
    private String idNo;

    @JsonProperty("页码")
    private String pageNo;

    @JsonProperty("最近参保单位名称")
    private String participatingCompany;

    @JsonProperty("单位编号")
    private String companyNo;

    @JsonProperty("计算单位")
    private String calculateUnit;

    @JsonProperty("养老个人账户余额")
    private String pensionPersonalAccountBalance;

    @JsonProperty("医疗个人账户余额")
    private String medicalPersonalAccountBalance;

    @JsonProperty("单位编号对应的单位名称")
    private List<InsuranceCompanyInfo> insuranceCompanyList;

    @JsonProperty("缴费明细")
    private List<SzSocialInsuranceTran> socialInsuranceTranList;

    // 单位编号对应的单位名称
    @Data
    public static class InsuranceCompanyInfo {

        @JsonProperty("单位编号")
        private String companyNo;

        @JsonProperty("单位名称")
        private String companyName;
    }
}

