package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ChromeGjjAnyLoanBasicInfo {

    @JsonProperty("还款信息")
    private RepaymentInfo repaymentInfo;

    @JsonProperty("贷款信息")
    private LoanInfo loanInfo;

    @JsonProperty("申请人信息")
    private ApplicantInfo applicantInfo;

    @JsonProperty("房屋信息")
    private HouseInfo houseInfo;

//    @JsonProperty("还款明细")
//    private List<RepaymentDetail> repaymentDetailList;

    @Data
    public static class RepaymentInfo {

        @JsonProperty("本期应还(元)")
        private String currentRepaymentAmount;

        @JsonProperty("贷款余额(元)")
        private String loanBalance;

        @JsonProperty("累计已还本金(元)")
        private String totalRepaidPrincipal;

        @JsonProperty("累计已还利息(元)")
        private String totalRepaidInterest;

        @JsonProperty("贷款总额(元)")
        private String totalLoanAmount;

    }

    @Data
    public static class LoanInfo {

        @JsonProperty("贷款账号")
        private String loanAccount;

        @JsonProperty("借款合同编号")
        private String loanContractNumber;

        @JsonProperty("贷款金额(元)")
        private String loanAmount;

        @JsonProperty("贷款余额(元)")
        private String currentLoanBalance;

        @JsonProperty("贷款利息")
        private String loanInterest;

        @JsonProperty("还款方式")
        private String repaymentMethod;

        @JsonProperty("贷款期次")
        private String loanPeriod;

        @JsonProperty("约定放款日期")
        private String agreedDisbursementDate;

        @JsonProperty("约定到期日期")
        private String agreedMaturityDate;

    }

    @Data
    public static class ApplicantInfo {

        @JsonProperty("借款人姓名")
        private String borrowerName;

        @JsonProperty("借款人证件号码")
        private String borrowerIdNumber;

        @JsonProperty("共同借款人姓名")
        private String coBorrowerName;

        @JsonProperty("共同借款人证件号码")
        private String coBorrowerIdNumber;

    }

    @Data
    public static class HouseInfo {

        @JsonProperty("房屋类型")
        private String houseType;

        @JsonProperty("购房合同号")
        private String housePurchaseContractNumber;

        @JsonProperty("建筑面积")
        private String buildingArea;

        @JsonProperty("购房总价")
        private String houseTotalPrice;

        @JsonProperty("房屋坐落")
        private String houseLocation;

    }


}
