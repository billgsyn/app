package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 深圳社保缴费明细
 * @author anyspa
 */
@Data
public class SzSocialInsuranceTran {

    @JsonProperty("缴费年")
    private String paymentYear;

    @JsonProperty("月")
    private String paymentMonth;

    @JsonProperty("单位编号")
    private String companyNo;

    @JsonProperty("养老保险")
    private Pension pension;

    @JsonProperty("医疗保险")
    private MedicalInsurance medicalInsurance;

    @JsonProperty("生育")
    private Fertility fertility;

    @JsonProperty("工伤保险")
    private InjuryInsurance injuryInsurance;

    @JsonProperty("失业保险")
    private UnemploymentInsurance unemploymentInsurance;

    @Data
    static class BaseInsuranceInfo {

        @JsonProperty("基数")
        private String base;

        @JsonProperty("单位交")
        private String companyPays;
    }

    // 养老保险
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class Pension extends BaseInsuranceInfo {

        @JsonProperty("个人交")
        private String personalPays;
    }

    // 医疗保险
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class MedicalInsurance extends BaseInsuranceInfo {

        @JsonProperty("险种")
        private String type;

        @JsonProperty("个人交")
        private String personalPays;
    }

    // 工伤保险
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class InjuryInsurance extends BaseInsuranceInfo {
    }

    // 失业保险
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class UnemploymentInsurance extends BaseInsuranceInfo {

        @JsonProperty("个人交")
        private String personalPays;
    }

    // 生育保险
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class Fertility extends BaseInsuranceInfo {

        @JsonProperty("险种")
        private String type;
    }
}





