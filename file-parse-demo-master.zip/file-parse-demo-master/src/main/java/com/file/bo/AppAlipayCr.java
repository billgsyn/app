package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AppAlipayCr {

    @JsonProperty("芝麻分")
    private String zhimaScore = "";

    @JsonProperty("上次更新")
    private String lastUpdate = "";

    @JsonProperty("用例说明")
    private String caseDesc = "";

}
