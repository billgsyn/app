package com.file.bo;

import lombok.Data;

import java.util.List;

/**
  * 建行PC端Excel版流水文件交易明细
 * @author lingfenghe
 *
 */
@Data
public class CCB {
	
	/**
	  * 开户机构
	 */
	private String accountOpeningInstitution;
	
	/**
	  * 币种
	 */
	private String currency;
	
	/**
	  * 账号
	 */
	private String accountNumber;
	
	/**
	 * 建行流水交易明细
	 */
	private List<CCBTran> ccbTrans;

}
