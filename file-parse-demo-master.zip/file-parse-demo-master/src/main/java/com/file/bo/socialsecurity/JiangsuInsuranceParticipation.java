package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;
import java.util.Objects;

@Data
public class JiangsuInsuranceParticipation {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("公民身份号码（社会保障号）")
    private String socialSecurityNumber;

    @JsonProperty("性别")
    private String gender;

    @JsonProperty("参加社会保险基本情况")
    private ParticipationInSocialInsurance participationInSocialInsurance;

    @JsonProperty("缴费情况")
    private List<PaymentStatus> paymentStatusList;

    @JsonProperty("说明")
    private String description;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class ParticipationInSocialInsurance {

        @JsonProperty("险种")
        private List<String> insuranceTypeList;

        @JsonProperty("参保状态")
        private List<String> insuranceStatusList;

        @JsonProperty("现参保单位全称")
        private String currentInsuredUnitFullName;

        @JsonProperty("现参保地")
        private String currentInsuredLocation;

    }

    @Data
    @EqualsAndHashCode
    public static class PaymentStatus {

        @JsonProperty("年")
        private String year;

        @JsonProperty("月")
        private String month;

        @JsonProperty("单位全称")
        private String unitFullName;

        @JsonProperty("养老保险")
        private EndowmentInsurance endowmentInsurance;

        @JsonProperty("失业保险")
        private UnemploymentInsurance unemploymentInsurance;

        @JsonProperty("工伤保险")
        private EmploymentInjuryInsurance employmentInjuryInsurance;

        @JsonProperty("备注")
        private String notes;

    }

    @Data
    public static class EndowmentInsurance {

        @JsonProperty("缴费基数（元）")
        private String paymentBase;

        @JsonProperty("个人缴费（元）")
        private String individualPayment;

    }

    @Data
    public static class UnemploymentInsurance {

        @JsonProperty("缴费基数（元）")
        private String paymentBase;

        @JsonProperty("个人缴费（元）")
        private String individualPayment;

    }

    @Data
    public static class EmploymentInjuryInsurance {

        @JsonProperty("缴费基数（元）")
        private String paymentBase;

    }

}
