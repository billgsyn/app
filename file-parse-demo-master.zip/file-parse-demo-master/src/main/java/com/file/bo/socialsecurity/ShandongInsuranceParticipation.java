package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ShandongInsuranceParticipation {

    //证明编号、姓名、身份证号码、当前参保单位、参保状态、参保情况（险种、参保起止时间、累计缴费月数）、备注、打印时间
    @JsonProperty("证明编号")
    private String proofNumber;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("身份证号码")
    private String idNo;

    @JsonProperty("当前参保单位")
    private String currentInsuredUnit;

    @JsonProperty("参保状态")
    private String insuranceStatus;

    @JsonProperty("参保情况")
    private List<InsuranceDetails> insuranceDetailsList;

    @JsonProperty("备注")
    private String notes;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class InsuranceDetails {

        @JsonProperty("险种")
        private String insuranceType;

        @JsonProperty("参保起止时间")
        private String insuranceStartAndEndTime;

        @JsonProperty("累计缴费月数")
        private String accumulatedPaymentMonths;

    }


}
