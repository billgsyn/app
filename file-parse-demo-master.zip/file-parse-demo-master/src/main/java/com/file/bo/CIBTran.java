package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 兴业银行流水明细
 * @author anyspa
 */

@Data
public class CIBTran {

    @JsonProperty("交易时间")
    private String transactionTime;

    @JsonProperty("记账日")
    private String bookkeepingDate;

    @JsonProperty("支出")
    private String expense;

    @JsonProperty("收入")
    private String income;

    @JsonProperty("账户余额")
    private String accountBalance;

    @JsonProperty("摘要")
    private String summary;

    @JsonProperty("对方户名")
    private String counterPartyAccountName;

    @JsonProperty("对方银行")
    private String counterPartyBank;

    @JsonProperty("对方账号")
    private String counterPartyAccountNumber;

    @JsonProperty("用途")
    private String use;

    @JsonProperty("交易渠道")
    private String transactionChannel;

    @JsonProperty("备注")
    private String comment;

}
