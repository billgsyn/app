package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ShanxiInsuranceParticipation {

    @JsonProperty("验证编号")
    private String verifyNo;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("身份证号")
    private String idNo;

    @JsonProperty("人员参保关系ID")
    private String personnelInsuranceRelationshipId;

    @JsonProperty("个人编号")
    private String personalId;

    @JsonProperty("现缴费单位名称")
    private String currentPaymentUnitName;

    @JsonProperty("缴费情况")
    private List<PaymentDetails> paymentDetailsList;

    @JsonProperty("现参保经办机构")
    private String currentInsuranceAgency;

    @JsonProperty("打印时间")
    private String printTime;

    @JsonProperty("说明")
    private String description;

    @Data
    public static class PaymentDetails {

        @JsonProperty("序号")
        private String serialNumber;

        @JsonProperty("缴费年度")
        private String paymentYear;

        @JsonProperty("缴费月份")
        private String paymentMonth;

        @JsonProperty("个人缴费")
        private String personalPayment;

        @JsonProperty("对应缴费单位名称")
        private String correspondingPaymentUnitName;

        @JsonProperty("经办机构")
        private String handlingAgency;

    }

}
