package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 公积金PC html的缴存明细详情
 * @author anyspa
 * @date 2024-04-12
 */
@Data
public class ChromeGjjAnyDetail {


    @JsonProperty("近三年缴存明细")
    private List<ChromeGjjAnyHtmlDetailInfo> list;

    @Data
    public static class ChromeGjjAnyHtmlDetailInfo {

        @JsonProperty("序号")
        private String serialNum;

        @JsonProperty("时间")
        private String dateTime;

        @JsonProperty("业务类型")
        private String businessType;

        @JsonProperty("缴存金额(元)")
        private String depositAmount;

        @JsonProperty("账户余额(元)")
        private String depositBalance;
    }

}
