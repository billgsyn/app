package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 山西省个人权益记录单
 */

@Data
public class Shanxi2IndividualRecordSheet {

    @JsonProperty("姓名")
    private String name;

}
