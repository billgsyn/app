package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ShanghaiInsuranceParticipation {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("社会保障号码")
    private String socialSecurityNumber;

    @JsonProperty("证件号码")
    private String idNo;

    @JsonProperty("缴费情况")
    private List<PaymentDetail> paymentDetailList;

    @JsonProperty("缴费单位信息")
    private List<PaymentUnitInformation> paymentUnitInformationList;

    @JsonProperty("累计缴费月数")
    private String accumulatedPaymentMonths;

    @JsonProperty("备注")
    private String notes;

    @JsonProperty("经办机构")
    private String printMechanism;

    @JsonProperty("打印日期")
    private String printTime;

    @Data
    public static class PaymentDetail {

        @JsonProperty("序号")
        private String serialNumber;

        @JsonProperty("年月")
        private String date;

        @JsonProperty("缴费情况")
        private String paymentStatus;

        @JsonProperty("补缴退账年月")
        private String supplementaryPaymentAndRefundDate;

    }

    @Data
    public static class PaymentUnitInformation {

        @JsonProperty("缴费单位名称")
        private String paymentUnitName;

        @JsonProperty("缴费起止时间")
        private String paymentStartAndEndTime;

    }

}
