package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 光大银行流水明细
 * @author anyspa
 */

@Data
public class CEBTran {

    @JsonProperty("交易日期")
    private String transactionDate;

    @JsonProperty("支出金额")
    private String expenseAmount;

    @JsonProperty("存入金额")
    private String incomeAmount;

    @JsonProperty("账户余额")
    private String accountBalance;

    @JsonProperty("对方账号")
    private String counterPartyAccountNumber;

    @JsonProperty("对方户名")
    private String counterPartyAccountName;

    @JsonProperty("摘要")
    private String summary;
}
