package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 丰巢-江苏银行的pdf字段
 * @author v_wbstlu
 * @date 2023-09-25
 */
@Data
public class JsBank {

    /**
     * 卡号
     */
    @JsonProperty("卡号")
    private String cardNo;

    /**
     * 客户名称
     */
    @JsonProperty("客户名称")
    private String name;

    /**
     * 开始日期
     */
    @JsonProperty("开始日期")
    private String startDate;

    /**
     * 结束日期
     */
    @JsonProperty("结束日期")
    private String endDate;

    /**
     * 申请时间
     */
    @JsonProperty("申请时间")
    private String applyDateTime;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<JsBankTran> jsBankTrans;
}
