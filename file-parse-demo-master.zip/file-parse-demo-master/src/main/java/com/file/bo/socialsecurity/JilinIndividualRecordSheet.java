package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class JilinIndividualRecordSheet {

    @JsonProperty("账户类别")
    private String accountType;

    @JsonProperty("个人基本信息")
    private JilinInsuranceParticipation.PersonalBasicInformation personalBasicInformation;

    @JsonProperty("参保缴费")
    private JilinInsuranceParticipation.InsurancePaymentSituation insurancePaymentSituation;

    @JsonProperty("待遇领取情况")
    private JilinInsuranceParticipation.BenefitReceiptSituation benefitReceiptSituation;

    @JsonProperty("温馨提示")
    private String warmTips;

    @JsonProperty("经办人")
    private String handler;

    @JsonProperty("经办时间")
    private String handlingTime;

    @JsonProperty("打印时间")
    private String printTime;


    @Data
    public static class PersonalBasicInformation {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("证件类型")
        private String idType;

        @JsonProperty("证件号码")
        private String idNo;

        @JsonProperty("性别")
        private String gender;

        @JsonProperty("出生日期")
        private String birthDate;

        @JsonProperty("个人编号")
        private String personalId;

        @JsonProperty("生存状态")
        private String survivalStatus;

        @JsonProperty("参工时间")
        private String employmentDate;

    }

    @Data
    public static class InsurancePaymentSituation {

        @JsonProperty("险种")
        private String insuranceType;

        @JsonProperty("缴费状态")
        private String paymentStatus;

        @JsonProperty("参保单位名称")
        private String insuredUnitName;

        @JsonProperty("参保时间")
        private String insuranceTime;

        @JsonProperty("缴费记录开始时间")
        private String paymentRecordStartTime;

        @JsonProperty("缴费记录结束时间")
        private String paymentRecordEndTime;

        @JsonProperty("实际缴费月数")
        private String actualPaymentMonths;

    }

    @Data
    public static class BenefitReceiptSituation {

        @JsonProperty("险种")
        private String insuranceType;

        @JsonProperty("离退休时间(失业时间)")
        private String retirementDate;

        @JsonProperty("待遇领取开始时间")
        private String benefitReceiptStartTime;

        @JsonProperty("待遇领取结束时间")
        private String benefitReceiptEndTime;

        @JsonProperty("发放状态")
        private String issuingStatus;

        @JsonProperty("当前待遇金额（元）")
        private String currentBenefitAmount;

        @JsonProperty("待遇类型")
        private String benefitType;

        @JsonProperty("应享月数")
        private String entitledMonths;

        @JsonProperty("已领月数")
        private String receivedMonths;

        @JsonProperty("剩余月数")
        private String remainingMonths;

        @JsonProperty("终止原因")
        private String terminationReason;

        @JsonProperty("终止经办时间")
        private String terminationHandlingTime;

    }
    
}
