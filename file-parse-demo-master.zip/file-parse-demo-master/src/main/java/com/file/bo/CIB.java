package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.file.bo.CIBTran;
import lombok.Data;

import java.util.List;

/**
 * 兴业银行
 * @author anyspa
 */

@Data
public class CIB {

    @JsonProperty("账户别名")
    private String accountAlias;

    @JsonProperty("账户户名")
    private String accountName;

    @JsonProperty("账户账号")
    private String accountNo;

    @JsonProperty("卡内账户")
    private String InCardAccount;

    @JsonProperty("起始日期")
    private String startDate;

    @JsonProperty("截止日期")
    private String expirationDate;

    @JsonProperty("下载日期")
    private String downloadDate;

    @JsonProperty("交易明细")
    private List<CIBTran> cibTrans;
}
