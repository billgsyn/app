package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 个税申报收入明细(新版)
 * @author anyspa
 */

@Data
public class TaxiTran2 {
    @JsonProperty("所得项目")
    private String incomeItem;

    @JsonProperty("税款所属期起")
    private String taxPeriodStartDate;

    @JsonProperty("税款所属期止")
    private String taxPeriodEndDate;

    @JsonProperty("申报日期")
    private String declarationDate;

    @JsonProperty("申报表类别")
    private String declarationFormType;

    @JsonProperty("本期收入(元)")
    private String currentIncome;

    @JsonProperty("已申报税额(元)")
    private String declaredTax;

    @JsonProperty("所得来源单位(个人)")
    private String incomeSourceUnit;

    @JsonProperty("操作")
    private String operate;
}
