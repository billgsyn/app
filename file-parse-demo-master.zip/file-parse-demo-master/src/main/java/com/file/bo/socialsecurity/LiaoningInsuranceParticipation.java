package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 辽宁省社会保险个人参保证明
 * @author anyspa
 */
@Data
public class LiaoningInsuranceParticipation {

    @JsonProperty("姓名")
    private String name;


}
