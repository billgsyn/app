/**
* Copyright (C) 2016, GIAYBAC
*
* Released under the MIT license
*/
package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 *  支付宝流水交易明细
 * @author lingfenghe
 *
 */
@Data
public class AliPayTran {
	
	@JsonProperty("收/支")
	private String incomeOrExpense;
	
	@JsonProperty("交易对方")
	private String counterParty;
	
	@JsonProperty("商品说明")
	private String productDescription;
	
	@JsonProperty("收/付款方式")
	private String paymentMethod;
	
	@JsonProperty("金额")
	private String amt;
	
	@JsonProperty("交易订单号")
	private String tranOrderNo;
	
	@JsonProperty("商家订单号")
	private String merchantOrderNo;
	
	@JsonProperty("交易时间")
	private String tranDate;
	
}
