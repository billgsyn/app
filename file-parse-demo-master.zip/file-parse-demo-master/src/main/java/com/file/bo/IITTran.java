package com.file.bo;

import lombok.Data;


/**
 *  个人所得税纳税记录
 * @author trentchen
 *
 */
@Data
public class IITTran {
	
    /**
           * 申报日期
     */
    private String declarationDate;

    /**
           * 实缴（退）金额
     */
    private String paidInOutAmount;

    /**
           * 入（退）库日期
     */
    private String StockInOutDate;

    /**
           * 所得项目
     */
    private String incomeItem;

    /**
           * 税款所属期
     */
    private String taxPeriod;

    /**
           * 入库税务机关
     */
    private String stockInTaxAuthority;

    /**
           * 备注
     */
    private String comment;
}
