package com.file.bo;

import lombok.Data;

import java.util.List;

/**
 *  
 * @author trentchen
 *
 */
@Data
public class IIT {
	
    /**
     * 记录期间
     */
    private String recordPeriod;

    /**
     * 纳税人名称
     */
    private String taxpayerName;

    /**
     * 纳税人识别号
     */
    private String taxpayerIdNo;

    /**
     * 身份证件类型
     */
    private String idCardType;

    /**
     * 身份证件号码
     */
    private String idNo;

    /**
     * 金额单位
     */
    private String amountUnit;

    /**
           * 开具日期
     */
    private String issueDate;

    /**
           * 个人所得税纳税记录
     */
    List<IITTran> iitTrans;
}
