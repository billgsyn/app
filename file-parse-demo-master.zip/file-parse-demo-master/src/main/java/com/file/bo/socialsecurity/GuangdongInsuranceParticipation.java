package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 个人参保证明
 */
@Data
public class GuangdongInsuranceParticipation {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("证件号码")
    private String idNo;

    @JsonProperty("参保险种情况")
    private List<InsuranceParticipationRecord> insuranceParticipationRecordList;

    @Data
    public static class InsuranceParticipationRecord {

        @JsonProperty("参保起止时间")
        private String insuranceParticipationStartAndEndTime;

        @JsonProperty("单位")
        private String unit;

        @JsonProperty("参保险种（养老）")
        private String insuredPension;

        @JsonProperty("参保险种（工伤）")
        private String insuredWorkRelatedInjury;

        @JsonProperty("参保险种（失业）")
        private String insuredUnemployment;

    }

    @JsonProperty("证明时间")
    private String proofTime;

}
