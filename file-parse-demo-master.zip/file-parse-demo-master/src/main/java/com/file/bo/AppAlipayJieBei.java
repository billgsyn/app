package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 借呗
 * @author anyspa
 */

@Data
public class AppAlipayJieBei {

    @JsonProperty("可借金额")
    private String borrowableAmount = "";

    @JsonProperty("年利率")
    private String annualInterestRate = "";

    @JsonProperty("总额度")
    private String totalAmount = "";

    @JsonProperty("逾期金额")
    private String overdueAmt = "";

    @JsonProperty("用例说明")
    private String caseDesc = "";

}
