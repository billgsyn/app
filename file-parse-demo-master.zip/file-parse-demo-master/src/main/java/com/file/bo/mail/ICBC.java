package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.file.bo.mail.ICBCTran;
import lombok.Data;

import java.util.List;


/**
 * 工商银行流水字段
 * @author v_wbhwliu
 */
@Data
public class ICBC {
    /**
     * 卡号
     */
    @JsonProperty("卡号")
    private String cardNo;

    /**
     * 户名
     */
    @JsonProperty("户名")
    private String name;

    /**
     * 起止日期
     */
    @JsonProperty("起止日期")
    private String transDetailPeriod;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<ICBCTran> icbcTrans;
}
