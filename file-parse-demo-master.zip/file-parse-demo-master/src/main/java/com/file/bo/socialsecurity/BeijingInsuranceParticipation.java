package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 北京市社会保险个人参保证明
 * @author anyspa
 */

@Data
public class BeijingInsuranceParticipation {
    @JsonProperty("参保人姓名")
    private String name;

    @JsonProperty("校验码")
    private String verifyCode;

    @JsonProperty("社会保障号码")
    private String socialInsuranceNo;

    @JsonProperty("查询流水号")
    private String queryFlowingNo;

    @JsonProperty("单位名称")
    private String companyName;

    @JsonProperty("查询日期")
    private String queryDate;

    @JsonProperty("养老保险单位变动记录")
    private List<PensionUnitChangeRecord> pensionUnitChangeRecords;

    @JsonProperty("养老保险累计实际缴费年限")
    private String pensionActualTotalPaymentYears;

    @JsonProperty("医疗保险累计实际缴费年限")
    private String medicalActualTotalPaymentYears;

    @JsonProperty("养老保险个人账户本息合计金额")
    private String pensionPersonalAccountBalance;

    @JsonProperty("五险缴费明细")
    private List<SocialInsurancePaymentTran> socialInsurancePaymentTrans;

    // 养老保险单位变动记录
    @Data
    public static class PensionUnitChangeRecord {

        @JsonProperty("缴费起始年月")
        private String paymentStartDate;

        @JsonProperty("缴费截止年月")
        private String paymentEndDate;

        @JsonProperty("实际缴费月数")
        private String actualPaymentMonths;

        @JsonProperty("单位名称")
        private String companyName;

        @JsonProperty("缴费区县")
        private String paymentDistrict;
    }

    // 五险缴费明细
    @Data
    public static class SocialInsurancePaymentTran {

        @JsonProperty("缴费起止年月")
        private String paymentStartAndEndDate;

        @JsonProperty("养老实际缴费")
        private PensionActualPayment pensionActualPayment;

        @JsonProperty("失业实际缴费")
        private UnemploymentActualPayment unemploymentActualPayment;

        @JsonProperty("工伤实际缴费")
        private InjuryActualPayment injuryActualPayment;

        @JsonProperty("医疗实际缴费")
        private MedicalActualPayment medicalActualPayment;

        @JsonProperty("生育实际缴费")
        private FertilityActualPayment fertilityActualPayment;

    }
    @Data
    static class BaseInsuranceInfo {

        @JsonProperty("月数")
        private String month;

        @JsonProperty("年缴费基数")
        private String annualPaymentBase;
    }

    // 养老实际缴费
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class PensionActualPayment extends BaseInsuranceInfo {
        @JsonProperty("个人缴费")
        private String personalPayment;
    }

    // 失业实际缴费
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class UnemploymentActualPayment extends BaseInsuranceInfo {
        @JsonProperty("个人缴费")
        private String personalPayment;
    }

    // 工伤实际缴费
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class InjuryActualPayment extends BaseInsuranceInfo {}

    // 医疗实际缴费
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class MedicalActualPayment extends BaseInsuranceInfo {
        @JsonProperty("个人缴费")
        private String personalPayment;
    }

    // 生育实际缴费
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class FertilityActualPayment extends BaseInsuranceInfo {}
}
