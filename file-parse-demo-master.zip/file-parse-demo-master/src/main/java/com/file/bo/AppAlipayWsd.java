package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 网商贷
 * @author anyspa
 */

@Data
public class AppAlipayWsd {

    @JsonProperty("可借金额")
    private String borrowableAmount = "";

    @JsonProperty("原年利率")
    private String originalAnnualInterestRate = "";

    @JsonProperty("优惠年利率")
    private String preferentialAnnualInterestRate = "";

    @JsonProperty("总额度")
    private String totalAmount = "";

    @JsonProperty("逾期金额")
    private String overdueAmt = "";

    @JsonProperty("用例说明")
    private String caseDesc = "";

    @JsonProperty("其他")
    private String other = "";

    @Data
    public static class AggregateInfo {
        @JsonProperty("贷款机构")
        private String lenders;

        @JsonProperty("总额度(元)")
        private String totalAmount;

        @JsonProperty("可借金额(元)")
        private String borrowableAmount;

        @JsonProperty("年利率")
        private String annualInterestRate;
    }

}
