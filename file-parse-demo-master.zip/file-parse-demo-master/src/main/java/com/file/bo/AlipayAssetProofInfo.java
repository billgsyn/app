package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 支付宝理财资产证明-资产信息
 * @author anyspa
 */

@Data
public class AlipayAssetProofInfo {

    @JsonProperty("序号")
    private String serialNum;

    @JsonProperty("基金交易账号")
    private String fundTransactionAccount;

    @JsonProperty("基金名称")
    private String fundName;

    @JsonProperty("基金代码")
    private String fundCode;

    @JsonProperty("总份额")
    private String totalShare;

    @JsonProperty("单位净值")
    private String averageNAV;

    @JsonProperty("单位净值日期")
    private String unitNetValueDate;

    @JsonProperty("资产小计")
    private String subtotalOfAssets;

}
