package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;


@Data
public class ChongqingInsuranceParticipation {

    @JsonProperty("参保人姓名")
    private String name;

    @JsonProperty("性别")
    private String gender;

    @JsonProperty("社会保障号码")
    private String socialSecurityNumber;

    @JsonProperty("历年参保基本情况")
    private List<InsuranceBasicInfo> basicInfos;

    @JsonProperty("参保缴费明细")
    private List<InsuranceDetail> insuranceDetails;

    @JsonProperty("打印日期")
    private String printTime;

    @JsonProperty("说明")
    private String verifyDescription;


    @Data
    public static class InsuranceBasicInfo {
        @JsonProperty("险种")
        private String insuranceType;

        @JsonProperty("当前缴费状态")
        private String currentPaymentStatus;

        @JsonProperty("实际缴费月数")
        private String actualPaymentMonths;
    }

    @Data
    public static class InsuranceDetail {
        @JsonProperty("缴费月份")
        private String paymentMonth;

        @JsonProperty("养老保险")
        private PensionInsurance pensionInsurance;

        @JsonProperty("失业保险")
        private UnemploymentInsurance unemploymentInsurance;

        @JsonProperty("工伤保险")
        private WorkInjuryInsurance workInjuryInsurance;
    }

    @Data
    public static class PensionInsurance {
        @JsonProperty("险种")
        private String insuranceType;

        @JsonProperty("单位编号")
        private String unitId;

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("个人缴纳")
        private String individualContribution;

        @JsonProperty("单位缴纳")
        private String unitContribution;

        @JsonProperty("缴费地")
        private String paymentLocation;
    }

    @Data
    public static class UnemploymentInsurance {
        @JsonProperty("单位编号")
        private String unitId;

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("个人缴纳")
        private String individualContribution;

        @JsonProperty("单位缴纳")
        private String unitContribution;

        @JsonProperty("缴费地")
        private String paymentLocation;
    }

    @Data
    public static class WorkInjuryInsurance {
        @JsonProperty("单位编号")
        private String unitId;

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("个人缴纳")
        private String individualContribution;

        @JsonProperty("单位缴纳")
        private String unitContribution;

        @JsonProperty("缴费地")
        private String paymentLocation;
    }

}
