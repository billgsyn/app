package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 学籍查询
 * @author anyspa
 */

@Data
public class Chsixj {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("性别")
    private String sex;

    @JsonProperty("证件号码")
    private String idNo;

    @JsonProperty("民族")
    private String nationality;

    @JsonProperty("出生日期")
    private String dateOfBirth;

    @JsonProperty("院校")
    private String schoolName;

    @JsonProperty("层次")
    private String degree;

    @JsonProperty("院系")
    private String schoolDepartment;

    @JsonProperty("班级")
    private String className;

    @JsonProperty("专业")
    private String major;

    @JsonProperty("学号")
    private String studentId;

    @JsonProperty("形式")
    private String learningStyle;

    @JsonProperty("入学时间")
    private String dateOfEnrollment;

    @JsonProperty("学制")
    private String schoolSystem;

    @JsonProperty("类型")
    private String diplomaClassification;

    @JsonProperty("学籍状态")
    private String graduation;

    @JsonProperty("在线验证码")
    private String onlineVerificationCode;

    @JsonProperty("更新日期")
    private String updateDate;
}
