package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.file.bo.mail.CITICTran;
import lombok.Data;

import java.util.List;


/**
 * 中信银行流水
 * @author v_wbhwliu
 */
@Data
public class CITIC {

    @JsonProperty("户名")
    private String accountName;

    @JsonProperty("证件类型")
    private String idType;
    
    @JsonProperty("证件号码")
    private String idNumber;

    @JsonProperty("账号")
    private String accountNo;
    
    @JsonProperty("时间段")
    private String inquiryPeriod;

    @JsonProperty("开立日期")
    private String issuanceDate;
    
    @JsonProperty("查询最低限额")
    private String inquireTheMinimumLimit;
    
    @JsonProperty("币种")
    private String currency;

    @JsonProperty("交易明细")
    private List<CITICTran> citicTrans;
}

