package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class GuangxiIndividualRecordSheet {

    @JsonProperty("时间")
    private String time;

    @JsonProperty("个人编号")
    private String personalId;

    @JsonProperty("个人基本信息")
    private PersonalBasicInfo personalBasicInfo;

    @JsonProperty("缴费情况")
    private ContributionInfo contributionInfo;

    @JsonProperty("个人账户情况")
    private IndividualAccountInfo individualAccountInfo;

    @JsonProperty("地址")
    private String address;

    @JsonProperty("联系电话")
    private String phoneNumber;

    @Data
    public static class PersonalBasicInfo {
        @JsonProperty("姓名")
        private String name;
        @JsonProperty("单位名称")
        private String organizationName;
        @JsonProperty("社会保障号码")
        private String socialSecurityNumber;
        @JsonProperty("首次参保日期")
        private InitialEnrollmentDates initialEnrollmentDates;
    }

    @Data
    public static class InitialEnrollmentDates {
        @JsonProperty("养老")
        private String pension;
        @JsonProperty("失业")
        private String unemployment;
        @JsonProperty("工伤")
        private String injury;
    }
    @Data
    public static class ContributionInfo {
        @JsonProperty("个人月缴费基数")
        private ContributionBaseInfo contributionBase;
        @JsonProperty("养老缴费信息")
        private PensionContribution pensionContribution;
        @JsonProperty("失业缴费信息")
        private UnemploymentContribution unemploymentContribution;
        @JsonProperty("工伤缴费信息")
        private InjuryContribution injuryContribution;
        @JsonProperty("本年个人补缴欠费金额")
        private ArrearsPaymentInfo currentYearArrearsPayment;
        @JsonProperty("补历年缴费月数")
        private ArrearsPaymentInfo pastYearsContributionMonths;
        @JsonProperty("截至本年末实际缴费月数")
        private ArrearsPaymentInfo actualContributionMonthsThisYear;
        @JsonProperty("累计欠费月数")
        private ArrearsPaymentInfo accumulatedArrearsMonths;

    }
    @Data
    public static class ContributionBaseInfo {
        @JsonProperty("养老")
        private String pension;
        @JsonProperty("失业")
        private String unemployment;
        @JsonProperty("工伤")
        private String injury;
    }

    @Data
    public static class ArrearsPaymentInfo {
        @JsonProperty("养老")
        private String pension;
        @JsonProperty("失业")
        private String unemployment;
    }
    @Data
    public static class PensionContribution {
        @JsonProperty("单位缴费")
        private String unitContribution;
        @JsonProperty("个人缴费")
        private String personalContribution;
    }
    @Data
    public static class UnemploymentContribution {
        @JsonProperty("单位缴费")
        private String unitContribution;
        @JsonProperty("个人缴费")
        private String personalContribution;
    }
    @Data
    public static class InjuryContribution {
        @JsonProperty("单位缴费")
        private String unitContribution;
    }
    @Data
    public static class IndividualAccountInfo {
        @JsonProperty("基本养老保险")
        private BasicPensionInsuranceInfo basicPensionInsurance;
        @JsonProperty("养老金领取情况")
        private PensionBenefitInfo pensionBenefitInfo;

        @JsonProperty("失业保险待遇享受情况")
        private UnemploymentBenefitInfo unemploymentBenefitInfo;

        @JsonProperty("工伤保险待遇享受情况")
        private InjuryBenefitInfo injuryBenefitInfo;
    }
    @Data
    public static class BasicPensionInsuranceInfo {
        @JsonProperty("截至上年末个人账户累计储存额")
        private String accumulatedStorageAmountLastYear;
        @JsonProperty("当年记账金额")
        private String currentAccountingAmount;
        @JsonProperty("当年个人账户支出金额")
        private String currentAccountExpense;
        @JsonProperty("当年记账利息")
        private String currentAccountInterest;
        @JsonProperty("至本年末账户累计储存额")
        private String accumulatedStorageAmountEndOfYear;
    }
    @Data
    public static class PensionBenefitInfo {
        @JsonProperty("月养老金水平")
        private String monthlyPensionLevel;
        @JsonProperty("其中当年调待金额")
        private String annualPensionAdjustmentAmount;
    }
    @Data
    public static class UnemploymentBenefitInfo {
        @JsonProperty("上次失业未领取失业保险金剩余月数")
        private String remainingUnemploymentInsuranceMonths;
        @JsonProperty("本次失业保险待遇享受开始年月")
        private String unemploymentBenefitStartYearMonth;
        @JsonProperty("本次应领取失业保险金月数")
        private String unemploymentBenefitMonths;
        @JsonProperty("本次应领取失业保险金金额")
        private String unemploymentBenefitAmount;
        @JsonProperty("本次累计领取失业保险金月数")
        private String cumulativeUnemploymentBenefitMonths;
        @JsonProperty("本次累计领取失业保险金金额")
        private String cumulativeUnemploymentBenefitAmount;
    }
    @Data
    public static class InjuryBenefitInfo {
        @JsonProperty("工伤保险待遇享受开始年月")
        private String injuryBenefitStartYearMonth;
        @JsonProperty("伤残等级")
        private String disabilityGrade;
        @JsonProperty("本年工伤保险基金支付总额")
        private String annualInjuryInsuranceFundPayment;
        @JsonProperty("工伤医疗费")
        private String medicalExpenses;
        @JsonProperty("康复性治疗费")
        private String rehabilitationCosts;
        @JsonProperty("辅助器具配置费")
        private String auxiliaryApplianceCost;
        @JsonProperty("住院伙食费")
        private String hospitalizationSubsidy;
        @JsonProperty("统筹区以外就医交通费")
        private String transportationExpenseOutsideTheRegion;
        @JsonProperty("一次性伤残补助金")
        private String oneTimeDisabilityAllowance;
        @JsonProperty("伤残津贴")
        private String disabilityAllowance;
        @JsonProperty("生活护理费")
        private String livingMaintenanceFee;
        @JsonProperty("养老金工伤补差")
        private String pensionDifferenceDueToInjury;
        @JsonProperty("一次性工伤医疗补助金")
        private String oneTimeMedicalAssistance;
        @JsonProperty("一次性工亡补助金")
        private String oneTimeDeathBenefit;
        @JsonProperty("丧葬补助金")
        private String funeralAllowance;
        @JsonProperty("供养亲属抚恤金")
        private String dependentRelativesAllowance;
    }

}
