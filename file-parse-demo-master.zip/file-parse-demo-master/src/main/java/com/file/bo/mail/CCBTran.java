package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 建行qq邮箱pdf版流水明细
 * @author v_wbhwliu
 */
@Data
public class CCBTran {

    /**
     * 序号
     */
    @JsonProperty("序号")
    private String id;

    /**
     * 摘要
     */
    @JsonProperty("摘要")
    private String transactionType;

    /**
     * 币别
     */
    @JsonProperty("币别")
    private String currency;

    /**
     * 钞汇
     */
    @JsonProperty("钞汇")
    private String cashRemit;

    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String transactionDate;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String transactionAmount;

    /**
     * 账户余额
     */
    @JsonProperty("账户余额")
    private String balance;

    /**
     * 交易地点/附言
     */
    @JsonProperty("交易地点/附言")
    private String transactionComment = "";

    /**
     * 对方账号与户名
     */
    @JsonProperty("对方账号与户名")
    private String counterParty = "";
}
