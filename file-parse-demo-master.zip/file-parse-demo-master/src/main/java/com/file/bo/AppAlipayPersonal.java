package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AppAlipayPersonal {

    @JsonProperty("真实姓名")
    private String realName;

    @JsonProperty("支付宝账户")
    private String alipayAccount;
}
