package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 北京农商银行流水字段
 * @author anyspa
 */
@Data
public class BJRCB {

    /**
     * 账户名称
     */
    @JsonProperty("账户名称")
    private String accountName;

    /**
     * 客户申请日期
     */
    @JsonProperty("客户申请日期")
    private String customerApplyDate;

    /**
     * 查询机构
     */
    @JsonProperty("查询机构")
    private String queryAgency;

    /**
     * 系统查询日期
     */
    @JsonProperty("系统查询日期")
    private String systemQueryDate;

    /**
     * 收入金额合计
     */
    @JsonProperty("收入金额合计")
    private String incomeAmtTotal;

    /**
     * 支出金额合计
     */
    @JsonProperty("支出金额合计")
    private String payAmtTotal;

    /**
     * 查询区间期末余额
     */
    @JsonProperty("查询区间期末余额")
    private String queryIntervalBalance;

    /**
     * 交易明细合计
     */
    @JsonProperty("交易明细合计")
    private String transactionDetailsTotal;

    /**
     * 账号
     */
    @JsonProperty("账号")
    private String accountNo;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 交易起止日期
     */
    @JsonProperty("交易起止日期")
    private String transactionDate;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String transactionAmount;

    /**
     * 交易类型
     */
    @JsonProperty("交易类型")
    private String tranType;

    /**
     * 交付日期
     */
    @JsonProperty("交付日期")
    private String deliverDate;

    /**
     * 查询索引号
     */
    @JsonProperty("查询索引号")
    private String queryIndexNumber;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<BJRCBTran> bjrcbTrans;
}
