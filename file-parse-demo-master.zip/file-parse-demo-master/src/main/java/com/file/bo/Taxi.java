package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 个税申报收入明细(老版)
 * @author anyspa
 */

@Data
public class Taxi {
    @JsonProperty("纳税人识别号")
    private String taxpayerIdentifier;

    @JsonProperty("纳税人名称")
    private String taxpayerName;

    @JsonProperty("身份证件类型")
    private String idCardType;

    @JsonProperty("身份证件号码")
    private String idNo;

    @JsonProperty("税款所属期")
    private String taxPeriod;

    @JsonProperty("申报收入合计")
    private String declareIncomeTotal;

    @JsonProperty("申报税额合计")
    private String declareTaxTotal;

    @JsonProperty("个税申报收入明细")
    private List<TaxiTran> taxiTrans;
}
