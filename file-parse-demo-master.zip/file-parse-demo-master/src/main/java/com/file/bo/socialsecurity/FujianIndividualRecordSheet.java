package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class FujianIndividualRecordSheet {

    @JsonProperty("姓名")
    private String name;

}
