package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class GuangxiInsuranceParticipation {

    @JsonProperty("标题")
    private String title;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("个人编号")
    private String personalId;

    @JsonProperty("居民身份证号码")
    private String idNumber;

    @JsonProperty("参保情况")
    private List<EnrollmentInfo> enrollmentInfo;

    @JsonProperty("日期")
    private String date;

    @JsonProperty("说明")
    private String description;

    @Data
    public static class EnrollmentInfo {

        @JsonProperty("单位编号")
        private String organizationCode;

        @JsonProperty("单位名称")
        private String organizationName;

        @JsonProperty("参保险种")
        private String insuranceType;

        @JsonProperty("起始年月")
        private String startDate;

        @JsonProperty("截止年月")
        private String endDate;

        @JsonProperty("是否足额缴费")
        private String fullPayment;
    }
}