package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 国家政务-驾驶证
 * @author anyspa
 */

@Data
public class AppGjzwfwJsz {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("身份证号")
    private String idNo;

    @JsonProperty("档案编号")
    private String archivesNo;

    @JsonProperty("准驾车型")
    private String quasiDrivingModel;

    @JsonProperty("发证机关")
    private String issuingAuthority;

    @JsonProperty("驾驶证有效期")
    private String driverLicenseExpireDate;

    @JsonProperty("下一检验日")
    private String nextInspectionDay;

    @JsonProperty("驾驶证状态")
    private String driverLicenseStatus;

    @JsonProperty("累计记分")
    private String score;

    @JsonProperty("审验有效期")
    private String verificationValidityPeriod;
}
