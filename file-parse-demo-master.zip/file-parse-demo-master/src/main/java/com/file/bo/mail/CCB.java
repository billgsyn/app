package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;


/**
 * 建行qq邮箱pdf版流水文件交易明细
 * @author v_wbhwliu
 */
@Data
public class CCB {

    /**
     * 卡号/账号
     */
    @JsonProperty("卡号/账号")
    private String accountNo;

    /**
     * 客户名称
     */
    @JsonProperty("客户名称")
    private String name;

    /**
     * 起始日期
     */
    @JsonProperty("起始日期")
    private String startDate;

    /**
     * 结束日期
     */
    @JsonProperty("结束日期")
    private String endDate;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<CCBTran> ccbTrans;

}
