package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DomesticDiploma {
	
	@JsonProperty("姓名")
	private String name;
	
	@JsonProperty("性别")
	private String sex;
	
	@JsonProperty("出生日期")
	private String dateOfBirth;
	
	@JsonProperty("入学日期")
	private String dateOfEnrollment;
	
	@JsonProperty("毕(结)业日期")
	private String dateOfGraduation;
	
	@JsonProperty("学历类别")
	private String diplomaClassification;
	
	@JsonProperty("层次")
	private String degree;
	
	@JsonProperty("学校名称")
	private String schoolName;
	
	@JsonProperty("学制")
	private String schoolSystem;
	
	@JsonProperty("专业")
	private String major;
	
	@JsonProperty("学习形式")
	private String learningStyle;
	
	@JsonProperty("证书编号")
	private String certificateNo;
	
	@JsonProperty("毕(结)业")
	private String graduation;
	
	@JsonProperty("校(院)长姓名")
	private String principalName;
	
	@JsonProperty("在线验证码")
	private String onlineVerificationCode;
	
	@JsonProperty("证件号码")
	private String idNo;
	
	@JsonProperty("补证学校")
	private String supplementaryCertificateSchool;
	
	@JsonProperty("补证日期")
	private String supplementaryCertificateDate;
	
	@JsonProperty("补证编号")
	private String supplementaryCertificateNo;

}
