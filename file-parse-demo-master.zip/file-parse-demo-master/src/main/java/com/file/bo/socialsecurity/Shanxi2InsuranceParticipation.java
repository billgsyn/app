package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 山西省参保证明
 */

@Data
public class Shanxi2InsuranceParticipation {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("身份证号")
    private String idNo;

    @JsonProperty("当前参保经办机构")
    private String currentInsuranceAgency;

    @JsonProperty("当前参保单位名称")
    private String currentInsuredUnitName;

    @JsonProperty("险种")
    private String insuranceType;

    @JsonProperty("本统筹地区缴费起止时间")
    private String coordinatedAreaPaymentStartAndEndTime;

    @JsonProperty("本统筹地区实际缴费年限")
    private String coordinatedAreaActualPaymentYears;

    @JsonProperty("参保状态")
    private String insuranceStatus;

    @JsonProperty("打印时间")
    private String printTime;

    @JsonProperty("个人缴费明细")
    private List<Shanxi2InsuranceParticipation.PaymentDetail> paymentDetailList;

    @JsonProperty("备注")
    private String remarks;


    @Data
    public static class PaymentDetail {

        @JsonProperty("起止年月")
        private String startAndEndDate;

        @JsonProperty("基本养老保险")
        private BasicPensionInsurance basicPensionInsurance;

    }

    @Data
    public static class BasicPensionInsurance {

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("个人缴费")
        private String individualPayment;

    }

}
