package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class JinritemaiBillBO {

    @JsonProperty("公司名称")
    private String companyName;

    @JsonProperty("统一社会信用代码")
    private String unifiedSocialCreditCode;

    @JsonProperty("经营者姓名")
    private String operatorName;

    @JsonProperty("经营者证件号码")
    private String operatorIdNo;

}
