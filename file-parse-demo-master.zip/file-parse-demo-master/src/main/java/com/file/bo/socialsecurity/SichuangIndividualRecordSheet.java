package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 四川省社会保险个人权益信息表
 * @author anyspa
 */

@Data
public class SichuangIndividualRecordSheet {


    @JsonProperty("记录期间")
    private String recordPeriod;

    @JsonProperty("个人基础信息")
    private PersonalBasicInformation personalBasicInformation;

    @JsonProperty("城镇职工参保人员本年度缴费情况")
    private List<WorkersYearPaymentStatusOfUrbanEmployeeInsuredPersons> workersYearPaymentList;

    @JsonProperty("城乡居民参保人员本年度缴费情况")
    private List<ResidentYearPaymentStatusOfUrbanEmployeeInsuredPersons> residentYearPaymentList;

    @JsonProperty("养老保险个人账户情况")
    private List<PersonalAccountInformationOfPensionInsurance> personalAccountList;

    @JsonProperty("说明")
    private String verifyDescription;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class PersonalBasicInformation {
        @JsonProperty("姓名")
        private String name;

        @JsonProperty("性别")
        private String gender;

        @JsonProperty("社会保障号码")
        private String socialSecurityNumber;

        @JsonProperty("证件类型")
        private String idType;

        @JsonProperty("证件号码")
        private String idNo;

        @JsonProperty("本地首次参保年月")
        private LocalInsuranceYearMonth localInsuranceYearMonth;
    }

    @Data
    public static class LocalInsuranceYearMonth {

        @JsonProperty("企业职工基本养老保险")
        private String enterpriseWorkPension;

        @JsonProperty("机关事业单位基本养老保险")
        private String causeWorkPension;

        @JsonProperty("城乡居民基本养老保险")
        private String urbanResidentsPension;

        @JsonProperty("工伤保险")
        private String injuryInsurance;

        @JsonProperty("失业保险")
        private String unemploymentInsurance;

    }

    @Data
    public static class WorkersYearPaymentStatusOfUrbanEmployeeInsuredPersons {

        @JsonProperty("序号")
        private String id;

        @JsonProperty("险种")
        private String type;

        @JsonProperty("缴费基数和")
        private String paymentBaseTotal;

        @JsonProperty("个人缴费金额")
        private String personalPaymentAmount;

        @JsonProperty("本年度缴费月数")
        private String yearPaymentMonths;

        @JsonProperty("累计缴费月数")
        private String totalPaymentMonths;

    }

    @Data
    public static class ResidentYearPaymentStatusOfUrbanEmployeeInsuredPersons {

        @JsonProperty("序号")
        private String id;

        @JsonProperty("险种")
        private String type;

        @JsonProperty("个人缴费金额")
        private String personalPaymentAmount;

        @JsonProperty("集体补助金额")
        private String teamSubsidyAmount;

        @JsonProperty("政府补贴（含政府代缴）金额")
        private String governmentSubsidiesAmount;

        @JsonProperty("累计缴费年限")
        private String totalPaymentYear;

    }

    @Data
    public static class PersonalAccountInformationOfPensionInsurance {

        @JsonProperty("序号")
        private String id;

        @JsonProperty("险种")
        private String type;

        @JsonProperty("截至上年末个人账户累计存储额")
        private String endYearPrivateAccountTotalAmount;

        @JsonProperty("当年记账金额")
        private String currentYearAccountingAmount;

        @JsonProperty("当年记账利息")
        private String currentYearAccountingInterest;

        @JsonProperty("至本年末账户累计存储额")
        private String endOfThisYearAccumulatedAccountStorageAmount;

    }

}
