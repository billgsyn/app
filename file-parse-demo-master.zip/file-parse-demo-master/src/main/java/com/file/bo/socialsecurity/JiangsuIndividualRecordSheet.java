package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class JiangsuIndividualRecordSheet {

    @JsonProperty("记录期间")
    private String recordPeriod;

    @JsonProperty("个人基本信息")
    private PersonalInformation personalInformation;

    @JsonProperty("缴费情况")
    private PaymentDetails paymentDetails;

    @JsonProperty("个人账户情况")
    private PersonalAccountInformation personalAccountInformation;

    @JsonProperty("社会保险经办机构名称")
    private String socialInsuranceAgencyName;

    @JsonProperty("打印时间")
    private String printTime;

    @JsonProperty("联系电话")
    private String telephoneNumber;

    @JsonProperty("地址")
    private String address;

    @Data
    public static class PersonalInformation {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("单位名称")
        private String unitName;

        @JsonProperty("社会保障号码")
        private String socialSecurityNumber;

        @JsonProperty("首次参保日期")
        private FirstInsuredDate firstInsuredDate;

    }

    @Data
    public static class FirstInsuredDate {

        @JsonProperty("养老")
        private String pension;

        @JsonProperty("失业")
        private String unemployment;

        @JsonProperty("工伤")
        private String workRelatedInjury;

    }

    @Data
    public static class PaymentDetails {

        @JsonProperty("个人月缴费基数")
        private PersonalMonthlyPaymentBase personalMonthlyPaymentBase;

        @JsonProperty("养老缴费信息")
        private PensionPaymentInformation pensionPaymentInformation;

        @JsonProperty("失业缴费信息")
        private UnemploymentPaymentInformation unemploymentPaymentInformation;

        @JsonProperty("工伤缴费信息（单位缴费）")
        private String workRelatedInjuryPaymentInformation;

        @JsonProperty("本年个人补缴欠费金额")
        private ThisYearPersonalOverduePaymentAmount thisYearPersonalOverduePaymentAmount;

        @JsonProperty("补历年缴费月数")
        private SupplementaryOverTheYearsPaymentMonths supplementaryOverTheYearsPaymentMonths;

        @JsonProperty("截止本年末实际缴费月数")
        private EndOfTheYearActualPaymentMonths endOfTheYearActualPaymentMonths;

        @JsonProperty("累计欠缴月数")
        private AccumulatedUnpaidMonths accumulatedUnpaidMonths;

    }

    @Data
    public static class PersonalMonthlyPaymentBase {

        @JsonProperty("养老")
        private String pension;

        @JsonProperty("失业")
        private String unemployment;

        @JsonProperty("工伤")
        private String workRelatedInjury;

    }

    @Data
    public static class PensionPaymentInformation {

        @JsonProperty("单位缴费")
        private String unitPayment;

        @JsonProperty("个人缴费")
        private String personalPayment;

    }

    @Data
    public static class UnemploymentPaymentInformation {

        @JsonProperty("单位缴费")
        private String unitPayment;

        @JsonProperty("个人缴费")
        private String personalPayment;

    }

    @Data
    public static class ThisYearPersonalOverduePaymentAmount {

        @JsonProperty("养老")
        private String pension;

        @JsonProperty("失业")
        private String unemployment;

    }

    @Data
    public static class SupplementaryOverTheYearsPaymentMonths {

        @JsonProperty("养老")
        private String pension;

        @JsonProperty("失业")
        private String unemployment;

    }

    @Data
    public static class EndOfTheYearActualPaymentMonths {

        @JsonProperty("养老")
        private String pension;

        @JsonProperty("失业")
        private String unemployment;

    }

    @Data
    public static class AccumulatedUnpaidMonths {

        @JsonProperty("养老")
        private String pension;

        @JsonProperty("失业")
        private String unemployment;

    }

    @Data
    public static class PersonalAccountInformation {

        @JsonProperty("基本养老保险")
        private BasicEndowmentInsurance basicEndowmentInsurance;

    }

    @Data
    public static class BasicEndowmentInsurance {

        @JsonProperty("截止上年末个人账户累计储存额")
        private String endOfLastYearAccumulatedPersonalAccountSavings;

        @JsonProperty("当年记账金额")
        private String currentYearAccountingAmount;

        @JsonProperty("当年个人账户支出金额")
        private String currentYearPersonalAccountExpenditureAmount;

        @JsonProperty("当年记账利息")
        private String currentYearAccountingInterest;

        @JsonProperty("至本年末账户累计存储额")
        private String endOfThisYearAccumulatedAccountStorageAmount;
    }
}
