package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 海南农信交易明细
 * @author v_wbhwliu
 */
@Data
public class HNNXTran {

    /**
     * 序号
     */
    @JsonProperty("序号")
    private String id;

    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String tranDate;

    /**
     * 收支类型
     */
    @JsonProperty("收支类型")
    private String revenueExpenditureType;

    /**
     * 摘要
     */
    @JsonProperty("摘要")
    private String summary;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String tranAmt;

    /**
     * 账户余额
     */
    @JsonProperty("账户余额")
    private String balance;

    /**
     * 对方户名
     */
    @JsonProperty("对方户名")
    private String counterPartyAccountName;

    /**
     * 对方账户
     */
    @JsonProperty("对方账户")
    private String paymentReceiptAccount;

}
