package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 湖北省个人权益记录单
 * @author anyspa
 */
@Data
public class HubeiIndividualRecordSheet {

    @JsonProperty("记录期间")
    private String recordPeriod;

    @JsonProperty("个人基本信息")
    private PersonBaseInfo personBaseInfo;

    @JsonProperty("缴费情况")
    private PaymentInfo paymentInfo;

    @JsonProperty("基本养老保险")
    private BasicPension basicPension;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class PersonBaseInfo {
        @JsonProperty("姓名")
        private String name;

        @JsonProperty("单位名称")
        private String unitName;

        @JsonProperty("社会保障号码")
        private String socialSecurityNumber;

        @JsonProperty("首次参保日期")
        private FirstEnrollmentDate firstEnrollmentDate;
    }

    @Data
    @EqualsAndHashCode(callSuper=false)
    public static class FirstEnrollmentDate extends BaseInsurances {
        @JsonProperty("工伤")
        private String injury;

        @JsonProperty("生育")
        private String fertility;
    }

    @Data
    public static class PaymentInfo {
        @JsonProperty("个人月缴费基数")
        private PersonalPaymentBase personalPaymentBase;

        @JsonProperty("养老缴费信息")
        private PensionPaymentInfo pensionPaymentInfo;

        @JsonProperty("医疗缴费信息")
        private MedicalPaymentInfo medicalPaymentInfo;

        @JsonProperty("失业缴费信息")
        private UnemploymentPaymentInfo unemploymentPaymentInfo;

        @JsonProperty("工伤缴费信息(单位缴费)")
        private String injuryPaymentInfo;

        @JsonProperty("生育缴费信息(单位缴费)")
        private String fertilityPaymentInfo;

        @JsonProperty("本年个人补缴欠费金额")
        private IndividualsPaidArrears individualsPaidArrears ;

        @JsonProperty("补历年缴费月数")
        private NumberOfPaymentMonths numberOfPaymentMonths;

        @JsonProperty("截止本年末实际缴费月数")
        private NumberOfActualPaymentMonths numberOfActualPaymentMonths;

        @JsonProperty("累积欠缴月数")
        private AccumulatedUnpaidMonths accumulatedUnpaidMonths;
    }

    @Data
    @EqualsAndHashCode(callSuper=false)
    public static class PersonalPaymentBase extends BaseInsurances {
        @JsonProperty("工伤")
        private String injury;

        @JsonProperty("生育")
        private String fertility;
    }

    @Data
    public static class PensionPaymentInfo {
        @JsonProperty("单位缴费")
        private String companyPays;

        @JsonProperty("个人缴费")
        private String personalPays;
    }

    @Data
    public static class MedicalPaymentInfo {
        @JsonProperty("单位缴费")
        private String companyPays;

        @JsonProperty("个人缴费")
        private String personalPays;
    }

    @Data
    public static class UnemploymentPaymentInfo {
        @JsonProperty("单位缴费")
        private String companyPays;

        @JsonProperty("个人缴费")
        private String personalPays;
    }

    @Data
    @EqualsAndHashCode(callSuper=false)
    public static class IndividualsPaidArrears extends BaseInsurances {
    }

    @Data
    @EqualsAndHashCode(callSuper=false)
    public static class NumberOfPaymentMonths extends BaseInsurances {
    }

    @Data
    @EqualsAndHashCode(callSuper=false)
    public static class NumberOfActualPaymentMonths extends BaseInsurances {
    }

    @Data
    @EqualsAndHashCode(callSuper=false)
    public static class AccumulatedUnpaidMonths extends BaseInsurances {
    }

    @Data
    public static class BaseInsurances {
        @JsonProperty("养老")
        private String pension;

        @JsonProperty("医疗")
        private String medical;

        @JsonProperty("失业")
        private String unemployment;
    }

    @Data
    public static class BasicPension {
        @JsonProperty("截止上年末个人账户累计储存额")
        private String accumulatedSavingsInPersonalAccountsLastYear;

        @JsonProperty("当年记账金额")
        private String currentAccountAmount;

        @JsonProperty("当年个人账户支出金额")
        private String amountOfPersonalAccountDisbursementsThisYear;

        @JsonProperty("当年记账利息")
        private String currentRecordedInterest;

        @JsonProperty("至本年末个人账户累计储存额")
        private String accumulatedSavingsInPersonalAccountsThisYear;
    }
}
