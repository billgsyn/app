package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class HebeiIndividualRecordSheet {

    @JsonProperty("记录期间")
    private String recordPeriod;

    @JsonProperty("个人基础信息")
    private PersonalInfo personalInfo;

    @JsonProperty("缴费情况")
    private PaymentSituation paymentSituation;

    @JsonProperty("个人账户情况")
    private AccountStatus accountStatus;

    @JsonProperty("打印时间")
    private String printTime;

    @JsonProperty("社会保险经办机构名称")
    private String agencyName;

    @JsonProperty("地址")
    private String address;

    @JsonProperty("联系电话")
    private String contactNumber;

    @Data
    public static class PersonalInfo {
        @JsonProperty("姓名")
        private String name;
        @JsonProperty("单位名称")
        private String companyName;
        @JsonProperty("社会保障号码")
        private String socialSecurityNumber;
        @JsonProperty("首次参保日期")
        private Insurance firstEnrollmentDate;
    }

    @Data
    public static class Insurance {

        @JsonProperty("养老")
        private String pension;

        @JsonProperty("医疗")
        private String medical;

        @JsonProperty("失业")
        private String unemployment;

        @JsonProperty("工伤")
        private String injury;

        @JsonProperty("生育")
        private String maternity;

        public Insurance() {
            this.pension = "--";
            this.medical = "--";
            this.unemployment = "--";
            this.injury = "--";
            this.maternity = "--";
        }
    }

    @Data
    public static class Insurance1 {

        @JsonProperty("养老")
        private String pension;

        @JsonProperty("医疗")
        private String medical;

        @JsonProperty("失业")
        private String unemployment;

        public Insurance1() {
            this.pension = "--";
            this.medical = "--";
            this.unemployment = "--";
        }
    }


    @Data
    public static class PaymentSituation {
        @JsonProperty("个人月缴费基数")
        private Insurance individualContributionBase;

        @JsonProperty("养老缴费信息")
        private PaymentInfo pensionPayment;

        @JsonProperty("医疗缴费信息")
        private PaymentInfo medicalPayment;

        @JsonProperty("失业缴费信息")
        private PaymentInfo unemploymentPayment;

        @JsonProperty("工伤缴费（单位缴费）")
        private String injuryPayment;

        @JsonProperty("生育缴费（单位缴费）")
        private String maternityPayment;
        @JsonProperty("本年个人补缴欠费金额")
        private Insurance1 currentYearArrearsPaid;

        @JsonProperty("补历年缴费月数")
        private Insurance1 pastYearsMonthsPaid;

        @JsonProperty("截至本年末实际缴费月数")
        private Insurance1 actualMonthsPaidThisYear;

        @JsonProperty("累计欠费月数")
        private Insurance1 cumulativeArrearsMonths;

        public PaymentSituation() {
            this.injuryPayment = "--";
            this.maternityPayment = "--";
        }
    }

    @Data
    public static class PaymentInfo {
        @JsonProperty("单位缴费")
        private String companyContribution;
        @JsonProperty("个人缴费")
        private String individualContribution;

        public PaymentInfo() {
            this.companyContribution = "--";
            this.individualContribution = "--";
        }
    }

    @Data
    public static class AccountStatus {
        @JsonProperty("基本养老保险")
        private PensionAccount basicPension;
        @JsonProperty("基本医疗保险")
        private MedicalAccount basicMedical;
        @JsonProperty("养老金领取情况")
        private PensionReceipt pensionReceipt;
    }

    @Data
    @NoArgsConstructor
    public static class PensionAccount {
        @JsonProperty("截至上年末个人账户累计存储额")
        private String previousYearEndBalance = "";
        @JsonProperty("当年记账金额")
        private String currentYearCreditAmount = "";
        @JsonProperty("当年个人账户支出金额")
        private String currentYearExpenseAmount = "";
        @JsonProperty("当年记账利息")
        private String currentYearInterest = "";
        @JsonProperty("至本年末账户累计存储额")
        private String endOfYearBalance = "";
    }

    @Data
    public static class MedicalAccount {
        @JsonProperty("截至上年末个人账户累计存储额")
        private String previousYearEndBalance;
        @JsonProperty("当年记账金额")
        private String currentYearCreditAmount;
        @JsonProperty("当年个人账户支出金额")
        private String currentYearExpenseAmount;
        @JsonProperty("当年记账利息")
        private String currentYearInterest;
        @JsonProperty("至本年末账户累计存储额")
        private String endOfYearBalance;

        public MedicalAccount() {
            this.previousYearEndBalance = "--";
            this.currentYearCreditAmount = "--";
            this.currentYearExpenseAmount = "--";
            this.currentYearInterest = "--";
            this.endOfYearBalance = "--";
        }
    }

    @Data
    @NoArgsConstructor
    public static class PensionReceipt {
        @JsonProperty("月养老金水平")
        private String monthlyPensionLevel="";
        @JsonProperty("当年调待金额")
        private String adjustmentAmount="";
    }

}


