package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CMBCorpSummary {

    @JsonProperty("企业名称")
    private String companyName;

    @JsonProperty("开户行名称")
    private String accountBank;

    @JsonProperty("开户账号")
    private String accountNo;

    @JsonProperty("交易开始时间")
    private String startDate;

    @JsonProperty("交易结束时间")
    private String endDate;

    @JsonProperty("总转出金额")
    private String totalDebitAmt;

    @JsonProperty("总转出笔数")
    private String totalDebitNo;

    @JsonProperty("最近30日开始时间")
    private String recentThirtyDaysStartDate;

    @JsonProperty("最近30日结束时间")
    private String recentThirtyDaysEndDate;

    @JsonProperty("最近30日转出金额")
    private String recentThirtyDaysTotalDebitAmt;

    @JsonProperty("最近30日转出总笔数")
    private String recentThirtyDaysTotalDebitNo;

}
