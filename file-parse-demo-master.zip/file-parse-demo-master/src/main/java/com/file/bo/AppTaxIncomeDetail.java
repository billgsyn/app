package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


@Data
public class AppTaxIncomeDetail {

    @JsonProperty("纳税明细信息")
    private TaxDetail taxDetail;

    @JsonProperty("纳税明细-基础情况")
    private TaxDetailBaseInfo taxDetailBaseInfo;

    @JsonProperty("本期收入与扣除详情")
    private CurrentIncomeAndDeductionsDetail currentIncomeAndDeductionsDetail;

    @JsonProperty("税款计算")
    private TaxCalculation taxCalculation;

    @Data
    public static class TaxDetail {
        @JsonProperty("收入")
        private String income = "";

        @JsonProperty("已申报税额")
        private String declaredTax = "";
    }

    @Data
    public static class TaxDetailBaseInfo {
        @JsonProperty("所得项目小类")
        private String incomeItemSubCategory = "";

        @JsonProperty("扣缴义务人名称")
        private String withholdingAgent = "";

        @JsonProperty("扣缴义务人纳税人识别号")
        private String withholdingAgentIdentifier = "";

        @JsonProperty("主管税务机关")
        private String competentTaxAuthority = "";

        @JsonProperty("申报渠道")
        private String declarationChannel = "";

        @JsonProperty("申报日期")
        private String declarationDate = "";

        @JsonProperty("税款所属期")
        private String taxPeriod = "";
    }

    @Data
    public static class CurrentIncomeAndDeductionsDetail {
        @JsonProperty("本期收入")
        private String currentIncome = "";

        @JsonProperty("本期免税收入")
        private String currentTaxExemptIncome = "";

        @JsonProperty("本期减除费用")
        private String currentExpenseDeduction = "";

        @JsonProperty("本期专项扣除")
        private CurrentSpecialDeduction currentSpecialDeduction;

        @JsonProperty("本期其他扣除")
        private String currentOtherDeduction = "";

        @JsonProperty("本期准予扣除的捐赠项目")
        private String donationItemsOfCurrentDeducted = "";

        @JsonProperty("应纳税所得额")
        private String taxableIncome = "";

        // 本期专项扣除
        @Data
        public static class CurrentSpecialDeduction {
            @JsonProperty("专项扣除小计")
            private String specialDeductionTotal = "";

            @JsonProperty("基本养老保险")
            private String basePensionActual = "";

            @JsonProperty("基本医疗保险")
            private String baseMedicalActual = "";

            @JsonProperty("失业保险")
            private String unemploymentActual = "";

            @JsonProperty("住房公积金")
            private String housingFund = "";
        }

    }

    @Data
    public static class TaxCalculation {
        @JsonProperty("应纳税所得额")
        private String taxableIncome = "";

        @JsonProperty("税率/预扣率")
        private String taxRate = "";

        @JsonProperty("速算扣除数")
        private String quickCalculationDeduction = "";

        @JsonProperty("应纳税额")
        private String taxPayable = "";

        @JsonProperty("减免税额")
        private String taxExempt = "";

        @JsonProperty("已缴税额")
        private String taxPaid = "";

        @JsonProperty("申报税额")
        private String taxDeclared = "";
    }
}
