package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 邮储PC端Excel版流水明细
 * @author v_wbhwliu
 */
@Data
public class PSBCTran {
    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String transactionDate;

    /**
     * 付款户名
     */
    @JsonProperty("付款户名")
    private String paymentAccountName;

    /**
     * 收款户名
     */
    @JsonProperty("收款户名")
    private String payeeAccountNumber;

    /**
     * 收入/支出
     */
    @JsonProperty("收入/支出")
    private String incomeExpense;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String transactionAmount;

    /**
     * 余额
     */
    @JsonProperty("余额")
    private String balance;


    /**
     * 摘要
     */
    @JsonProperty("摘要")
    private String summary;

    /**
     * 备注
     */
    @JsonProperty("备注")
    private String comment;
}
