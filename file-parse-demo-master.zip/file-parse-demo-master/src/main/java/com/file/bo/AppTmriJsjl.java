package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 交管12123APP机动车驾驶人安全驾驶记录
 * @author anyspa
 */

@Data
public class AppTmriJsjl {

    @JsonProperty("基本情况")
    private BasicInfo basicInfo;

    @JsonProperty("交通违法情况")
    private TrafficViolation trafficViolation;

    @JsonProperty("交通事故情况")
    private TrafficAccidentSituation trafficAccidentSituation;

    @JsonProperty("满分记录情况")
    private FullMarkRecord fullMarkRecord;

    @JsonProperty("准驾车型变更记录情况")
    private QuasiDrivingTypeChangeRecord quasiDrivingTypeChangeRecord;

    @Data
    public static class BasicInfo {
        @JsonProperty("姓名")
        private String name;

        @JsonProperty("性别")
        private String sex;

        @JsonProperty("身份证明号码")
        private String idNo;

        @JsonProperty("初次领证日期")
        private String initialApplicationDate;

        @JsonProperty("当前驾驶准驾车型")
        private String currentQuasiDrivingModel;

        @JsonProperty("当前交通违法累积记分")
        private String currentTrafficViolationsAccumulateScore;
    }

    @Data
    public static class TrafficViolation {
        @JsonProperty("描述")
        private String trafficViolationDescription;

        @JsonProperty("记录")
        private List<TrafficViolationRecord> trafficViolationRecords;
    }

    @Data
    public static class TrafficViolationRecord {
        @JsonProperty("违法时间")
        private String violationTime;

        @JsonProperty("违法地点")
        private String violationPlace;

        @JsonProperty("违法行为")
        private String violationBehavior;

        @JsonProperty("违法类型")
        private String violationType;

        @JsonProperty("记分")
        private String recordPoints;

        @JsonProperty("罚款金额")
        private String penaltyAmount;

        @JsonProperty("处罚种类")
        private String punishmentType;

        @JsonProperty("缴款标记")
        private String paymentMark;
    }

    @Data
    public static class TrafficAccidentSituation {
        @JsonProperty("描述")
        private String trafficAccidentSituationDescription;

        @JsonProperty("记录")
        private List<TrafficAccidentSituationRecord> trafficAccidentSituationRecords;
    }

    @Data
    public static class TrafficAccidentSituationRecord {
        @JsonProperty("事故时间")
        private String accidentTime;

        @JsonProperty("事故地点")
        private String accidentLocation;

        @JsonProperty("主要过错行为")
        private String principalWrongfulAct;

        @JsonProperty("事故类型")
        private String accidentType;

        @JsonProperty("事故责任")
        private String accidentLiability;

        @JsonProperty("死亡人数")
        private String deathToll;

        @JsonProperty("受伤人数")
        private String numberOfInjured;
    }

    @Data
    public static class FullMarkRecord {
        @JsonProperty("描述")
        private String fullMarkRecordDescription;

        @JsonProperty("记录")
        private List<FullMarkRecordDetail> fullMarkRecordDetails;
    }

    @Data
    public static class FullMarkRecordDetail {
        @JsonProperty("清分日期")
        private String clearingDate;

        @JsonProperty("记分年度")
        private String scoringYear;

        @JsonProperty("清分分值")
        private String clearScores;

        @JsonProperty("驾驶证核发地")
        private String licenseIssuePlace;
    }

    @Data
    public static class QuasiDrivingTypeChangeRecord {
        @JsonProperty("描述")
        private String quasiDrivingTypeChangeRecordDescription;

        @JsonProperty("记录")
        private List<QuasiDrivingTypeChangeRecordDetail> quasiDrivingTypeChangeRecordDetails;
    }

    @Data
    public static class QuasiDrivingTypeChangeRecordDetail {
        @JsonProperty("变更日期")
        private String changeDate;

        @JsonProperty("原准驾车型")
        private String originalQuasiDrivingModel;

        @JsonProperty("新准驾车型")
        private String newQuasiDrivingModel;
    }
}