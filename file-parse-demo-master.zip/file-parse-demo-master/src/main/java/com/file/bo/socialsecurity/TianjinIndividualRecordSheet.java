package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class TianjinIndividualRecordSheet {

    @JsonProperty("个人基本信息")
    private PersonalInfo personalInfo;

    @JsonProperty("城镇企业养老年限")
    private UrbanEnterprisePension urbanEnterprisePension;

    @JsonProperty("机关事业养老年限")
    private InstitutionalAffairsPension institutionalAffairsPension;

    @JsonProperty("参保缴费信息")
    private EnrollmentFeeInfo enrollmentFeeInfo;

    @JsonProperty("个人账户信息")
    private PersonalAccountInfo personalAccountInfo;

    @JsonProperty("注")
    private String note;

    @JsonProperty("数据统计截至")
    private String dataStatisticsUntil;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class PersonalInfo {
        @JsonProperty("姓名")
        private String name;

        @JsonProperty("社会保障号码")
        private String socialSecurityNumber;

        @JsonProperty("性别")
        private String gender;

        @JsonProperty("年龄")
        private String age;

        @JsonProperty("单位名称")
        private String employerName;

        @JsonProperty("单位类型")
        private String employerType;

        @JsonProperty("参加工作时间")
        private String startOfWork;

        @JsonProperty("联系地址")
        private String contactAddress;

        @JsonProperty("邮政编码")
        private String postalCode;

        @JsonProperty("手机号码")
        private String phoneNumber;
    }

    @Data
    public static class UrbanEnterprisePension {
        @JsonProperty("视同缴费年限")
        private String deemedContributionYears;

        @JsonProperty("核定缴费年限")
        private String verifiedContributionYears;

        @JsonProperty("异地转入年限")
        private String transferredYearsFromOtherPlaces;

        @JsonProperty("实际缴费年限")
        private String actualContributionYears;
    }

    @Data
    public static class InstitutionalAffairsPension {
        @JsonProperty("视同导入年限")
        private String deemedServiceYears;

        @JsonProperty("异地转入年限")
        private String transferredYearsFromOtherPlaces;

        @JsonProperty("实际缴费年限")
        private String actualContributionYears;
    }

    @Data
    public static class EnrollmentFeeInfo {
        @JsonProperty("基本养老保险")
        private BasicEndowmentInsurance basicEndowmentInsurance;

        @JsonProperty("基本医疗保险")
        private BasicMedicalInsurance basicMedicalInsurance;

        @JsonProperty("失业保险")
        private UnemploymentInsurance unemploymentInsurance;

        @JsonProperty("工伤保险")
        private WorkInjuryInsurance workInjuryInsurance;

        @JsonProperty("生育保险")
        private MaternityInsurance maternityInsurance;
    }

    @Data
    public static class BasicEndowmentInsurance {
        @JsonProperty("缴费月数")
        private String contributionMonths;

        @JsonProperty("月均缴费基数")
        private String averageMonthlyContributionBase;

        @JsonProperty("缴费金额")
        private FeeAmount feeAmount;

        @JsonProperty("职业年金缴费金额")
        private FeeAmount occupationalPensionFeeAmount;
    }

    @Data
    @AllArgsConstructor
    public static class FeeAmount {
        @JsonProperty("单位")
        private String employer;

        @JsonProperty("个人")
        private String individual;
    }

    @Data
    public static class BasicMedicalInsurance {
        @JsonProperty("缴费月数")
        private String contributionMonths;

        @JsonProperty("月均缴费基数")
        private String averageMonthlyContributionBase;

        @JsonProperty("缴费金额")
        private FeeAmount feeAmount;

        @JsonProperty("缴纳大额医疗救助金额")
        private String largeMedicalAidPayment;
    }

    @Data
    public static class UnemploymentInsurance {
        @JsonProperty("缴费月数")
        private String contributionMonths;

        @JsonProperty("月均缴费基数")
        private String averageMonthlyContributionBase;

        @JsonProperty("缴费金额")
        private FeeAmount feeAmount;
    }

    @Data
    public static class WorkInjuryInsurance {
        @JsonProperty("缴费月数")
        private String contributionMonths;

        @JsonProperty("月均缴费基数")
        private String averageMonthlyContributionBase;

        @JsonProperty("缴费金额")
        private String feeAmount;
    }
    @Data
    public static class MaternityInsurance {
        @JsonProperty("缴费月数")
        private String contributionMonths;

        @JsonProperty("月均缴费基数")
        private String averageMonthlyContributionBase;

        @JsonProperty("缴费金额")
        private String feeAmount;
    }

    @Data
    public static class PersonalAccountInfo {
        @JsonProperty("险种")
        private String insuranceType;

        @JsonProperty("截至上年末累计储存额")
        private String accumulatedBalanceByLastYear;

        @JsonProperty("当年记账本金")
        private String accountingPrincipalOfThisYear;

        @JsonProperty("当年记账利息")
        private String accountingInterestOfThisYear;

        @JsonProperty("当年个人账户支出金额")
        private String personalAccountExpenditureOfThisYear;

        @JsonProperty("至本年末账户累计储存额")
        private String accumulatedBalanceByEndOfYear;
    }
}
