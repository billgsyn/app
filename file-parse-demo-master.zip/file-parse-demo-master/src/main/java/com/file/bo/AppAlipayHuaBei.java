package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 花呗
 * @author anyspa
 */

@Data
public class AppAlipayHuaBei {

    @JsonProperty("可用额度")
    private String availableAmount = "";

    @JsonProperty("总计额度")
    private String totalAmount = "";

    @JsonProperty("用例说明")
    private String caseDesc = "";

    @Data
    public static class Quota {
        @JsonProperty("额度类型")
        private String quotaType;

        @JsonProperty("总额度")
        private String totalAmount;

        @JsonProperty("可用额度")
        private String availableAmount;
    }

}
