package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.file.bo.CEBTran;
import lombok.Data;

import java.util.List;

/**
 * 光大银行
 * @author anyspa
 */

@Data
public class CEB {

    @JsonProperty("起始日期")
    private String startDate;

    @JsonProperty("结束日期")
    private String endDate;

    @JsonProperty("下载/打印日期")
    private String downloadPrintDate;

    @JsonProperty("账号")
    private String accountNumber;

    @JsonProperty("账户类型")
    private String accountType;

    @JsonProperty("户名")
    private String accountName;

    @JsonProperty("币种")
    private String currency;

    @JsonProperty("钞汇标志")
    private String cashExchange;

    @JsonProperty("支出笔数")
    private String expenseCount;

    @JsonProperty("支出金额")
    private String expenseAmount;

    @JsonProperty("存入笔数")
    private String incomeCount;

    @JsonProperty("存入金额")
    private String incomeAmount;

    @JsonProperty("交易明细")
    private List<CEBTran> cebTrans;
}
