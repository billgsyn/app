package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class YunnanIndividualRecordSheet {


    @JsonProperty("年度")
    private String year;

    @JsonProperty("企业职工工伤保险基本信息")
    private EmploymentInjuryBasicInfo employmentInjuryBasicInfo;

    @JsonProperty("企业职工工伤保险参保信息")
    private List<EmployeeInsuranceInfo> employeeInsuranceInfos;

    @JsonProperty("失业保险基本信息")
    private UnemploymentBasicInfo unemploymentBasicInfo;

    @JsonProperty("失业保险缴费明细")
    private List<PaymentItem> paymentDetails;

    @JsonProperty("机关事业工伤保险基本信息")
    private EmploymentInjuryBasicInfo institutionEmploymentInjuryBasicInfo;

    @JsonProperty("机关事业工伤保险参保信息")
    private List<EmployeeInsuranceInfo> institutionEmploymentInjuryInfo;

//    @Data
//    public static class InstitutionEmploymentInjuryInfo {
//
//        @JsonProperty("个人编号")
//        private String personalId;
//
//        @JsonProperty("参保单位名称")
//        private String companyName;
//
//        @JsonProperty("参保单位行政区划")
//        private String companyArea;
//
//        @JsonProperty("参保日期")
//        private String enrollmentDate;
//
//        @JsonProperty("参保状态")
//        private String enrollmentStatus;
//    }
//
//    @Data
//    public static class InstitutionEmploymentInjuryBasicInfo {
//
//        @JsonProperty("姓名")
//        private String name;
//
//        @JsonProperty("证件号码")
//        private String idNumber;
//    }


    @Data
    public static class PaymentItem {

        @JsonProperty("缴费期号")
        private String paymentPeriod;

        @JsonProperty("缴费类别")
        private String paymentCategory;

        @JsonProperty("补退收开始期号")
        private String refundStartDate;

        @JsonProperty("补退收结束期号")
        private String refundEndDate;

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("单位缴费金额")
        private String companyContributionAmount;

        @JsonProperty("个人缴费金额")
        private String individualContributionAmount;

        @JsonProperty("单位缴费标志")
        private String companyContributionFlag;

        @JsonProperty("个人缴费标志")
        private String individualContributionFlag;
    }

    @Data
    public static class UnemploymentBasicInfo {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("证件号")
        private String idNumber;

        @JsonProperty("出生日期")
        private String birthDate;

        @JsonProperty("参保日期")
        private String insuranceDate;

        @JsonProperty("本次缴费月数")
        private String currentPaymentMonths;

        @JsonProperty("累计结转缴费月数")
        private String accumulatedTransferPaymentMonths;

        @JsonProperty("合计缴费月数")
        private String totalPaymentMonths;

        @JsonProperty("结转可享受待遇月数")
        private String transferEntitlementMonths;

        @JsonProperty("合计可享受待遇月数")
        private String totalEntitlementMonths;

        @JsonProperty("是否在领取失业保险")
        private String isReceivingInsurance;

        @JsonProperty("单位名称")
        private String companyName;

    }

    @Data
    public static class EmploymentInjuryBasicInfo {

        @JsonProperty("姓名")
        private String name;

        @JsonProperty("证件证号")
        private String idCardNumber;
    }

    @Data
    public static class EmployeeInsuranceInfo {

        @JsonProperty("个人编号")
        private String personalId;

        @JsonProperty("参保单位名称")
        private String companyName;

        @JsonProperty("参保单位行政区划")
        private String companyArea;

        @JsonProperty("参保日期")
        private String insuranceDate;

        @JsonProperty("参保状态")
        private String insuranceStatus;
    }


}


