package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AppTaxIncomeTran {

    @JsonProperty("所得项目")
    private String incomeItem;

    @JsonProperty("税款所属期")
    private String taxPeriod;

    @JsonProperty("所得项目小类")
    private String incomeItemSubCategory;

    @JsonProperty("扣缴义务人")
    private String withholdingAgent;

    @JsonProperty("收入")
    private String income;

    @JsonProperty("已申报税额")
    private String declaredTax;

}
