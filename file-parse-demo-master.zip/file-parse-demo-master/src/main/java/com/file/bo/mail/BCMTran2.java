package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 交通银行流水明细 (无交易对手版)
 *
 * @author anyspa
 */
@Data
public class BCMTran2 {

    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String transDate;

    /**
     * 交易地点
     */
    @JsonProperty("交易地点")
    private String tradingPlace;

    /**
     * 交易方式
     */
    @JsonProperty("交易方式")
    private String transType;

    /**
     * 借贷状态
     */
    @JsonProperty("借贷状态")
    private String dcFlg;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String transAmt;

    /**
     * 余额
     */
    @JsonProperty("余额")
    private String balance;
}
