package com.file.bo.mail;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 四川省农村信用社账户交易明细流水字段
 * @author v_wbhwliu
 */
@Data
public class SCRCU {

    /**
     * 账号
     */
    @JsonProperty("账号")
    private String accountNo;

    /**
     * 户名
     */
    @JsonProperty("户名")
    private String accountName;

    /**
     * 开户行
     */
    @JsonProperty("开户行")
    private String accountBank;

    /**
     * 起止日期
     */
    @JsonProperty("起止日期")
    private String transDetailPeriod;

    /**
     * 收入合计
     */
    @JsonProperty("收入合计")
    private String totalIncome;

    /**
     * 支出合计
     */
    @JsonProperty("支出合计")
    private String totalExpenditure;

    /**
     * 备注
     */
    @JsonProperty("备注")
    private String comment;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    List<SCRCUTran> scrcuTrans;
}
