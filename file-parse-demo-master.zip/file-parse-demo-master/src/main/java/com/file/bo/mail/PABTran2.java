package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author v_wbhwliu
 */
@Data
public class PABTran2 {
    /**
     * 序号
     */
    @JsonProperty("序号")
    private String id;

    /**
     * 交易日期
     */
    @JsonProperty("交易时间")
    private String transactionTime;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String transactionAmount;

    /**
     * 余额
     */
    @JsonProperty("余额")
    private String balance;

    /**
     * 交易地点
     */
    @JsonProperty("交易地点")
    private String tradingPlace;

    /**
     * 摘要
     */
    @JsonProperty("摘要")
    private String transactionType;

    /**
     * 备注
     */
    @JsonProperty("备注")
    private String comment;

    /**
     * 交易对手信息
     */
    @JsonProperty("交易对手信息")
    private String counterParty;
}