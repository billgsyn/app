package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.file.bo.PSBCTran;
import lombok.Data;

import java.util.List;

/**
 * 邮储PC端Excel版流水
 * @author v_wbhwliu
 */
@Data
public class PSBC {

    /**
     * 账号/卡号
     */
    @JsonProperty("账号/卡号")
    private String accountNumber;

    /**
     * 交易类型
     */
    @JsonProperty("交易类型")
    private String transactionType;

    /**
     * 转入账号/卡号
     */
    @JsonProperty("转入账号/卡号")
    private String transferInAccountNumber;

    /**
     * 收入/支出
     */
    @JsonProperty("收入/支出")
    private String incomeExpense;

    /**
     * 起始日期
     */
    @JsonProperty("起始日期")
    private String startDate;

    /**
     * 截止日期
     */
    @JsonProperty("截止日期")
    private String expirationDate;

    /**
     * 总收入
     */
    @JsonProperty("总收入")
    private String totalIncome;

    /**
     * 总支出
     */
    @JsonProperty("总支出")
    private String totalExpense;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<PSBCTran> psbcTrans;
}
