package com.file.bo.mail;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.file.bo.mail.AliPayTran;
import lombok.Data;

import java.util.List;

@Data
public class AliPay {
	
	@JsonProperty("编号")
	private String number;
	
	@JsonProperty("姓名")
	private String name;
	
	@JsonProperty("证件号码")
	private String idNumber;
	
	@JsonProperty("币种")
	private String currency;
	
	@JsonProperty("单位")
	private String unit;
	
	@JsonProperty("支付宝账号")
	private String aliPayAccount;
	
	@JsonProperty("交易时间段")
	private String transDetailPeriod;
	
	@JsonProperty("交易类型")
	private String tranType;
	
	@JsonProperty("交易明细")
	private List<AliPayTran> aliPayTrans;

}
