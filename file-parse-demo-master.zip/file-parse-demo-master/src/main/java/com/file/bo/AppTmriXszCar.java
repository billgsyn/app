package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 机动车
 * @author anyspa
 */

@Data
public class AppTmriXszCar {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("登记手机号码")
    private String cellphoneNo;

    @JsonProperty("机动车状态")
    private String motorVehicleStatus;

    @JsonProperty("抵押登记状态")
    private String mortgageRegistrationStatus;

    @JsonProperty("注册登记日期")
    private String registrationDate;

    @JsonProperty("号牌号码")
    private String numberPlate;

    @JsonProperty("检验有效期止")
    private String expiryDateOfInspection;

    @JsonProperty("强制报废期止")
    private String endOfMandatoryRetirementPeriod;

    @JsonProperty("交强险终止日期")
    private String compulsoryInsuranceExpiryDate;

    @JsonProperty("查看被他人备案记录")
    private String recordedByOthers = "false";

}