package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 安徽省参保证明
 */

@Data
public class AnhuiInsuranceParticipation {

    @JsonProperty("参保人")
    private String name;

    @JsonProperty("性别")
    private String sex;

    @JsonProperty("身份证号码")
    private String idNo;

    @JsonProperty("缴费情况")
    private List<AnhuiInsuranceParticipation.PaymentDetail> paymentDetailList;

    @JsonProperty("注")
    private String notes;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class PaymentDetail {

        @JsonProperty("参保险种")
        private String insuranceType;

        @JsonProperty("开始时间")
        private String startTime;

        @JsonProperty("截止时间")
        private String endTime;

        @JsonProperty("缴费基数")
        private String paymentBase;

        @JsonProperty("单位名称")
        private String unitName;

        @JsonProperty("个人应缴金额")
        private String individualPayableAmount;

        @JsonProperty("缴费情况")
        private String paymentStatus;

        @JsonProperty("参保地")
        private String insuredPlace;

    }

}
