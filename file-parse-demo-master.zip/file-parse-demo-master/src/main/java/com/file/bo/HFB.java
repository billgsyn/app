package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 恒丰银行
 * @author anyspa
 */

@Data
public class HFB {

    @JsonProperty("开户机构")
    private String accountOpeningInstitution;

    @JsonProperty("币种")
    private String currency;

    @JsonProperty("账号")
    private String accountNumber;

    @JsonProperty("交易明细")
    private List<HFBTran> hfbTrans;
}
