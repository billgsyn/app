package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 北京社保缴费明细
 * @author anyspa
 */

@Data
public class BjSocialInsuranceTran {

    @JsonProperty("缴费起止年月")
    private String paymentStartAndEndDate;

    @JsonProperty("养老实际缴费")
    private PensionActualPayment pensionActualPayment;

    @JsonProperty("失业实际缴费")
    private UnemploymentActualPayment unemploymentActualPayment;

    @JsonProperty("工伤实际缴费")
    private InjuryActualPayment injuryActualPayment;

    @JsonProperty("医疗实际缴费")
    private MedicalActualPayment medicalActualPayment;

    @JsonProperty("生育实际缴费")
    private FertilityActualPayment fertilityActualPayment;

    @Data
    static class BaseInsuranceInfo {

        @JsonProperty("月数")
        private String month;

        @JsonProperty("年缴费基数")
        private String annualPaymentBase;
    }

    // 养老实际缴费
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class PensionActualPayment extends BaseInsuranceInfo {
        @JsonProperty("个人缴费")
        private String personalPayment;
    }

    // 失业实际缴费
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class UnemploymentActualPayment extends BaseInsuranceInfo {
        @JsonProperty("个人缴费")
        private String personalPayment;
    }

    // 工伤实际缴费
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class InjuryActualPayment extends BaseInsuranceInfo {}

    // 医疗实际缴费
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class MedicalActualPayment extends BaseInsuranceInfo {
        @JsonProperty("个人缴费")
        private String personalPayment;
    }

    // 生育实际缴费
    @EqualsAndHashCode(callSuper = true)
    @Data
    public static class FertilityActualPayment extends BaseInsuranceInfo {}

}
