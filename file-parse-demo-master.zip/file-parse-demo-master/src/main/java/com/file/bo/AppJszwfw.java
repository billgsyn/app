package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 江苏不动产
 * @author anyspa
 */

@Data
public class AppJszwfw {

    @JsonProperty("查询日期")
    private String queryDate;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("自然状况")
    private NaturalStatus naturalStatus;

    @JsonProperty("权属状况")
    private OwnershipStatus ownershipStatus;

    @JsonProperty("抵押状况")
    private List<MortgageStatus> mortgageStatuses;

    @JsonProperty("权利限制")
    private List<RestrictionOfRights> restrictionOfRights;

    // 自然状况
    @Data
    public static class NaturalStatus {

        @JsonProperty("坐落")
        private String located;

        @JsonProperty("房屋结构")
        private String houseStructure;

        @JsonProperty("房屋用途")
        private String housePurposes;

        @JsonProperty("建筑面积（㎡）")
        private String constructionArea;

        @JsonProperty("套内建筑面积（㎡）")
        private String insideConstructionArea;

        @JsonProperty("独用土地面积（㎡）")
        private String exclusiveLandArea;
    }

    // 权属状况
    @Data
    public static class OwnershipStatus {

        @JsonProperty("不动产单元号")
        private String realEstateUnitNumber;

        @JsonProperty("房屋性质")
        private String natureOfHouse;

        @JsonProperty("土地使用权期限")
        private String termOfLandUseRight;

        @JsonProperty("土地权利性质")
        private String natureOfLandRights;

        @JsonProperty("证书/证明号")
        private String certificate;

        @JsonProperty("登记时间")
        private String checkInTime;

        @JsonProperty("共有方式")
        private String sharedWay;

        @JsonProperty("共有人")
        private String sharedPeople;
    }

    // 抵押状况
    @Data
    public static class MortgageStatus {

        @JsonProperty("抵押权人")
        private String mortgagee;

        @JsonProperty("抵押金额（万元）")
        private String mortgageAmount;

        @JsonProperty("抵押期限")
        private String mortgagePeriod;

        @JsonProperty("不动产登记证明号")
        private String realEstateRegistrationCertificateNo;

        @JsonProperty("登记时间")
        private String checkInTime;
    }

    // 权利限制
    @Data
    public static class RestrictionOfRights {

        @JsonProperty("限制人")
        private String restrictedPerson;

        @JsonProperty("限制类别")
        private String restrictedCategory;

        @JsonProperty("限制文号")
        private String restrictedDocumentNumber;

        @JsonProperty("限制期限")
        private String restrictedPeriod;

        @JsonProperty("登记时间")
        private String checkInTime;

    }
}
