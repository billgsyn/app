package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 支付宝理财资产证明
 * @author anyspa
 */

@Data
public class AlipayAssetProof {
    @JsonProperty("姓名")
    private String name;

    @JsonProperty("身份证号码")
    private String idNo;

    @JsonProperty("资产合计")
    private String assetTotal;

    @JsonProperty("编号")
    private String number;

    @JsonProperty("开具公司")
    private String issuingCompany;

    @JsonProperty("开具日期")
    private String issuingDate;

    @JsonProperty("资产列表")
    private List<AlipayAssetProofInfo> alipayAssetProofInfoList;
}
