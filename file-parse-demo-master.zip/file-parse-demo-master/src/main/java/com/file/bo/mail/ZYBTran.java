package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ZYBTran {

    @JsonProperty("交易日期")
    private String tranDate;

    @JsonProperty("交易时间")
    private String tranTime;

    @JsonProperty("金额")
    private String amount;

    @JsonProperty("收支状态")
    private String revenueExpenditureStatus;

    @JsonProperty("余额")
    private String balance;

    @JsonProperty("对方行名")
    private String counterPartyBankName;

    @JsonProperty("对方户名")
    private String counterPartyAccountName;

    @JsonProperty("对方账号")
    private String counterPartyAccountNumber;

    @JsonProperty("交易渠道")
    private String tradeChannel;

    @JsonProperty("交易类型")
    private String tradeType;

    @JsonProperty("币种")
    private String currency;

}
