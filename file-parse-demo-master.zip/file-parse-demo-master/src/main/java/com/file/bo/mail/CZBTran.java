package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author anyspa
 */
@Data
public class CZBTran {

    /**
     * 交易时间
     */
    @JsonProperty("交易时间")
    private String tranDate;

    /**
     * 发生额(元)
     */
    @JsonProperty("发生额(元)")
    private String tranAmount;

    /**
     * 当前余额
     */
    @JsonProperty("当前余额")
    private String balance;

    /**
     * 当前可用余额 (元)
     */
    @JsonProperty("当前可用余额 (元)")
    private String availableBalance;

    /**
     * 摘要
     */
    @JsonProperty("摘要")
    private String summary;

    /**
     * 对方账号
     */
    @JsonProperty("对方账号")
    private String counterPartyAccountNumber;

    /**
     * 对方户名
     */
    @JsonProperty("对方户名")
    private String counterPartyAccountName;

    /**
     * 对方开户行
     */
    @JsonProperty("对方开户行")
    private String counterPartyBank;

    /**
     * 备注
     */
    @JsonProperty("备注")
    private String remark;


}
