package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 民生银行
 */
@Data
public class CMBC {

    /**
     * 客户姓名
     */
    @JsonProperty("客户姓名")
    private String customerName;

    /**
     * 客户账号
     */
    @JsonProperty("客户账号")
    private String customerAccount;

    /**
     * 产品名称
     */
    @JsonProperty("产品名称")
    private String productName;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 钞汇标志
     */
    @JsonProperty("钞汇标志")
    private String cashExchange;

    /**
     * 开户机构
     */
    @JsonProperty("开户机构")
    private String accountOpeningInstitution;

    /**
     * 账户账号
     */
    @JsonProperty("账户账号")
    private String accountNo;

    /**
     * 起止日期
     */
    @JsonProperty("起止日期")
    private String transDetailPeriod;

    /**
     * 筛选条件
     */
    @JsonProperty("筛选条件")
    private String filter;

    /**
     * 证件号码
     */
    @JsonProperty("证件号码")
    private String idNo;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<CMBCTran> cmbcTrans;

}
