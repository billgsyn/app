package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 国家政务APP-婚姻证件-结婚证/离婚证原件
 * @author anyspa
 */

@Data
public class AppGjzwfwHyzjOriginal {

    @JsonProperty("持证人姓名")
    private String holderName;

    @JsonProperty("持证人身份证件号")
    private String holderIdNo;

    @JsonProperty("配偶姓名")
    private String partnerName;

    @JsonProperty("配偶身份证件号")
    private String partnerIdNo;
}
