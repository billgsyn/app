package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 成都不动产-房屋信息查询记录
 * @author anyspa
 */

@Data
public class CDBDCHousingInfoQueryRecord {

    @JsonProperty("文件信息")
    private FileInfo fileInfo;

    @JsonProperty("基本信息")
    private BasicInfo basicInfo;

    @JsonProperty("所有权信息")
    private OwnershipInfo ownershipInfo;

    @JsonProperty("合同备案信息")
    private ContractFilingInfo contractFilingInfo;

    @JsonProperty("买受人")
    private Buyer buyer;

    @JsonProperty("出卖人")
    private Seller seller;

    @JsonProperty("抵押信息")
    private List<MortgageInfo> mortgageInfoList;

    @JsonProperty("限制登记信息")
    private String restrictedRegistrationInfo;

    @JsonProperty("其他信息")
    private OtherInfo otherInfo;

    @JsonProperty("历史变动信息")
    private List<HistoricalChangeInfo> historicalChangeInfo;

    @Data
    public static class FileInfo {
        @JsonProperty("文件名")
        private String fileName;

        @JsonProperty("业务件号")
        private String itemNumber;

        @JsonProperty("验证码")
        private String verificationCode;

        @JsonProperty("查询编号")
        private String queryNumber;

        @JsonProperty("查询平台")
        private String queryPlatform;

        @JsonProperty("打印机构")
        private String printingMechanism;

        @JsonProperty("查询时点")
        private String queryTimePoint;

        @JsonProperty("特别提示")
        private String specialSuggestion;
    }

    @Data
    public static class BasicInfo {
        @JsonProperty("所在区")
        private String hostDistrict;

        @JsonProperty("街道")
        private String street;

        @JsonProperty("门牌")
        private String doorPlate;

        @JsonProperty("附号")
        private String attachedNumber;

        @JsonProperty("栋号")
        private String buildingNumber;

        @JsonProperty("单元")
        private String unit;

        @JsonProperty("楼层")
        private String floor;

        @JsonProperty("房号")
        private String roomNumber;

        @JsonProperty("规划用途")
        private String planningUsage;

        @JsonProperty("结构")
        private String structure;

        @JsonProperty("建筑面积")
        private String structureArea;
    }

    @Data
    public static class OwnershipInfo {

        @JsonProperty("所有权人信息")
        private List<OwnerInfo> ownerInfoList;

        @JsonProperty("所有方式")
        private String owningMethod;

        @JsonProperty("取得方式")
        private String gainingMethod;

        @JsonProperty("取得时间")
        private String gainingTime;

        @JsonProperty("备注")
        private String comment;
    }

    @Data
    public static class OwnerInfo {
        @JsonProperty("所有权人")
        private String owner;

        @JsonProperty("证件号码")
        private String idNo;

        @JsonProperty("证书编号")
        private String certificateNumber;

        @JsonProperty("份额")
        private String share;
    }

    @Data
    public static class ContractFilingInfo {
        @JsonProperty("存量房买卖合同签订时间")
        private String saleContractSignedDate;

        @JsonProperty("商品房定购时间")
        private String commercialHousingPurchaseDate;

        @JsonProperty("商品房合同拟定时间")
        private String commercialHousingContractDraftingDate;

        @JsonProperty("商品房合同备案时间")
        private String commercialHousingContractFilingDate;

        @JsonProperty("预售许可证号")
        private String presaleLicenseNumber;

        @JsonProperty("项目名称")
        private String projectName;
    }

    @Data
    public static class Buyer {
        @JsonProperty("买受人信息")
        private List<BuyerInfo> buyerInfo;
    }

    @Data
    public static class BuyerInfo {
        @JsonProperty("名称")
        private String name;

        @JsonProperty("证件类型")
        private String idType;

        @JsonProperty("证件号码")
        private String idNo;
    }

    @Data
    public static class Seller {
        @JsonProperty("出卖人信息")
        private List<SellerInfo> sellerList;
    }

    @Data
    public static class SellerInfo {
        @JsonProperty("名称")
        private String name;
    }

    @Data
    public static class MortgageInfo {
        @JsonProperty("权利设定时间")
        private String rightEstablishmentTime;

        @JsonProperty("抵押权人")
        private String mortgagee;

        @JsonProperty("债务人")
        private String debtor;

        @JsonProperty("抵押面积（平方米）")
        private String mortgagedArea;

        @JsonProperty("被担保债权数额（元）")
        private String securedClaimAmount;

        @JsonProperty("债务履行期限")
        private String debtPerformancePeriod;

        @JsonProperty("状态")
        private String status;

        @JsonProperty("抵押件号")
        private String mortgageNo;
    }

    @Data
    public static class OtherInfo {

        @JsonProperty("是否征收")
        private String isCollected;
    }

    @Data
    public static class HistoricalChangeInfo {
        @JsonProperty("所有权人")
        private String owner;

        @JsonProperty("取得方式")
        private String gainingMethod;

        @JsonProperty("取得时间")
        private String gainingTime;
    }
}
