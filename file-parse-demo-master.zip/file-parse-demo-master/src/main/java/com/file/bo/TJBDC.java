package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 天津不动产
 * @author anyspa
 */

@Data
public class TJBDC {

    @JsonProperty("权利人")
    private String obligee;

    @JsonProperty("共有情况")
    private String coOwnership;

    @JsonProperty("坐落")
    private String location;

    @JsonProperty("不动产单元号")
    private String realEstateUnitNo;

    @JsonProperty("权利类型")
    private String rightType;

    @JsonProperty("登记日期")
    private String registrationDate;

    @JsonProperty("不动产权证号")
    private String realEstateOwnershipCertificateNo;

    @JsonProperty("不动产权登记证明号")
    private String realEstateRegistrationCertificateNo;

    @JsonProperty("土地（非林地）登记信息")
    private List<LandRegistrationInfo> landRegistrationInfos;

    @JsonProperty("房屋（构筑物）等登记信息")
    private List<HouseRegistrationInfo> houseRegistrationInfos;

    @JsonProperty("林地（森林、林木）登记信息")
    private List<ForestLandRegistrationInfo> forestLandRegistrationInfos;

    @JsonProperty("海域信息")
    private List<SeaAreaInfo> seaAreaInfos;

    @JsonProperty("抵押权登记信息")
    private List<MortgageRegistrationInfo> mortgageRegistrationInfos;

    @JsonProperty("地役权登记信息")
    private List<EasementRegistrationInfo> easementRegistrationInfos;

    @JsonProperty("预告登记信息")
    private List<PreviewRegistrationInfo> previewRegistrationInfos;

    @JsonProperty("查封登记信息")
    private List<SealUpRegistrationInfo> sealUpRegistrationInfos;

    @JsonProperty("异议登记信息")
    private List<ObjectionRegistrationInfo> objectionRegistrationInfos;

    @JsonProperty("其他信息")
    private List<OtherInfo> otherInfos;

    // 土地（非林地）登记信息
    @Data
    public static class LandRegistrationInfo {
        @JsonProperty("权利性质")
        private String natureOfRights;

        @JsonProperty("面积")
        private String area;

        @JsonProperty("使用(承包)期限")
        private String serviceLife;

        @JsonProperty("用途")
        private String use;
    }

    // 房屋（构筑物）等登记信息
    @Data
    public static class HouseRegistrationInfo {
        @JsonProperty("幢(房)号")
        private String buildingNo;

        @JsonProperty("房屋结构")
        private String houseStructure;

        @JsonProperty("层数")
        private String totalFloors;

        @JsonProperty("所在层")
        private String floor;

        @JsonProperty("规划用途")
        private String plannedUse;

        @JsonProperty("建筑面积(㎡)")
        private String floorArea;

        @JsonProperty("建筑物类型")
        private String buildingType;
    }

    // 林地（森林、林木）登记信息
    @Data
    public static class ForestLandRegistrationInfo {
        @JsonProperty("面积(亩)")
        private String area;

        @JsonProperty("使用(承包)期限")
        private String serviceLife;

        @JsonProperty("主要种树")
        private String mainTrees;

        @JsonProperty("株数")
        private String treeCount;

        @JsonProperty("小地名")
        private String toponymy;

        @JsonProperty("林班")
        private String forestClass;

        @JsonProperty("小班")
        private String smallClass;
    }

    // 海域信息
    @Data
    public static class SeaAreaInfo {
        @JsonProperty("项目名称")
        private String projectName;

        @JsonProperty("项目性质")
        private String natureOfProject;

        @JsonProperty("使用期限")
        private String serviceLife;

        @JsonProperty("用海类型")
        private String seaUseType;

        @JsonProperty("用海总面积(公顷)")
        private String areaOfSeaUse;

        @JsonProperty("用海方式")
        private String seaUseMode;
    }

    // 抵押权登记信息
    @Data
    public static class MortgageRegistrationInfo {
        @JsonProperty("登记日期")
        private String registrationDate;

        @JsonProperty("不动产登记证明号")
        private String realEstateRegistrationCertificateNo;

        @JsonProperty("抵押人")
        private String mortgagor;

        @JsonProperty("抵押权人")
        private String mortgagee;

        @JsonProperty("抵押范围")
        private String mortgageScope;

        @JsonProperty("被担保主债权数额/最高债权数额")
        private String securedPrincipalClaimAmount;

        @JsonProperty("债务履行期限(债权确定期间)")
        private String debtPerformancePeriod;
    }

    // 地役权登记信息
    @Data
    public static class EasementRegistrationInfo {
        @JsonProperty("登记日期")
        private String registrationDate;

        @JsonProperty("不动产登记证明号")
        private String realEstateRegistrationCertificateNo;

        @JsonProperty("地役权人")
        private String easementHolder;

        @JsonProperty("地役权内容")
        private String easementContent;

        @JsonProperty("需役地坐落")
        private String servileLandLocated;

        @JsonProperty("需役地不动产单元号")
        private String servileLandRealEstateUnitNo;
    }

    // 预告登记信息
    @Data
    public static class PreviewRegistrationInfo {
        @JsonProperty("登记日期")
        private String registrationDate;

        @JsonProperty("不动产登记证明号")
        private String realEstateRegistrationCertificateNo;

        @JsonProperty("预告登记种类")
        private String previewRegistrationType;

        @JsonProperty("建筑面积(㎡)")
        private String floorArea;

        @JsonProperty("权利人")
        private String obligee;

        @JsonProperty("义务人")
        private String obligor;

        @JsonProperty("被担保债权数额(元)")
        private String securedClaimAmount;

        @JsonProperty("债务履行期限")
        private String debtPerformancePeriod;
    }

    // 查封登记信息
    @Data
    public static class SealUpRegistrationInfo {
        @JsonProperty("查封机关")
        private String sealUpAuthority;

        @JsonProperty("查封类型")
        private String sealUpType;

        @JsonProperty("查封时间")
        private String sealUpDate;

        @JsonProperty("查封文件及文号")
        private String sealUpDocument;

        @JsonProperty("查封期限")
        private String sealUpPeriod;
    }

    //异议登记信息
    @Data
    public static class ObjectionRegistrationInfo {
        @JsonProperty("申请人")
        private String applicant;

        @JsonProperty("登记日期")
        private String registrationDate;

        @JsonProperty("异议事项")
        private String objectionItem;
    }

    // 其他信息
    @Data
    public static class OtherInfo {
        @JsonProperty("记载日期")
        private String recordDate;

        @JsonProperty("记载事项")
        private String recordItem;
    }
}
