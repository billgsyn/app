package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class ZhejiangInsuranceParticipation {

    @JsonProperty("姓名")
    private String name = "";

    @JsonProperty("社会保障号")
    private String socialSecurityNumber = "";

    @JsonProperty("证件类型")
    private String idType = "";

    @JsonProperty("证件号码")
    private String idNo = "";

    @JsonProperty("性别")
    private String gender = "";

    @JsonProperty("参加社会保险基本情况")
    private ParticipationInSocialInsurance participationInSocialInsurance;

    @JsonProperty("缴费情况")
    private List<PaymentStatus> paymentStatusList;

    @JsonProperty("备注")
    private String notes = "";

    @JsonProperty("打印时间")
    private String printTime = "";

    @Data
    public static class ParticipationInSocialInsurance {

        @JsonProperty("险种")
        private List<String> insuranceTypeList;

        @JsonProperty("参保状态")
        private List<String> insuranceStatusList;

        @JsonProperty("参保单位")
        private String insuredUnit = "";

    }

    @Data
    @NoArgsConstructor
    public static class PaymentStatus {

        @JsonProperty("年")
        private String year = "";

        @JsonProperty("月")
        private String month = "";

        @JsonProperty("养老参保地")
        private String retirementInsurancePlace = "";

        @JsonProperty("单位编号")
        private String unitNumber = "";

        @JsonProperty("养老保险")
        private EndowmentInsurance endowmentInsurance;

        @JsonProperty("失业保险")
        private UnemploymentInsurance unemploymentInsurance;

        @JsonProperty("备注")
        private String notes = "";

    }

    @Data
    @NoArgsConstructor
    public static class EndowmentInsurance {

        @JsonProperty("参保地")
        private String insurancePlace = "";

        @JsonProperty("缴费基数(元)")
        private String paymentBase = "";

        @JsonProperty("个人缴费(元)")
        private String individualPayment = "";

        @JsonProperty("缴费状况")
        private String paymentStatus = "";

    }

    @Data
    @NoArgsConstructor
    public static class UnemploymentInsurance {

        @JsonProperty("参保地")
        private String insurancePlace = "";

        @JsonProperty("缴费基数(元)")
        private String paymentBase = "";

        @JsonProperty("个人缴费(元)")
        private String individualPayment = "";

        @JsonProperty("缴费状况")
        private String paymentStatus = "";

    }


}
