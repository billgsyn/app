package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 微众银行理财类资产明细
 * @author anyspa
 */

@Data
public class WebankAssetInfo {
    @JsonProperty("资产种类")
    private String assetType;

    @JsonProperty("币种/金额")
    private String currency;

    @JsonProperty("起息日")
    private String valueDate;

    @JsonProperty("到期日")
    private String dueDate;

}
