package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AppAlipayIdCard {

    @JsonProperty("身份证号")
    private String idNo;

    @JsonProperty("证件有效期")
    private String certificateValidity;
}
