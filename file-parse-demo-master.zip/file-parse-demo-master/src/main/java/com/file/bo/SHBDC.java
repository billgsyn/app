package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 上海不动产
 * @author anyspa
 */

@Data
public class SHBDC {

    @JsonProperty("房屋状况及产权人信息")
    private HouseStatusAndOwnerInfo houseStatusAndOwnerInfo;

    @JsonProperty("土地状况信息")
    private LandStatusInfo landStatusInfo;

    @JsonProperty("房地产抵押状况信息")
    private List<RealEstateMortgageInfo> estateMortgageInfos;

    @JsonProperty("文件登记信息")
    private List<DocumentRegistrationInfo> documentRegistrationInfos;

    @Data
    public static class HouseStatusAndOwnerInfo {
        @JsonProperty("No")
        private String no;

        @JsonProperty("房屋坐落")
        private String houseLocation;

        @JsonProperty("幢号")
        private String buildingNo;

        @JsonProperty("部位")
        private String position;

        @JsonProperty("建筑面积")
        private String floorArea;

        @JsonProperty("其中地下建筑面积")
        private String undergroundFloorArea;

        @JsonProperty("房屋类型")
        private String houseType;

        @JsonProperty("房屋结构")
        private String houseStructure;

        @JsonProperty("所有权来源")
        private String sourceOfOwnership;

        @JsonProperty("竣工日期")
        private String completionDate;

        @JsonProperty("房屋用途")
        private String housePurposes;

        @JsonProperty("总层数")
        private String totalFloors;

        @JsonProperty("权利人")
        private String obligee;

        @JsonProperty("共有人及共有情况")
        private String coOwnersAndCoOwnership;

        @JsonProperty("房地产权证号")
        private String realEstateOwnershipCertificateNo;

        @JsonProperty("受理日期")
        private String acceptanceDate;

        @JsonProperty("核准日期")
        private String approvalDate;

        @JsonProperty("备注")
        private String comment;

        @JsonProperty("查询日期")
        private String queryDate;
    }

    @Data
    public static class LandStatusInfo {
        @JsonProperty("No")
        private String no;

        @JsonProperty("土地坐落")
        private String landLocation;

        @JsonProperty("土地宗地号")
        private String landParcelNo;

        @JsonProperty("使用期限")
        private String serviceLife;

        @JsonProperty("土地权属性质")
        private String natureOfLandOwnership;

        @JsonProperty("使用权取得方式")
        private String acquisitionMethodOfUseRight;

        @JsonProperty("土地用途")
        private String landUse;

        @JsonProperty("宗地(丘)面积")
        private String landArea;

        @JsonProperty("使用权面积")
        private String areaOfUseRight;

        @JsonProperty("独用面积")
        private String exclusiveUseArea;

        @JsonProperty("分摊面积")
        private String allocatedArea;

        @JsonProperty("权利人")
        private String obligee;

        @JsonProperty("共有人及共有情况")
        private String coOwnersAndCoOwnership;

        @JsonProperty("房地产权证号")
        private String realEstateOwnershipCertificateNo;

        @JsonProperty("受理日期")
        private String acceptanceDate;

        @JsonProperty("核准日期")
        private String approvalDate;

        @JsonProperty("备注")
        private String comment;

        @JsonProperty("查询日期")
        private String queryDate;
    }

    @Data
    public static class RealEstateMortgageInfo {
        @JsonProperty("No")
        private String no;

        @JsonProperty("房屋坐落")
        private String realEstateLocation;

        @JsonProperty("幢号")
        private String buildingNo;

        @JsonProperty("部位")
        private String position;

        @JsonProperty("抵押权人")
        private String mortgagee;

        @JsonProperty("登记证明号")
        private String registrationCertificateNo;

        @JsonProperty("债权数额")
        private String amountOfCredit;

        @JsonProperty("债务履行期限")
        private String debtPerformancePeriod;

        @JsonProperty("受理日期")
        private String acceptanceDate;

        @JsonProperty("核准日期")
        private String approvalDate;

        @JsonProperty("抵押担保范围")
        private String mortgageGuaranteeScope;

        @JsonProperty("关于不动产转让的约定")
        private String realEstateTransferAgreement;

        @JsonProperty("备注")
        private String comment;

        @JsonProperty("查询日期")
        private String queryDate;
    }

    @Data
    public static class DocumentRegistrationInfo {
        @JsonProperty("No")
        private String no;

        @JsonProperty("申请人")
        private String applicant;

        @JsonProperty("房地产坐落")
        private String realEstateLocation;

        @JsonProperty("文件名称")
        private String documentName;

        @JsonProperty("文件号")
        private String documentNo;

        @JsonProperty("登记证明号")
        private String registrationCertificateNo;

        @JsonProperty("受理日期")
        private String acceptanceDate;

        @JsonProperty("备注")
        private String comment;

        @JsonProperty("查询日期")
        private String queryDate;
    }
}
