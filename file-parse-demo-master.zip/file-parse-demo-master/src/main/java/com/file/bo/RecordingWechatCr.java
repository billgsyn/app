package com.file.bo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class RecordingWechatCr {

    @JsonProperty("姓名")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String name;

    @JsonProperty("手机号")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String mobilePhone;

    @JsonProperty("微信支付分")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String weixinScore;

    @JsonProperty("芝麻分")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String zmfScore;

}
