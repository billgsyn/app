package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ShanxiIndividualRecordSheet {

    @JsonProperty("记录期间")
    private String recordPeriod;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("单位名称")
    private String unitName;

    @JsonProperty("社会保障号码")
    private String socialSecurityNumber;

    @JsonProperty("首次参保日期")
    private FirstInsuranceDate firstInsuranceDate;

    @JsonProperty("缴费情况")
    private PaymentSituation paymentSituation;

    @JsonProperty("个人账户情况")
    private PersonalAccount personalAccount;

    @JsonProperty("打印时间")
    private String printTime;

    @Data
    public static class PaymentSituation {

        @JsonProperty("个人月缴费基数")
        private IndividualMonthlyPaymentBase individualMonthlyPaymentBase;

        @JsonProperty("养老缴费信息")
        private PensionInsuranceFee pensionInsuranceFee;

        @JsonProperty("医疗缴费信息")
        private MedicalInsuranceFee medicalInsuranceFee;

        @JsonProperty("失业缴费信息")
        private UnemploymentInsuranceFee unemploymentInsuranceFee;

        @JsonProperty("工伤缴费信息(单位缴费)")
        private String injuryFee;

        @JsonProperty("生育缴费信息(单位缴费)")
        private String maternityFee;

        @JsonProperty("本年个人补缴欠费金额")
        private PersonalArrearsPaymentThisYear PersonalArrearsPaymentThisYear;

        @JsonProperty("补历年缴费月数")
        private CompensatoryPaymentYearMonths CompensatoryPaymentYearMonths;

        @JsonProperty("截至本年末实际缴费月数")
        private ActualPaymentMonthsByYearEnd ActualPaymentMonthsByYearEnd;

        @JsonProperty("累计欠缴月数")
        private CumulativeArrearsMonths CumulativeArrearsMonths;
    }

    @Data
    public static class IndividualMonthlyPaymentBase {
        @JsonProperty("养老")
        private String pension;

        @JsonProperty("医疗")
        private String medical;

        @JsonProperty("失业")
        private String unemployment;

        @JsonProperty("工伤")
        private String injury;

        @JsonProperty("生育")
        private String maternity;
    }


    @Data
    public static class PensionInsuranceFee {
        @JsonProperty("单位缴费")
        private String unitContribution;

        @JsonProperty("个人缴费")
        private String personalContribution;
    }

    @Data
    public static class MedicalInsuranceFee {
        @JsonProperty("单位缴费")
        private String unitContribution;

        @JsonProperty("个人缴费")
        private String personalContribution;
    }

    @Data
    public static class UnemploymentInsuranceFee {
        @JsonProperty("单位缴费")
        private String unitContribution;

        @JsonProperty("个人缴费")
        private String personalContribution;
    }

    @Data
    public static class FirstInsuranceDate {
        @JsonProperty("养老")
        private String pension;

        @JsonProperty("医疗")
        private String medical;

        @JsonProperty("失业")
        private String unemployment;

        @JsonProperty("工伤")
        private String injury;

        @JsonProperty("生育")
        private String maternity;

    }

    @Data
    public static class PersonalArrearsPaymentThisYear {
        @JsonProperty("养老")
        private String pension;

        @JsonProperty("医疗")
        private String medical;

        @JsonProperty("失业")
        private String unemployment;

    }
    @Data
    public static class CompensatoryPaymentYearMonths {
        @JsonProperty("养老")
        private String pension;

        @JsonProperty("医疗")
        private String medical;

        @JsonProperty("失业")
        private String unemployment;

    }
    @Data
    public static class ActualPaymentMonthsByYearEnd {
        @JsonProperty("养老")
        private String pension;

        @JsonProperty("医疗")
        private String medical;

        @JsonProperty("失业")
        private String unemployment;

    }
    @Data
    public static class CumulativeArrearsMonths {
        @JsonProperty("养老")
        private String pension;

        @JsonProperty("医疗")
        private String medical;

        @JsonProperty("失业")
        private String unemployment;

    }

    @Data
    public static class PersonalAccount {

        @JsonProperty("险种")
        private String insuranceType;

        @JsonProperty("截至上年末个人账户累计储存额")
        private String accumulatedSavings;

        @JsonProperty("当年记账金额")
        private String annualBookkeepingAmount;

        @JsonProperty("当年个人账户支出金额")
        private String annualPersonalExpenditure;

        @JsonProperty("当年记账利息")
        private String annualInterest;

        @JsonProperty("至本年末账户累计储存额")
        private String yearEndAccumulatedSavings;
    }

}
