package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 四川省农村信用社账户交易明细
 * @author v_wbhwliu
 */
@Data
public class SCRCUTran {

    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String transactionDate;

    /**
     * 交易时间
     */
    @JsonProperty("交易时间")
    private String time;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String transactionAmount;

    /**
     * 账户余额
     */
    @JsonProperty("账户余额")
    private String balance;

    /**
     * 对方户名
     */
    @JsonProperty("对方户名")
    private String counterPartyAccountName;

    /**
     * 对方账号
     */
    @JsonProperty("对方账号")
    private String counterPartyAccountNo;

    /**
     * 对方银行
     */
    @JsonProperty("对方银行")
    private String counterPartyBank;

    /**
     * 用途
     */
    @JsonProperty("用途")
    private String purpose;

    /**
     * 备注
     */
    @JsonProperty("备注")
    private String comment;

    /**
     * 记账日期
     */
    @JsonProperty("记账日期")
    private String date;

}
