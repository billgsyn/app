package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 微众银行理财类资产证明
 * @author anyspa
 */

@Data
public class WebankAsset {
    @JsonProperty("姓名")
    private String name;

    @JsonProperty("身份证号码")
    private String idNo;

    @JsonProperty("金融资产金额合计")
    private String assetTotal;

    @JsonProperty("编号")
    private String number;

    @JsonProperty("截止时间")
    private String expirationDate;

    @JsonProperty("开具日期")
    private String issueDate;

    @JsonProperty("资产列表")
    private List<WebankAssetInfo> webankAssetInfos;
}
