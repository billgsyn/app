package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class TianjinInsuranceParticipation {

    @JsonProperty("打印日期")
    private String printDate;

    @JsonProperty("校验码")
    private String verificationCode;

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("社会保障号")
    private String socialSecurityNumber;

    @JsonProperty("当前参保单位名称")
    private String currentEmployerName;

    @JsonProperty("缴费情况")
    private List<ContributionDetails> contributionDetails;

    @JsonProperty("天津市城职参保情况")
    private List<TianjinUrbanEmploymentInsurance> tianjinUrbanEmploymentInsurance;

    @JsonProperty("备注")
    private String remarks;

    @Data
    public static class ContributionDetails {
        @JsonProperty("险种")
        private String insuranceType;

        @JsonProperty("本市缴费起止时间")
        private String localContributionPeriod;

        @JsonProperty("缴费年限")
        private String contributionYears;
    }

    @Data
    public static class TianjinUrbanEmploymentInsurance {
        @JsonProperty("起止年月")
        private String period;

        @JsonProperty("基本养老保险")
        private PensionInsurance pensionInsurance;

        @JsonProperty("失业保险")
        private UnemploymentInsurance unemploymentInsurance;

        @JsonProperty("缴费类型")
        private String contributionType;

        @JsonProperty("缴费单位")
        private String contributingOrganization;

        @Data
        public static class PensionInsurance {
            @JsonProperty("缴费基数")
            private String contributionBase;

            @JsonProperty("个人缴费")
            private String personalContribution;
        }

        @Data
        public static class UnemploymentInsurance {
            @JsonProperty("缴费基数")
            private String contributionBase;

            @JsonProperty("个人缴费")
            private String personalContribution;
        }
    }

}