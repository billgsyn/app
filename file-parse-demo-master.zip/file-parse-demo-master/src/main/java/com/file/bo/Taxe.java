package com.file.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 任职单位
 * @author anyspa
 */

@Data
public class Taxe {

    @JsonProperty("姓名")
    private String name;

    @JsonProperty("任职受雇信息")
    private List<EmploymentInfo> employmentInfoList;

    // 任职受雇信息
    @Data
    public static class EmploymentInfo {

        @JsonProperty("任职受雇单位")
        private String employedCompany;

        @JsonProperty("统一社会信用代码")
        private String unifiedSocialCreditCode;

        @JsonProperty("任职受雇日期")
        private String employedPeriod;

        @JsonProperty("职务")
        private String position;

        @JsonProperty("离职日期")
        private String reasonDate;

    }
}
