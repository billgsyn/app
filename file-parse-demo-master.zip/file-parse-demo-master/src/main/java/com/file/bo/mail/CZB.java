package com.file.bo.mail;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.file.bo.mail.CZBTran;
import lombok.Data;

import java.util.List;

/**
 * 浙商银行
 * @author anyspa
 */

@Data
public class CZB {

    /**
     * 户名
     */
    @JsonProperty("户名")
    private String name;

    /**
     * 账号
     */
    @JsonProperty("账号")
    private String accountNo;

    /**
     * 起止日期
     */
    @JsonProperty("起止日期")
    private String transDetailPeriod;

    /**
     * 查询日期
     */
    @JsonProperty("查询日期")
    private String queryDate;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<CZBTran> czbTrans;

}
