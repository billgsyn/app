package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class HenanIndividualRecordSheet {

    @JsonProperty("姓名")
    private String name;

}
