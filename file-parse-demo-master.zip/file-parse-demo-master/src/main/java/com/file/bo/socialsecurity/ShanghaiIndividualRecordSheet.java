package com.file.bo.socialsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ShanghaiIndividualRecordSheet {

    @JsonProperty("参保人姓名")
    private String insuredName;

    @JsonProperty("个人账号")
    private String personalAccount;

    @JsonProperty("参保单位名称")
    private String insuredUnitName;

    @JsonProperty("连续工龄")
    private String continuousWorkingYears;

    @JsonProperty("金额单位")
    private String monetaryUnit;

    @JsonProperty("养老保险个人账户的记账情况")
    private List<PaymentDetail> paymentDetailList;

    @JsonProperty("补充资料")
    private String supplementaryInformation;

    @JsonProperty("经办机构")
    private String operatingAgency;

    @JsonProperty("打印日期")
    private String printTime;

    @Data
    public static class PaymentDetail {

        @JsonProperty("项目年份")
        private String projectYear;

        @JsonProperty("缴费月数")
        private String paymentMonths;

        @JsonProperty("本息储存总额")
        private String principalAndInterestTotalDepositAmount;

        @JsonProperty("个人缴费本息")
        private String individualPaymentPrincipalAndInterest;

        @JsonProperty("记账额")
        private String bookkeepingAmount;

        @JsonProperty("个人缴费额")
        private String individualPaymentAmount;

        @JsonProperty("当年计算利息")
        private String theYearCalculateInterest;

    }

}
