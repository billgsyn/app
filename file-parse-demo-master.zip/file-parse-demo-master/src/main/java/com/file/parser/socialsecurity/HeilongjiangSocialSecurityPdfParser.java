package com.file.parser.socialsecurity;


import com.file.bo.ResponseData;
import com.file.bo.socialsecurity.HeilongjiangIndividualRecordSheet;
import com.file.bo.socialsecurity.HeilongjiangInsuranceParticipation;
import com.file.constant.ErrorCode;
import com.file.parser.BasePdfParser;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import technology.tabula.*;
import technology.tabula.detectors.SpreadsheetDetectionAlgorithm;
import technology.tabula.extractors.SpreadsheetExtractionAlgorithm;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class HeilongjiangSocialSecurityPdfParser extends BasePdfParser {

    public ResponseData<String> parseHeilongjiangSocialSecurityPdfToJson(String daId, String filePath) {
        log.info("parseHeilongjiangSocialSecurityPdfToJson started, daId:{}", daId);
        String json = null;

        try {
            if (filePath.contains("cbzm")) {
                HeilongjiangInsuranceParticipation heilongjiangInsuranceParticipation = parseHeilongjiangInsuranceParticipation(filePath, daId);
                json = JsonUtils.convertObjectToJson(heilongjiangInsuranceParticipation);
            } else if (filePath.contains("qyd")) {//NOSONAR
                HeilongjiangIndividualRecordSheet heilongjiangIndividualRecordSheet = parseHeilongjiangIndividualRecordSheet(filePath);
                json = JsonUtils.convertObjectToJson(heilongjiangIndividualRecordSheet);//NOSONAR
            } else {
                log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseHeilongjiangSocialSecurityPdfToJson failed, new type not supported");
                return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
            }
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseHeilongjiangSocialSecurityPdfToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseHeilongjiangSocialSecurityPdfToJson completed, daId:{}", daId);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private HeilongjiangInsuranceParticipation parseHeilongjiangInsuranceParticipation(String filePath, String daId) {
        HeilongjiangInsuranceParticipation heilongjiangInsuranceParticipation = parseHeilongjiangInsuranceParticipationHeader(filePath, daId);
        List<List<String>> rowList = parseFileToRowList(filePath);
//        for (List<String> cellList : rowList) {
//            System.out.println(cellList);
//        }

        parseListToBO(rowList, heilongjiangInsuranceParticipation);
        return heilongjiangInsuranceParticipation;
    }

    private HeilongjiangInsuranceParticipation parseHeilongjiangInsuranceParticipationHeader(String filePath, String daId) {  //NOSONAR
        HeilongjiangInsuranceParticipation heilongjiangInsuranceParticipation = new HeilongjiangInsuranceParticipation();
        String pdfText = getPdfTextByStripper2(filePath)
                .replace(System.getProperty("line.separator", "\n"), "");

        String enterpriseEmployeesBasicEndowmentInsuranceText = pdfText.substring(0, pdfText.indexOf("黑龙江省工伤保险个人参保证明")).replace("社会保险机构名称:", "");
//
//
//        .println("enterpriseEmployeesBasicEndowmentInsuranceText = " + enterpriseEmployeesBasicEndowmentInsuranceText);
        HeilongjiangInsuranceParticipation.EnterpriseEmployeesBasicEndowmentInsurance enterpriseEmployeesBasicEndowmentInsurance = new HeilongjiangInsuranceParticipation.EnterpriseEmployeesBasicEndowmentInsurance();
        enterpriseEmployeesBasicEndowmentInsurance.setInsuranceAgencyName(parsePdfHeaderNullableField(enterpriseEmployeesBasicEndowmentInsuranceText, "基本养老保险个人参保证明|所在单位名称:").trim());
        enterpriseEmployeesBasicEndowmentInsurance.setUnitName(parsePdfHeaderNullableField(enterpriseEmployeesBasicEndowmentInsuranceText, "所在单位名称:|单位编号:").trim());
        enterpriseEmployeesBasicEndowmentInsurance.setUnitNumber(parsePdfHeaderNullableField(enterpriseEmployeesBasicEndowmentInsuranceText, "单位编号:|姓名:").trim());
        enterpriseEmployeesBasicEndowmentInsurance.setName(parsePdfHeaderNullableField(enterpriseEmployeesBasicEndowmentInsuranceText, "姓名:|性别：").trim());
        enterpriseEmployeesBasicEndowmentInsurance.setGender(parsePdfHeaderNullableField(enterpriseEmployeesBasicEndowmentInsuranceText, "性别：|个人编号:").trim());
        enterpriseEmployeesBasicEndowmentInsurance.setPersonalNumber(parsePdfHeaderNullableField(enterpriseEmployeesBasicEndowmentInsuranceText, "个人编号:|参保日期:").trim());
        enterpriseEmployeesBasicEndowmentInsurance.setEnrollmentDate(parsePdfHeaderNullableField(enterpriseEmployeesBasicEndowmentInsuranceText, "参保日期:|参保状态:").trim());
        enterpriseEmployeesBasicEndowmentInsurance.setEnrollmentStatus(parsePdfHeaderNullableField(enterpriseEmployeesBasicEndowmentInsuranceText, "参保状态:|社会保障号码:").trim());
        enterpriseEmployeesBasicEndowmentInsurance.setSocialSecurityNumber(parsePdfHeaderNullableField(enterpriseEmployeesBasicEndowmentInsuranceText, "社会保障号码:|打印日期:").trim());
        enterpriseEmployeesBasicEndowmentInsurance.setPrintDate(parsePdfHeaderNullableField(enterpriseEmployeesBasicEndowmentInsuranceText, "打印日期: |单位:").trim());
        enterpriseEmployeesBasicEndowmentInsurance.setUnit("元");
        enterpriseEmployeesBasicEndowmentInsurance.setDescription(parsePdfHeaderNullableField(enterpriseEmployeesBasicEndowmentInsuranceText, "说明:|").trim());

        if (StringUtils.isEmpty(enterpriseEmployeesBasicEndowmentInsurance.getUnitName())) {
            try {
                enterpriseEmployeesBasicEndowmentInsuranceText = getPdfTextByStripper(filePath)
                        .replace(System.getProperty("line.separator", "\n"), "&");
                enterpriseEmployeesBasicEndowmentInsuranceText = enterpriseEmployeesBasicEndowmentInsuranceText.substring(enterpriseEmployeesBasicEndowmentInsuranceText.indexOf("打印日期:&") + 6, enterpriseEmployeesBasicEndowmentInsuranceText.indexOf("&" + enterpriseEmployeesBasicEndowmentInsurance.getName()));
//                System.out.println(enterpriseEmployeesBasicEndowmentInsuranceText);
                enterpriseEmployeesBasicEndowmentInsurance.setInsuranceAgencyName(enterpriseEmployeesBasicEndowmentInsuranceText.substring(0, enterpriseEmployeesBasicEndowmentInsuranceText.indexOf("&")));
                enterpriseEmployeesBasicEndowmentInsurance.setUnitName(enterpriseEmployeesBasicEndowmentInsuranceText.substring(enterpriseEmployeesBasicEndowmentInsuranceText.indexOf("&") + 1).replace("&", ""));
                enterpriseEmployeesBasicEndowmentInsurance.setUnitNumber(enterpriseEmployeesBasicEndowmentInsurance.getUnitNumber().replace("司", ""));
            } catch (Exception e) {
                log.error("enterpriseEmployeesBasicEndowmentInsurance parse insuranceAgencyName + unitName error");
            }

        }

        heilongjiangInsuranceParticipation.setEnterpriseEmployeesBasicEndowmentInsurance(enterpriseEmployeesBasicEndowmentInsurance);

        String workInjuryInsuranceText = pdfText.substring(pdfText.indexOf("黑龙江省工伤保险个人参保证明"), pdfText.indexOf("黑龙江省失业保险参保证明"));
//        System.out.println("workInjuryInsuranceText = " + workInjuryInsuranceText);
        HeilongjiangInsuranceParticipation.WorkInjuryInsurance workInjuryInsurance = new HeilongjiangInsuranceParticipation.WorkInjuryInsurance();
        workInjuryInsurance.setAgencyName(parsePdfHeaderNullableField(workInjuryInsuranceText, "工伤保险机构名称：|所在单位名称：").trim());
        workInjuryInsurance.setUnitName(parsePdfHeaderNullableField(workInjuryInsuranceText, "所在单位名称：|单位编号：").trim());
        workInjuryInsurance.setUnitNumber(parsePdfHeaderNullableField(workInjuryInsuranceText, "单位编号：|姓名：").trim());
        workInjuryInsurance.setName(parsePdfHeaderNullableField(workInjuryInsuranceText, "姓名：|性别：").trim());
        workInjuryInsurance.setGender(parsePdfHeaderNullableField(workInjuryInsuranceText, "性别：|个人编号：").trim());
        workInjuryInsurance.setPersonalNumber(parsePdfHeaderNullableField(workInjuryInsuranceText, "个人编号：|参保日期：").trim());
        workInjuryInsurance.setEnrollmentDate(parsePdfHeaderNullableField(workInjuryInsuranceText, "参保日期：|参保状态：").trim());
        workInjuryInsurance.setEnrollmentStatus(parsePdfHeaderNullableField(workInjuryInsuranceText, "参保状态：|社会保障号：").trim());
        workInjuryInsurance.setSocialSecurityNumber(parsePdfHeaderNullableField(workInjuryInsuranceText, "社会保障号：|打印日期：").trim());
        workInjuryInsurance.setPrintDate(parsePdfHeaderNullableField(workInjuryInsuranceText, "打印日期：|单位：").trim());
        workInjuryInsurance.setUnit("元");
        workInjuryInsurance.setDescription(parsePdfHeaderNullableField(workInjuryInsuranceText, "说明：|").trim());
        if (workInjuryInsurance.getDescription().contains("说明：")) {
            workInjuryInsurance.setDescription("1.年度缴费标识中：√为已缴费，×为未缴费。2.提供近5年的参保缴费情况。");
        }
        heilongjiangInsuranceParticipation.setWorkInjuryInsurance(workInjuryInsurance);

        String unemploymentInsuranceText = pdfText.substring(pdfText.indexOf("黑龙江省失业保险参保证明"));
//        System.out.println("unemploymentInsuranceText = " + unemploymentInsuranceText);
        HeilongjiangInsuranceParticipation.UnemploymentInsurance unemploymentInsurance = new HeilongjiangInsuranceParticipation.UnemploymentInsurance();
        unemploymentInsurance.setName(parsePdfHeaderNullableField(unemploymentInsuranceText, "姓名：|性别：").trim());
        unemploymentInsurance.setGender(parsePdfHeaderNullableField(unemploymentInsuranceText, "性别：|社会保障号：").trim());
        unemploymentInsurance.setSocialSecurityNumber(parsePdfHeaderNullableField(unemploymentInsuranceText, "社会保障号：|参保日期：").trim());
        unemploymentInsurance.setEnrollmentDate(parsePdfHeaderNullableField(unemploymentInsuranceText, "参保日期：|当前参保单位：").trim());
        unemploymentInsurance.setCurrentUnit(parsePdfHeaderNullableField(unemploymentInsuranceText, "当前参保单位：|缴费状态：").trim());
        unemploymentInsurance.setPaymentStatus(parsePdfHeaderNullableField(unemploymentInsuranceText, "缴费状态：|当前参保属地：").trim());
        unemploymentInsurance.setCurrentLocation(parsePdfHeaderNullableField(unemploymentInsuranceText, "当前参保属地：|查询打印日期：").trim());
        unemploymentInsurance.setQueryPrintDate(parsePdfHeaderNullableField(unemploymentInsuranceText, "查询打印日期：|历年参保缴费情况").trim());
        heilongjiangInsuranceParticipation.setUnemploymentInsurance(unemploymentInsurance);

        return  heilongjiangInsuranceParticipation;
    }

    private HeilongjiangIndividualRecordSheet parseHeilongjiangIndividualRecordSheet(String filePath) { //NOSONAR
        HeilongjiangIndividualRecordSheet heilongjiangIndividualRecordSheet = parseHeilongjiangIndividualRecordSheetHeader(filePath);
        List<List<String>> rowList = parseFileToRowList(filePath);
//        for (List<String> cellList : rowList) {
//            System.out.println(cellList);
//        }

        parseListToBO(rowList, heilongjiangIndividualRecordSheet);
        return heilongjiangIndividualRecordSheet;
    }

    private void parseListToBO(List<List<String>> rowList, HeilongjiangIndividualRecordSheet heilongjiangIndividualRecordSheet) {
        HeilongjiangIndividualRecordSheet.PersonalInfo personalInfo = new HeilongjiangIndividualRecordSheet.PersonalInfo();
        HeilongjiangIndividualRecordSheet.ContributionDetails contributionDetails = new HeilongjiangIndividualRecordSheet.ContributionDetails();
        HeilongjiangIndividualRecordSheet.AccountDetails accountDetails = new HeilongjiangIndividualRecordSheet.AccountDetails();
        HeilongjiangIndividualRecordSheet.PensionDetails pensionDetails = new HeilongjiangIndividualRecordSheet.PensionDetails();
        heilongjiangIndividualRecordSheet.setPersonalInfo(personalInfo);
        heilongjiangIndividualRecordSheet.setContributionDetails(contributionDetails);
        heilongjiangIndividualRecordSheet.setAccountDetails(accountDetails);
        heilongjiangIndividualRecordSheet.setPensionDetails(pensionDetails);

        String sectionName = "";

        for (int i = 0; i < rowList.size(); i++) {
            List<String> cellList = rowList.get(i);
            if (StringUtils.equals(cellList.get(0), "个人基本信息")) {
                sectionName = "个人基本信息";
                continue;
            } else if (StringUtils.equals(cellList.get(0), "首次参保日期")) {
                sectionName = "首次参保日期";
            } else if (StringUtils.equals(cellList.get(0), "缴费情况")) {
                sectionName = "缴费情况";
                continue;
            } else if (StringUtils.equals(cellList.get(0), "个人账户情况")) {
                sectionName = "个人账户情况";
                continue;
            } else if (StringUtils.equals(cellList.get(0), "养老金领取情况")) {
                sectionName = "养老金领取情况";
                continue;
            } else if (StringUtils.equalsAny(cellList.get(0), "个人月缴费基数", "截至上年末个人账户累计储存额")) {
                continue;
            }

            switch (sectionName) { //NOSONAR
                case "个人基本信息":
                    personalInfo.setName(cellList.get(1));
                    personalInfo.setCompanyName(cellList.get(3));
                    break;
                case "首次参保日期":
                    personalInfo.setFirstEnrollmentDate(cellList.get(1));
                    personalInfo.setSocialSecurityNumber(cellList.get(3));
                    break;
                case "缴费情况":
                    contributionDetails.setMonthlyContributionBase(cellList.get(0));
                    contributionDetails.setCompanyContribution(cellList.get(1));
                    contributionDetails.setPersonalContribution(cellList.get(2));
                    contributionDetails.setAnnualArrearsPayment(cellList.get(3));
                    contributionDetails.setMonthsOfArrearsCompensation(cellList.get(4));
                    contributionDetails.setActualPaidMonthsByYearEnd(cellList.get(5));
                    contributionDetails.setAccumulatedUnpaidMonths(cellList.get(6));
                    break;
                case "个人账户情况":
                    accountDetails.setCumulativeBalanceAtLastYearEnd(cellList.get(0));
                    accountDetails.setCurrentYearBookkeepingAmount(cellList.get(1));
                    accountDetails.setCurrentYearAccountExpenditure(cellList.get(2));
                    accountDetails.setCurrentYearInterest(cellList.get(3));
                    accountDetails.setCumulativeBalanceAtThisYearEnd(cellList.get(4));
                    break;
                case "养老金领取情况":
                    pensionDetails.setMonthlyPensionLevel(cellList.get(1));
                    pensionDetails.setCurrentYearAdjustmentAmount(cellList.get(3));
                    break;
            }
        }

    }

    private HeilongjiangIndividualRecordSheet parseHeilongjiangIndividualRecordSheetHeader(String filePath) {
        HeilongjiangIndividualRecordSheet heilongjiangIndividualRecordSheet = new HeilongjiangIndividualRecordSheet();
        String pdfText = getPdfTextByStripper2(filePath)
                .replace(System.getProperty("line.separator", "\n"), "");
//        System.out.println(pdfText);
        heilongjiangIndividualRecordSheet.setYear(pdfText.substring(0, pdfText.indexOf("年度社会保险个人权益记录单")));
        heilongjiangIndividualRecordSheet.setInsuranceOfficeName(parsePdfHeaderNullableField(pdfText, "社会保险经办机构名称：|联系电话：").trim());
        heilongjiangIndividualRecordSheet.setContactPhone(parsePdfHeaderNullableField(pdfText, "联系电话：|地址：").trim());
        heilongjiangIndividualRecordSheet.setAddress(parsePdfHeaderNullableField(pdfText, "地址：|打印时间：").trim());
        heilongjiangIndividualRecordSheet.setPrintTime(parsePdfHeaderNullableField(pdfText, "打印时间：|").trim());

        return heilongjiangIndividualRecordSheet;
    }



    private void parseListToBO(List<List<String>> rowList, HeilongjiangInsuranceParticipation heilongjiangInsuranceParticipation) {
        List<HeilongjiangInsuranceParticipation.EnterpriseEmployeesBasicEndowmentInsurancePaymentDetail> enterpriseEmployeesBasicEndowmentInsurancePaymentDetailList = new ArrayList<>();
        heilongjiangInsuranceParticipation.getEnterpriseEmployeesBasicEndowmentInsurance().setEnterpriseEmployeesBasicEndowmentInsurancePaymentDetailList(enterpriseEmployeesBasicEndowmentInsurancePaymentDetailList);

        List<HeilongjiangInsuranceParticipation.WorkInjuryInsurancePaymentDetail> workInjuryInsurancePaymentDetailList = new ArrayList<>();
        heilongjiangInsuranceParticipation.getWorkInjuryInsurance().setWorkInjuryInsurancePaymentDetailList(workInjuryInsurancePaymentDetailList);

        List<HeilongjiangInsuranceParticipation.UnemploymentInsurancePaymentDetail> unemploymentInsurancePaymentDetailList = new ArrayList<>();
        heilongjiangInsuranceParticipation.getUnemploymentInsurance().setUnemploymentInsurancePaymentDetailList(unemploymentInsurancePaymentDetailList);

        int tableIndex = 0;


        for (int i = 0; i < rowList.size(); i++) {
            List<String> cellList = rowList.get(i);
            if (StringUtils.equals(cellList.get(0), "缴费年度")) {
                if (StringUtils.equals(cellList.get(5), "年度缴费标识")) {
                    tableIndex = 1;
                    continue;
                }  else if (StringUtils.equals(cellList.get(3), "年度缴费标识")) {
                    tableIndex = 2;
                    continue;
                } else if (StringUtils.equals(cellList.get(2), "年度个人缴费标识")) {
                    tableIndex = 3;
                    continue;
                }
            } else if (StringUtils.isEmpty(cellList.get(0))) {
                continue;
            } else if (cellList.get(0).contains("所在单位名称") || cellList.get(0).contains("单位") || cellList.get(0).contains("缴费状态")) {
                continue;
            }

            switch (tableIndex) { //NOSONAR
                case 1:
//                    System.out.println("table 1 = " + cellList);
                    HeilongjiangInsuranceParticipation.EnterpriseEmployeesBasicEndowmentInsurancePaymentDetail enterpriseEmployeesBasicEndowmentInsurancePaymentDetail = new HeilongjiangInsuranceParticipation.EnterpriseEmployeesBasicEndowmentInsurancePaymentDetail();
                    enterpriseEmployeesBasicEndowmentInsurancePaymentDetail.setPaymentYear(cellList.get(0));
                    enterpriseEmployeesBasicEndowmentInsurancePaymentDetail.setPaymentMonthCount(cellList.get(1));
                    enterpriseEmployeesBasicEndowmentInsurancePaymentDetail.setPaymentBaseTotal(cellList.get(2));
                    enterpriseEmployeesBasicEndowmentInsurancePaymentDetail.setPersonalAccountPaymentAmount(cellList.get(3));
                    enterpriseEmployeesBasicEndowmentInsurancePaymentDetail.setAccountBalance(cellList.get(4));
                    String[] paymentStatus = new String[12];
                    paymentStatus[0] = cellList.get(5);
                    paymentStatus[1] = cellList.get(6);
                    paymentStatus[2] = cellList.get(7);
                    paymentStatus[3] = cellList.get(8);
                    paymentStatus[4] = cellList.get(9);
                    paymentStatus[5] = cellList.get(10);
                    paymentStatus[6] = cellList.get(11);
                    paymentStatus[7] = cellList.get(12);
                    paymentStatus[8] = cellList.get(13);
                    paymentStatus[9] = cellList.get(14);
                    paymentStatus[10] = cellList.get(15);
                    paymentStatus[11] = cellList.get(16);
                    for (int j = 0; j < paymentStatus.length; j++) {
                        paymentStatus[j] = StringUtils.equals(paymentStatus[j], "√") ? "Y" : paymentStatus[j];
                        paymentStatus[j] = StringUtils.equals(paymentStatus[j], "×") ? "N" : paymentStatus[j];
                    }

                    enterpriseEmployeesBasicEndowmentInsurancePaymentDetail.setPaymentStatus(paymentStatus);
                    enterpriseEmployeesBasicEndowmentInsurancePaymentDetailList.add(enterpriseEmployeesBasicEndowmentInsurancePaymentDetail);
                    break;
                case 2:
//                    System.out.println("table 2 = " + cellList);
                    HeilongjiangInsuranceParticipation.WorkInjuryInsurancePaymentDetail workInjuryInsurancePaymentDetail = new HeilongjiangInsuranceParticipation.WorkInjuryInsurancePaymentDetail();
                    workInjuryInsurancePaymentDetail.setPaymentYear(cellList.get(0));
                    workInjuryInsurancePaymentDetail.setPaymentMonthCount(cellList.get(1));
                    workInjuryInsurancePaymentDetail.setPaymentBaseTotal(cellList.get(2));
                    String[] paymentStatus2 = new String[12];
                    paymentStatus2[0] = cellList.get(3);
                    paymentStatus2[1] = cellList.get(4);
                    paymentStatus2[2] = cellList.get(5);
                    paymentStatus2[3] = cellList.get(6);
                    paymentStatus2[4] = cellList.get(7);
                    paymentStatus2[5] = cellList.get(8);
                    paymentStatus2[6] = cellList.get(9);
                    paymentStatus2[7] = cellList.get(10);
                    paymentStatus2[8] = cellList.get(11);
                    paymentStatus2[9] = cellList.get(12);
                    paymentStatus2[10] = cellList.get(13);
                    paymentStatus2[11] = cellList.get(14);
                    for (int j = 0; j < paymentStatus2.length; j++) {
                        paymentStatus2[j] = StringUtils.equals(paymentStatus2[j], "√") ? "Y" : paymentStatus2[j];
                        paymentStatus2[j] = StringUtils.equals(paymentStatus2[j], "×") ? "N" : paymentStatus2[j];
                    }
                    workInjuryInsurancePaymentDetail.setPaymentStatus(paymentStatus2);
                    workInjuryInsurancePaymentDetailList.add(workInjuryInsurancePaymentDetail);
                    break;
                case 3:
//                    System.out.println("table 3 = " + cellList);
                    HeilongjiangInsuranceParticipation.UnemploymentInsurancePaymentDetail unemploymentInsurancePaymentDetail = new HeilongjiangInsuranceParticipation.UnemploymentInsurancePaymentDetail();
                    unemploymentInsurancePaymentDetail.setPaymentYear(cellList.get(0));
                    unemploymentInsurancePaymentDetail.setAnnualPaymentBaseTotal(cellList.get(1));
                    String[] paymentStatus3 = new String[12];
                    paymentStatus3[0] = cellList.get(2);
                    paymentStatus3[1] = cellList.get(3);
                    paymentStatus3[2] = cellList.get(4);
                    paymentStatus3[3] = cellList.get(5);
                    paymentStatus3[4] = cellList.get(6);
                    paymentStatus3[5] = cellList.get(7);
                    paymentStatus3[6] = cellList.get(8);
                    paymentStatus3[7] = cellList.get(9);
                    paymentStatus3[8] = cellList.get(10);
                    paymentStatus3[9] = cellList.get(11);
                    paymentStatus3[10] = cellList.get(12);
                    paymentStatus3[11] = cellList.get(13);
                    for (int j = 0; j < paymentStatus3.length; j++) {
                        paymentStatus3[j] = StringUtils.equals(paymentStatus3[j], "√") ? "Y" : paymentStatus3[j];
                        paymentStatus3[j] = StringUtils.equals(paymentStatus3[j], "×") ? "N" : paymentStatus3[j];
                    }
                    unemploymentInsurancePaymentDetail.setPaymentStatus(paymentStatus3);
                    unemploymentInsurancePaymentDetailList.add(unemploymentInsurancePaymentDetail);
                    break;
            }

        }
    }

    private List<List<String>> parseFileToRowList(String filePath) {
        // 1. 读取文件
        File pdf = new File(filePath);

        //页面所有table的记录，每一个元素代表下面一条记录cellList
        List<List<String>> rowList = new ArrayList<>();

        // 2. pdfbox读取PDDocument
        try (PDDocument pdfDocument = PDDocument.load(pdf)) {
            // 3. tabula新建ObjectExtractor和NurminenDetectionAlgorithm，同时准备接收表格Rectangle的结构
            ObjectExtractor objectExtractor = new ObjectExtractor(pdfDocument);
            SpreadsheetDetectionAlgorithm detectionAlgorithm = new SpreadsheetDetectionAlgorithm();
            Map<Integer, List<Rectangle>> pageNumber2RectangleListMap = new HashMap<>();//key为页的序号， value为对应的Rectangle的list

            // 4. 获取每页的PageIterator
            PageIterator pageIterator = objectExtractor.extract();

            // 5. 解析每页的Rectangle
            // 如果单页pdf中有多个Rectangle，则解析出来的List<Rectangle>会有多个对象
            while (pageIterator.hasNext()) {
                Page page = pageIterator.next();
                List<Rectangle> rectangleList = detectionAlgorithm.detect(page);
                if (rectangleList.size() > 0) {
                    pageNumber2RectangleListMap.put(page.getPageNumber(), rectangleList);
                }
            }

            // 6.通过table位置获取表格具体内容
            SpreadsheetExtractionAlgorithm extractionAlgorithm = new SpreadsheetExtractionAlgorithm();

            // 如果单页pdf中有多个表格，则解析出来的List<Rectangle>会有多个对象
            for (Map.Entry<Integer, List<Rectangle>> entry : pageNumber2RectangleListMap.entrySet()) {
                Page page = objectExtractor.extract(entry.getKey());
                Rectangle rectangle = null;

                List<Rectangle> rectangleList = entry.getValue();
                for (Rectangle r : rectangleList) {
                    double rectangleHeight = r.getHeight();
                    if (Double.compare(rectangleHeight, 0) > 0) {
                        rectangle = r;
                        break;
                    }
                }
                if (rectangle == null) {
                    throw new RuntimeException("rectangle is null.");
                }

//                if (entry.getKey() > 1) {
                    rectangle.setTop(rectangle.getTop() - 100);
//                }
                rectangle.setBottom(rectangle.getBottom() + 200);
                Page area = page.getArea(rectangle);

                // 如果每页有多个表格，解析每一个table
                List<Table> tableList = extractionAlgorithm.extract(area);
                for (Table table : tableList) {
                    for (int i = 0; i < table.getRowCount(); i++) {
                        List<String> cellList = new ArrayList<>();//一条记录，每个单元格占一个元素
                        for (int j = 0; j < table.getColCount(); j++) {
                            cellList.add(table.getCell(i, j).getText(false));
                        }
                        rowList.add(cellList);
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }

        return rowList;
    }

    public static void main(String[] args) {
        String filePath = "D:\\data\\file\\socialsecurity\\黑龙江\\黑龙江1\\app-gjzwfw-dzsb_qyd.pdf";
        String json = null;
        HeilongjiangSocialSecurityPdfParser heilongjiangSocialSecurityPdfParser = new HeilongjiangSocialSecurityPdfParser();
        json = heilongjiangSocialSecurityPdfParser.parseHeilongjiangSocialSecurityPdfToJson("", filePath).getData();
        System.out.println(json);
    }

}
