package com.file.parser;


import com.file.bo.AppGjzwfwJsz;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;

/**
 * 国家政务-驾驶证 html 解析
 * @author anyspa
 */

@Slf4j
public class AppGjzwfwJszHtmlParser {
    public ResponseData<String> parseAppGjzwfwJszHtmlToJson(String daId, String filePath) {
        log.info("parseAppGjzwfwJszHtmlToJson started, daId:{}, filePath:{}", daId, filePath);
        String json = null;

        try {
            AppGjzwfwJsz jszInfo = parseJszInfoHtml(filePath);
            json = JsonUtils.convertObjectToJson(jszInfo);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseAppGjzwfwJszHtmlToJson failed", e);
            return new ResponseData<>(json, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseAppGjzwfwJszHtmlToJson completed, daId:{}, filePath:{}, json:{}", daId, filePath, json);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private AppGjzwfwJsz parseJszInfoHtml(String filePath) throws IOException {
        log.info("parseJszInfoHtml started, filePath:{}", filePath);
        AppGjzwfwJsz jszInfo = new AppGjzwfwJsz();

        File input = new File(filePath);
        Document doc = Jsoup.parse(input, "UTF-8");

        Element maskElement = doc.select(".mask").first();
        if (maskElement != null) {
            String score = maskElement.getElementsByClass("score").text();
            jszInfo.setScore(score);
            Element element = maskElement.getElementsByTag("p").first();
            if (element != null && StringUtils.isNotBlank(element.text())) {
                try {
                    String text = element.text();
                    String verificationValidityPeriod = text.substring(text.indexOf("审验有效期") + 5).trim();
                    jszInfo.setVerificationValidityPeriod(verificationValidityPeriod);
                } catch (Exception e) {
                    log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "appGjzwfwJsz html [审验有效期] not found");
                }
            }
        }

        Elements elements = doc.select(".am-list-item");
        for (Element element : elements) {
            String labelText = element.getElementsByClass("am-list-label").text();
            String controlText = element.getElementsByClass("am-list-control").text();
            switch (labelText) {//NOSONAR
                case "姓名":
                    jszInfo.setName(controlText);
                    break;
                case "身份证号":
                    jszInfo.setIdNo(controlText);
                    break;
                case "档案编号":
                    jszInfo.setArchivesNo(controlText);
                    break;
                case "准驾车型":
                    jszInfo.setQuasiDrivingModel(controlText);
                    break;
                case "发证机关":
                    jszInfo.setIssuingAuthority(controlText);
                    break;
                case "驾照有效期":
                    jszInfo.setDriverLicenseExpireDate(controlText);
                    break;
                case "下一检验日":
                    jszInfo.setNextInspectionDay(controlText);
                    break;
                case "驾驶证状态":
                    jszInfo.setDriverLicenseStatus(controlText);
                    break;
            }
        }

        log.info("parseJszInfoHtml completed, filePath:{}, jszInfo:{}", filePath, jszInfo);
        return jszInfo;
    }

    public static void main(String[] args) {
        String filePath = "D:\\data\\file\\appGjzwJsz\\jsz_zm.html";
        AppGjzwfwJszHtmlParser jszHtmlParser = new AppGjzwfwJszHtmlParser();
        String json = jszHtmlParser.parseAppGjzwfwJszHtmlToJson("daId", filePath).getData();
        System.out.println(json);
    }
}
