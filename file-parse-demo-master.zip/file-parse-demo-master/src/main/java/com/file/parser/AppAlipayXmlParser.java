package com.file.parser;


import com.file.bo.AppAlipayIdCard;
import com.file.bo.AppAlipayPersonal;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.dom4j.DocumentException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 芝麻分，蚂蚁借呗，蚂蚁花呗，网商贷 四合一
 * @author anyspa
 */

@Slf4j
public class AppAlipayXmlParser extends AppAlipayBaseXmlParser {

    private AppAlipayCrXmlParser appAlipayCrXmlParser = new AppAlipayCrXmlParser();

    private AppAlipayHuaBeiXmlParser appAlipayHuaBeiXmlParser = new AppAlipayHuaBeiXmlParser();

    private AppAlipayJieBeiXmlParser appAlipayJieBeiXmlParser = new AppAlipayJieBeiXmlParser();

    private AppAlipayWsdXmlParser appAlipayWsdXmlParser = new AppAlipayWsdXmlParser();

    public ResponseData<String> parseAppAlipayXmlToJson(String daId, String filePath,
                                                        List<String> zhimafenNoDataScenarioList,
                                                        List<String> jiebeiNoDataScenarioList,
                                                        List<String> huabeiNoDataScenarioList,
                                                        List<String> wsdNoDataScenarioList) {
        log.info("parseAppAlipayXmlToJson started, daId:{}, filePath:{}", daId, filePath);
        String json;

        try {
            if (filePath.contains("alipay_cr")) {
                return appAlipayCrXmlParser.parseAppAlipayCrXmlToJson(daId, filePath, zhimafenNoDataScenarioList);
            } else if (filePath.contains("alipay_jiebei")) {
                return appAlipayJieBeiXmlParser.parseAppAlipayJieBeiXmlToJson(daId, filePath, jiebeiNoDataScenarioList);
            } else if (filePath.contains("alipay_huabei")) {
                return appAlipayHuaBeiXmlParser.parseAppAlipayHuaBeiXmlToJson(daId, filePath, huabeiNoDataScenarioList);
            } else if (filePath.contains("alipay_wsd")) {
                return appAlipayWsdXmlParser.parseAppAlipayWsdXmlToJson(daId, filePath, wsdNoDataScenarioList);
            } else if (filePath.contains("alipay_personal")) {
                AppAlipayPersonal appAlipayPersonal = parseAppAlipayPersonalXml(filePath);
                json = JsonUtils.convertObjectToJson(appAlipayPersonal);
            } else if (filePath.contains("alipay_idcard")) {
                AppAlipayIdCard appAlipayIdCard = parseAppAlipayIdcardXml(filePath);
                json = JsonUtils.convertObjectToJson(appAlipayIdCard);
            } else {
                throw new RuntimeException("the file name is not supported");
            }
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseAppAlipayXmlToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseAppAlipayXmlToJson completed, daId:{}, filePath:{}", daId, filePath);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    public static void main(String[] args) throws DocumentException {
        AppAlipayXmlParser appAlipayXmlParser = new AppAlipayXmlParser();
        AppAlipayCrXmlParser appAlipayCrXmlParser = new AppAlipayCrXmlParser();
        AppAlipayHuaBeiXmlParser appAlipayHuaBeiXmlParser = new AppAlipayHuaBeiXmlParser();
        AppAlipayJieBeiXmlParser appAlipayJieBeiXmlParser = new AppAlipayJieBeiXmlParser();
        AppAlipayWsdXmlParser appAlipayWsdXmlParser = new AppAlipayWsdXmlParser();
        List<String> zhimafenNoDataScenarioList =  Arrays.asList("暂时无法开通");
        List<String> jiebeiNoDataScenarioList = Arrays.asList("借呗服务未开通到你", "暂时无法向你提供借款服务", "你当前登录的账号暂无申请资格", "服务未开通到你", "服务暂未开放到你","建议多使用支付宝");
        List<String> huabeiNoDataScenarioList = Arrays.asList("花呗暂时无法为您服务", "不支持开通花呗", "你暂时无法升级");
        List<String> wsdNoDataScenarioList = Arrays.asList("暂未确认你的经营身份", "暂时没有贷款额度","网商贷借钱已关闭","暂时无法为你提供服务","无可用额度","本次申请未通过");

        List<String> list = new ArrayList<>();
        list.add("D:\\data\\file\\app-alipay-zmxy\\alipay_cr.xml");
        list.add("D:\\data\\file\\app-alipay-hb\\alipay_huabei.xml");
        list.add("D:\\data\\file\\app-alipay-jb\\alipay_jiebei.xml");
        list.add("D:\\data\\file\\app-alipay-wsd\\alipay_wsd.xml");
        list.add("D:\\data\\file\\app-alipay-jb\\alipay_personal.xml");
        list.add("D:\\data\\file\\app-alipay-jb\\alipay_idcard.xml");

        for (String filePath : list) {
            String json = "";
            if (filePath.contains("alipay_cr")) {
                json = appAlipayCrXmlParser.parseAppAlipayCrXmlToJson("", filePath, zhimafenNoDataScenarioList).getData();
                System.out.println(json);
            } else if (filePath.contains("alipay_jiebei")) {
                json = appAlipayJieBeiXmlParser.parseAppAlipayJieBeiXmlToJson("", filePath, jiebeiNoDataScenarioList).getData();
                System.out.println(json);
            } else if (filePath.contains("alipay_huabei")) {
                json = appAlipayHuaBeiXmlParser.parseAppAlipayHuaBeiXmlToJson("", filePath, huabeiNoDataScenarioList).getData();
                System.out.println(json);
            } else if (filePath.contains("alipay_wsd")) {
                json = appAlipayWsdXmlParser.parseAppAlipayWsdXmlToJson("", filePath, wsdNoDataScenarioList).getData();
                System.out.println(json);
            } else if (filePath.contains("alipay_personal")) {
                AppAlipayPersonal appAlipayPersonal = appAlipayXmlParser.parseAppAlipayPersonalXml(filePath);
                json = JsonUtils.convertObjectToJson(appAlipayPersonal);
                System.out.println(json);
            } else if (filePath.contains("alipay_idcard")) {
                AppAlipayIdCard appAlipayIdCard = appAlipayXmlParser.parseAppAlipayIdcardXml(filePath);
                json = JsonUtils.convertObjectToJson(appAlipayIdCard);
                System.out.println(json);
            }
        }
    }
}
