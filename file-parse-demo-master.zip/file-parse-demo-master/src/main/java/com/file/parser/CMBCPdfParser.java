package com.file.parser;

import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * 民生银行pdf流水解析
 * @author anyspa
 */

@Slf4j
public class CMBCPdfParser extends BasePdfParser{

    private CMBCPdfParser1 cmbcPdfParser1 = new CMBCPdfParser1();

    private CMBCPdfParser2 cmbcPdfParser2 = new CMBCPdfParser2();

    public ResponseData<String> parseCMBCPdfToJson(String daId, String filePath) {
        log.info("parseCMBCPdfToJson started, daId:{}", daId);

        try {
            String pdfHeaderText = parsePdfHeaderText(filePath);
            if (pdfHeaderText.contains("Personal Account Statement") || pdfHeaderText.contains("客户姓名Name")) {
                return cmbcPdfParser2.parseCMBCPdfToJson(daId, filePath);
            } else {
                return cmbcPdfParser1.parseCMBCPdfToJson(daId, filePath);
            }
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseCMBCPdfToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }
    }


    public static void main(String[] args) {
        CMBCPdfParser bcmPdfParser = new CMBCPdfParser();
//        String filePath = "D:\\data\\files\\CMBC\\zd4gujg61577132004024164352_acbf4bbb179c21bbfe225f4005045514_beehive-cmbc_jyls-0.pdf";
//        String filePath = "D:\\data\\files\\CMBC\\zd4tdybm1547483479489552384_b5cdad2b11232f0a51ed1bef89cccb15_beehive-cmbc_jyls-0.pdf";
        String filePath = "D:\\data\\files\\CMBC\\pdf_mx2022102110293145454.pdf";
        String json = null;
        String pdfHeaderText = bcmPdfParser.parsePdfHeaderText(filePath);
        if (StringUtils.isNotBlank(pdfHeaderText)) {
            if (pdfHeaderText.contains("Personal Account Statement") || pdfHeaderText.contains("客户姓名Name")) {
                json = new CMBCPdfParser2().parseCMBCPdfToJson("dd", filePath).getData();
            } else {
                json = new CMBCPdfParser1().parseCMBCPdfToJson("dd", filePath).getData();
            }
        }
        System.out.println(json);
    }
}
