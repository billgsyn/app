package com.file.parser;

import com.file.bo.PSBC;
import com.file.bo.PSBCTran;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
public class PSBCExcelParser {

	public ResponseData<String> parsePSBCExcelToJson(String daId, String filePath) {
		log.info("parsePSBCExcelToJson started, daId:{}", daId);
		String json = null;

		try {
			PSBC psbc = parsePSBCExcel(filePath);
			json = JsonUtils.convertObjectToJson(psbc);
			doAlert(daId, psbc);
		} catch (Exception e) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson failed", e);
			return new ResponseData<String>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
					ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
		}

		log.info("parsePSBCExcelToJson completed, daId:{}", daId);
		return new ResponseData<String>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
	}

	public PSBC parsePSBCExcel(String filePath) {
		PSBC psbc = null;
		try (FileInputStream fis = new FileInputStream(new File(filePath));
				HSSFWorkbook workbook = new HSSFWorkbook(fis)) {
			HSSFSheet sheet = workbook.getSheetAt(0);
			psbc = new PSBC();
			List<PSBCTran> psbcTrans = new ArrayList<>();
			for (int i = 0; i < sheet.getLastRowNum(); i++) {
				Row row = sheet.getRow(i);
				if (i == 1) {
                    psbc.setAccountNumber(row.getCell(0) != null ? row.getCell(0).getStringCellValue() : "");
                    psbc.setTransactionType(row.getCell(1) != null ? row.getCell(1).getStringCellValue() : "");
                    psbc.setTransferInAccountNumber(row.getCell(2) != null ? row.getCell(2).getStringCellValue() : "");
                    psbc.setIncomeExpense(row.getCell(3) != null ? row.getCell(3).getStringCellValue() : "");
                    psbc.setStartDate(row.getCell(4) != null ? row.getCell(4).getStringCellValue() : "");
                    psbc.setExpirationDate(row.getCell(5) != null ? row.getCell(5).getStringCellValue() : "");
                    psbc.setTotalIncome(row.getCell(6) != null ? this.getStringCellValue(row.getCell(6)) : "");
                    psbc.setTotalExpense(row.getCell(7) != null ? this.getStringCellValue(row.getCell(7)) : "");
	            }
	
	            if (i >= 3) {
	                    PSBCTran psbcTran = new PSBCTran();
	                    psbcTran.setTransactionDate(row.getCell(0) != null ? row.getCell(0).getStringCellValue() : "");
	                    psbcTran.setPaymentAccountName(row.getCell(1) != null ? row.getCell(1).getStringCellValue() : "");
	                    psbcTran.setPayeeAccountNumber(row.getCell(2) != null ? row.getCell(2).getStringCellValue() : "");
	                    psbcTran.setIncomeExpense(row.getCell(3) != null ? row.getCell(3).getStringCellValue() : "");
	                    psbcTran.setTransactionAmount(row.getCell(4) != null ? this.getStringCellValue(row.getCell(4)) : "");
	                    psbcTran.setBalance(row.getCell(5) != null ? this.getStringCellValue(row.getCell(5)) : "");
	                    psbcTran.setSummary(row.getCell(6) != null ? row.getCell(6).getStringCellValue() : "");
	                    psbcTran.setComment(row.getCell(7) != null ? row.getCell(7).getStringCellValue() : "");
	                    psbcTrans.add(psbcTran);
	            }
			}
			psbc.setPsbcTrans(psbcTrans);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		return psbc;
	}
	
	private void doAlert(String daId, PSBC psbc) {
		log.info("doAlert started daId: {}", daId);
		//加入字段告警
		if (StringUtils.isBlank(psbc.getAccountNumber())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbc AccountNumber is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(psbc.getTransactionType())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbc TransactionType is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(psbc.getIncomeExpense())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbc IncomeExpense is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(psbc.getStartDate())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbc StartDate is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(psbc.getExpirationDate())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbc ExpirationDate is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(psbc.getTotalIncome())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbc TotalIncome is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(psbc.getTotalExpense())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbc TotalExpense is null");
			throw new RuntimeException();
		}
		
		List<PSBCTran> psbcTrans = psbc.getPsbcTrans();
		if (psbcTrans.size() == 0) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbcTrans size is 0");
		}
		
		for (PSBCTran psbcTran : psbcTrans) {
			if (StringUtils.isBlank(psbcTran.getTransactionDate())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbcTran TransactionDate is null");
				throw new RuntimeException();
			}
			if (StringUtils.isBlank(psbcTran.getIncomeExpense())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbcTran IncomeExpense is null");
				throw new RuntimeException();
			}
			if (StringUtils.isBlank(psbcTran.getTransactionAmount())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbcTran TransactionAmount is null");
				throw new RuntimeException();
			}
			if (StringUtils.isBlank(psbcTran.getBalance())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parsePSBCExcelToJson psbcTran Balance is null");
				throw new RuntimeException();
			}
		}
		
		log.info("doAlert completed daId: {}", daId);
	}
	
	private String getStringCellValue(Cell cell) {
        String cellStr;
        if (Objects.equals(cell.getCellType(), CellType.NUMERIC)) {
                cellStr = String.valueOf(cell.getNumericCellValue());
        } else {
                cellStr = cell.getStringCellValue();
        }
        return cellStr;
}

	public static void main(String[] args) throws IOException {
//		String pdfFilePath = "E:\\data\\files\\PSBC\\邮储流水.xls";
//		String jsonFilePath = "E:\\data\\files\\PSBC\\邮储流水.json";
		
		String pdfFilePath = "D:\\data\\files\\PSBC\\383566684931231510_9a30509eeef142d878402bfc05c6a9c1_psbc_jyls-1.xls";
//		String jsonFilePath = "E:\\data\\files\\PSBC\\383566684931231510_9a30509eeef142d878402bfc05c6a9c1_psbc_jyls-1.json";
		
		
//		File jsonFile = new File(jsonFilePath);

		PSBCExcelParser psbcExcelParser = new PSBCExcelParser();
		ResponseData<String> responseData = psbcExcelParser.parsePSBCExcelToJson("dd", pdfFilePath);
		log.info(responseData.getData());
//		FileUtils.write(jsonFile, responseData.getData(), "UTF-8");
//		jsonFile.createNewFile();
	}

}
