package com.file.parser;

import com.file.bo.BOC;
import com.file.bo.ResponseData;
import com.file.bo.BOCTran;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import com.google.common.base.Splitter;
import com.opencsv.CSVReader;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class BOCCsvParser {

	public ResponseData<String> parseBOCCsvToJson(String daId, String filePath) {
		log.info("parseBOCCsvToJson started, daId:{}", daId);
		String json = null;

		try {
			json = parseBOCCsv(filePath);
		} catch (Exception e) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseBOCCsvToJson failed", e);
			return new ResponseData<String>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
					ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
		}

		log.info("parseBOCCsvToJson completed, daId:{}", daId);
		return new ResponseData<String>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
	}

	private String parseBOCCsv(String filePath) throws Exception {
		String json = null;
		BOC boc = new BOC();
		List<BOCTran> transList = new ArrayList<>();

		try (FileInputStream fis = new FileInputStream(filePath);
			 BufferedReader in = new BufferedReader(new InputStreamReader(fis, Charset.forName("Unicode")));
			 CSVReader csvReader = new CSVReader(in)) {
			// 先把头信息读取出来
			csvReader.readNext();
			while (true) {
				String[] content = csvReader.readNext();
				if (content == null) {
					break;
				}
				List<String> list = Splitter.on('\t').trimResults().splitToList(content[0]);
				BOCTran bocTran = new BOCTran();
				bocTran.setTransactionDate(formatString(list.get(0)));
				bocTran.setBusinessSummary(formatString(list.get(1)));
				bocTran.setCounterPartyAccountName(formatString(list.get(2)));
				bocTran.setCounterPartyAccountNumber(formatString(list.get(3)));
				bocTran.setCurrency(formatString(list.get(4)));
				bocTran.setCashExchange(formatString(list.get(5)));
				bocTran.setRevenueAmount(formatString(list.get(6)));
				bocTran.setExpenseAmount(formatString(list.get(7)));
				bocTran.setBalance(formatString(list.get(8)));
				bocTran.setTransactionChannel(formatString(list.get(9)));
				bocTran.setOutletName(formatString(list.get(10)));
				bocTran.setAdditionalComments(formatString(list.get(11)));
				transList.add(bocTran);
			}
		} catch (Exception e) {
			log.info("parseBOCCsv failed");
			throw new RuntimeException(e);
		}

		boc.setBocTrans(transList);
		json = JsonUtils.convertObjectToJson(boc);
		return json;
	}

	private String formatString(String str) {
		String result = "";
		if (StringUtils.isNotBlank(str)) {
			String s = str.replace("\"", "");
			result = "-".equals(s) ? "" : s;
		}
		return result;
	}

	public static void main(String[] args) throws Exception {
		String csvFilePath = "D:\\data\\file\\中行流水.csv";
//		String jsonFilePath = "D:\\data\\file\\中行流水.json";
//		File jsonFile = new File(jsonFilePath);

		BOCCsvParser parser = new BOCCsvParser();
		ResponseData<String> responseData = parser.parseBOCCsvToJson("1", csvFilePath);
		log.info(responseData.getData());
//		FileUtils.write(jsonFile, responseData.getData(), "UTF-8");
//		jsonFile.createNewFile();
	}

}
