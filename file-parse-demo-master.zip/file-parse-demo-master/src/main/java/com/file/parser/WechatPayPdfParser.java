package com.file.parser;

import com.file.bo.ResponseData;
import com.file.bo.mail.WechatPay;
import com.file.bo.mail.WechatPayTran;
import com.file.constant.ErrorCode;
import com.file.parser.traprange.PDFTableExtractor;
import com.file.util.JsonUtils;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class WechatPayPdfParser extends BasePdfParser {

	public static final Integer WECHATPAY_HEADER_LINE_NUMBER = 7;
	public static final Integer WECHATPAY_FOOTER_LINE_NUMBER = 10;

	public ResponseData<String> parseWechatPayPdfToJson(String daId, String filePath) {
		log.info("parseWechatPayPdfToJson started, daId:{}", daId);
		String json = null;

		try {
			WechatPay wechatPay = parseWechatPayPdf(filePath);
			json = JsonUtils.convertObjectToJson(wechatPay);
			doAlert(daId, wechatPay);
		} catch (Exception e) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson failed", e);
			return new ResponseData<String>(json, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
		}

		log.info("parseWechatPayPdfToJson completed, daId:{}", daId);
		return new ResponseData<String>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
	}


	public WechatPay parseWechatPayPdf(String filePath) {
		WechatPay wechatPay = parseWechatHeader(filePath);

		List<WechatPayTran> wechatPayTrans = new ArrayList<WechatPayTran>();//NOSONAR
		wechatPayTrans = parseWechatTrans(filePath);
		//wechatPayTrans = parseTrans(filePath);

		wechatPay.setWechatPayTrans(wechatPayTrans);
		return wechatPay;
	}

	public WechatPay parseWechatHeader(String filePath) {
		WechatPay wechatPay = new WechatPay();
		String pdfHeaderText = parsePdfHeaderText(filePath);
		pdfHeaderText = pdfHeaderText.substring(0, pdfHeaderText.indexOf("具体交易明细"));
		String number = pdfHeaderText.substring(pdfHeaderText.indexOf("编号：") + 3, pdfHeaderText.indexOf("微信支付交易明细证明"))
				.trim();
		String name = null;
		if (pdfHeaderText.contains("(身份证")) {
			name = pdfHeaderText.substring(pdfHeaderText.indexOf("兹证明：") + 4, pdfHeaderText.indexOf("(身份证：")).trim();
		} else {
			name = pdfHeaderText.substring(pdfHeaderText.indexOf("兹证明：") + 4, pdfHeaderText.indexOf("(居民身份证：")).trim();
		}


		String idNumber = pdfHeaderText.substring(pdfHeaderText.indexOf("身份证：") + 4, pdfHeaderText.indexOf(")，在其微信号"))
				.trim();
		String wechatAccount = pdfHeaderText
				.substring(pdfHeaderText.indexOf("在其微信号：") + 6, pdfHeaderText.indexOf("中的交易明细信息如下")).trim();
		String currency = pdfHeaderText.substring(pdfHeaderText.indexOf("币种：") + 3, pdfHeaderText.indexOf("/单位："))
				.trim();
		String unit = pdfHeaderText.substring(pdfHeaderText.indexOf("/单位：") + 4, pdfHeaderText.indexOf("交易明细对应时间段"))
				.trim();
		String transDetailPeriod = pdfHeaderText.substring(pdfHeaderText.indexOf("交易明细对应时间段") + 9).trim();
		wechatPay.setNumber(number);
		wechatPay.setName(name);
		wechatPay.setIdNumber(idNumber);
		wechatPay.setWechatAccount(wechatAccount);
		wechatPay.setCurrency(currency);
		wechatPay.setUnit(unit);
		wechatPay.setTransDetailPeriod(transDetailPeriod);

		return wechatPay;
	}

	public List<WechatPayTran> parseWechatTrans(String filePath) { //NOSONAR
		List<WechatPayTran> wechatPayTrans = new ArrayList<WechatPayTran>();

		// 生成从ASCII 32到126组成的随机字符串, 替换默认的分隔符";"
		String separator =  "~" + RandomStringUtils.randomAscii(8) + "~";

		String transText = parseTransToText(filePath, separator);
		if (Strings.isNullOrEmpty(transText)) {
			return wechatPayTrans;
		}

		List<List<String>> tranFieldsList = parseTransTextToTranFieldsList(transText, separator);

		int emptyColumnIndex = 0;
		if (tranFieldsList.get(0).size() == 7) {
			emptyColumnIndex = getEmptyColumnIndex(tranFieldsList);
		}

		StringBuilder tranOrderIdSb = new StringBuilder();
		StringBuilder tranDateSb = new StringBuilder();
		StringBuilder tranTypeSb = new StringBuilder();
		StringBuilder incomeOrExpenseSb = new StringBuilder();
		StringBuilder tranMethodSb = new StringBuilder();
		StringBuilder tranAmtSb = new StringBuilder();
		StringBuilder tranConterPartySb = new StringBuilder();
		StringBuilder merchantOrderIdSb = new StringBuilder();
		for (int i = 0; i < tranFieldsList.size(); i++) {
			// 正常情况下为8个col
			if (tranFieldsList.get(i).size() == 8) {
				// 如果这一行是新的交易的第一行文本，则新建一个stringbuilder
				boolean isStartOfNewTran = !Strings.isNullOrEmpty(tranFieldsList.get(i).get(3));
				if (isStartOfNewTran) {
					if (i != 0) {
						WechatPayTran wechatPayTran = new WechatPayTran();
						wechatPayTran.setTranOrderId(tranOrderIdSb.toString());
						wechatPayTran.setTranDate(tranDateSb.toString());
						wechatPayTran.setTranType(tranTypeSb.toString());
						wechatPayTran.setIncomeOrExpense(incomeOrExpenseSb.toString());
						wechatPayTran.setTranMethod(tranMethodSb.toString());
						wechatPayTran.setTranAmt(tranAmtSb.toString());
						wechatPayTran.setTranConterParty(tranConterPartySb.toString());
						wechatPayTran.setMerchantOrderId(merchantOrderIdSb.toString());
						wechatPayTrans.add(wechatPayTran);
					}

					tranOrderIdSb = new StringBuilder();
					tranDateSb = new StringBuilder();
					tranTypeSb = new StringBuilder();
					incomeOrExpenseSb = new StringBuilder();
					tranMethodSb = new StringBuilder();
					tranAmtSb = new StringBuilder();
					tranConterPartySb = new StringBuilder();
					merchantOrderIdSb = new StringBuilder();

					tranOrderIdSb.append(tranFieldsList.get(i).get(0));
					tranDateSb.append(tranFieldsList.get(i).get(1));
					tranDateSb.append(" ");
					tranTypeSb.append(tranFieldsList.get(i).get(2));
					incomeOrExpenseSb.append(tranFieldsList.get(i).get(3));
					tranMethodSb.append(tranFieldsList.get(i).get(4));
					tranAmtSb.append(tranFieldsList.get(i).get(5));
					tranConterPartySb.append(tranFieldsList.get(i).get(6));
					if (tranFieldsList.get(i).size() == 8) {
						merchantOrderIdSb.append(tranFieldsList.get(i).get(7));
					}

					if (i == tranFieldsList.size() - 1) {
						WechatPayTran wechatPayTran = new WechatPayTran();
						wechatPayTran.setTranOrderId(tranOrderIdSb.toString());
						wechatPayTran.setTranDate(tranDateSb.toString());
						wechatPayTran.setTranType(tranTypeSb.toString());
						wechatPayTran.setIncomeOrExpense(incomeOrExpenseSb.toString());
						wechatPayTran.setTranMethod(tranMethodSb.toString());
						wechatPayTran.setTranAmt(tranAmtSb.toString());
						wechatPayTran.setTranConterParty(tranConterPartySb.toString());
						wechatPayTran.setMerchantOrderId(merchantOrderIdSb.toString());
						wechatPayTrans.add(wechatPayTran);
					}
					// 如果这一行不是新的交易的第一行文本，则使用已有的stringbuilder继续拼接
				} else {
					tranOrderIdSb.append(tranFieldsList.get(i).get(0));
					tranDateSb.append(tranFieldsList.get(i).get(1));
					tranTypeSb.append(tranFieldsList.get(i).get(2));
					incomeOrExpenseSb.append(tranFieldsList.get(i).get(3));
					tranMethodSb.append(tranFieldsList.get(i).get(4));
					tranAmtSb.append(tranFieldsList.get(i).get(5));
					tranConterPartySb.append(tranFieldsList.get(i).get(6));
					merchantOrderIdSb.append(tranFieldsList.get(i).get(7));

					if (i == tranFieldsList.size() - 1) {
						WechatPayTran wechatPayTran = new WechatPayTran();
						wechatPayTran.setTranOrderId(tranOrderIdSb.toString());
						wechatPayTran.setTranDate(tranDateSb.toString());
						wechatPayTran.setTranType(tranTypeSb.toString());
						wechatPayTran.setIncomeOrExpense(incomeOrExpenseSb.toString());
						wechatPayTran.setTranMethod(tranMethodSb.toString());
						wechatPayTran.setTranAmt(tranAmtSb.toString());
						wechatPayTran.setTranConterParty(tranConterPartySb.toString());
						wechatPayTran.setMerchantOrderId(merchantOrderIdSb.toString());
						wechatPayTrans.add(wechatPayTran);
					}
				}
			} else if (tranFieldsList.get(i).size() == 7) {
				if (emptyColumnIndex == 2) {
					boolean isStartOfNewTran = (tranFieldsList.get(i).get(1).trim().matches("//d{4}-//d{2}-//d{2}"));
					if (isStartOfNewTran) {
						if (i != 0) {
							// 金额
							if (tranFieldsList.get(i).get(4).trim().matches("\\d{1,8}.\\d{2}")) {//NOSONAR
								WechatPayTran wechatPayTran = new WechatPayTran();
								wechatPayTran.setTranOrderId(tranOrderIdSb.toString());
								wechatPayTran.setTranDate(tranDateSb.toString());
								wechatPayTran.setTranType(tranTypeSb.toString());
								wechatPayTran.setIncomeOrExpense(incomeOrExpenseSb.toString());
								wechatPayTran.setTranMethod(tranMethodSb.toString());
								wechatPayTran.setTranAmt(tranAmtSb.toString());
								wechatPayTran.setTranConterParty(tranConterPartySb.toString());
								wechatPayTran.setMerchantOrderId(merchantOrderIdSb.toString());
								wechatPayTrans.add(wechatPayTran);
							}
						}

						tranOrderIdSb = new StringBuilder();
						tranDateSb = new StringBuilder();
						tranTypeSb = new StringBuilder();
						incomeOrExpenseSb = new StringBuilder();
						tranMethodSb = new StringBuilder();
						tranAmtSb = new StringBuilder();
						tranConterPartySb = new StringBuilder();
						merchantOrderIdSb = new StringBuilder();

						tranOrderIdSb.append(tranFieldsList.get(i).get(0));
						tranDateSb.append(tranFieldsList.get(i).get(1));
						tranDateSb.append(" ");
						// tranTypeSb.append(tranFieldsList.get(i).get(2));
						incomeOrExpenseSb.append(tranFieldsList.get(i).get(2));
						tranMethodSb.append(tranFieldsList.get(i).get(3));
						tranAmtSb.append(tranFieldsList.get(i).get(4));
						tranConterPartySb.append(tranFieldsList.get(i).get(5));
						merchantOrderIdSb.append(tranFieldsList.get(i).get(6));

						if (i == tranFieldsList.size() - 1) {
							WechatPayTran wechatPayTran = new WechatPayTran();
							wechatPayTran.setTranOrderId(tranOrderIdSb.toString());
							wechatPayTran.setTranDate(tranDateSb.toString());
							wechatPayTran.setTranType(tranTypeSb.toString());
							wechatPayTran.setIncomeOrExpense(incomeOrExpenseSb.toString());
							wechatPayTran.setTranMethod(tranMethodSb.toString());
							wechatPayTran.setTranAmt(tranAmtSb.toString());
							wechatPayTran.setTranConterParty(tranConterPartySb.toString());
							wechatPayTran.setMerchantOrderId(merchantOrderIdSb.toString());
							wechatPayTrans.add(wechatPayTran);
						}
					// 如果这一行不是新的交易的第一行文本，则使用已有的stringbuilder继续拼接
					} else {
						tranOrderIdSb.append(tranFieldsList.get(i).get(0));
						tranDateSb.append(tranFieldsList.get(i).get(1));
						tranDateSb.append(" ");
						// tranTypeSb.append(tranFieldsList.get(i).get(2));
						incomeOrExpenseSb.append(tranFieldsList.get(i).get(2));
						tranMethodSb.append(tranFieldsList.get(i).get(3));
						tranAmtSb.append(tranFieldsList.get(i).get(4));
						tranConterPartySb.append(tranFieldsList.get(i).get(5));
						merchantOrderIdSb.append(tranFieldsList.get(i).get(6));

						if (i == tranFieldsList.size() - 1) {
							WechatPayTran wechatPayTran = new WechatPayTran();
							wechatPayTran.setTranOrderId(tranOrderIdSb.toString());
							wechatPayTran.setTranDate(tranDateSb.toString());
							wechatPayTran.setTranType(tranTypeSb.toString());
							wechatPayTran.setIncomeOrExpense(incomeOrExpenseSb.toString());
							wechatPayTran.setTranMethod(tranMethodSb.toString());
							wechatPayTran.setTranAmt(tranAmtSb.toString());
							wechatPayTran.setTranConterParty(tranConterPartySb.toString());
							wechatPayTran.setMerchantOrderId(merchantOrderIdSb.toString());
							wechatPayTrans.add(wechatPayTran);
						}
					}
				} else if (emptyColumnIndex == 7) {
					boolean isStartOfNewTran = (tranFieldsList.get(i).get(1).trim().matches("//d{4}-//d{2}-//d{2}"));
					if (isStartOfNewTran) {
						if (i != 0) {
							WechatPayTran wechatPayTran = new WechatPayTran();
							wechatPayTran.setTranOrderId(tranOrderIdSb.toString());
							wechatPayTran.setTranDate(tranDateSb.toString());
							wechatPayTran.setTranType(tranTypeSb.toString());
							wechatPayTran.setIncomeOrExpense(incomeOrExpenseSb.toString());
							wechatPayTran.setTranMethod(tranMethodSb.toString());
							wechatPayTran.setTranAmt(tranAmtSb.toString());
							wechatPayTran.setTranConterParty(tranConterPartySb.toString());
							wechatPayTran.setMerchantOrderId(merchantOrderIdSb.toString());
							wechatPayTrans.add(wechatPayTran);
						}

						tranOrderIdSb = new StringBuilder();
						tranDateSb = new StringBuilder();
						tranTypeSb = new StringBuilder();
						incomeOrExpenseSb = new StringBuilder();
						tranMethodSb = new StringBuilder();
						tranAmtSb = new StringBuilder();
						tranConterPartySb = new StringBuilder();
						merchantOrderIdSb = new StringBuilder();

						tranOrderIdSb.append(tranFieldsList.get(i).get(0));
						tranDateSb.append(tranFieldsList.get(i).get(1));
						tranDateSb.append(" ");
						tranTypeSb.append(tranFieldsList.get(i).get(2));
						incomeOrExpenseSb.append(tranFieldsList.get(i).get(3));
						tranMethodSb.append(tranFieldsList.get(i).get(4));
						tranAmtSb.append(tranFieldsList.get(i).get(5));
						tranConterPartySb.append(tranFieldsList.get(i).get(6));

						if (i == tranFieldsList.size() - 1) {
							WechatPayTran wechatPayTran = new WechatPayTran();
							wechatPayTran.setTranOrderId(tranOrderIdSb.toString());
							wechatPayTran.setTranDate(tranDateSb.toString());
							wechatPayTran.setTranType(tranTypeSb.toString());
							wechatPayTran.setIncomeOrExpense(incomeOrExpenseSb.toString());
							wechatPayTran.setTranMethod(tranMethodSb.toString());
							wechatPayTran.setTranAmt(tranAmtSb.toString());
							wechatPayTran.setTranConterParty(tranConterPartySb.toString());
							wechatPayTran.setMerchantOrderId(merchantOrderIdSb.toString());
							wechatPayTrans.add(wechatPayTran);
						}
						// 如果这一行不是新的交易的第一行文本，则使用已有的stringbuilder继续拼接
					} else {
						tranOrderIdSb.append(tranFieldsList.get(i).get(0));
						tranDateSb.append(tranFieldsList.get(i).get(1));
						tranDateSb.append(" ");
						tranTypeSb.append(tranFieldsList.get(i).get(2));
						incomeOrExpenseSb.append(tranFieldsList.get(i).get(3));
						tranMethodSb.append(tranFieldsList.get(i).get(4));
						tranAmtSb.append(tranFieldsList.get(i).get(5));
						tranConterPartySb.append(tranFieldsList.get(i).get(6));

						if (i == tranFieldsList.size() - 1) {
							WechatPayTran wechatPayTran = new WechatPayTran();
							wechatPayTran.setTranOrderId(tranOrderIdSb.toString());
							wechatPayTran.setTranDate(tranDateSb.toString());
							wechatPayTran.setTranType(tranTypeSb.toString());
							wechatPayTran.setIncomeOrExpense(incomeOrExpenseSb.toString());
							wechatPayTran.setTranMethod(tranMethodSb.toString());
							wechatPayTran.setTranAmt(tranAmtSb.toString());
							wechatPayTran.setTranConterParty(tranConterPartySb.toString());
							wechatPayTran.setMerchantOrderId(merchantOrderIdSb.toString());
							wechatPayTrans.add(wechatPayTran);
						}
					}
				}
			}
		}

		return wechatPayTrans;
	}

	private int getEmptyColumnIndex(List<List<String>> tranFieldsList) {
		int emptyColumnIndex = 0;
		List<String> firstLineColumnList = tranFieldsList.get(0);
		for (int i = 0; i < firstLineColumnList.size(); i++) {
			// 250230921100032228013161264837 | 2023-09-21 14:48:41 | 收入 | / | 0.63 | / | /
			if (StringUtils.equalsAny(firstLineColumnList.get(2).trim(), "收入", "支出", "其他")) {
				emptyColumnIndex = 2;
			} else if (StringUtils.equalsAny(firstLineColumnList.get(3).trim(), "收入", "支出", "其他")
					&& firstLineColumnList.get(5).trim().matches("\\d{1,8}.\\d{2}")) {
				// 250230921100032228013161264837 | 2023-09-21 14:48:41 | 微信红包退 | 收入 | / | 0.63 | /
				emptyColumnIndex = 7;
			}
		}
		return emptyColumnIndex;
	}

	public String parseTransToText(String filePath, String separator) {
		PDFTableExtractor extractor = (new PDFTableExtractor()).setSource(filePath);
		int pdfPageNumber = getPdfPageNumber(filePath);
		//去掉第一页的Header，
		int[] skipFirstPageHeaderLinesIndexes = new int[WECHATPAY_HEADER_LINE_NUMBER];
		for (int i = 0; i < WECHATPAY_HEADER_LINE_NUMBER; i++) {
			skipFirstPageHeaderLinesIndexes[i] = i;
		}
		extractor.exceptLine(0, skipFirstPageHeaderLinesIndexes);

		//去掉最后一页的Footer,两种情况
		int lineNumberInLastPdf = getLineNumberInLastPage(filePath, pdfPageNumber);
		//1.footer文本行完整展现在最后一页PDF,则直接排除最后一页的footer文本行
		if (lineNumberInLastPdf >= WECHATPAY_FOOTER_LINE_NUMBER) {
			int[] skipLastPageFooterLinesIndexes = new int[WECHATPAY_FOOTER_LINE_NUMBER];
			for (int j = 0; j < WECHATPAY_FOOTER_LINE_NUMBER; j++) {
				skipLastPageFooterLinesIndexes[j] = -(j + 1);
			}
			extractor.exceptLine(pdfPageNumber - 1, skipLastPageFooterLinesIndexes);
		} else {
			//2.footer文本行拆分在倒数第一页和倒数第二页，则直接排除最后一页和倒数第二页的WECHAT_FOOTER_LINE_NO-lineNumberInLastPdf
			extractor.exceptPage(pdfPageNumber - 1);

			int footerLinesNumberInlastSecondPage = WECHATPAY_FOOTER_LINE_NUMBER - lineNumberInLastPdf;
			int[] skipLastSecondPageFooterLinesIndexes = new int[footerLinesNumberInlastSecondPage];
			for (int k = 0; k < footerLinesNumberInlastSecondPage; k++) {
				skipLastSecondPageFooterLinesIndexes[k] = -(k + 1);
			}
			extractor.exceptLine(pdfPageNumber - 2, skipLastSecondPageFooterLinesIndexes);
		}

		String text = extractPdfToText(extractor, separator);
		return text;
	}

	private void doAlert(String daId, WechatPay wechatPay) {
		log.info("doAlert started daId: {}", daId);
		//加入字段告警
		if (StringUtils.isBlank(wechatPay.getNumber())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPay Number is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(wechatPay.getName())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPay Name is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(wechatPay.getIdNumber())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPay IdNumber is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(wechatPay.getWechatAccount())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPay WechatAccount is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(wechatPay.getCurrency())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPay Currency is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(wechatPay.getUnit())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPay Unit is null");
			throw new RuntimeException();
		}
		if (StringUtils.isBlank(wechatPay.getTransDetailPeriod())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPay TransDetailPeriod is null");
			throw new RuntimeException();
		}

		List<WechatPayTran> wechatPayTrans = wechatPay.getWechatPayTrans();
		if (wechatPayTrans.size() == 0) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPayTrans size is 0");
		}

		for (WechatPayTran wechatPayTran : wechatPayTrans) {
			if (StringUtils.isBlank(wechatPayTran.getTranOrderId())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPayTran TranOrderId is null");
				throw new RuntimeException();
			}
			if (StringUtils.isBlank(wechatPayTran.getTranDate())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPayTran TranDate is null");
				throw new RuntimeException();
			}
			if (StringUtils.isBlank(wechatPayTran.getIncomeOrExpense())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPayTran IncomeOrExpense is null");
				throw new RuntimeException();
			}
			if (StringUtils.isBlank(wechatPayTran.getTranAmt())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_NULL_ALERT_EXCEPTION.getCode(), daId, "", "", "parseWechatPayPdfToJson wechatPayTran TranAmt is null");
				throw new RuntimeException();
			}
		}
		log.info("doAlert completed daId: {}", daId);
	}

	public static void main(String[] args) throws IOException {
		WechatPayPdfParser wechatPayPdfParser = new WechatPayPdfParser();
		String json;
//		json = wechatPayPdfParser.parseWechatPayPdfToJson("", "D:\\data\\file\\beehive-wechatpay\\20240402\\CgBRa2YLq2uAOdynACAuIxt0ujc436.pdf").getData();
//		System.out.println(json);

		json = wechatPayPdfParser.parseWechatPayPdfToJson("", "D:\\data\\files\\wechatpay\\zd2sqy121592763889706319872_20221116141930.pdf").getData();
		System.out.println(json);

//		json = wechatPayPdfParser.parseWechatPayPdfToJson("", "D:\\data\\file\\wechatpay\\zd2ee2951727874438490787840_b3ef44747a310906b8ad6ea99bbc0d46_beehive-wechatpay_jyls-0.pdf").getData();
//		System.out.println(json);
	}
}
