package com.file.parser;

import com.file.bo.ResponseData;
import com.file.bo.mail.ABC;
import com.file.bo.mail.ABCTran;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import technology.tabula.*;
import technology.tabula.detectors.NurminenDetectionAlgorithm;
import technology.tabula.extractors.BasicExtractionAlgorithm;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class ABCPdfParser extends BasePdfParser {


    public ResponseData<String> parseABCPdfToJson(String daId, String filePath) {
        log.info("parseABCPdfToJson started, daId:{}", daId);
        String json = null;

        try {
            ABC abc = parseABCPdf(filePath);
            json = JsonUtils.convertObjectToJson(abc);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseABCPdfToJson failed", e);
            return new ResponseData<String>(json, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseABCPdfToJson completed, daId:{}", daId);
        return new ResponseData<String>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private ABC parseABCPdf(String filePath) {
        String pdfHeaderText = parsePdfHeaderText(filePath);
        ABC abc = parseABCHeader(pdfHeaderText);
        List<List<String>> rowList = parseFileToRowList(filePath);
//        for (List<String> cellList : rowList) {
//            System.out.println(cellList);
//        }
        parseListToBO(rowList, abc, filePath);

        return abc;
    }

    private void parseListToBO(List<List<String>> rowList, ABC abc, String filePath) {
        List<ABCTran> abcTrans = new ArrayList<>();
        abc.setAbcTrans(abcTrans);

        rowList = reSetRowList_SplitTranDateAndTranTime(rowList);
        rowList = reSetRowList_Split_CounterPartyInfoAndJournalNumber(rowList);
        rowList = reSetRowList_removeExtraColumnAfterTranChannel(rowList);
        rowList = reSetRowList_resetValueForCrossRow(rowList);

        for (int i = 0; i < rowList.size(); i++) {
            if (rowList.get(i).get(0).contains("该交易明细因不可预测") || rowList.get(i).get(5).contains("页")) {
                continue;
            } else if (StringUtils.equals(rowList.get(i).get(0), "交易日期")) {
                continue;
            } else if (StringUtils.isEmpty(rowList.get(i).get(0))) {
                continue;
            }
            ABCTran abcTran = new ABCTran();
            // 兼容交易日期有串行: 有****关村20240326
            Pattern pattern = Pattern.compile("\\d{8}");
            Matcher matcher = pattern.matcher(rowList.get(i).get(0));
            if (matcher.find()) {
                abcTran.setTranDate(matcher.group());
            } else {
                continue;
            }
            abcTran.setTranDate(rowList.get(i).get(0));
            abcTran.setTranTime(rowList.get(i).get(1));
            abcTran.setTranSummary(rowList.get(i).get(2));
            abcTran.setTranAmt(rowList.get(i).get(3));
            abcTran.setBalance(rowList.get(i).get(4));
            abcTran.setCounterPartyInfo(rowList.get(i).get(5));
            abcTran.setJournalNumber(rowList.get(i).get(6));
            abcTran.setTranChannel(rowList.get(i).get(7));
            if (rowList.get(i).size() > 8) {
                abcTran.setTranComment(rowList.get(i).get(8));
            } else {
                System.out.println(rowList.get(i));
                abcTran.setTranComment("");
            }
            abcTrans.add(abcTran);
        }
//        parseCounterPartyInfoAndTranComment(filePath, abcTrans);
    }


    private List<List<String>> reSetRowList_Split_CounterPartyInfoAndJournalNumber(List<List<String>> rowList) {
        // ["交易日期","交易时间","交易摘要","交易金额","本次余额","对手信息 日 志 号","","交易渠道","交易附言"]
        // [交易日期, 交易时间, 交易摘要, 交易金额, 本次余额, 对手信息 日 志 号, 交易渠道, 交易附言]
        boolean needSplit = false;
        boolean addColumn = false;
        for (int i = 0; i < rowList.size(); i++) {
            if (rowList.get(i).get(5).contains("对手信息 日 志 号")) {
                needSplit = true;
                if (rowList.get(i).get(6).contains("交易渠道")) {
                    addColumn = true;
                } else {
                    addColumn = false;
                }
                continue;
            } else if (rowList.get(i).get(5).contains("对手信息") && rowList.get(i).get(6).contains("日 志 号")) {
                needSplit = false;
            }

            if (needSplit) {
                String journalNumber = "";
                String counterPartyInfo = "";
                List<String> row = rowList.get(i);
                if (row.get(5).matches(".*\\d{1,20}")) {
                    Matcher matcher2 = Pattern.compile("\\d{1,20}").matcher(row.get(5));
                    if (matcher2.find()) {
                        journalNumber = matcher2.group();
                        counterPartyInfo = row.get(5).replace(journalNumber, "").trim();
                    }
                    //  日志号出现中文:"0847尾号商户转入"
                } else {
                    if (StringUtils.isBlank(row.get(0))) {
                        continue;
                    }
                    String[] array = row.get(5).split(" ");
                    if (array.length >= 2) {
                        journalNumber = array[array.length - 1];
                        counterPartyInfo = row.get(5).replace(journalNumber, "").trim();
                    }
                }
                //[交易日期, 交易时间, 交易摘要, 交易金额, 本次余额, 对手信息 日 志 号, 交易渠道, 交易附言]
                if (addColumn) {
                    rowList.get(i).set(5, counterPartyInfo);
                    rowList.get(i).add(6, journalNumber);
                    // ["交易日期","交易时间","交易摘要","交易金额","本次余额","对手信息 日 志 号","","交易渠道","交易附言"]
                } else {
                    rowList.get(i).set(5, counterPartyInfo);
                    rowList.get(i).set(6, journalNumber);
                }
            }
        }
        return rowList;
    }

    private List<List<String>> reSetRowList_SplitTranDateAndTranTime(List<List<String>> rowList) {
        //[交易日期 交易时间, 交易摘要, 交易金额, 本次余额, 对手信息, 日 志 号, 交易渠道, , 交易附言]
        boolean needSplitTranDateAndTranTime = false;

        for (int i = 0; i < rowList.size(); i++) {
            if (rowList.get(i).get(0).contains("交易日期 交易时间")) {
                needSplitTranDateAndTranTime = true;
            } else if (rowList.get(i).get(0).contains("交易日期") && rowList.get(i).get(1).contains("交易时间")) {
                needSplitTranDateAndTranTime = false;
            }

            if (needSplitTranDateAndTranTime) {
                String tranDateAndTranTime = rowList.get(i).get(0);
                if (StringUtils.isEmpty(tranDateAndTranTime)) {
                    rowList.get(i).add(1, "");
                } else {
                    String[] array = tranDateAndTranTime.split(" ");
                    if (array.length == 2) {
                        rowList.get(i).set(0, array[0]);
                        rowList.get(i).add(1, array[1]);
                    } else if (array.length == 1) {
                        rowList.get(i).add(1, "");
                    }
                }
            }
        }

//        if (needSplitTranDateAndTranTime) {
//            for (int i = 0; i < rowList.size(); i++) {
//                String tranDateAndTranTime = rowList.get(i).get(0);
//                if (StringUtils.isEmpty(tranDateAndTranTime)) {
//                    rowList.get(i).add(1, "");
//                } else {
//                    String[] array = tranDateAndTranTime.split(" ");
//                    if (array.length == 2) {
//                        rowList.get(i).set(0, array[0]);
//                        rowList.get(i).add(1, array[1]);
//                    } else if (array.length == 1) {
//                        rowList.get(i).add(1, "");
//                    }
//                }
//            }
//        }

        return rowList;
    }


    private List<List<String>> reSetRowList_resetValueForCrossRow(List<List<String>> rowList) {
//        [, , , , , 武汉合众易宝科技有限, , , NG2024010200113923426084530210000抖音生活服务]
//        [20240102, 144713, 代付, +2174.34, 6373.11, , 430829307, 电子商务, ]
//        [, , , , , 公司, , , 商家提现合众易宝]
        for (int i = 0; i < rowList.size(); i++) {
            if (rowList.get(i).size() > 5 && StringUtils.isEmpty(rowList.get(i).get(5))) {
                if (i > 0 && i < rowList.size() - 1
                        && StringUtils.isNotBlank(rowList.get(i - 1).get(5))
                        && StringUtils.isEmpty(rowList.get(i - 1).get(0))) {
                    rowList.get(i).set(5, rowList.get(i - 1).get(5) + rowList.get(i + 1).get(5));
                }
            }

            // 日志号换行
            // [, , , , , 招联消费金融股份有, 单号, , ]
            // [20240122, 122637, 转存, +13200.00, 48848.30, 招联消费金融股份有限公司, , 超级网银, 招联放款13200.00元]
            // [, , , , , 限公司, 24012200XXXX175, , ]
            if (rowList.get(i).size() > 6 && StringUtils.isEmpty(rowList.get(i).get(6))) {
                if (i > 0 && i < rowList.size() - 1
                        && StringUtils.isNotBlank(rowList.get(i - 1).get(6))
                        && StringUtils.isEmpty(rowList.get(i - 1).get(0))
                        && StringUtils.isEmpty(rowList.get(i + 1).get(0))) {
                    rowList.get(i).set(6, rowList.get(i - 1).get(6) + rowList.get(i + 1).get(6));
                }
            }

            //  交易附言换行
            // [, , , , , , , , NA202307039068532XXXXXXX银行股份]
            //  [20230703, 174411, 支付宝, -3.88, 4213.32, 215500690, 515446105, 电子商务, ]
            // [, , , , , , , , 有限公司]
            if (i > 0 && i < rowList.size() - 1 && rowList.get(i).size() > 8 && StringUtils.isEmpty(rowList.get(i).get(8))) {
                if (rowList.get(i - 1).size() < 9 || rowList.get(i + 1).size() < 9) {
                    continue;
                }
                if (StringUtils.isNotBlank(rowList.get(i - 1).get(8))
                        && StringUtils.isEmpty(rowList.get(i - 1).get(0))
                        && StringUtils.isEmpty(rowList.get(i + 1).get(0))) {
                    rowList.get(i).set(8, rowList.get(i - 1).get(8) + rowList.get(i + 1).get(8));
                }
            }
        }
        return rowList;
    }

    private void parseCounterPartyInfoAndTranComment(String filePath, List<ABCTran> abcTrans) {
        String pdfText = getPdfTextByStripper(filePath);
        pdfText = pdfText.replace(System.getProperty("line.separator", "\n"), " ");

        // 20221020 125058 代付 +2000.00 2073.05 财付通⽀付科技有限公 司 216355563 电⼦商务 NG20221020142128555576932S0301305微信零钱提现
        // 20230207 100843 1．15 (D +3750.00 3766.60 惠⺠县中正⽅元影城有 限公司 268465261 ⽹上银⾏ 1．15号货款+1．30号货款
        Pattern pattern = Pattern
                .compile("\\s\\d{8}(\\s|\\s\\d{6}\\s)((\\S{1,10}\\s\\S{1,10})(?!-+)|\\S{1,20})\\s\\-?\\+?\\d+(\\.\\d{1,2})?\\s\\d+(\\.\\d{1,2})?\\s");//NOSONAR
        Matcher matcher = pattern.matcher(pdfText);

        // 每行交易记录的第一个字所在的index
        int tranIndex = 0;
        Map<Integer, Integer> tranTextStartIndexMap = new HashMap<>();

        while (matcher.find()) {
            // log.info(
            // "Match \"" + matcher.group() + "\" at positions " + matcher.start() + "-" +
            // (matcher.end() - 1));
            tranTextStartIndexMap.put(tranIndex, matcher.start());
            tranIndex++;
        }
        if (tranTextStartIndexMap.isEmpty()) {
            return;
        }
        // 找出每行交易记录的文本
        List<String> tranTextList = new ArrayList<>();
        for (int i = 1; i < tranTextStartIndexMap.size(); i++) {
            String tranText = pdfText.substring(tranTextStartIndexMap.get(i - 1), tranTextStartIndexMap.get(i));
            if (tranText.contains("交易⽇期")) {
                tranText = tranText.substring(0, tranText.indexOf("交易⽇期")).trim();
            } else if (tranText.contains("交易日期")) {
                tranText = tranText.substring(0, tranText.indexOf("交易日期")).trim();
            } else if (tranText.contains("该交易明细因不可预测的⾮⼈控技术原因可能导致数据缺失")) {
                tranText = tranText.substring(0, tranText.indexOf("该交易明细因不可预测的⾮⼈控技术原因可能导致数据缺失")).trim();
            } else if (tranText.contains("该交易明细因不可预测的非人控技术原因可能导致数据缺失")) {
                tranText = tranText.substring(0, tranText.indexOf("该交易明细因不可预测的非人控技术原因可能导致数据缺失")).trim();
            }
            tranTextList.add(tranText.trim());
        }

        String lastTranText = pdfText.substring(tranTextStartIndexMap.get(tranTextStartIndexMap.size() - 1));
        if (lastTranText.contains("交易⽇期")) {
            lastTranText = lastTranText.substring(0, lastTranText.indexOf("交易⽇期")).trim();
        } else if (lastTranText.contains("交易日期")) {
            lastTranText = lastTranText.substring(0, lastTranText.indexOf("交易日期")).trim();
        }
        tranTextList.add(lastTranText.trim());

        // 找出每行交易里的对手信息的值
        for (int i = 0; i < abcTrans.size(); i++) {
            ABCTran abcTran = abcTrans.get(i);
            String tranText = tranTextList.get(i);
            String counterPartyInfo = "";
            String journalNumber = "";
            try {
                String[] trans = tranText.split(" ");
//                String tran = "";
//                if (trans[1].matches("\\d{6}")) {
//                    tran = StringUtils.join(trans[0], trans[1], trans[2]);
//                } else {
//                    tran = StringUtils.join(trans[0], trans[1]);
//                }
//                if (!StringUtils.equals(StringUtils.join(abcTran.getTranDate(), abcTran.getTranTime(), abcTran.getTranSummary()), tran)) {
//                    System.out.println("");
//                }
                // counterPartyInfo
                // 20221016 084232 银联⼊账 +11456.30 12293.05    "银盛⽀付服务股份有限 公司备付⾦"
                String[] strArr = {abcTran.getTranDate(), abcTran.getTranTime(), abcTran.getTranSummary(),
                        abcTran.getTranAmt(), abcTran.getBalance()};
                String str = String.join(StringUtils.SPACE, strArr).replaceAll("\\s+", StringUtils.SPACE).trim();
                // 跨行的会包含空格


                if (abcTran.getCounterPartyInfo().length() > 20) {
                    if (StringUtils.equals(trans[9], abcTran.getJournalNumber())) {
                        // 跨4行 ""
                        counterPartyInfo = tranText.substring(str.length() + 1, tranText.indexOf(abcTran.getJournalNumber()) - 1).trim();
                    } else if (StringUtils.equals(trans[8], abcTran.getJournalNumber())) {
                        // 跨三行 "⽀付宝-消费上海拉 扎斯信息科技有限 公司"
                        counterPartyInfo = tranText.substring(str.length() + 1, tranText.indexOf(abcTran.getJournalNumber()) - 1).trim();
                    }

                }
//                else {
//                    // 跨二行 "中信百信银⾏股份有 限公司中信百信银⾏ 股份有限公司"
//                    counterPartyInfo = tranText.substring(str.length() + 1, str.length() + abcTran.getCounterPartyInfo().length() + 3).trim();
//                }

//                // journalNumber
//                String[] strArr1 = {abcTran.getTranDate(), abcTran.getTranTime(), abcTran.getTranSummary(),
//                        abcTran.getTranAmt(), abcTran.getBalance(), counterPartyInfo};
//                String str1 = String.join(StringUtils.SPACE, strArr1).replaceAll("\\s+", StringUtils.SPACE).trim();
//                // 跨行的会包含空格
//                if (tranText.length() > str1.length() + abcTran.getJournalNumber().length() + 1) {
//                    // 跨一行 "4680尾号商⼾转 ⼊"
//                    journalNumber = tranText.substring(str1.length() + 1, str1.length() + abcTran.getJournalNumber().length() + 2).trim();
//                } else {
//                    journalNumber = tranText.substring(str1.length() + 1, str1.length() + abcTran.getJournalNumber().length() + 1).trim();
//                }
//
//                // tranComment
//                // 20221016 084232 银联⼊账 +11456.30 12293.05 银盛⽀付服务股份有限 公司备付⾦ 374074012 电⼦商务    "NG20221020142128555576932S0301305微信零钱提现"
//                String[] strArr2 = {abcTran.getTranDate(), abcTran.getTranTime(), abcTran.getTranSummary(),
//                        abcTran.getTranAmt(), abcTran.getBalance(), counterPartyInfo,
//                        journalNumber, abcTran.getTranChannel()};
//                String str2 = String.join(StringUtils.SPACE, strArr2).replaceAll("\\s+", StringUtils.SPACE).trim();
//                // "NG20221020142128555576932S0301305微信零钱提现"
//                String tranComment = tranText.substring(str2.length()).trim();
                if (StringUtils.isNotBlank(counterPartyInfo)) {
                    abcTran.setCounterPartyInfo(counterPartyInfo.replaceAll("\\s+", ""));
                }
//                if (StringUtils.isNotBlank(journalNumber)) {
//                    abcTran.setJournalNumber(journalNumber.replaceAll("\\s+", ""));
//                }
//               abcTran.setTranComment(tranComment.replaceAll("\\s+", ""));
            } catch (Exception e) {
                log.warn("parse counterPartyInfo and tranComment failed");
            }
        }
    }


    private List<List<String>> reSetRowList_removeExtraColumnAfterTranChannel(List<List<String>> rowList) {
        //[交易日期, 交易时间, 交易摘要, 交易金额, 本次余额, 对手信息, 日 志 号, 交易渠道, , 交易附言]
        boolean needRemoveExtraColumnAfterTranChannel = false;

        for (int i = 0; i < rowList.size(); i++) {
            if (rowList.get(i).size() >= 9 && rowList.get(i).get(7).contains("交易渠道") && StringUtils.isBlank(rowList.get(i).get(8))) {
                needRemoveExtraColumnAfterTranChannel = true;

            } else if (rowList.get(i).size() >= 9 && rowList.get(i).get(7).contains("交易渠道") && rowList.get(i).get(8).contains("交易附言")) {
                needRemoveExtraColumnAfterTranChannel = false;
            }
            if (needRemoveExtraColumnAfterTranChannel) {
                rowList.get(i).remove(8);
            }
        }

        return rowList;
    }

    private List<List<String>> parseFileToRowList(String filePath) {
        //页面所有table的记录，每一个元素代表下面一条记录cellList
        List<List<String>> rowList = new ArrayList<>();

        // 1. 读取文件
        File pdf = new File(filePath);

        // 2. pdfbox读取PDDocument
        try (PDDocument pdfDocument = PDDocument.load(pdf)) {

            // 3. tabula新建ObjectExtractor和NurminenDetectionAlgorithm，同时准备接收表格Rectangle的结构
            ObjectExtractor objectExtractor = new ObjectExtractor(pdfDocument);
            NurminenDetectionAlgorithm detectionAlgorithm = new NurminenDetectionAlgorithm();
            Map<Integer, List<Rectangle>> detectedTables = new HashMap<>();

            // 4. 获取每页的PageIterator
            PageIterator pages = objectExtractor.extract();

            // 5. 解析每页的Rectangle(table的位置)
            while (pages.hasNext()) {
                Page page = pages.next();
                List<Rectangle> tablesOnPage = detectionAlgorithm.detect(page);
                if (tablesOnPage.size() > 0) {
                    detectedTables.put(page.getPageNumber(), tablesOnPage);
                }
            }

            // 6.通过table位置获取表格具体内容
            BasicExtractionAlgorithm bea = new BasicExtractionAlgorithm();

            // 如果单页pdf中有多个表格，则解析出来的List<Rectangle>会有多个对象
            for (Map.Entry<Integer, List<Rectangle>> entry : detectedTables.entrySet()) {
                Page page = objectExtractor.extract(entry.getKey());
                // 默认每页只有一个表格，因此获取第0个rectangle/
                Rectangle rectangle = null; //NOSONAR
                List<Rectangle> rectangleList = entry.getValue();
                for (Rectangle r : rectangleList) {
                    double rectangleHeight = r.getHeight();
                    if (Double.compare(rectangleHeight, 0) > 0) {
                        rectangle = r;
                        break;
                    }
                }
                if (rectangle == null) {
                    throw new RuntimeException("rectangle is null.");
                }
                rectangle.setBottom(rectangle.getBottom() + 700);

                Page area = page.getArea(rectangle);
                List<Table> tableList = null;
                try {
                    tableList = bea.extract(area);
                } catch (Exception e) {
                    log.info("rectangle extract table fail.");
                    continue;
                }
                // 如果每页有多个表格，解析每一个table
                for (Table table : tableList) {
                    for (int i = 0; i < table.getRowCount(); i++) {
                        List<String> cellList = new ArrayList<>();//一条记录，每个单元格占一个元素
                        for (int j = 0; j < table.getColCount(); j++) {
                            cellList.add(table.getCell(i, j).getText(false));
                        }
                        rowList.add(cellList);
                    }
                }

            }
            return rowList;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private ABC parseABCHeader(String pdfHeaderText) {
        ABC abc = new ABC();
        String name = "";
        if (pdfHeaderText.contains("⼾名：") && pdfHeaderText.contains("账⼾：")) {
            name = pdfHeaderText.substring(pdfHeaderText.indexOf("⼾名：") + 3, pdfHeaderText.indexOf("账⼾：")).trim();
        } else if (pdfHeaderText.contains("户名：") && pdfHeaderText.contains("账户：")) {
            name = pdfHeaderText.substring(pdfHeaderText.indexOf("户名：") + 3, pdfHeaderText.indexOf("账户：")).trim();
        }
        String account = "";
        if (pdfHeaderText.contains("账⼾：")) {
            account = pdfHeaderText.substring(pdfHeaderText.indexOf("账⼾：") + 3, pdfHeaderText.indexOf("币种：")).trim();
        } else if (pdfHeaderText.contains("账户：")) {
            account = pdfHeaderText.substring(pdfHeaderText.indexOf("账户：") + 3, pdfHeaderText.indexOf("币种：")).trim();
        }
        String currency = pdfHeaderText.substring(pdfHeaderText.indexOf("币种：") + 3, pdfHeaderText.indexOf("钞汇标识："))
                .trim();

        String cashExchangeIndicator = "";
        String transDetailPeriod = "";
        if (pdfHeaderText.contains("起⽌⽇期：")) {
            cashExchangeIndicator = pdfHeaderText.substring(pdfHeaderText.indexOf("钞汇标识：") + 5, pdfHeaderText.indexOf("起⽌⽇期：")).trim();
            if (pdfHeaderText.contains("电⼦流⽔号：")) {
                transDetailPeriod = pdfHeaderText.substring(pdfHeaderText.indexOf("起⽌⽇期：") + 5, pdfHeaderText.indexOf("电⼦流⽔号：")).trim();
            }
        } else if (pdfHeaderText.contains("起止日期：")) {
            cashExchangeIndicator = pdfHeaderText.substring(pdfHeaderText.indexOf("钞汇标识：") + 5, pdfHeaderText.indexOf("起止日期：")).trim();
            if (pdfHeaderText.contains("电子流水号：")) {
                transDetailPeriod = pdfHeaderText.substring(pdfHeaderText.indexOf("起止日期：") + 5, pdfHeaderText.indexOf("电子流水号：")).trim();
            }
        }
        String serialNo = "";
        if (pdfHeaderText.contains("电⼦流⽔号：") && pdfHeaderText.contains("交易⽇期")) {
            serialNo = pdfHeaderText.substring(pdfHeaderText.indexOf("电⼦流⽔号：") + 6, pdfHeaderText.indexOf("交易⽇期")).trim();
        } else if (pdfHeaderText.contains("电子流水号：") && pdfHeaderText.contains("交易日期")) {
            serialNo = pdfHeaderText.substring(pdfHeaderText.indexOf("电子流水号：") + 6, pdfHeaderText.indexOf("交易日期")).trim();
        }

        abc.setName(name);
        abc.setAccount(account);
        abc.setCurrency(currency);
        abc.setCashExchangeIndicator(cashExchangeIndicator);
        abc.setTransDetailPeriod(transDetailPeriod);
        abc.setSerialNo(serialNo);
        return abc;
    }


    public static void main(String[] args) throws IOException {
        ABCPdfParser abcPdfParser = new ABCPdfParser();
        String json = "";
        json = abcPdfParser.parseABCPdfToJson("", "D:\\data\\file\\beehive-abc\\240701\\zd4nstlc1806715379945074688_297c63072e0fb6a0130cf542e8e1bccd_beehive-abc_jyls-0.pdf").getData();
        System.out.println(json);

//        json = abcPdfParser.parseABCPdfToJson("", "D:\\data\\file\\beehive-abc\\240701\\zd4nqzjg1805779586787340288_bdc3cba209381b2b05f2ebbc7a64b2e5_beehive-abc_jyls-0.pdf").getData();
//        json = abcPdfParser.parseABCPdfToJson("", "D:\\data\\file\\beehive-abc\\240701\\zd4nqzjg1805807813745057792_87f39942d998cee7e2a1beffd418d5b0_beehive-abc_jyls-0.pdf").getData();
//
//        json = abcPdfParser.parseABCPdfToJson("", "D:\\data\\file\\beehive-abc\\240701\\zd4nstlc1806706635678429184_664a48d9804ee98f1fd95238651297df_beehive-abc_jyls-0.pdf").getData();
//        System.out.println(json);
//
//        json = abcPdfParser.parseABCPdfToJson("", "D:\\data\\file\\beehive-abc\\240701\\zd4y7qpv1806697331141038080_751e6e31cab6b89d6acc25b39dd49d81_beehive-abc_jyls-0.pdf").getData();
//
//        System.out.println(json);

    }
}