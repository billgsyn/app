package com.file.parser;

import com.file.bo.IIT;
import com.file.bo.IITTran;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.parser.traprange.PDFTableExtractor;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class IITPdfParser extends BaseDecryptPdfParser {

	private static final Integer IIT_HEADER_LINE_NUMBER = 10;
	private static final Integer IIT_FOOTER_LINE_NUMBER = 8;

	public ResponseData<String> parseIITPdfToJson(String daId, String filePath, String pdfPassword) {
		log.info("parseIITPdfToJson started, daId:{}, pdfPassword:{}", daId, pdfPassword);
		String json = null;

		try {
			IIT iit = parseIITPdf(filePath, pdfPassword);
			json = JsonUtils.convertObjectToJson(iit);
			doAlert(daId, iit);
		} catch (Exception e) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "parseIITPdfToJson failed", e);
			return new ResponseData<String>(json, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
					ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
		}

		log.info("parseIITPdfToJson completed, daId:{}, pdfPassword:{}", daId, pdfPassword);
		return new ResponseData<String>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
	}



	public IIT parseIITPdf(String filePath, String pdfPassword) {
		IIT iit = parseIITHeader(filePath, pdfPassword);

		List<IITTran> iitTrans = new ArrayList<>();//NOSONAR
		iitTrans = parseIITTrans(filePath, pdfPassword);


		iit.setIitTrans(iitTrans);
		return iit;
	}

	public IIT parseIITHeader(String filePath, String pdfPassword) {
		IIT iit = new IIT();
		String pdfHeaderText = parsePdfHeaderText(filePath, pdfPassword);
		String recordPeriod = pdfHeaderText
				.substring(pdfHeaderText.indexOf("记 录 期 间 :") + 9, pdfHeaderText.indexOf("纳 税 ⼈ 名 称 : ")).trim();
		String taxpayerName = pdfHeaderText
				.substring(pdfHeaderText.indexOf("纳 税 ⼈ 名 称 :") + 11, pdfHeaderText.indexOf("纳税⼈识别号:")).trim();
		String taxpayerIdNo = pdfHeaderText
				.substring(pdfHeaderText.indexOf("纳税⼈识别号:") + 7, pdfHeaderText.indexOf("⾝份证件类型:")).trim();
		String IdCardType = pdfHeaderText
				.substring(pdfHeaderText.indexOf("⾝份证件类型:") + 7, pdfHeaderText.indexOf("⾝份证件号码:")).trim();
		String idNo = pdfHeaderText.substring(pdfHeaderText.indexOf("⾝份证件号码:") + 7, pdfHeaderText.indexOf("⾦额单位:"))
				.trim();
		String amountUnit = pdfHeaderText.substring(pdfHeaderText.indexOf("⾦额单位:") + 5, pdfHeaderText.indexOf("申报⽇期"))
				.trim();
		String issueDate = pdfHeaderText
				.substring(pdfHeaderText.indexOf("开具时间：") + 5, pdfHeaderText.indexOf("本凭证不作为纳税⼈记账")).trim();

		iit.setRecordPeriod(recordPeriod);
		iit.setTaxpayerName(taxpayerName);
		iit.setTaxpayerIdNo(taxpayerIdNo);
		iit.setIdCardType(IdCardType);
		iit.setIdNo(idNo);
		iit.setAmountUnit(amountUnit);
		iit.setIssueDate(issueDate);

		return iit;
	}

	public String parseTransToText(String filePath, String pdfPassword) {
		PDFTableExtractor extractor = (new PDFTableExtractor()).setSource(filePath, pdfPassword);
		int pdfPageNumber = getPdfPageNumber(filePath, pdfPassword);

		for (int k = 0; k < pdfPageNumber; k++) {
			// 对第一页处理
			int[] skipLinesIndexes1;
			if (k == 0) {
				//第一页多一行，单位，其它页少一行这个
				skipLinesIndexes1 = new int[IIT_HEADER_LINE_NUMBER];
				for (int i = 0; i < IIT_HEADER_LINE_NUMBER; i++) {
					skipLinesIndexes1[i] = i;
				}
			} else {
				skipLinesIndexes1 = new int[IIT_HEADER_LINE_NUMBER - 1];
				for (int i = 0; i < IIT_HEADER_LINE_NUMBER - 1; i++) {
					skipLinesIndexes1[i] = i;
				}
			}
			extractor.exceptLine(k, skipLinesIndexes1);

			int[] skipLinesIndexes2 = new int[IIT_FOOTER_LINE_NUMBER];
			for (int j = 0; j < IIT_FOOTER_LINE_NUMBER; j++) {
				skipLinesIndexes2[j] = -(j + 1);
			}
			extractor.exceptLine(k, skipLinesIndexes2);
		}

		return extractPdfToText(extractor);
	}

	public List<IITTran> parseIITTrans(String filePath, String pdfPassword) {
		List<IITTran> finalIitTrans = new ArrayList<>();
		List<IITTran> iitTrans = new ArrayList<>();

		String transText = parseTransToText(filePath, pdfPassword);
		if (StringUtils.isBlank(transText)) {
			return iitTrans;
		}

		List<List<String>> tranFieldsList = parseTransTextToTranFieldsList(transText);

		for (int i = 0; i < tranFieldsList.size(); i++) {
			if (StringUtils.isNotBlank(tranFieldsList.get(i).get(0))) {
				if (StringUtils.equals(tranFieldsList.get(i).get(0), "申报⽇期")) continue;
				// 申报⽇期 | 实缴(退)⾦额 | ⼊(退)库⽇期 | 所得项⽬ | 税款所属期 | ⼊库税务机关
				// 申报⽇期 | 实缴(退)⾦额⼊(退)库⽇期 | 所得项⽬ | 税款所属期 | ⼊库税务机关 | 备注
				if (tranFieldsList.get(i).size() == 6) {
					IITTran iitTran = new IITTran();
					iitTran.setDeclarationDate(tranFieldsList.get(i).get(0));
					// 实缴(退)⾦额 ⼊(退)库⽇期两个col粘在一起
					if (tranFieldsList.get(i).get(1).matches("[-]?(\\d+.\\d{2})((\\d{4}.\\d{2}.\\d{2})|-)")) {
						Pair<String, String> pair = parsePaidInOutAmountAndStockInOutDate(tranFieldsList.get(i).get(1));
						iitTran.setPaidInOutAmount(pair.getLeft());
						iitTran.setStockInOutDate(pair.getRight());

						iitTran.setIncomeItem(tranFieldsList.get(i).get(2));
						iitTran.setTaxPeriod(tranFieldsList.get(i).get(3));
						iitTran.setStockInTaxAuthority(formatStockInTaxAuthority(tranFieldsList.get(i).get(4)));
						iitTran.setComment(tranFieldsList.get(i).get(5));
					}
					// 备注为空
					else if (tranFieldsList.get(i).get(1).matches("[-]?(\\d+.\\d{2})")) {
						iitTran.setPaidInOutAmount(tranFieldsList.get(i).get(1));
						iitTran.setStockInOutDate(tranFieldsList.get(i).get(2));
						iitTran.setIncomeItem(tranFieldsList.get(i).get(3));
						iitTran.setTaxPeriod(tranFieldsList.get(i).get(4));
						iitTran.setStockInTaxAuthority(formatStockInTaxAuthority(tranFieldsList.get(i).get(5)));
					}
					iitTrans.add(iitTran);
				}
				// 申报⽇期 | 实缴(退)⾦额 | ⼊(退)库⽇期 | 所得项⽬ | 税款所属期 | ⼊库税务机关 | 备注
				else if (tranFieldsList.get(i).size() == 7) {
					IITTran iitTran = new IITTran();
					iitTran.setDeclarationDate(tranFieldsList.get(i).get(0));
					iitTran.setPaidInOutAmount(tranFieldsList.get(i).get(1));
					iitTran.setStockInOutDate(tranFieldsList.get(i).get(2));
					iitTran.setIncomeItem(tranFieldsList.get(i).get(3));
					iitTran.setTaxPeriod(tranFieldsList.get(i).get(4));
					iitTran.setStockInTaxAuthority(formatStockInTaxAuthority(tranFieldsList.get(i).get(5)));
					iitTran.setComment(tranFieldsList.get(i).get(6));
					iitTrans.add(iitTran);
				//申报⽇期;实缴(退)⾦额;⼊(退)库⽇期;所得项⽬;税款所属期;⼊库税务机关;;备注
				} else if (tranFieldsList.get(i).size() == 8) {
					IITTran iitTran = new IITTran();
					iitTran.setDeclarationDate(tranFieldsList.get(i).get(0));
					iitTran.setPaidInOutAmount(tranFieldsList.get(i).get(1));
					iitTran.setStockInOutDate(tranFieldsList.get(i).get(2));
					iitTran.setIncomeItem(tranFieldsList.get(i).get(3));
					iitTran.setTaxPeriod(tranFieldsList.get(i).get(4));
					iitTran.setStockInTaxAuthority(formatStockInTaxAuthority(tranFieldsList.get(i).get(5)));
					iitTran.setComment(tranFieldsList.get(i).get(7));
					iitTrans.add(iitTran);
				}
			} else {
				if (tranFieldsList.get(i).size() == 6) {
					// 过滤掉第一行 ";;;;;国家税务总局宁乡经济技术" 这种case
					if (i > 0) {
						// 实缴(退)⾦额 ⼊(退)库⽇期两个col粘在一起
						if (tranFieldsList.get(i - 1).get(1).matches("[-]?(\\d+.\\d{2})((\\d{4}.\\d{2}.\\d{2})|-)")) {
							try {
								if (StringUtils.isNotBlank(tranFieldsList.get(i).get(2))) {
									iitTrans.get(iitTrans.size() -1).setIncomeItem(iitTrans.get(iitTrans.size() -1).getIncomeItem() + tranFieldsList.get(i).get(2));
								}
							} catch (Exception e) {
								log.info("reset IncomeItem exception");
							}
							try {
								if (StringUtils.isNotBlank(tranFieldsList.get(i).get(4))) {
									iitTrans.get(iitTrans.size() -1).setStockInTaxAuthority(iitTrans.get(iitTrans.size() -1).getStockInTaxAuthority() + tranFieldsList.get(i).get(4));
								}
							} catch (Exception e) {
								log.info("reset StockInTaxAuthority exception");
							}
						}
						// 备注为空
						else if (tranFieldsList.get(i - 1).get(1).matches("[-]?(\\d+.\\d{2})")) {
							try {
								if (StringUtils.isNotBlank(tranFieldsList.get(i).get(3))) {
									iitTrans.get(iitTrans.size() -1).setIncomeItem(iitTrans.get(iitTrans.size() -1).getIncomeItem() + tranFieldsList.get(i).get(3));
								}
							} catch (Exception e) {
								log.info("reset IncomeItem exception");
							}
							try {
								if (StringUtils.isNotBlank(tranFieldsList.get(i).get(5))) {
									iitTrans.get(iitTrans.size() -1).setStockInTaxAuthority(iitTrans.get(iitTrans.size() -1).getStockInTaxAuthority() + tranFieldsList.get(i).get(5));
								}
							} catch (Exception e) {
								log.info("reset StockInTaxAuthority exception");
							}
						}
					}
				} else if (tranFieldsList.get(i).size() == 7 || tranFieldsList.get(i).size() == 8) {
					try {
						if (StringUtils.isNotBlank(tranFieldsList.get(i).get(3))) {
							iitTrans.get(iitTrans.size() -1).setIncomeItem(iitTrans.get(iitTrans.size() -1).getIncomeItem() + tranFieldsList.get(i).get(3));
						}
					} catch (Exception e) {
						log.info("reset IncomeItem exception");
					}
					try {
						if (StringUtils.isNotBlank(tranFieldsList.get(i).get(5))) {
							iitTrans.get(iitTrans.size() -1).setStockInTaxAuthority(iitTrans.get(iitTrans.size() -1).getStockInTaxAuthority() + tranFieldsList.get(i).get(5));
						}
					} catch (Exception e) {
						log.info("reset StockInTaxAuthority exception");
					}
				}
			}
		}

		try {
			// 个税表格 记录以外的行(比如以"金额合计" "特别说明"等开头的行)
			iitTrans.forEach(iitTran -> {
				if (StringUtils.isNotBlank(iitTran.getTaxPeriod())) {
					finalIitTrans.add(iitTran);
				}
			});

			resetIncomeItemForSpecialCase(finalIitTrans);
		} catch (Exception e) {
			log.info("resetIncomeItemForSpecialCase exception");
		}

		return finalIitTrans;
	}

	// 解析  实缴(退)⾦额 ⼊(退)库⽇期 两个字段
	private Pair<String, String> parsePaidInOutAmountAndStockInOutDate(String paidInOutAmountAndStockInOutDate) {
		Pair<String, String> pair = Pair.of("", "");
		if (StringUtils.isNotBlank(paidInOutAmountAndStockInOutDate)) {
			// 362.692021.09.16  0.00-  -151.462022.06.17
			Pattern pattern = Pattern.compile("[-]?(\\d+.\\d{2})");
			Matcher matcher = pattern.matcher(paidInOutAmountAndStockInOutDate);
			if (matcher.find()) {
				String paidInOutAmount = matcher.group();
				String stockInOutDate = paidInOutAmountAndStockInOutDate.substring(matcher.end());
				pair = Pair.of(paidInOutAmount, stockInOutDate);
			}
		}
		return pair;
	}

	private void resetIncomeItemForSpecialCase(List<IITTran> iitTrans) {
		for (IITTran iitTran : iitTrans) {
			if (StringUtils.equals("利息、利股所息得、红", iitTran.getIncomeItem())) {
				iitTran.setIncomeItem("利息、股息、红利所得");
			} else if ((StringUtils.equals("个⼈房屋得出租所", iitTran.getIncomeItem()))) {
				iitTran.setIncomeItem("个⼈房屋出租所得");
			} else if ((StringUtils.equals("个⼈房屋得转让所", iitTran.getIncomeItem()))) {
				iitTran.setIncomeItem("个⼈房屋转让所得");
			} else if ((StringUtils.equals("特许权使得⽤费所", iitTran.getIncomeItem()))) {
				iitTran.setIncomeItem("特许权使⽤费所得");
			} else if (StringUtils.equals("其他财产得租赁所", iitTran.getIncomeItem())) {
				iitTran.setIncomeItem("其他财产租赁所得");
			}
		}
	}

	private String formatStockInTaxAuthority(String stockInTaxAuthority) {
		String formatStr = stockInTaxAuthority;

		try {
			//入库税务机关，一行最多显示12个汉字，超过12个就会换行，只有超过12个字才会需要调整
			//国成家都税管务理总委局员四会川税天务府局新区
			if (stockInTaxAuthority.length() <= 12 || stockInTaxAuthority.length() > 24) {
				return formatStr;
			}

			// 下面就是显示两行的情况
			StringBuilder sb = new StringBuilder(stockInTaxAuthority);
			int charNumInNewLine = stockInTaxAuthority.length() - 12;
			for (int i = 0 ; i < charNumInNewLine; i++) {
				sb.append(stockInTaxAuthority.charAt(2 * i + 1));
			}
			for (int i = 1 ; i <= charNumInNewLine; i++) {
				sb.deleteCharAt(i);
			}
			formatStr = sb.toString();
		} catch (Exception e) {
			log.error("formatStockInTaxAuthority failed, stockInTaxAuthority: {}", stockInTaxAuthority, e);
			e.printStackTrace();
		}

		return formatStr;
	}

	private void doAlert(String daId, IIT iit) {
		log.info("doAlert started daId: {}", daId);
		//加入字段告警
		if (StringUtils.isBlank(iit.getRecordPeriod())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iit recordPeriod is empty");
			throw new RuntimeException("the tax pdf format maybe changed");
		}
		if (StringUtils.isBlank(iit.getTaxpayerName())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iit taxpayerName is empty");
			throw new RuntimeException("the tax pdf format maybe changed");
		}
		if (StringUtils.isBlank(iit.getTaxpayerIdNo())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iit taxpayerIdNo is empty");
			throw new RuntimeException("the tax pdf format maybe changed");
		}
		if (StringUtils.isBlank(iit.getIdCardType())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iit idCardType is empty");
			throw new RuntimeException("the tax pdf format maybe changed");
		}
		if (StringUtils.isBlank(iit.getIdNo())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iit idNo is empty");
			throw new RuntimeException("the tax pdf format maybe changed");
		}
		if (StringUtils.isBlank(iit.getAmountUnit())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iit amountUnit is empty");
			throw new RuntimeException("the tax pdf format maybe changed");
		}
		if (StringUtils.isBlank(iit.getIssueDate())) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iit issueDate is empty");
			throw new RuntimeException("the tax pdf format maybe changed");
		}

		List<IITTran> iitTrans= iit.getIitTrans();

		for (IITTran iitTran : iitTrans) {
			if (StringUtils.isBlank(iitTran.getDeclarationDate())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iitTran declarationDate is empty");
				throw new RuntimeException("the tax pdf format maybe changed");
			}
			if (StringUtils.isBlank(iitTran.getPaidInOutAmount())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iitTran paidInOutAmount is empty");
				throw new RuntimeException("the tax pdf format maybe changed");
			}
			if (StringUtils.isBlank(iitTran.getIncomeItem())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iitTran incomeItem is empty");
				throw new RuntimeException("the tax pdf format maybe changed");
			}
			if (StringUtils.isBlank(iitTran.getTaxPeriod())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iitTran taxPeriod is empty");
				throw new RuntimeException("the tax pdf format maybe changed");
			}
			if (StringUtils.isBlank(iitTran.getStockInTaxAuthority())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iitTran stockInTaxAuthority is empty");
				throw new RuntimeException("the tax pdf format maybe changed");
			}
			if (StringUtils.isBlank(iitTran.getStockInOutDate())) {
				log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "iitTran stockInOutDate is empty");
				throw new RuntimeException("the tax pdf format maybe changed");
			}
		}

		log.info("doAlert completed daId: {}", daId);
	}


	public static void main(String[] args) throws IOException {
//		String pdfFilePath = "E:\\data\\file\\iit\\381859402262513295_d0ed1c34fda5a640698578392ced6a38_tax_nsjl-055614.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\381859402262513295_d0ed1c34fda5a640698578392ced6a38_tax_nsjl-055614.json";
//		String passWord = "055614";
//		String pdfFilePath = "E:\\data\\file\\iit\\381295244299215025_2f912da2c5dcbee03430d93b956f5961_tax_nsjl-272811.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\381295244299215025_2f912da2c5dcbee03430d93b956f5961_tax_nsjl-272811.json";
//		String passWord = "272811";

//		String pdfFilePath = "E:\\data\\file\\iit\\382006000938386319_01ffcc1ba1f9ac1aca08333f7f0aebb9_tax_nsjl-083661.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\382006000938386319_01ffcc1ba1f9ac1aca08333f7f0aebb9_tax_nsjl-083661.json";
//		String passWord = "083661";

//		String pdfFilePath = "E:\\data\\file\\iit\\382581175476031254_7bce4e73aa481a85a2e6865ba9b72661_tax_nsjl-224757.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\382581175476031254_7bce4e73aa481a85a2e6865ba9b72661_tax_nsjl-224757.json";
//		String passWord = "224757";

//		String pdfFilePath = "E:\\data\\file\\iit\\382885884011218575_7e6cce107c8a4837011eec1f7628c438_tax_nsjl-145166.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\382885884011218575_7e6cce107c8a4837011eec1f7628c438_tax_nsjl-145166.json";
//		String passWord = "145166";

//		String pdfFilePath = "E:\\data\\file\\iit\\383307762106368911_ec2099b438809ee6962905e890c92518_tax_nsjl-161326.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\383307762106368911_ec2099b438809ee6962905e890c92518_tax_nsjl-161326.json";
//		String passWord = "161326";

//		String pdfFilePath = "E:\\data\\file\\iit\\389419489160077489_665ebefa2d85e02aae0e4c87bb68c272_tax_nsjl-151173.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\389419489160077489_665ebefa2d85e02aae0e4c87bb68c272_tax_nsjl-151173.json";
//		String passWord = "151173";

//		String pdfFilePath = "E:\\data\\file\\iit\\390268201054766735_d0c3e4dd44421a1981b597980fc28d1c_tax_nsjl-206994.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\390268201054766735_d0c3e4dd44421a1981b597980fc28d1c_tax_nsjl-206994.json";
//		String passWord = "206994";

//		String pdfFilePath = "E:\\data\\file\\iit\\390282578038359695_abc79867a42191c9e419b1123e36b397_tax_nsjl-186014.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\390282578038359695_abc79867a42191c9e419b1123e36b397_tax_nsjl-186014.json";
//		String passWord = "186014";

//		String pdfFilePath = "E:\\data\\file\\iit\\390268956247589775_0354870fe31ce8b3885841471e489de6_tax_nsjl-128116.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\390268956247589775_0354870fe31ce8b3885841471e489de6_tax_nsjl-128116.json";
//		String passWord = "128116";

//		String pdfFilePath = "E:\\data\\file\\iit\\382127552405177999_a6783eef078e41bcc618a06cf70554aa_tax_nsjl-233231.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\382127552405177999_a6783eef078e41bcc618a06cf70554aa_tax_nsjl-233231.json";
//		String passWord = "233231";

//		String pdfFilePath = "E:\\data\\file\\iit\\zdddjj1m1534808182491426816_b134f47b7e7138350508090c2d9934b3_tax_nsjl-213320.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\zdddjj1m1534808182491426816_b134f47b7e7138350508090c2d9934b3_tax_nsjl-213320.json";
//		String passWord = "213320";

//		String pdfFilePath = "E:\\data\\file\\iit\\zd44oxav1537699590034366464_cff1894024f6c9603cc5158ea1e9bd02_tax_nsjl.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\zd44oxav1537699590034366464_cff1894024f6c9603cc5158ea1e9bd02_tax_nsjl.json";
//		String passWord = "127431";

//		String pdfFilePath = "E:\\data\\file\\iit\\zd44oxav1537682266585767936_9013d97bb81c9065167a89f7b6b380f7_tax_nsjl.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\zd44oxav1537682266585767936_9013d97bb81c9065167a89f7b6b380f7_tax_nsjl.json";
//		String passWord = "16241X";

//		String pdfFilePath = "E:\\data\\file\\iit\\zd44oxav1537729807616503808_01ddf2575d9881f311e47c29e011237f_tax_nsjl-021716.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\zd44oxav1537729807616503808_01ddf2575d9881f311e47c29e011237f_tax_nsjl-021716.json";
//		String passWord = "021716";

//		String pdfFilePath = "E:\\data\\file\\iit\\zdddjj1m1538491630984781824_206b028f06869e07377b3d4253012ddb_tax_nsjl-282337.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\zdddjj1m1538491630984781824_206b028f06869e07377b3d4253012ddb_tax_nsjl-282337.json";
//		String passWord = "282337";

//		String pdfFilePath = "E:\\data\\file\\iit\\zdddjj1m1538463272674689024_f71badb7cfb3003787c834b16610a5f4_tax_nsjl.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\zdddjj1m1538463272674689024_f71badb7cfb3003787c834b16610a5f4_tax_nsjl.json";
//		String passWord = "155674";

//		String pdfFilePath = "E:\\data\\file\\iit\\zdddjj1m1541666763442446336_5c2a04a295a2aaf2a02edbb56776c190_tax_nsjl.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\zdddjj1m1541666763442446336_5c2a04a295a2aaf2a02edbb56776c190_tax_nsjl.json";
//		String passWord = "090415";

//		String pdfFilePath = "E:\\data\\file\\iit\\zdddjj1m1538695582464565248_71dbedd69dc0ffffbeddfb9f8d481393_tax_nsjl.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\zdddjj1m1538695582464565248_71dbedd69dc0ffffbeddfb9f8d481393_tax_nsjl.json";
//		String passWord = "138142";

//		String pdfFilePath = "E:\\data\\file\\iit\\zd44oxav1546737260127506432_2263d061974740c175b4cf8b3a607309_tax_nsjl-063555.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\zd44oxav1546737260127506432_2263d061974740c175b4cf8b3a607309_tax_nsjl.json";
//		String passWord = "063555";

//		String pdfFilePath = "E:\\data\\file\\iit\\zd4h5f8n1548905504342974464_80dd01f6808caed6ccf0ed387d060a10_tax_nsjl-234331.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\zd4h5f8n1548905504342974464_80dd01f6808caed6ccf0ed387d060a10_tax_nsjl.json";
//		String passWord = "234331";

//		String pdfFilePath = "E:\\data\\file\\iit\\zd44oxav1547896307182641152_86523c9e2726cec7409e07d3d0a9879a_tax_nsjl-033370.pdf";
//		String jsonFilePath = "E:\\data\\file\\iit\\zd44oxav1547896307182641152_86523c9e2726cec7409e07d3d0a9879a_tax_nsjl.json";
//		String passWord = "033370";

		String pdfFilePath = "D:\\data\\file\\iit\\zd4lxrz01573230457355710464_a4b1045039c62069c25b71004f453a97_tax_nsjl-200811.pdf";
		String jsonFilePath = "D:\\data\\file\\iit\\zd4lxrz01573230457355710464_a4b1045039c62069c25b71004f453a97_tax_nsjl-200811json";
		String passWord = "200811";


//		File jsonFile = new File(jsonFilePath);
		IITPdfParser iitParser = new IITPdfParser();
		ResponseData<String> responseData = iitParser.parseIITPdfToJson("dd", pdfFilePath, passWord);
//		FileUtils.write(jsonFile, responseData.getData(), "UTF-8");
		System.out.println(responseData.getData());

//		jsonFile.createNewFile();

//		log.info(iitParser.formatStockInTaxAuthority("国税家务税局务总局成都市⾦⽜区"));
	}

}
