package com.file.parser;

import com.file.bo.JinritemaiBillBO;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 抖音电商
 */

@Slf4j
public class JinritemaiBillHtmlParser {

    public ResponseData<String> parseJinritemaiHtmlToJson(String daId, String filePath) {
        log.info("parseJinritemaiHtmlToJson started, daId:{}", daId);

        String json = null;

        try {
            JinritemaiBillBO jinritemaiBillBO = parseJinritemaiBill(filePath);
            if (StringUtils.isBlank(jinritemaiBillBO.getCompanyName())
                || StringUtils.isBlank(jinritemaiBillBO.getUnifiedSocialCreditCode())
                || StringUtils.isBlank(jinritemaiBillBO.getOperatorName())
                || StringUtils.isBlank(jinritemaiBillBO.getOperatorIdNo())) {
                throw new RuntimeException("any of the parse field is empty");
            }
            json = JsonUtils.convertObjectToJson(jinritemaiBillBO);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseJinritemaiHtmlToJson failed", e);
            return new ResponseData<String>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseJinritemaiHtmlToJson started, daId:{}, json:{}", daId, json);
        return new ResponseData<String>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private JinritemaiBillBO parseJinritemaiBill(String filePath) throws IOException {
        JinritemaiBillBO jinritemaiBillBO = new JinritemaiBillBO();

        File htmFile = new File(filePath);
        Document doc = Jsoup.parse(htmFile, "UTF-8");

        List<String> relatedDivTextList = new ArrayList<>();
        Elements elements = doc.select("div[class*=ant-col]");

        elements.forEach(element -> {
            relatedDivTextList.add(element.text());
        });

        for (int i = 0; i < relatedDivTextList.size(); i++) {
            String divText = relatedDivTextList.get(i);
            switch (divText) {//SONAR
                case "公司名称":
                    jinritemaiBillBO.setCompanyName(relatedDivTextList.get(i + 1));
                    break;
                case "统一社会信用代码":
                    jinritemaiBillBO.setUnifiedSocialCreditCode(relatedDivTextList.get(i + 1));
                    break;
                case "经营者姓名":
                    jinritemaiBillBO.setOperatorName(relatedDivTextList.get(i + 1));
                    break;
                case "经营者证件号码":
                    jinritemaiBillBO.setOperatorIdNo(relatedDivTextList.get(i + 1));
                    break;
            }
        }


        return jinritemaiBillBO;
    }

    public static void main(String[] args) throws IOException {
        JinritemaiBillHtmlParser jinritemaiBillHtmlParser = new JinritemaiBillHtmlParser();
        String filePath = "D:\\data\\file\\jinritemai-bill\\chrome-jinritemai-bill_userInfo.html";
        ResponseData<String> responseData = jinritemaiBillHtmlParser.parseJinritemaiHtmlToJson("", filePath);
        log.info(responseData.getData());
    }

}
