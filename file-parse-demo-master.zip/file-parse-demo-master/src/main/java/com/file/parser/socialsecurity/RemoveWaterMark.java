package com.file.parser.socialsecurity;

import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.cos.COSString;
import org.apache.pdfbox.pdfparser.PDFStreamParser;
import org.apache.pdfbox.pdfwriter.ContentStreamWriter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDStream;
import org.apache.pdfbox.pdmodel.font.PDFont;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RemoveWaterMark {

    public void removeWaterMark(String filePath) throws Exception {
        File file = new File(filePath);
        PDDocument pd = PDDocument.load(file);
        // 需要的字体文件
        Map<COSName, PDFont> oldfont = new HashMap<COSName, PDFont>();
        COSName fontName = null;

        for (PDPage page : pd.getPages()) {
            PDFStreamParser pdfsp = new PDFStreamParser(page);
            pdfsp.parse();
            List<Object> tokens = pdfsp.getTokens();
            for (int j = 0; j < tokens.size(); j++) {
                //创建一个object对象去接收标记
                Object next = tokens.get(j);
                //instanceof判断其左边对象是否为其右边类的实例
                if (next instanceof COSName) {
                    fontName = (COSName) next;
                    if (!oldfont.containsKey(fontName)) {
                        oldfont.put(fontName, page.getResources().getFont(fontName));
                    }
                } else if (next instanceof COSString) {
                    COSString previous = (COSString) next;
                    try (InputStream in = new ByteArrayInputStream(previous.getBytes())) {
                        StringBuilder sb = new StringBuilder();
                        while (in.available() > 0) {
                            int rc = oldfont.get(fontName).readCode(in);
                            sb.append(oldfont.get(fontName).toUnicode(rc));
                        }

                        //重置COSString对象
                        String text = sb.toString();
//                        System.out.println("--Tj----" + text);
                        String str1 = "任何形式用于商业用途，否则将追究法律责任";
                        String str2 = "本证明由全国社保卡服务平台提供，任何第三方";
                        String str3 = "机构不得对社保数据进行二次加工、处理、解析或以";
                        if (text.contains(str1) || text.contains(str2) || text.contains(str3)) {
//                            System.out.println("++++++++ matched ++++++++" + text);
                            previous.setValue(oldfont.get(fontName).encode(""));
                        }
                    }
                }
            }
            PDStream updatedStream = new PDStream(pd);
            OutputStream out = updatedStream.createOutputStream();
            ContentStreamWriter tokenWriter = new ContentStreamWriter(out);
            tokenWriter.writeTokens(tokens);
            out.close();

            page.setContents(updatedStream);
        }
        pd.save(filePath);
        pd.close();
    }

    public static void main(String[] args) throws Exception {
        RemoveWaterMark removeWaterMark = new RemoveWaterMark();
        removeWaterMark.removeWaterMark("D:\\data\\cbzm - 副本.pdf");
    }

}
