package com.file.parser;

import com.file.bo.ResponseData;
import com.file.bo.mail.PAB;
import com.file.bo.mail.PABTran;
import com.file.constant.ErrorCode;
import com.file.parser.traprange.PDFTableExtractor;
import com.file.util.JsonUtils;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class PABPdfParser extends BasePdfParser {

	private PABPdfParser1 bcmPdfParser1 = new PABPdfParser1();

	private PABPdfParser2 bcmPdfParser2 = new PABPdfParser2();

	public ResponseData<String> parsePABPdfToJson(String daId, String filePath) {
		log.info("parseBCMPdfToJson started, daId:{}", daId);

		try {
			String pdfHeaderText = parsePdfHeaderText(filePath);
			if (pdfHeaderText.contains("清单编号")) {
				return bcmPdfParser2.parsePABPdfToJson(daId, filePath);
			} else {
				return bcmPdfParser1.parsePABPdfToJson(daId, filePath);
			}
		} catch (Exception e) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parsePABPdfToJson failed", e);
			return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
					ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
		}
	}


	public static void main(String[] args) {
		PABPdfParser PABPdfParser = new PABPdfParser();
		String filePath = "D:\\data\\file\\beehive-pabc\\平安新版本有所有数据.pdf";
		String json = null;
		String pdfHeaderText = PABPdfParser.parsePdfHeaderText2(filePath);
		if (StringUtils.isNotBlank(pdfHeaderText)) {
			if (pdfHeaderText.contains("清单编号")) {
				json = new PABPdfParser2().parsePABPdfToJson("dd", filePath).getData();
			} else {
				json = new PABPdfParser1().parsePABPdfToJson("dd", filePath).getData();
			}
		}
		System.out.println(json);
	}

}
