package com.file.parser;

import java.io.File;

import com.file.bo.Chsixw;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * 学位查询解析
 * @author anyspa
 */

@Slf4j
public class ChsixwHtmlParser {

    public ResponseData<String> parseChsixwToJson(String daId, String filePath) {
        log.info("parseChsixwToJson started, daId:{}", daId);
        String json;

        try {
            File input = new File(filePath);
            Document doc = Jsoup.parse(input, "UTF-8");
            boolean isNewVersion = isNewVersion(doc);
            log.info("parseChsixwToJson, daId:{}, isNewVersion:{}", daId, isNewVersion);

            Chsixw chsixw = isNewVersion ? parseChsixw_NewVersion(doc) : parseChsixw(doc);
            json = JsonUtils.convertObjectToJson(chsixw);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseChsixwToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseChsixwToJson completed, daId:{}, json:{}", daId, json);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private boolean isNewVersion(Document doc) {
        boolean isNewVersion = true;
        Element rowElement = doc.select(".rowcard > .row").first();
        if (rowElement == null) {
            isNewVersion = false;
        }
        return isNewVersion;
    }

    private Chsixw parseChsixw(Document doc) {
        Chsixw chsixw = new Chsixw();

        chsixw.setName(doc.select(".img-right > h6").textNodes().get(0).text());
        chsixw.setSex(doc.select(".img-right > h6 > span").text());
        chsixw.setDateOfBirth(doc.select(".img-right > p").text());

        Elements rowCollectionItems = doc.select(".collection.card > .row.collection-item");
        for (Element collectionItem : rowCollectionItems) {
            String itemKey = collectionItem.select(".col.s4").text();
            String itemValue = collectionItem.select(".col.s8").text();

            switch (itemKey) {//NOSONAR
                case "获学位日期":
                    chsixw.setDateOfDegreeAwarded(itemValue);
                    break;
                case "学位授予单位":
                    chsixw.setDegreeAwardingUnit(itemValue);
                    break;
                case "所授学位":
                    chsixw.setDegreeAwarded(itemValue);
                    break;
                case "学科专业":
                    chsixw.setMajor(itemValue);
                    break;
                case "学位证书编号":
                    chsixw.setDegreeCertificateNo(itemValue);
                    break;
                case "在线验证码":
                    chsixw.setOnlineVerificationCode(itemValue);
                    break;
                case "更新日期":
                    chsixw.setUpdateDate(itemValue);
                    break;
            }
        }

        return chsixw;
    }

    private Chsixw parseChsixw_NewVersion(Document doc) {
        Chsixw chsixw = new Chsixw();
        Elements elements = doc.select(".rowcard > .row");
        if (elements.size() == 0) {
            throw new RuntimeException("parseChsixwToJson failed, html format changed.");
        }

        elements.forEach(element -> {
            switch (element.child(0).text()) {//NOSONAR
                case "姓名":
                    String name = element.child(1).text();
                    chsixw.setName(name);
                    break;
                case "性别":
                    String sex = element.child(1).text();
                    chsixw.setSex(sex);
                    break;
                case "出生日期":
                    String dateOfBirth = element.child(1).text();
                    chsixw.setDateOfBirth(dateOfBirth);
                    break;
                case "获学位日期":
                    String dateOfDegreeAwarded = element.child(1).text();
                    chsixw.setDateOfDegreeAwarded(dateOfDegreeAwarded);
                    break;
                case "学位授予单位":
                    String degreeAwardingUnit = element.child(1).text();
                    chsixw.setDegreeAwardingUnit(degreeAwardingUnit);
                    break;
                case "所授学位":
                    String degreeAwarded = element.child(1).text();
                    chsixw.setDegreeAwarded(degreeAwarded);
                    break;
                case "学科专业":
                    String major = element.child(1).text();
                    chsixw.setMajor(major);
                    break;
                case "学位证书编号":
                    String degreeCertificateNo = element.child(1).text();
                    chsixw.setDegreeCertificateNo(degreeCertificateNo);
                    break;
                case "在线验证码":
                    String onlineVerificationCode = element.child(1).text();
                    chsixw.setOnlineVerificationCode(onlineVerificationCode);
                    break;
                case "更新日期":
                    String updateDate = element.child(1).text();
                    chsixw.setUpdateDate(updateDate);
                    break;
            }
        });
        return chsixw;
    }

    public static void main(String[] args) {
//        String filePath = "D:\\data\\file\\chsixw\\chsi_xwzm.html";
        String filePath = "D:\\data\\file\\chsixw\\chsi_xwzm.html";
        ChsixwHtmlParser chsixwParser = new ChsixwHtmlParser();
        String json = chsixwParser.parseChsixwToJson("", filePath).getData();
        System.out.println(json);
    }

}
