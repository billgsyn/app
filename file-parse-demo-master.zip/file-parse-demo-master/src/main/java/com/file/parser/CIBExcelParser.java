package com.file.parser;

import com.file.bo.CIB;
import com.file.bo.CIBTran;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 兴业银行PC模式流水解析
 * @author anyspa
 */

@Slf4j
public class CIBExcelParser {
    public ResponseData<String> parseCIBExcelToJson(String daId, String filePath) {
        log.info("parseCIBExcelToJson started, daId:{}", daId);
        String json = null;

        try {
            CIB cib = parseCIBExcel(filePath);
            json = JsonUtils.convertObjectToJson(cib);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseCIBExcelToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseCIBExcelToJson completed, daId:{}", daId);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private CIB parseCIBExcel(String filePath) {
        CIB cib = new CIB();
        try (FileInputStream fis = new FileInputStream(new File(filePath));
             HSSFWorkbook workbook = new HSSFWorkbook(fis)) {

            HSSFSheet sheet = workbook.getSheetAt(0);
            List<CIBTran> cibTrans = new ArrayList<>();
            for (int i = 0; i < sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (i == 2) {
                    cib.setAccountAlias(row.getLastCellNum() == 2 ? row.getCell(1).getStringCellValue() : null);
                }
                if (i == 3) {
                    cib.setAccountName(row.getCell(1).getStringCellValue());
                }
                if (i == 4) {
                    cib.setAccountNo(row.getCell(1).getStringCellValue());
                }
                if (i == 5) {
                    cib.setInCardAccount(row.getCell(1).getStringCellValue());
                }
                if (i == 6) {
                    cib.setStartDate(row.getCell(1).getStringCellValue());
                }
                if (i == 7) {
                    cib.setExpirationDate(row.getCell(1).getStringCellValue());
                }
                if (i == 8) {
                    cib.setDownloadDate(row.getCell(1).getStringCellValue());
                }

                if (i >= 11) {
                    CIBTran cibTran = new CIBTran();
                    cibTran.setTransactionTime(row.getCell(0).getStringCellValue());
                    cibTran.setBookkeepingDate(row.getCell(1).getStringCellValue());
                    cibTran.setExpense(this.getStringCellValue(row.getCell(2)));
                    cibTran.setIncome(this.getStringCellValue(row.getCell(3)));
                    cibTran.setAccountBalance(this.getStringCellValue(row.getCell(4)));
                    cibTran.setSummary(row.getCell(5).getStringCellValue());
                    cibTran.setCounterPartyAccountName(row.getCell(6).getStringCellValue());
                    cibTran.setCounterPartyBank(row.getCell(7).getStringCellValue());
                    cibTran.setCounterPartyAccountNumber(row.getCell(8).getStringCellValue());
                    cibTran.setUse(row.getCell(9).getStringCellValue());
                    cibTran.setTransactionChannel(row.getCell(10).getStringCellValue());
                    cibTran.setComment(row.getCell(11).getStringCellValue());
                    cibTrans.add(cibTran);
                }
            }
            cib.setCibTrans(cibTrans);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return cib;
    }

    private String getStringCellValue(Cell cell) {
        String cellStr;
        if (Objects.equals(cell.getCellType(), CellType.NUMERIC)) {
            cellStr = String.valueOf(cell.getNumericCellValue());
        } else {
            cellStr = cell.getStringCellValue();
        }
        return cellStr;
    }

    public static void main(String[] args) {
        String pdfFilePath = "D:\\data\\files\\CIB\\兴业银行流水.xls";

        CIBExcelParser cibExcelParser = new CIBExcelParser();
        ResponseData<String> responseData = cibExcelParser.parseCIBExcelToJson("dd", pdfFilePath);
        System.out.println(responseData.getData());
    }
}
