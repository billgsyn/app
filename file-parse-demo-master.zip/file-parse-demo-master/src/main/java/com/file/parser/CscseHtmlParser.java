package com.file.parser;

import com.file.bo.OverseasDiploma;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import com.google.common.base.Splitter;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * 国外学历
 * @author anyspa
 */

@Slf4j
public class CscseHtmlParser {

    public ResponseData<String> parseCscseHtmlToJson(String daId, String filePath) {
        log.info("parseCscseHtmlToJson started, daId:{}", daId);
        String json = null;

        try {
            OverseasDiploma diploma = parseCscseHtml(filePath);
            json = JsonUtils.convertObjectToJson(diploma);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseXlcxHtmlToJson failed", e);
            return new ResponseData<>(json, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseCscseHtmlToJson completed, daId:{}, json:{}", daId, json);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private OverseasDiploma parseCscseHtml(String filePath) throws IOException {
        File input = new File(filePath);
        OverseasDiploma overseasDiploma = new OverseasDiploma();

        Document doc = Jsoup.parse(input, "UTF-8");

        overseasDiploma.setCertificateNo(doc.getElementById("number").html());
        List<String> firstpStrList =
                Splitter.on("，").trimResults().splitToList(doc.getElementById("firstp").html());

        String name = firstpStrList.get(0).substring(firstpStrList.get(0).lastIndexOf("&nbsp;") + 6).trim();
        overseasDiploma.setName(name);
        overseasDiploma.setSex(firstpStrList.get(1));

        String nationality = firstpStrList.get(2).substring(0, firstpStrList.get(2).indexOf("国籍"));
        overseasDiploma.setNationality(nationality);

        String secondpStr = doc.getElementById("secondp").html();
        Pattern datePattern = Pattern.compile("[0-9]{4}年[0-9]{1,2}月");
        Matcher dateMatcher = datePattern.matcher(secondpStr);
        List<String> dateList = new ArrayList<>();
        while (dateMatcher.find()) {
            dateList.add(dateMatcher.group());
        }
        if (dateList.size() == 1) {
            overseasDiploma.setDateOfEnrollment("");
            overseasDiploma.setDateOfCertificateIssuance(dateList.get(0));
        } else if (dateList.size() >= 2) {
            overseasDiploma.setDateOfEnrollment(dateList.get(0));
            overseasDiploma.setDateOfCertificateIssuance(dateList.get(dateList.size() - 1));
        }

        String major = "";
        String academicDegree = "";
        if (secondpStr.contains("专业领域为")) {
            major = secondpStr.substring(secondpStr.indexOf("专业领域为") + 5, secondpStr.lastIndexOf("。"));
        } else {
            Pattern majorPattern = Pattern.compile("学习\\S{2,20}专业");
            Matcher majorMatcher = majorPattern.matcher(secondpStr);
            if (majorMatcher.find()) {
                major = majorMatcher.group().substring(2, majorMatcher.group().length()-2);
            }
        }

        Pattern pattern = Pattern.compile("[\u4e00-\u9fa5]{4}学位");
        Matcher matcher = pattern.matcher(secondpStr);
        if (matcher.find()) {
            academicDegree = matcher.group().substring(0, 4);
        }
        overseasDiploma.setMajor(major);
        overseasDiploma.setAcademicDegree(academicDegree);

        String graduateSchool = secondpStr.substring(secondpStr.indexOf("在") + 1, secondpStr.indexOf("（"));
        if (graduateSchool.contains("，")) {
            String text = graduateSchool.split("，")[1];
            graduateSchool = text.substring(text.indexOf("在") + 1);
        }
        overseasDiploma.setGraduateSchool(graduateSchool);

        try {
            String dateOfAuthentication = doc.getElementById("certificatedate").html();
            overseasDiploma.setDateOfAuthentication(dateOfAuthentication);
        } catch (Exception e) {
            overseasDiploma.setDateOfAuthentication("");
        }

        log.info("overseasDiploma:{}", overseasDiploma);

        return overseasDiploma;
    }

    public static void main(String[] args) {
        CscseHtmlParser cscseHtmlParser = new CscseHtmlParser();
        String json = cscseHtmlParser.parseCscseHtmlToJson("", "D:\\data\\files\\cscse\\zd1tuknz1589585570970189824_15dd50459833d2327244806954b321d0_cscse.html").getData();
        System.out.println(json);

        json = cscseHtmlParser.parseCscseHtmlToJson("", "D:\\data\\files\\cscse\\zd1tuknz1589587084300238848_4581671f2d7bf95cfd7ffc385183474e_cscse.html").getData();
        System.out.println(json);

        json = cscseHtmlParser.parseCscseHtmlToJson("", "D:\\data\\files\\cscse\\zd1tuknz1589588770615967744_f5c782790d941d78207ca4365038bd72_cscse.html").getData();
        System.out.println(json);

        json = cscseHtmlParser.parseCscseHtmlToJson("", "D:\\data\\files\\cscse\\zd1tuknz1589589746143969280_b632ff8984a96411c2263b1a1105d363_cscse.html").getData();
        System.out.println(json);

        json = cscseHtmlParser.parseCscseHtmlToJson("", "D:\\data\\files\\cscse\\zd1tuknz1589592064377733120_f43caff9729458f497b16dc62939fcc3_cscse.html").getData();
        System.out.println(json);

        json = cscseHtmlParser.parseCscseHtmlToJson("", "D:\\data\\files\\cscse\\zd1tuknz1589592669976510464_ccb102eeba56a01702c4d9e97106e54e_cscse.html").getData();
        System.out.println(json);
    }

}
