package com.file.parser;

import com.file.bo.HFB;
import com.file.bo.HFBTran;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 恒丰银行PC模式流水解析
 * @author anyspa
 */

@Slf4j
public class HFBExcelParser {
    public ResponseData<String> parseHFBExcelToJson(String daId, String filePath) {
        log.info("parseHFBExcelToJson started, daId:{}", daId);
        String json = null;

        try {
            HFB hfb = parseHFBExcel(filePath);
            json = JsonUtils.convertObjectToJson(hfb);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseHFBExcelToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseHFBExcelToJson completed, daId:{}", daId);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private HFB parseHFBExcel(String filePath) {
        HFB hfb = new HFB();
        try (FileInputStream fis = new FileInputStream(new File(filePath));
             HSSFWorkbook workbook = new HSSFWorkbook(fis)) {

            HSSFSheet sheet = workbook.getSheetAt(0);
            List<HFBTran> hfbTrans = new ArrayList<>();
            for (int i = 0; i < sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (i == 1) {
                    hfb.setAccountOpeningInstitution(row.getCell(1).getStringCellValue());
                }
                if (i == 2) {
                    hfb.setCurrency(row.getCell(1).getStringCellValue());
                }
                if (i == 3) {
                    hfb.setAccountNumber(row.getCell(1).getStringCellValue());
                }

                if (i >= 6) {
                    HFBTran hfbTran = new HFBTran();
                    hfbTran.setBookkeepingDate(row.getCell(0).getStringCellValue());
                    hfbTran.setTransactionDate(row.getCell(1).getStringCellValue());
                    hfbTran.setTransactionTime(row.getCell(2).getStringCellValue());
                    hfbTran.setExpense(this.getStringCellValue(row.getCell(3)));
                    hfbTran.setIncome(this.getStringCellValue(row.getCell(4)));
                    hfbTran.setAccountBalance(this.getStringCellValue(row.getCell(5)));
                    hfbTran.setCurrency(row.getCell(6).getStringCellValue());
                    hfbTran.setSummary(row.getCell(7).getStringCellValue());
                    hfbTran.setCounterPartyAccountNumber(row.getCell(8).getStringCellValue());
                    hfbTran.setCounterPartyAccountName(row.getCell(9).getStringCellValue());
                    hfbTran.setTradingPlace(row.getCell(10).getStringCellValue());
                    hfbTrans.add(hfbTran);
                }
            }
            hfb.setHfbTrans(hfbTrans);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return hfb;
    }

    private String getStringCellValue(Cell cell) {
        String cellStr;
        if (Objects.equals(cell.getCellType(), CellType.NUMERIC)) {
            cellStr = String.valueOf(cell.getNumericCellValue());
        } else {
            cellStr = cell.getStringCellValue();
        }
        return cellStr;
    }

    public static void main(String[] args) {
        String pdfFilePath = "D:\\data\\files\\HFB\\恒丰银行流水.xls";

        HFBExcelParser hfbExcelParser = new HFBExcelParser();
        ResponseData<String> responseData = hfbExcelParser.parseHFBExcelToJson("dd", pdfFilePath);
        System.out.println(responseData.getData());
    }
}
