package com.file.parser;


import com.file.bo.ResponseData;
import com.file.bo.mail.CGB;
import com.file.bo.mail.CGBTran;
import com.file.constant.ErrorCode;
import com.file.parser.traprange.PDFTableExtractor;
import com.file.util.JsonUtils;
import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class CGBPdfParser extends BaseDecryptPdfParser {

    private static final Integer CGB_PDF_HEADER_LINE_NUMBER = 2;
    private static final Integer CGB_PDF_FOOTER_LINE_NUMBER = 1;

    public ResponseData<String> parseCGBPdfToJson(String daId, String filePath, String pdfPassword) {
        log.info("parseCGBPdfToJson started, daId:{}, pdfPassword:{}", daId, pdfPassword);
        String json = null;

        try {
            CGB cgb = parseCGBPdf(filePath, pdfPassword);
            json = JsonUtils.convertObjectToJson(cgb);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseCGBPdfToJson failed", e);
            return new ResponseData<String>(json, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseCGBPdfToJson completed, daId:{}, pdfPassword:{}", daId, pdfPassword);
        return new ResponseData<String>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private CGB parseCGBPdf(String filePath, String pdfPassword) {
        CGB cgb = parseCGBHeader(filePath, pdfPassword);

        List<CGBTran> cgbTrans = parseCgbTrans(filePath, pdfPassword);

        cgb.setCgbTrans(cgbTrans);

        return cgb;
    }

    private CGB parseCGBHeader(String filePath, String pdfPassword) {
        CGB cgb = new CGB();
        String pdfHeaderText = parsePdfHeaderText(filePath, pdfPassword);
        log.info(pdfHeaderText);

        String accountNo = pdfHeaderText
                .substring(pdfHeaderText.indexOf("个人账户交易流水证明账号:") + 13, pdfHeaderText.indexOf("户名: ")).trim();
        String accountName = pdfHeaderText.substring(pdfHeaderText.indexOf("户名: ") + 3, pdfHeaderText.indexOf("起止日期: "))
                .trim();
        String inquiryPeriod = pdfHeaderText
                .substring(pdfHeaderText.indexOf("起止日期: ") + 5, pdfHeaderText.indexOf("交易时间 币种")).trim();

        cgb.setAccountNo(accountNo);
        cgb.setAccountName(accountName);
        cgb.setInquiryPeriod(inquiryPeriod);

        return cgb;
    }

    private List<CGBTran> parseCgbTrans(String filePath, String pdfPassword) {
        List<CGBTran> cgbTrans = new ArrayList<>();

        String transText = parseTransToText(filePath, pdfPassword);

        String pdfText = getPdfTextByStripper(filePath, pdfPassword);
        pdfText = pdfText.replace(System.getProperty("line.separator", "\n"), " ");

        if (Strings.isNullOrEmpty(transText)) {
            return cgbTrans;
        }

        List<List<String>> tranFieldsList = parseTransTextToTranFieldsList(transText);
        if (tranFieldsList.isEmpty()) {
            return cgbTrans;
        }

        List<String> headerTextList = tranFieldsList.get(0);
        // 新版pdf多了"附言"这一列
        if (StringUtils.contains(StringUtils.join(headerTextList), "附言")) {
            parseNewVersionCgbTrans(cgbTrans, pdfText);
        } else {
            parseCgbTrans(cgbTrans, tranFieldsList, pdfText);
        }

        return cgbTrans;
    }

    private void parseNewVersionCgbTrans(List<CGBTran> cgbTrans, String pdfText) {
        // 2023-03-14 10:46: 26 人民币 +1000.00 1000.00 蔡旭权 991584000049XXX 银联入账 微信零钱提现
        // 2023-10-28 15: 28:50 人民币 -20734.46 0.00 李XX 6214830211197XXX 转账支出 工资
        Pattern pattern = Pattern
                .compile("\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\s*\\d{2}:\\s*\\d{2}\\s\\S{1,10}\\s([-+])\\d{1,9}.\\d{2}\\s\\d{1,9}.\\d{2}\\s");
        Matcher matcher = pattern.matcher(pdfText);

        // 每行交易记录的第一个字所在的index
        int tranIndex = 0;
        Map<Integer, Integer> tranTextStartIndexMap = new HashMap<>();

        while (matcher.find()) {
            // System.out.println("Match " + matcher.group() + " at positions " + matcher.start() + "-" + (matcher.end() - 1));
            tranTextStartIndexMap.put(tranIndex, matcher.start());
            tranIndex++;
        }

        // 找出每行交易记录的文本
        List<String> tranTextList = new ArrayList<>();
        // 2023-04-22 05:22: 应付商户款-B端新金融 621462552100071651500
        Pattern pattern1 = Pattern.compile("\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\s\\D{1,10}");
        for (int i = 1; i < tranTextStartIndexMap.size(); i++) {
            String tranText = pdfText.substring(tranTextStartIndexMap.get(i - 1), tranTextStartIndexMap.get(i));
            Matcher matcher1 = pattern1.matcher(tranText);
            if (matcher1.find()) {
                tranText = tranText.substring(0, matcher1.start());
            }
            if (tranText.contains("账号:")) {
                tranText = tranText.substring(0, tranText.indexOf("账号:")).trim();
            } else if (tranText.contains("广发银行股份有限公司第")) {
                tranText = tranText.substring(0, tranText.indexOf("广发银行股份有限公司第")).trim();
            } else if (tranText.contains("个人账户交易流水证明")) {
                tranText = tranText.substring(0, tranText.indexOf("个人账户交易流水证明")).trim();
            }
            tranTextList.add(tranText.trim());
        }

        String lastTranText = pdfText.substring(tranTextStartIndexMap.get(tranTextStartIndexMap.size() - 1));
        Matcher matcher1 = pattern1.matcher(lastTranText);
        if (matcher1.find()) {
            lastTranText = lastTranText.substring(0, matcher1.start());
        } else if (lastTranText.contains("账号:")) {
            lastTranText = lastTranText.substring(0, lastTranText.indexOf("账号:")).trim();
        } else if (lastTranText.contains("广发银行股份有限公司第")) {
            lastTranText = lastTranText.substring(0, lastTranText.indexOf("广发银行股份有限公司第")).trim();
        }
        tranTextList.add(lastTranText.trim());

        for (String tranText : tranTextList) {
            CGBTran cgbTran = new CGBTran();
            // 2023-03-14 10:46: 26 人民币 +1000.00 1000.00 蔡** 991584000049XXX 银联入账 微信零钱提现
            // 2023-10-28 15: 28:50 人民币 -20734.46 0.00 李XX 6214830211197XXX 转账支出 工资
            List<String> textList = Splitter.on(StringUtils.SPACE).splitToList(tranText);
            if (textList.get(1).matches("(\\d{2}:\\d{2}:|\\d{2}:)")) {
                cgbTran.setTranDate(StringUtils.join(textList.get(0), " ", textList.get(1), textList.get(2)));
                cgbTran.setCurrency(textList.get(3));
                cgbTran.setTranAmt(textList.get(4));
                cgbTran.setAccountBalance(textList.get(5));
                // 2023-06-21 01:10: 48 人民币 +4.07 623.60 结息转入
                if (textList.size() == 7) {
                    cgbTran.setSummary(textList.get(6));
                    cgbTran.setCounterPartyAccountName("");
                    cgbTran.setConterPartyAccountNo("");
                    cgbTran.setPostscript("");
                } else {
                    // 蔡** 991584000049XXX 银联入账 微信零钱提现
                    String lastFourColText = tranText.substring(tranText.indexOf(textList.get(5)) + textList.get(5).length() + 1);

                    // 2023-09-12 13:40: 22 人民币 -7000.00 389.49 周** 621728115290317XXXX 转账支出
                    if (textList.get(7).matches("[A-Za-z0-9_*\\-]{6,35}")) {
                        cgbTran.setCounterPartyAccountName(textList.get(6));
                        cgbTran.setConterPartyAccountNo(textList.get(7));
                        if (textList.size() == 9) {
                            cgbTran.setSummary(textList.get(8));
                            cgbTran.setPostscript("");
                        } else if (textList.size() > 9) {
                            cgbTran.setSummary(textList.get(8));
                            String postscript = lastFourColText.substring(lastFourColText.indexOf(textList.get(8)) + textList.get(8).length() + 1);
                            cgbTran.setPostscript(postscript.replaceAll("\\s+", ""));
                        }
                        // 对方姓名为空
                        // 2023-02-10 12:34: 25 人民币 +1000.00 15837.84 623259039100010xxxx 转账存入
                        //对方姓名和对方账户连在一起
                        // 2023-10-05 05:29: 00 人民币 +20199.00 91531.24 广发银行股份有限公司1730011562611102157xxxx 收单入账 621462422100070xxxx， 20231004至20231004， 20199.00费0.00，其他 0.00
                    } else if (textList.get(6).matches("\\S+[A-Za-z0-9_*\\-]{6,35}")) {
                        Matcher matcher2 = Pattern.compile("[A-Za-z0-9_*\\-]{6,35}").matcher(textList.get(6));
                        if (matcher2.find()) {
                            cgbTran.setCounterPartyAccountName(textList.get(6).replaceAll(matcher2.group(), ""));
                            cgbTran.setConterPartyAccountNo(matcher2.group());
                        }
                        if (textList.size() == 8) {
                            cgbTran.setSummary(textList.get(7));
                            cgbTran.setPostscript("");
                        } else if (textList.size() > 8) {
                            cgbTran.setSummary(textList.get(7));
                            String postscript = lastFourColText.substring(lastFourColText.indexOf(textList.get(7)) + textList.get(7).length() + 1);
                            cgbTran.setPostscript(postscript.replaceAll("\\s+", ""));
                        }
                        // 对方姓名 字段跨行
                        // "2023-09-08 07:11: 45 人民币 +6330.95 7389.49 应付商户款-B端新金融 生态圈项目 17300115626111000 收单入账 6214622421001819777， 20230716至20230716
                    } else if (textList.size() > 8 && textList.get(8).matches("[A-Za-z0-9_*\\-]{6,35}")) {
                        cgbTran.setCounterPartyAccountName(StringUtils.join(textList.get(6), textList.get(7)));
                        cgbTran.setConterPartyAccountNo(textList.get(8));
                        if (textList.size() == 10) {
                            cgbTran.setSummary(textList.get(9));
                            cgbTran.setPostscript("");
                        } else if (textList.size() > 10) {
                            cgbTran.setSummary(textList.get(9));
                            String postscript = lastFourColText.substring(lastFourColText.indexOf(textList.get(9)) + textList.get(9).length() + 1);
                            cgbTran.setPostscript(postscript.replaceAll("\\s+", ""));
                        }
                        // 对方姓名 字段跨3行
                        // 2023-11-10 09: 17:44 人民币 +8378.61 8378.61 XXX XXX 分公司 95508802260016XXXXX 网银转入 转款##20231108-E1102##DH  20000007642023##P46191##EB04####320000007642023
                    } else if (textList.size() > 9 && textList.get(9).matches("[A-Za-z0-9_*\\-]{6,35}")) {
                        cgbTran.setCounterPartyAccountName(StringUtils.join(textList.get(6), textList.get(7), textList.get(8)));
                        cgbTran.setConterPartyAccountNo(textList.get(9));
                        if (textList.size() == 11) {
                            cgbTran.setSummary(textList.get(10));
                            cgbTran.setPostscript("");
                        } else if (textList.size() > 11) {
                            cgbTran.setSummary(textList.get(10));
                            String postscript = lastFourColText.substring(lastFourColText.indexOf(textList.get(10)) + textList.get(10).length() + 1);
                            cgbTran.setPostscript(postscript.replaceAll("\\s+", ""));
                        }
                    } else {
                        // 对方姓名对方账户为空
                        // 2023-02-17 06:31: 23 人民币 -1000000.00 2176823.98 产品扣款 （尊享版）“广银创 富”D款2023年第35 期人民币结构性存款 (挂钩中证500指数阶 梯式看涨自动赎回结 构)(个人版)
                        if (textList.stream().skip(6).noneMatch(s -> Pattern.compile("[A-Za-z0-9_*\\-]{6,35}").matcher(s).matches())) {
                            cgbTran.setCounterPartyAccountName("");
                            cgbTran.setConterPartyAccountNo("");
                            cgbTran.setSummary(textList.get(6));
                            String postscript = lastFourColText.substring(lastFourColText.indexOf(textList.get(6)) + textList.get(6).length() + 1);
                            cgbTran.setPostscript(postscript.replaceAll("\\s+", ""));
                        }
                    }
                }
                // 2023-03-14 10:46:26 人民币 +1000.00 1000.00 蔡** 991584000049XXX 银联入账 微信零钱提现
            } else if (textList.get(1).matches("\\d{2}:\\d{2}:\\d{2}")) {
                cgbTran.setTranDate(StringUtils.join(textList.get(0), " ", textList.get(1)));
                cgbTran.setCurrency(textList.get(2));
                cgbTran.setTranAmt(textList.get(3));
                cgbTran.setAccountBalance(textList.get(4));
                // 2023-06-21 01:10:48 人民币 +4.07 623.60 结息转入
                if (textList.size() == 6) {
                    cgbTran.setSummary(textList.get(5));
                    cgbTran.setCounterPartyAccountName("");
                    cgbTran.setConterPartyAccountNo("");
                    cgbTran.setPostscript("");
                } else {
                    // 蔡** 991584000049XXX 银联入账 微信零钱提现
                    String lastFourColText = tranText.substring(tranText.indexOf(textList.get(5)) + textList.get(5).length() + 1);
                    // 2023-09-12 13:40:22 人民币 -7000.00 389.49 周** 621728115290317XXXX 转账支出
                    if (textList.get(6).matches("[A-Za-z0-9_*\\-]{6,35}")) {
                        cgbTran.setCounterPartyAccountName(textList.get(5));
                        cgbTran.setConterPartyAccountNo(textList.get(6));
                        if (textList.size() == 8) {
                            cgbTran.setSummary(textList.get(7));
                            cgbTran.setPostscript("");
                        } else if (textList.size() > 8) {
                            cgbTran.setSummary(textList.get(7));
                            String postscript = lastFourColText.substring(lastFourColText.indexOf(textList.get(7)) + textList.get(7).length() + 1);
                            cgbTran.setPostscript(postscript.replaceAll("\\s+", ""));
                        }
                        // 对方姓名和对方账户连在一起
                        // 2023-06-19, 11:00:29, 人民币, +92.00, 32945.06, XXXXXXXX有限公司95508802345961XXXXX, 代发工资
                        // 对方姓名为空
                        // 2023-07-11 12:47:49 人民币 +1500.00 2464.12 00000000000XXXX 存入
                    } else if (textList.get(5).matches("\\S+[A-Za-z0-9_*\\-]{6,35}")) {
                        Matcher matcher2 = Pattern.compile("[A-Za-z0-9_*\\-]{6,35}").matcher(textList.get(5));
                        if (matcher2.find()) {
                            cgbTran.setCounterPartyAccountName(textList.get(5).replaceAll(matcher2.group(), ""));
                            cgbTran.setConterPartyAccountNo(matcher2.group());
                        }
                        if (textList.size() == 7) {
                            cgbTran.setSummary(textList.get(6));
                            cgbTran.setPostscript("");
                        } else if (textList.size() > 7) {
                            cgbTran.setSummary(textList.get(6));
                            String postscript = lastFourColText.substring(lastFourColText.indexOf(textList.get(6)) + textList.get(6).length() + 1);
                            cgbTran.setPostscript(postscript.replaceAll("\\s+", ""));
                        }
                        // 对方姓名 字段跨行
                        // "2023-09-08 07:11:45 人民币 +6330.95 7389.49 应付商户款-B端新金融 生态圈项目 17300115626111000 收单入账 6214622421001819777， 20230716至20230716
                    } else if (textList.size() > 7 && textList.get(7).matches("[A-Za-z0-9_*\\-]{6,35}")) {
                        cgbTran.setCounterPartyAccountName(StringUtils.join(textList.get(5), textList.get(6)));
                        cgbTran.setConterPartyAccountNo(textList.get(7));
                        if (textList.size() == 9) {
                            cgbTran.setSummary(textList.get(8));
                            cgbTran.setPostscript("");
                        } else if (textList.size() > 9) {
                            cgbTran.setSummary(textList.get(8));
                            String postscript = lastFourColText.substring(lastFourColText.indexOf(textList.get(8)) + textList.get(8).length() + 1);
                            cgbTran.setPostscript(postscript.replaceAll("\\s+", ""));
                        }
                        // 对方姓名 字段跨3行
                        // 2023-05-05 19:40:31 人民币 -7000.00 140000.02 xxx 增利货币支付商户号-支 付商户号 180000xxxx 快捷支付 xxx 日
                    } else if (textList.size() > 8 && textList.get(8).matches("[A-Za-z0-9_*\\-]{6,35}")) {
                        cgbTran.setCounterPartyAccountName(StringUtils.join(textList.get(5), textList.get(6), textList.get(7)));
                        cgbTran.setConterPartyAccountNo(textList.get(8));
                        if (textList.size() == 10) {
                            cgbTran.setSummary(textList.get(9));
                            cgbTran.setPostscript("");
                        } else if (textList.size() > 10) {
                            cgbTran.setSummary(textList.get(9));
                            String postscript = lastFourColText.substring(lastFourColText.indexOf(textList.get(9)) + textList.get(9).length() + 1);
                            cgbTran.setPostscript(postscript.replaceAll("\\s+", ""));
                        }
                    } else {
                        // 对方姓名对方账户为空
                        //2023-02-10 11:36:07 人民币 +2019178.08 3199803.29 产品还款 （尊享版）“广银创 富”D款2022年第200 期人民币结构性存款 (挂钩中证500指数阶 梯式看涨自动赎回结 构)(个人版)
                        if (textList.stream().skip(5).noneMatch(s -> Pattern.compile("[A-Za-z0-9_*\\-]{6,35}").matcher(s).matches())) {
                            cgbTran.setCounterPartyAccountName("");
                            cgbTran.setConterPartyAccountNo("");
                            cgbTran.setSummary(textList.get(5));
                            cgbTran.setPostscript(lastFourColText.replaceAll("\\s+", ""));
                        }
                    }
                }
            } else {
                log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "CGB Pdf format changed");
                throw new RuntimeException();
            }
            cgbTrans.add(cgbTran);
        }
    }

    private void parseCgbTrans(List<CGBTran> cgbTrans, List<List<String>> tranFieldsList, String pdfText) {
        for (List<String> strings : tranFieldsList) {
            // 正常情况下, 一条记录包含7的column
            if (strings.size() == 7) {
                if (StringUtils.isNotBlank(strings.get(0)) && strings.get(0).contains("交易时间")) {
                    continue;
                }
                if (StringUtils.isNotBlank(strings.get(0))) {
                    CGBTran cgbTran = new CGBTran();
                    cgbTran.setTranDate(strings.get(0));
                    cgbTran.setCurrency(strings.get(1));
                    cgbTran.setTranAmt(strings.get(2));
                    cgbTran.setAccountBalance(strings.get(3));
                    cgbTran.setCounterPartyAccountName(strings.get(4));
                    cgbTran.setConterPartyAccountNo(strings.get(5));
                    cgbTran.setSummary(strings.get(6));
                    cgbTrans.add(cgbTran);
                }
            }
            // 对方姓名和对方账号 粘在一起了
            else if (strings.size() == 6) {
                if (StringUtils.isNotBlank(strings.get(0)) && strings.get(0).contains("交易时间")) {
                    continue;
                }
                if (StringUtils.isNotBlank(strings.get(0))) {
                    CGBTran cgbTran = new CGBTran();
                    cgbTran.setTranDate(strings.get(0));
                    cgbTran.setCurrency(strings.get(1));
                    cgbTran.setTranAmt(strings.get(2));
                    cgbTran.setAccountBalance(strings.get(3));
                    splitCounterPartyAccountNameAndAccountNo(cgbTran, strings.get(4));
                    cgbTran.setSummary(strings.get(5));
                    cgbTrans.add(cgbTran);
                }
            }
        }
        // 对方姓名有跨行的情况
        resetCounterPartyAccountName(pdfText, cgbTrans);
    }

    private void resetCounterPartyAccountName(String pdfText, List<CGBTran> cgbTrans) {
        // 2022-10-08 20:41:25 人民币 -71.00 474.89
        // 扫二维码付款 1000107101 快捷支付
        Pattern pattern = Pattern
                .compile("\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\s\\S{1,10}\\s([-+])\\d{1,9}.\\d{2}\\s\\d{1,9}.\\d{2}\\s");
        Matcher matcher = pattern.matcher(pdfText);

        // 每行交易记录的第一个字所在的index
        int tranIndex = 0;
        Map<Integer, Integer> tranTextStartIndexMap = new HashMap<>();

        while (matcher.find()) {
            // log.info(
            // "Match \"" + matcher1.group() + "\" at positions " + matcher1.start() + "-" +
            // (matcher1.end() - 1));
            tranTextStartIndexMap.put(tranIndex, matcher.start());
            tranIndex++;
        }
        log.info(String.valueOf(cgbTrans.size()));

        // 找出每行交易记录的文本
        List<String> tranTextList = new ArrayList<>();
        for (int i = 1; i < tranTextStartIndexMap.size(); i++) {
            String tranText = pdfText.substring(tranTextStartIndexMap.get(i - 1), tranTextStartIndexMap.get(i));
            if (tranText.contains("账号: ")) {
                tranText = tranText.substring(0, tranText.indexOf("账号: ")).trim();
            }
            // log.info(tranText);
            tranTextList.add(tranText.trim());
        }

        String lastTranText = pdfText.substring(tranTextStartIndexMap.get(tranTextStartIndexMap.size() - 1));
        if (lastTranText.contains("账号: ")) {
            lastTranText = lastTranText.substring(0, lastTranText.indexOf("账号: ")).trim();
        }
        log.info(lastTranText);
        tranTextList.add(lastTranText.trim());

        log.info(String.valueOf(tranTextList.size()));

        // 找出每行交易里的对手信息的值
        for (int i = 0; i < tranTextList.size(); i++) {
            try {
                if (StringUtils.isNotBlank(cgbTrans.get(i).getConterPartyAccountNo())) {
                    CGBTran cgbTran = cgbTrans.get(i);
                    String[] strArr = {cgbTran.getTranDate(), cgbTran.getCurrency(), cgbTran.getTranAmt(),
                            cgbTran.getAccountBalance()};
                    String str = String.join(StringUtils.SPACE, strArr).replaceAll("\\s+", StringUtils.SPACE).trim();
                    String counterPartyAccountName = tranTextList.get(i).substring(str.length(),
                            tranTextList.get(i).indexOf(cgbTran.getConterPartyAccountNo())).trim();
                    cgbTran.setCounterPartyAccountName(counterPartyAccountName);
                }
            } catch (Exception e) {
                log.warn("resetCounterPartyAccountName failed");
            }
        }
    }

    private String parseTransToText(String filePath, String pdfPassword) {
        PDFTableExtractor extractor = (new PDFTableExtractor()).setSource(filePath, pdfPassword);
        int pdfPageNumber = getPdfPageNumber(filePath, pdfPassword);

        for (int k = 0; k < pdfPageNumber; k++) {
            int[] skipLinesIndexes = new int[CGB_PDF_HEADER_LINE_NUMBER
                    + CGB_PDF_FOOTER_LINE_NUMBER];
            for (int i = 0; i < CGB_PDF_HEADER_LINE_NUMBER; i++) {
                skipLinesIndexes[i] = i;
            }
            for (int j = 0; j < CGB_PDF_FOOTER_LINE_NUMBER; j++) {
                skipLinesIndexes[CGB_PDF_HEADER_LINE_NUMBER + j] = -(j + 1);
            }
            extractor.exceptLine(k, skipLinesIndexes);
        }

        return extractPdfToText(extractor);
    }

    // 拆分对方姓名和对方账号两个字段
    private void splitCounterPartyAccountNameAndAccountNo(CGBTran cgbTran, String counterParty) {
        // 北京xx有限公司11000024730990
        if (StringUtils.isNotBlank(counterParty)) {
            Pattern pattern = Pattern.compile("[0-9]+$");
            Matcher matcher = pattern.matcher(counterParty);
            if (matcher.find()) {
                cgbTran.setCounterPartyAccountName(counterParty.substring(0, matcher.start()));
                cgbTran.setConterPartyAccountNo(matcher.group());
                return;
            }
        }
        cgbTran.setCounterPartyAccountName(StringUtils.EMPTY);
        cgbTran.setConterPartyAccountNo(StringUtils.EMPTY);
    }
    public static void main(String[] args) {
        CGBPdfParser cgbPdfParser = new CGBPdfParser();
//		CGB cgb = cgbPdfParser.parseCGBPdf("E:\\data\\files\\CGB\\广发银行(7855036142).pdf", "7855036142");
//		CGB cgb = cgbPdfParser.parseCGBPdf("E:\\data\\files\\CGB\\zd4tdybm1547481139923558400_40d4f822d6806fffcf0ca49fde5cec9c_beehive-gdb_jyls-0-3758.pdf", "3758");

        CGB cgb = cgbPdfParser.parseCGBPdf("D:\\CgBRbGZWxpmAUKUqABrMUqlNUG0555.pdf", "7088634");
        String json = JsonUtils.convertObjectToJson(cgb);
        System.out.println(json);
    }
}
