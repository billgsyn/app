package com.file.parser;

import com.file.bo.BOB;
import com.file.bo.BOBTran;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 丰巢-北京银行的pdf解析类
 * @author anyspa
 * @date 2024-05-08
 */
@Slf4j
public class BOBPdfParser extends BasePdfParser{

    public ResponseData<String> parseBOBPdfToJson(String daId, String filePath) {
        log.info("parseBOBPdfToJson started, daId:{}", daId);
        String json = null;

        try {
            BOB bob = parseBOBPdf(filePath);
            json = JsonUtils.convertObjectToJson(bob);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseBOBPdfToJson failed", e);
            return new ResponseData<String>(json, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseBOBPdfToJson completed, daId:{}", daId);
        return new ResponseData<String>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    public BOB parseBOBPdf(String filePath) {
        List<BOBTran> bobTrans = parseTrans(filePath);

        BOB bob = parseBOBHeader(filePath);

        bob.setBobTrans(bobTrans);

        return bob;
    }

    public BOB parseBOBHeader(String filePath) {
        BOB bob = new BOB();
        String pdfHeaderText = parsePdfHeaderText(filePath);

        String name = pdfHeaderText.substring(pdfHeaderText.indexOf("客户姓名：") + 5, pdfHeaderText.indexOf("日期范围：")).trim(); //NOSONAR
        String dateRange = pdfHeaderText.substring(pdfHeaderText.indexOf("日期范围：") + 5, pdfHeaderText.indexOf("卡/账号：")).trim();//NOSONAR
        String accountNumber = pdfHeaderText.substring(pdfHeaderText.indexOf("卡/账号：") + 4, pdfHeaderText.indexOf("币种：")).trim();//NOSONAR
        String currency = pdfHeaderText.substring(pdfHeaderText.indexOf("币种：") + 3, pdfHeaderText.indexOf("流水单号：")).trim();//NOSONAR
        String serialNo = pdfHeaderText.substring(pdfHeaderText.indexOf("流水单号：") + 5, pdfHeaderText.indexOf("交易日期")).trim();//NOSONAR
        bob.setName(name);
        bob.setDateRange(dateRange);
        bob.setAccountNumber(accountNumber);
        bob.setCurrency(currency);
        bob.setSerialNo(serialNo);
        return bob;
    }

    public List<BOBTran> parseTrans(String filePath) {
        List<BOBTran> bobTrans = new ArrayList<>();

        String transText = getPdfTextByStripper(filePath);
        if (Strings.isNullOrEmpty(transText)) {
            return bobTrans;
        }

        List<List<String>> tranFieldsList = parseTransTextToTranFieldsList(transText);

        Pattern DATE_PATTERN = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");

        // 每行的记录是否读取完成
        for (int i = 0; i < tranFieldsList.size(); i++) {
            List<String> strings = tranFieldsList.get(i);

            String[] contents = strings.get(0).split(" ");
            if (contents.length > 5 && DATE_PATTERN.matcher(contents[0]).matches()) {
                BOBTran bobTran = new BOBTran();
                bobTran.setTranDate(contents[0]);
                bobTran.setCurrency(contents[1]);
                bobTran.setCashRemit(contents[2]);
                bobTran.setBusinessSummary(contents[3]);
                bobTran.setTranAmount(contents[4]);
                bobTran.setBalance(contents[5]);
                if (contents.length > 6) {
                    bobTran.setCounterPartyAccountName(contents[6]);
                } else {
                    bobTran.setCounterPartyAccountName("");
                }
                if (contents.length > 7) {
                    bobTran.setCounterPartyAccountNumber(contents[7]);
                } else {
                    bobTran.setCounterPartyAccountNumber("");
                }

                bobTrans.add(bobTran);

            }
        }

        return bobTrans;
    }

    public static void main(String[] args) {
        BOBPdfParser pdfParser = new BOBPdfParser();

        ResponseData<String> result = pdfParser.parseBOBPdfToJson("daId", "D:\\data\\file\\北京银行\\AOFC001003495970597.pdf");
        System.out.println(JsonUtils.convertObjectToJson(result));

    }

}
