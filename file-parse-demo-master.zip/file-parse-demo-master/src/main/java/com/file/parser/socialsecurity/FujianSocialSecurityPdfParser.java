package com.file.parser.socialsecurity;


import com.file.bo.ResponseData;
import com.file.bo.socialsecurity.FujianIndividualRecordSheet;
import com.file.bo.socialsecurity.FujianInsuranceParticipation;
import com.file.constant.ErrorCode;
import com.file.parser.BasePdfParser;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import technology.tabula.*;
import technology.tabula.detectors.SpreadsheetDetectionAlgorithm;
import technology.tabula.extractors.SpreadsheetExtractionAlgorithm;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class FujianSocialSecurityPdfParser extends BasePdfParser {

    public ResponseData<String> parseFujianSocialSecurityPdfToJson(String daId, String filePath) {
        log.info("parseFujianSocialSecurityPdfToJson started, daId:{}", daId);
        String json = null;

        try {
            if (filePath.contains("cbzm")) {
                FujianInsuranceParticipation fujianInsuranceParticipation = parseFujianInsuranceParticipation(filePath);
                json = JsonUtils.convertObjectToJson(fujianInsuranceParticipation);
            } else if (filePath.contains("qyd")) {//NOSONAR
                FujianIndividualRecordSheet fujianIndividualRecordSheet = parseFujianIndividualRecordSheet(filePath);
                json = JsonUtils.convertObjectToJson(fujianIndividualRecordSheet);//NOSONAR
            } else {
                log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseFujianSocialSecurityPdfToJson failed, new type not supported");
                return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
            }
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseFujianSocialSecurityPdfToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseFujianSocialSecurityPdfToJson completed, daId:{}", daId);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private FujianInsuranceParticipation parseFujianInsuranceParticipation(String filePath) {
        FujianInsuranceParticipation fujianInsuranceParticipation = parseFujianInsuranceParticipationHeader(filePath);
        List<List<String>> rowList = parseFileToRowList(filePath);
        parseListToBO(rowList, fujianInsuranceParticipation);
        return fujianInsuranceParticipation;
    }

    private FujianInsuranceParticipation parseFujianInsuranceParticipationHeader(String filePath) {
        FujianInsuranceParticipation fujianInsuranceParticipation = new FujianInsuranceParticipation();
        String pdfText = getPdfTextByStripper2(filePath)
                .replace(System.getProperty("line.separator", "\n"), StringUtils.EMPTY);

        String personalId = pdfText.substring(pdfText.lastIndexOf("个人编号：") + 5, pdfText.lastIndexOf("身份证号：")).trim();
        String idNo = pdfText.substring(pdfText.lastIndexOf("身份证号：") + 5, pdfText.lastIndexOf("姓名：")).trim();
        String name = pdfText.substring(pdfText.lastIndexOf("姓名：") + 3, pdfText.lastIndexOf("打印区间：")).trim();
        String notes = pdfText.substring(pdfText.lastIndexOf("注：") + 2, pdfText.lastIndexOf("经办人：")).trim();
        String operator = pdfText.substring(pdfText.lastIndexOf("经办人：") + 4, pdfText.lastIndexOf("打印机构：")).trim();
        String printMechanism = pdfText.substring(pdfText.lastIndexOf("打印机构：") + 5, pdfText.lastIndexOf("打印日期：")).trim();
        String printTime = pdfText.substring(pdfText.lastIndexOf("打印日期：") + 5, pdfText.lastIndexOf("第")).trim();
        fujianInsuranceParticipation.setPersonalId(personalId);
        fujianInsuranceParticipation.setIdNo(idNo);
        fujianInsuranceParticipation.setName(name);
        fujianInsuranceParticipation.setNotes(notes);
        fujianInsuranceParticipation.setOperator(operator);
        fujianInsuranceParticipation.setPrintMechanism(printMechanism);
        fujianInsuranceParticipation.setPrintTime(printTime);

        return  fujianInsuranceParticipation;
    }

    private FujianIndividualRecordSheet parseFujianIndividualRecordSheet(String filePath) { //NOSONAR
        FujianIndividualRecordSheet fujianIndividualRecordSheet = new FujianIndividualRecordSheet();
        return fujianIndividualRecordSheet;
    }

    private void parseListToBO(List<List<String>> rowList, FujianInsuranceParticipation fujianInsuranceParticipation) {
        List<FujianInsuranceParticipation.PaymentStatus> paymentStatusList = new ArrayList<>();

        for (List<String> cellList : rowList) {
            if (StringUtils.equals(cellList.get(0), "序号")) {
                continue;
            }
            FujianInsuranceParticipation.PaymentStatus paymentStatus = new FujianInsuranceParticipation.PaymentStatus();
            paymentStatus.setSerialNumber(cellList.get(0));
            paymentStatus.setInsuranceAgencyInTheInsuredArea(cellList.get(1));
            paymentStatus.setUnitNumber(cellList.get(2));
            paymentStatus.setUnitName(cellList.get(3));
            paymentStatus.setAccountEstablishmentYearMonth(cellList.get(4));
            paymentStatus.setPaymentCorrespondsToTheStartToEndPeriod(cellList.get(5));
            paymentStatus.setMonthNumber(cellList.get(6));
            paymentStatus.setPaymentBase(cellList.get(7));
            paymentStatus.setPaymentNature(cellList.get(8));
            paymentStatusList.add(paymentStatus);
        }

        fujianInsuranceParticipation.setPaymentStatusList(paymentStatusList);
    }

    private List<List<String>> parseFileToRowList(String filePath) {
        // 1. 读取文件
        File pdf = new File(filePath);

        //页面所有table的记录，每一个元素代表下面一条记录cellList
        List<List<String>> rowList = new ArrayList<>();

        // 2. pdfbox读取PDDocument
        try (PDDocument pdfDocument = PDDocument.load(pdf)) {
            // 3. tabula新建ObjectExtractor和NurminenDetectionAlgorithm，同时准备接收表格Rectangle的结构
            ObjectExtractor objectExtractor = new ObjectExtractor(pdfDocument);
            SpreadsheetDetectionAlgorithm detectionAlgorithm = new SpreadsheetDetectionAlgorithm();
            Map<Integer, List<Rectangle>> pageNumber2RectangleListMap = new HashMap<>();//key为页的序号， value为对应的Rectangle的list

            // 4. 获取每页的PageIterator
            PageIterator pageIterator = objectExtractor.extract();

            // 5. 解析每页的Rectangle
            // 如果单页pdf中有多个Rectangle，则解析出来的List<Rectangle>会有多个对象
            while (pageIterator.hasNext()) {
                Page page = pageIterator.next();
                List<Rectangle> rectangleList = detectionAlgorithm.detect(page);
                if (rectangleList.size() > 0) {
                    pageNumber2RectangleListMap.put(page.getPageNumber(), rectangleList);
                }
            }

            // 6.通过table位置获取表格具体内容
            SpreadsheetExtractionAlgorithm extractionAlgorithm = new SpreadsheetExtractionAlgorithm();

            // 如果单页pdf中有多个表格，则解析出来的List<Rectangle>会有多个对象
            for (Map.Entry<Integer, List<Rectangle>> entry : pageNumber2RectangleListMap.entrySet()) {
                Page page = objectExtractor.extract(entry.getKey());
                Rectangle rectangle = null;

                List<Rectangle> rectangleList = entry.getValue();
                for (Rectangle r : rectangleList) {
                    double rectangleHeight = r.getHeight();
                    if (Double.compare(rectangleHeight, 0) > 0) {
                        rectangle = r;
                        break;
                    }
                }
                if (rectangle == null) {
                    throw new RuntimeException("rectangle is null.");
                }

                if (entry.getKey() > 1) {
                    rectangle.setTop(rectangle.getTop());
                }
                rectangle.setBottom(rectangle.getBottom() + 300);
                Page area = page.getArea(rectangle);

                // 如果每页有多个表格，解析每一个table
                List<Table> tableList = extractionAlgorithm.extract(area);
                for (Table table : tableList) {
                    for (int i = 0; i < table.getRowCount(); i++) {
                        List<String> cellList = new ArrayList<>();//一条记录，每个单元格占一个元素
                        for (int j = 0; j < table.getColCount(); j++) {
                            cellList.add(table.getCell(i, j).getText(false));
                        }
                        rowList.add(cellList);
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }

        return rowList;
    }

    public static void main(String[] args) {
        String filePath = "D:\\data\\file\\socialsecurity\\福建\\20240306\\app-gjzwfw-dzsb_cbzm.pdf";
        FujianSocialSecurityPdfParser fujianSocialSecurityPdfParser = new FujianSocialSecurityPdfParser();
        String json = fujianSocialSecurityPdfParser.parseFujianSocialSecurityPdfToJson("", filePath).getData();
        System.out.println(json);
    }

}
