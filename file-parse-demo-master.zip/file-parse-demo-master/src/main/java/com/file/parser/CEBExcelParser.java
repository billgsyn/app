package com.file.parser.traprange;

import com.file.bo.CEB;
import com.file.bo.CEBTran;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 光大银行PC模式流水解析
 * @author anyspa
 */

@Slf4j
public class CEBExcelParser {
    public ResponseData<String> parseCEBExcelToJson(String daId, String filePath) {
        log.info("parseCEBExcelToJson started, daId:{}", daId);
        String json = null;

        try {
            CEB ceb = parseCEBExcel(filePath);
            json = JsonUtils.convertObjectToJson(ceb);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseCEBExcelToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseCEBExcelToJson completed, daId:{}", daId);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private CEB parseCEBExcel(String filePath) {
        CEB ceb = new CEB();
        try (FileInputStream fis = new FileInputStream(new File(filePath));
             HSSFWorkbook workbook = new HSSFWorkbook(fis)) {

            HSSFSheet sheet = workbook.getSheetAt(0);
            List<CEBTran> cebTrans = new ArrayList<>();
            for (int i = 0; i < sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (i == 3) {
                    ceb.setStartDate(row.getCell(1).getStringCellValue());
                    ceb.setEndDate(row.getCell(3).getStringCellValue());
                    ceb.setDownloadPrintDate(row.getCell(5).getStringCellValue());
                }
                if (i == 4) {
                    ceb.setAccountNumber(row.getCell(1).getStringCellValue());
                    ceb.setAccountType(row.getCell(3).getStringCellValue());
                }
                if (i == 5) {
                    ceb.setAccountName(row.getCell(1).getStringCellValue());
                    ceb.setCurrency(row.getCell(3).getStringCellValue());
                    ceb.setCashExchange(row.getCell(3).getStringCellValue());
                }
                if (i == 6) {
                    ceb.setExpenseCount(row.getCell(1).getStringCellValue());
                    ceb.setExpenseAmount(row.getCell(3).getStringCellValue());
                }
                if (i == 7) {
                    ceb.setIncomeCount(row.getCell(1).getStringCellValue());
                    ceb.setIncomeAmount(row.getCell(3).getStringCellValue());
                }

                if (i >= 10) {
                    if (StringUtils.isBlank(row.getCell(0).getStringCellValue())) {
                        break;
                    }
                    CEBTran cebTran = new CEBTran();
                    cebTran.setTransactionDate(row.getCell(0).getStringCellValue());
                    cebTran.setExpenseAmount(this.getStringCellValue(row.getCell(1)));
                    cebTran.setIncomeAmount(this.getStringCellValue(row.getCell(2)));
                    cebTran.setAccountBalance(this.getStringCellValue(row.getCell(3)));
                    cebTran.setCounterPartyAccountNumber(row.getCell(4).getStringCellValue());
                    cebTran.setCounterPartyAccountName(row.getCell(5).getStringCellValue());
                    cebTran.setSummary(row.getCell(6).getStringCellValue());
                    cebTrans.add(cebTran);
                }
            }
            ceb.setCebTrans(cebTrans);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return ceb;
    }

    private String getStringCellValue(Cell cell) {
        String cellStr;
        if (Objects.equals(cell.getCellType(), CellType.NUMERIC)) {
            cellStr = String.valueOf(cell.getNumericCellValue());
        } else {
            cellStr = cell.getStringCellValue();
        }
        return cellStr;
    }

    public static void main(String[] args) {
        String pdfFilePath = "D:\\data\\files\\CEB\\光大银行流水.xls";

        CEBExcelParser cebExcelParser = new CEBExcelParser();
        ResponseData<String> responseData = cebExcelParser.parseCEBExcelToJson("dd", pdfFilePath);
        System.out.println(responseData.getData());
    }

}
