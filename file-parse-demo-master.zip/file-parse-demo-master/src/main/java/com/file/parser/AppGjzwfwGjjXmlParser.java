package com.file.parser;

import com.file.bo.AppGjzwfwGjj;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.util.List;

/**
 * 国家政务服务平台-住房公积金 解析
 *
 * @author anyspa
 */

@Slf4j
public class AppGjzwfwGjjXmlParser {

    public ResponseData<String> parseAppGjzwfwGjjXmlToJson(String daId, String filePath) {
        log.info("parseAppGjzwfwGjjXmlToJson started, daId:{}", daId);
        String json;

        try {
            AppGjzwfwGjj appGjzwfwGjj = parseAppGjzwfwGjjXml(filePath);
            json = JsonUtils.convertObjectToJson(appGjzwfwGjj);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseAppGjzwfwGjjXmlToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseAppGjzwfwGjjXmlToJson completed, daId:{}, json:{}", daId, json);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private AppGjzwfwGjj parseAppGjzwfwGjjXml(String filePath) throws DocumentException {
        AppGjzwfwGjj appGjzwfwGjj = new AppGjzwfwGjj();
        SAXReader reader = new SAXReader();
        Document document = reader.read(new File(filePath));

        AppGjzwfwGjj.PersonalInfo personalInfo = new AppGjzwfwGjj.PersonalInfo();
        AppGjzwfwGjj.CenterInfo centerInfo = new AppGjzwfwGjj.CenterInfo();
        AppGjzwfwGjj.DepositInfo depositInfo = new AppGjzwfwGjj.DepositInfo();

        if (hasGjjData(document)) {
            personalInfo.setName(getAttributeOfTextValue(document, "姓名:"));
            personalInfo.setPhoneNumber(getAttributeOfTextValue(document, "手机号:"));
            personalInfo.setPersonalAccount(getAttributeOfTextValue(document, "个人账号:"));
            personalInfo.setPersonalAccountStatus(getAttributeOfTextValue(document, "个人账户状态:"));
            personalInfo.setPersonalAccountBalance(getAttributeOfTextValue(document, "个人账户余额:"));
            appGjzwfwGjj.setPersonalInfo(personalInfo);

            centerInfo.setCenterNumber(getAttributeOfTextValue(document, "中心编号:"));
            centerInfo.setCenterName(getAttributeOfTextValue(document, "中心名称:"));
            centerInfo.setCompanyName(getAttributeOfTextValue(document, "单位名称:"));
            appGjzwfwGjj.setCenterInfo(centerInfo);

            depositInfo.setPersonalDepositRatio(getAttributeOfTextValue(document, "个人缴存比例:"));
            depositInfo.setCompanyDepositRatio(getAttributeOfTextValue(document, "单位缴存比例:"));
            depositInfo.setPersonalDepositBase(getAttributeOfTextValue(document, "个人缴存基数:"));
            depositInfo.setPersonalMonthlyDeposit(getAttributeOfTextValue(document, "个人月缴存额:"));
            depositInfo.setCompanyMonthlyDeposit(getAttributeOfTextValue(document, "单位月缴存额:"));
            appGjzwfwGjj.setDepositInfo(depositInfo);

            return appGjzwfwGjj;
        }

        personalInfo.setName(StringUtils.EMPTY);
        personalInfo.setPhoneNumber(StringUtils.EMPTY);
        personalInfo.setPersonalAccount(StringUtils.EMPTY);
        personalInfo.setPersonalAccountStatus(StringUtils.EMPTY);
        personalInfo.setPersonalAccountBalance(StringUtils.EMPTY);
        appGjzwfwGjj.setPersonalInfo(personalInfo);

        centerInfo.setCenterNumber(StringUtils.EMPTY);
        centerInfo.setCenterName(StringUtils.EMPTY);
        centerInfo.setCompanyName(StringUtils.EMPTY);
        appGjzwfwGjj.setCenterInfo(centerInfo);

        depositInfo.setPersonalDepositRatio( "暂无公积金");
        depositInfo.setCompanyDepositRatio( "暂无公积金");
        depositInfo.setPersonalDepositBase("暂无公积金");
        depositInfo.setPersonalMonthlyDeposit("暂无公积金");
        depositInfo.setCompanyMonthlyDeposit("暂无公积金");
        appGjzwfwGjj.setDepositInfo(depositInfo);

        return appGjzwfwGjj;
    }

    private boolean hasGjjData(Document document) {
        Element element = (Element) document.selectSingleNode("//android.widget.TextView[@text='暂无公积金' or @text='暂无公积金贷款']");
        return element == null;
    }

    public boolean hasGjjData(String filePath) {
        boolean hasGjjData = true;

        try {
            SAXReader reader = new SAXReader();
            Document document = reader.read(new File(filePath));
            Element element = (Element) document.selectSingleNode("//android.widget.TextView[@text='暂无公积金' or @text='暂无公积金贷款']");
            if (element != null) {
                hasGjjData = false;
            }
        } catch (DocumentException e) {
            throw new RuntimeException(e);
        }

        return hasGjjData;
    }

    private String getAttributeOfTextValue(Document document, String textValue) {
        Element element = (Element) document.selectSingleNode("//android.widget.TextView[@text='" + textValue + "']");
        // 个人缴存比例 单位缴存比例 个人缴存基数 单位月缴存额 单位月缴存额 出现空的case
        if (element == null) {
            if (StringUtils.equalsAny(textValue,"个人缴存比例:", "单位缴存比例:", "个人缴存基数:", "个人月缴存额:", "单位月缴存额:")) {
                return "";
            } else {
                log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "appGjzwfwGjj xml [" + textValue + "] not found");
                throw new RuntimeException();
            }
        }
        List<Element> elements = element.getParent().elements();
        if (elements.size() >= 2) {
            return elements.get(1).attributeValue("text");
        }
        return "";
    }

    public static void main(String[] args) {
        AppGjzwfwGjjXmlParser appGjzwfwGjjXmlParser = new AppGjzwfwGjjXmlParser();

        boolean hasGjjData = appGjzwfwGjjXmlParser.hasGjjData("D:\\data\\file\\appGjzwfwGjj\\de1tuknz1539061385823240192_5abc806908a5ebdedab5f535cffa3a7a_fund_zm_1.xml");
        System.out.println(hasGjjData);
    }
}
