package com.file.parser.socialsecurity;

import com.file.bo.ResponseData;
import com.file.bo.socialsecurity.ZhejiangIndividualRecordSheet;
import com.file.bo.socialsecurity.ZhejiangInsuranceParticipation;
import com.file.constant.ErrorCode;
import com.file.parser.BasePdfParser;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import technology.tabula.*;
import technology.tabula.detectors.SpreadsheetDetectionAlgorithm;
import technology.tabula.extractors.SpreadsheetExtractionAlgorithm;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class ZhejiangSocialSecurityPdfParser extends BasePdfParser {

    public ResponseData<String> parseZhejiangSocialSecurityPdfToJson(String daId, String filePath) {
        log.info("parseZhejiangSocialSecurityPdfToJson started, daId:{}", daId);
        String json = null;

        try {
            if (filePath.contains("cbzm")) {
                ZhejiangInsuranceParticipation zhejiangInsuranceParticipation = parseZhejiangInsuranceParticipation(filePath);
                json = JsonUtils.convertObjectToJson(zhejiangInsuranceParticipation);
            } else if (filePath.contains("qyd")) {
                ZhejiangIndividualRecordSheet zhejiangIndividualRecordSheet = parseZhejiangIndividualRecordSheet(filePath);
                json = JsonUtils.convertObjectToJson(zhejiangIndividualRecordSheet);
            } else {
                log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseZhejiangSocialSecurityPdfToJson failed, new type not supported");
                return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
            }
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseZhejiangSocialSecurityPdfToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseZhejiangSocialSecurityPdfToJson completed, daId:{}", daId);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private ZhejiangInsuranceParticipation parseZhejiangInsuranceParticipation(String filePath) {
        ZhejiangInsuranceParticipation zhejiangInsuranceParticipation = new ZhejiangInsuranceParticipation();
        List<List<String>> rowList = parseFileToRowList(filePath);
        parseListToBO(rowList, zhejiangInsuranceParticipation);
        String pdfText = getPdfTextByStripper(filePath);
        String notes = pdfText.substring(pdfText.lastIndexOf("备注：") + 3, pdfText.lastIndexOf("（盖章）")).replace(System.getProperty("line.separator", "\n"), StringUtils.EMPTY).trim();
        String printTime = pdfText.substring(pdfText.lastIndexOf("打印时间：") + 5).trim();
        zhejiangInsuranceParticipation.setNotes(notes);
        zhejiangInsuranceParticipation.setPrintTime(printTime);
        return zhejiangInsuranceParticipation;
    }

    private void parseListToBO(List<List<String>> rowList, ZhejiangInsuranceParticipation zhejiangInsuranceParticipation) {
        ZhejiangInsuranceParticipation.ParticipationInSocialInsurance participationInSocialInsurance = new ZhejiangInsuranceParticipation.ParticipationInSocialInsurance();
        zhejiangInsuranceParticipation.setParticipationInSocialInsurance(participationInSocialInsurance);
        List<ZhejiangInsuranceParticipation.PaymentStatus> paymentStatusList = new ArrayList<>();
        zhejiangInsuranceParticipation.setPaymentStatusList(paymentStatusList);

//        for (List<String> cellList : rowList) {
//            System.out.println(cellList);
//        }

        String sectionName = "";

        //年|月|养老参保地|单位编号
        //已有case
        boolean hasFourColumnCase = true;
        //新case 年|月|单位编号

        for (int i = 0; i < rowList.size(); i++) {
            List<String> cellList = rowList.get(i);
            if (StringUtils.equals(cellList.get(0), "姓名")) {
                sectionName = "姓名";
            } else if (StringUtils.equals(cellList.get(0), "参加社会保险基本情况")) {
                continue;
            } else if (StringUtils.equals(cellList.get(0), "险  种")) {
                sectionName = "险种";
            } else if (StringUtils.equals(cellList.get(0), "参保状态")) {
                sectionName = "参保状态";
            } else if (StringUtils.equals(cellList.get(0), "参保单位")) {
                sectionName = "参保单位";
            } else if (StringUtils.contains(cellList.get(0), "缴费情况")) {
                sectionName = "缴费情况";
                continue;
            } else if (StringUtils.equals(cellList.get(0), "年") || StringUtils.equals(cellList.get(3), "缴费基数")) {
                if (StringUtils.equals(cellList.get(2), "单位编号")) {
                    hasFourColumnCase = false;
                }
                continue;
            }

            switch (sectionName) {//NOSONAR
                case "姓名":
                    zhejiangInsuranceParticipation.setName(cellList.get(1));
                    zhejiangInsuranceParticipation.setSocialSecurityNumber(cellList.get(3));
                    if (StringUtils.equals(cellList.get(4), "性别")) {
                        zhejiangInsuranceParticipation.setGender(cellList.get(5));
                    } else if (cellList.size() > 8 && StringUtils.equals(cellList.get(8), "性别")) {
                        zhejiangInsuranceParticipation.setGender(cellList.get(9));
                    }

                    if (StringUtils.equals(cellList.get(4), "证件类型")) {
                        zhejiangInsuranceParticipation.setIdType(cellList.get(5));
                    }

                    if (StringUtils.equals(cellList.get(6), "证件号码")) {
                        zhejiangInsuranceParticipation.setIdNo(cellList.get(7));
                    }

                    break;
                case "险种":
                    List<String> insuranceTypeList = new ArrayList<>();
                    insuranceTypeList.add(cellList.get(1));
                    insuranceTypeList.add(cellList.get(2));
                    insuranceTypeList.add(cellList.get(3));
                    zhejiangInsuranceParticipation.getParticipationInSocialInsurance().setInsuranceTypeList(insuranceTypeList);
                    break;
                case "参保状态":
                    List<String> insuranceStatusList = new ArrayList<>();
                    insuranceStatusList.add(cellList.get(1));
                    insuranceStatusList.add(cellList.get(2));
                    insuranceStatusList.add(cellList.get(3));
                    zhejiangInsuranceParticipation.getParticipationInSocialInsurance().setInsuranceStatusList(insuranceStatusList);
                    break;
                case "参保单位":
                    zhejiangInsuranceParticipation.getParticipationInSocialInsurance().setInsuredUnit(cellList.get(1));
                    break;
                case "缴费情况":
                    if (StringUtils.isBlank(cellList.get(0)) || !cellList.get(0).matches("\\d{4}")) {
                        continue;
                    }

                    ZhejiangInsuranceParticipation.PaymentStatus paymentStatus = new ZhejiangInsuranceParticipation.PaymentStatus();
                    paymentStatus.setYear(cellList.get(0));
                    paymentStatus.setMonth(cellList.get(1));
                    if (hasFourColumnCase) {
                        paymentStatus.setRetirementInsurancePlace(cellList.get(2));
                        paymentStatus.setUnitNumber(cellList.get(3));

                        ZhejiangInsuranceParticipation.EndowmentInsurance endowmentInsurance = new ZhejiangInsuranceParticipation.EndowmentInsurance();
                        endowmentInsurance.setPaymentBase(cellList.get(4));
                        endowmentInsurance.setIndividualPayment(cellList.get(5));
                        endowmentInsurance.setPaymentStatus(cellList.get(6));
                        paymentStatus.setEndowmentInsurance(endowmentInsurance);

                        ZhejiangInsuranceParticipation.UnemploymentInsurance unemploymentInsurance = new ZhejiangInsuranceParticipation.UnemploymentInsurance();
                        unemploymentInsurance.setPaymentBase(cellList.get(7));
                        unemploymentInsurance.setIndividualPayment(cellList.get(8));
                        paymentStatus.setUnemploymentInsurance(unemploymentInsurance);
                        paymentStatus.setNotes(cellList.get(9));
                    } else {
                        paymentStatus.setUnitNumber(cellList.get(2));
                        ZhejiangInsuranceParticipation.EndowmentInsurance endowmentInsurance = new ZhejiangInsuranceParticipation.EndowmentInsurance();
                        endowmentInsurance.setInsurancePlace(cellList.get(3));
                        endowmentInsurance.setPaymentBase(cellList.get(4));
                        endowmentInsurance.setIndividualPayment(cellList.get(5));
                        endowmentInsurance.setPaymentStatus(cellList.get(6));
                        paymentStatus.setEndowmentInsurance(endowmentInsurance);

                        ZhejiangInsuranceParticipation.UnemploymentInsurance unemploymentInsurance = new ZhejiangInsuranceParticipation.UnemploymentInsurance();
                        unemploymentInsurance.setInsurancePlace(cellList.get(7));
                        unemploymentInsurance.setPaymentBase(cellList.get(8));
                        unemploymentInsurance.setIndividualPayment(cellList.get(9));
                        unemploymentInsurance.setPaymentStatus(cellList.get(10));
                        paymentStatus.setUnemploymentInsurance(unemploymentInsurance);
                        paymentStatus.setNotes(cellList.get(11));
                    }


                    zhejiangInsuranceParticipation.getPaymentStatusList().add(paymentStatus);
                    break;
            }
        }
    }


    private List<List<String>> parseFileToRowList(String filePath) {
        // 1. 读取文件
        File pdf = new File(filePath);

        //页面所有table的记录，每一个元素代表下面一条记录cellList
        List<List<String>> rowList = new ArrayList<>();

        // 2. pdfbox读取PDDocument
        try (PDDocument pdfDocument = PDDocument.load(pdf)) {
            // 3. tabula新建ObjectExtractor和NurminenDetectionAlgorithm，同时准备接收表格Rectangle的结构
            ObjectExtractor objectExtractor = new ObjectExtractor(pdfDocument);
            SpreadsheetDetectionAlgorithm detectionAlgorithm = new SpreadsheetDetectionAlgorithm();
            Map<Integer, List<Rectangle>> pageNumber2RectangleListMap = new HashMap<>();//key为页的序号， value为对应的Rectangle的list

            // 4. 获取每页的PageIterator
            PageIterator pageIterator = objectExtractor.extract();

            // 5. 解析每页的Rectangle
            // 如果单页pdf中有多个Rectangle，则解析出来的List<Rectangle>会有多个对象
            while (pageIterator.hasNext()) {
                Page page = pageIterator.next();
                List<Rectangle> rectangleList = detectionAlgorithm.detect(page);
                if (!rectangleList.isEmpty()) {
                    pageNumber2RectangleListMap.put(page.getPageNumber(), rectangleList);
                }
            }

            // 6.通过table位置获取表格具体内容
            SpreadsheetExtractionAlgorithm extractionAlgorithm = new SpreadsheetExtractionAlgorithm();

            // 如果单页pdf中有多个表格，则解析出来的List<Rectangle>会有多个对象
            for (Map.Entry<Integer, List<Rectangle>> entry : pageNumber2RectangleListMap.entrySet()) {
                Page page = objectExtractor.extract(entry.getKey());
                for (int k = 0; k < entry.getValue().size(); k++) {
                    Rectangle rectangle = entry.getValue().get(k);
                    rectangle.setBottom(rectangle.getBottom() + 5);
                    Page area = page.getArea(rectangle);

                    // 如果每页有多个表格，解析每一个table
                    List<Table> tableList = extractionAlgorithm.extract(area);
                    for (Table table : tableList) {
                        for (int i = 0; i < table.getRowCount(); i++) {
                            List<String> cellList = new ArrayList<>();//一条记录，每个单元格占一个元素
                            for (int j = 0; j < table.getColCount(); j++) {
                                cellList.add(table.getCell(i, j).getText(false));
                            }
                            rowList.add(cellList);
                        }
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }

        return rowList;
    }

    private ZhejiangIndividualRecordSheet parseZhejiangIndividualRecordSheet(String filePath) {//NOSONAR
        ZhejiangIndividualRecordSheet zhejiangIndividualRecordSheet = new ZhejiangIndividualRecordSheet();
        List<List<String>> rowList = parseFileToRowList(filePath);
        parseListToBO(rowList, zhejiangIndividualRecordSheet);
        return zhejiangIndividualRecordSheet;
    }

    private void parseListToBO(List<List<String>> rowList, ZhejiangIndividualRecordSheet zhejiangIndividualRecordSheet) { //NOSONAR
        ZhejiangIndividualRecordSheet.BasicEndowmentInsurance basicEndowmentInsurance
                = new ZhejiangIndividualRecordSheet.BasicEndowmentInsurance();
        ZhejiangIndividualRecordSheet.InstitutionalEndowmentInsurance institutionalEndowmentInsurance
                = new ZhejiangIndividualRecordSheet.InstitutionalEndowmentInsurance();
        ZhejiangIndividualRecordSheet.UrbanAndRuralResidentsEndowmentInsurance urbanAndRuralResidentsEndowmentInsurance
                = new ZhejiangIndividualRecordSheet.UrbanAndRuralResidentsEndowmentInsurance();
        ZhejiangIndividualRecordSheet.UnemploymentInsurance unemploymentInsurance
                = new ZhejiangIndividualRecordSheet.UnemploymentInsurance();
        ZhejiangIndividualRecordSheet.EmploymentInjuryInsurance employmentInjuryInsurance
                = new ZhejiangIndividualRecordSheet.EmploymentInjuryInsurance();
        // 基本养老保险
        List<ZhejiangIndividualRecordSheet.BasicEndowmentPersonalPaymentInfo> basicEndowmentPersonalPaymentInfoList = new ArrayList<>();
        List<ZhejiangIndividualRecordSheet.PensionPaymentInfo> basicEndowmentInsurancePensionPaymentInfoList = new ArrayList<>();
        // 机关失业养老保险
        List<ZhejiangIndividualRecordSheet.InstitutionalEndowmentPersonalPaymentInfo> institutionalPersonalPaymentInfoList = new ArrayList<>();
        List<ZhejiangIndividualRecordSheet.PensionPaymentInfo> institutionalPensionPaymentInfoList = new ArrayList<>();
        // 城乡居民保险
        List<ZhejiangIndividualRecordSheet.PersonalPaymentInfo> urbanAndRuralResidentsPersonalPaymentInfoList = new ArrayList<>();
        List<ZhejiangIndividualRecordSheet.PensionPaymentInformation> urbanAndRuralResidentsPensionPaymentInformationList = new ArrayList<>();

        String sectionName = "";

        for (int i = 0; i < rowList.size(); i++) {
            List<String> cellList = rowList.get(i);

            if (StringUtils.equals(cellList.get(0), "在职参保人员基础信息")) {
                if (StringUtils.isBlank(sectionName)) {
                    sectionName = "基本养老保险-在职参保人员基础信息";
                } else {
                    sectionName = "机关事业养老保险-在职参保人员基础信息";
                }
                continue;
            } else if (StringUtils.equals(cellList.get(0), "在职年度个人账户")) {
                sectionName = "基本养老保险-在职年度个人账户";
                continue;
            } else if (StringUtils.contains(cellList.get(0), "个人缴费信息")) {
                if (StringUtils.equals(sectionName, "基本养老保险-在职年度个人账户")) {
                    sectionName = "基本养老保险-个人缴费信息";
                } else if (StringUtils.equals(sectionName, "机关事业养老保险-职业年金个人账户缴纳额")) {
                    sectionName = "机关事业养老保险-个人缴费信息";
                } else if (StringUtils.equals(sectionName, "城乡居民养老保险-养老金待遇人员基础信息")) {
                    sectionName = "城乡居民养老保险-个人缴费信息";
                }
                continue;
            } else if (StringUtils.equals(cellList.get(0), "养老金待遇人员基础信息")) {
                if (StringUtils.equals(sectionName, "基本养老保险-个人缴费信息")) {
                    sectionName = "基本养老保险-养老金待遇人员基础信息";
                } else if (StringUtils.equals(sectionName, "机关事业养老保险-个人缴费信息")) {
                    sectionName = "机关事业养老保险-养老金待遇人员基础信息";
                } else if (StringUtils.equals(sectionName, "城乡居民养老保险-参保缴费人员基础信息")) {
                    sectionName = "城乡居民养老保险-养老金待遇人员基础信息";
                }
                continue;
            } else if (StringUtils.contains(cellList.get(0), "养老金待遇发放信息")) {
                if (StringUtils.equals(sectionName, "基本养老保险-养老金待遇人员基础信息")) {
                    sectionName = "基本养老保险-养老金待遇发放信息";
                } else if (StringUtils.equals(sectionName, "机关事业养老保险-养老金待遇人员基础信息")) {
                    sectionName = "机关事业养老保险-养老金待遇发放信息";
                } else if (StringUtils.equals(sectionName, "城乡居民养老保险-个人缴费信息")) {
                    sectionName = "城乡居民养老保险-养老金待遇发放信息";
                }
                continue;
            } else if (StringUtils.equals(cellList.get(0), "基本养老金个人账户缴纳额")) {
                sectionName = "机关事业养老保险-基本养老金个人账户缴纳额";
                continue;
            } else if (StringUtils.equals(cellList.get(0), "职业年金个人账户缴纳额")) {
                sectionName = "机关事业养老保险-职业年金个人账户缴纳额";
                continue;
            } else if (StringUtils.equals(cellList.get(0), "参保缴费人员基础信息")) {
                sectionName = "城乡居民养老保险-参保缴费人员基础信息";
                continue;
            } else if (StringUtils.equals(cellList.get(0), "参保人员基础信息")) {
                if (StringUtils.equals(sectionName, "城乡居民养老保险-养老金待遇发放信息")) {
                    sectionName = "失业保险-参保人员基础信息";
                } else if (StringUtils.equals(sectionName, "失业保险-参保人员基础信息")) {
                    sectionName = "工伤保险-参保人员基础信息";
                }
                continue;
            } else if (StringUtils.equalsAny(cellList.get(0), "应征年月", "缴费年月", "发放年月", "缴费年度")) {
                continue;
            }

            switch (sectionName) {//NOSONAR
                case "基本养老保险-在职参保人员基础信息":
                    ZhejiangIndividualRecordSheet.InsuredPersonBaseInfo basicEndowmentInsuranceInsuredPersonBaseInfo
                            = new ZhejiangIndividualRecordSheet.InsuredPersonBaseInfo();
                    basicEndowmentInsurance.setInsuredPersonBaseInfo(basicEndowmentInsuranceInsuredPersonBaseInfo);
                    if (StringUtils.equals(cellList.get(0), "暂无数据")) {
                        break;
                    }
                    basicEndowmentInsuranceInsuredPersonBaseInfo.setSocialSecurityNumber(cellList.get(1));
                    basicEndowmentInsuranceInsuredPersonBaseInfo.setName(cellList.get(3));
                    basicEndowmentInsuranceInsuredPersonBaseInfo.setInsuranceStatus(rowList.get(i + 1).get(1));
                    basicEndowmentInsuranceInsuredPersonBaseInfo.setUnitName(rowList.get(i + 1).get(3));

                    i++; //NOSONAR
                    break;
                case "基本养老保险-在职年度个人账户":
                    ZhejiangIndividualRecordSheet.PersonalAccountOfOnServerYear personalAccountOfOnServerYear
                            = new ZhejiangIndividualRecordSheet.PersonalAccountOfOnServerYear();
                    basicEndowmentInsurance.setPersonalAccountOfOnServerYear(personalAccountOfOnServerYear);
                    if (StringUtils.equals(cellList.get(0), "暂无数据")) {
                        break;
                    }
                    personalAccountOfOnServerYear.setYear(cellList.get(1));
                    personalAccountOfOnServerYear.setAccumulatedSavingsInPersonalAccountsLastYear(cellList.get(3));
                    personalAccountOfOnServerYear.setCurrentYearActualPaymentMonths(rowList.get(i + 1).get(1));
                    personalAccountOfOnServerYear.setCurrentAccountAmount(rowList.get(i + 1).get(3));
                    personalAccountOfOnServerYear.setCurrentPrincipalInterest(rowList.get(i + 2).get(1));
                    personalAccountOfOnServerYear.setInterestAccruedUntilLastYear(rowList.get(i + 2).get(3));
                    personalAccountOfOnServerYear.setAccumulatedSavingsInAccountsThisYear(rowList.get(i + 3).get(1));
                    personalAccountOfOnServerYear.setActualPaymentMonthsUntilThisYear(rowList.get(i + 3).get(3));
                    i += 3; //NOSONAR
                    break;
                case "基本养老保险-个人缴费信息":
                    if (!StringUtils.equals(cellList.get(0), "暂无数据") && cellList.size() > 5) {
                        ZhejiangIndividualRecordSheet.BasicEndowmentPersonalPaymentInfo basicEndowmentPersonalPaymentInfo
                                = new ZhejiangIndividualRecordSheet.BasicEndowmentPersonalPaymentInfo();
                        basicEndowmentPersonalPaymentInfoList.add(basicEndowmentPersonalPaymentInfo);
                        basicEndowmentPersonalPaymentInfo.setRecruitmentYear(cellList.get(0));
                        basicEndowmentPersonalPaymentInfo.setPayer(cellList.get(1));
                        basicEndowmentPersonalPaymentInfo.setPaymentType(cellList.get(2));
                        basicEndowmentPersonalPaymentInfo.setPaymentBase(cellList.get(3));
                        basicEndowmentPersonalPaymentInfo.setPersonalPaymentAmount(cellList.get(4));
                        basicEndowmentPersonalPaymentInfo.setArrivalStatus(cellList.get(5));
                    }
                    break;
                case "基本养老保险-养老金待遇人员基础信息":
                    if (StringUtils.equals(cellList.get(0), "社会保障号")) {
                        break;
                    }
                    ZhejiangIndividualRecordSheet.PensionBenefitsPersonBaseInfo pensionBenefitsPersonBaseInfo
                            = new ZhejiangIndividualRecordSheet.PensionBenefitsPersonBaseInfo();
                    if (!StringUtils.equals(cellList.get(0), "暂无数据")) {
                        pensionBenefitsPersonBaseInfo.setSocialSecurityNumber(cellList.get(0));
                        pensionBenefitsPersonBaseInfo.setName(cellList.get(1));
                        pensionBenefitsPersonBaseInfo.setPaymentStatus(cellList.get(2));
                    } else {
                        pensionBenefitsPersonBaseInfo.setSocialSecurityNumber("");
                        pensionBenefitsPersonBaseInfo.setName("");
                        pensionBenefitsPersonBaseInfo.setPaymentStatus("");
                    }
                    basicEndowmentInsurance.setPensionBenefitsPersonBaseInfo(pensionBenefitsPersonBaseInfo);
                    break;
                case "基本养老保险-养老金待遇发放信息":
                    if (StringUtils.equalsAny(cellList.get(0), "暂无数据", "发放时间")) {
                        continue;
                    }
                    ZhejiangIndividualRecordSheet.PensionPaymentInfo pensionPaymentInfo
                            = new ZhejiangIndividualRecordSheet.PensionPaymentInfo();
                    pensionPaymentInfo.setPaymentYear(cellList.get(0));
                    pensionPaymentInfo.setPaymentAmount(cellList.get(1));
                    basicEndowmentInsurancePensionPaymentInfoList.add(pensionPaymentInfo);

                    break;
                case "机关事业养老保险-在职参保人员基础信息":
                    institutionalEndowmentInsurance.setInsuredPersonBaseInfo(cellList.get(0));
                    break;
                case "机关事业养老保险-基本养老金个人账户缴纳额":
                    institutionalEndowmentInsurance.setPensionPersonalPaymentAmount(cellList.get(0));
                    break;
                case "机关事业养老保险-职业年金个人账户缴纳额":
                    institutionalEndowmentInsurance.setOccupationalAnnuityPersonalPaymentAmount(cellList.get(0));
                    break;
                case "机关事业养老保险-个人缴费信息":
                    if (!StringUtils.equals(cellList.get(0), "暂无数据")) {
                        ZhejiangIndividualRecordSheet.InstitutionalEndowmentPersonalPaymentInfo personalPaymentInfo
                                = new ZhejiangIndividualRecordSheet.InstitutionalEndowmentPersonalPaymentInfo();
                        personalPaymentInfo.setPaymentYear(cellList.get(0));
                        personalPaymentInfo.setPaymentBaseOfMonth(cellList.get(1));
                        personalPaymentInfo.setPersonalPaymentAmount(cellList.get(2));
                        personalPaymentInfo.setType(cellList.get(3));
                        personalPaymentInfo.setArrivalStatus(cellList.get(4));
                        institutionalPersonalPaymentInfoList.add(personalPaymentInfo);
                    }
                    break;
                case "机关事业养老保险-养老金待遇人员基础信息":
                    if (StringUtils.equals(cellList.get(0), "社会保障号")) {
                        break;
                    }
                    ZhejiangIndividualRecordSheet.PensionBenefitsPersonBaseInfo personBaseInfo
                            = new ZhejiangIndividualRecordSheet.PensionBenefitsPersonBaseInfo();
                    if (!StringUtils.equals(cellList.get(0), "暂无数据")) {
                        personBaseInfo.setSocialSecurityNumber(cellList.get(0));
                        personBaseInfo.setName(cellList.get(1));
                        personBaseInfo.setPaymentStatus(cellList.get(2));
                    } else {
                        personBaseInfo.setSocialSecurityNumber("");
                        personBaseInfo.setName("");
                        personBaseInfo.setPaymentStatus("");
                    }
                    institutionalEndowmentInsurance.setPensionBenefitsPersonBaseInfo(personBaseInfo);
                    break;
                case "机关事业养老保险-养老金待遇发放信息":
                    if (StringUtils.equalsAny(cellList.get(0), "暂无数据", "发放时间")) {
                        continue;
                    }
                    ZhejiangIndividualRecordSheet.PensionPaymentInfo pensionPaymentInfo1
                            = new ZhejiangIndividualRecordSheet.PensionPaymentInfo();
                    pensionPaymentInfo1.setPaymentYear(cellList.get(0));
                    pensionPaymentInfo1.setPaymentAmount(cellList.get(1));
                    institutionalPensionPaymentInfoList.add(pensionPaymentInfo1);

                    break;
                case "城乡居民养老保险-参保缴费人员基础信息":
                    urbanAndRuralResidentsEndowmentInsurance.setInsurancePayerBaseInfo(cellList.get(0));
                    break;
                case "城乡居民养老保险-养老金待遇人员基础信息":
                    urbanAndRuralResidentsEndowmentInsurance.setPensionerBaseInfo(cellList.get(0));
                    break;
                case "城乡居民养老保险-个人缴费信息":
                    if (!StringUtils.equals(cellList.get(0), "暂无数据")) {
                        ZhejiangIndividualRecordSheet.PersonalPaymentInfo personalPaymentInfo
                                = new ZhejiangIndividualRecordSheet.PersonalPaymentInfo();
                        personalPaymentInfo.setPaymentYear(cellList.get(0));
                        personalPaymentInfo.setPersonalPaymentAmount(cellList.get(1));
                        personalPaymentInfo.setArrivalStatus(cellList.get(2));
                        urbanAndRuralResidentsPersonalPaymentInfoList.add(personalPaymentInfo);
                    }
                    break;
                case "城乡居民养老保险-养老金待遇发放信息":
                    if (StringUtils.equalsAny(cellList.get(0), "暂无数据", "发放时间")) {
                        continue;
                    }
                    ZhejiangIndividualRecordSheet.PensionPaymentInformation pensionPaymentInformation
                            = new ZhejiangIndividualRecordSheet.PensionPaymentInformation();
                    pensionPaymentInformation.setPaymentYear(cellList.get(0));
                    pensionPaymentInformation.setPaymentAmount(cellList.get(1));
                    urbanAndRuralResidentsPensionPaymentInformationList.add(pensionPaymentInformation);
                    break;
                case "失业保险-参保人员基础信息":
                    ZhejiangIndividualRecordSheet.InsuredPersonBaseInfo unemploymentInsuranceInsuredPersonBaseInfo
                            = new ZhejiangIndividualRecordSheet.InsuredPersonBaseInfo();
                    unemploymentInsurance.setInsuredPersonBaseInfo(unemploymentInsuranceInsuredPersonBaseInfo);
                    if (StringUtils.equals(cellList.get(0), "暂无数据")) {
                        break;
                    }
                    unemploymentInsuranceInsuredPersonBaseInfo.setSocialSecurityNumber(cellList.get(1));
                    unemploymentInsuranceInsuredPersonBaseInfo.setName(cellList.get(3));
                    unemploymentInsuranceInsuredPersonBaseInfo.setInsuranceStatus(rowList.get(i + 1).get(1));
                    unemploymentInsuranceInsuredPersonBaseInfo.setUnitName(rowList.get(i + 1).get(3));

                    i++; //NOSONAR

                    break;
                case "工伤保险-参保人员基础信息":
                    ZhejiangIndividualRecordSheet.InsuredPersonBaseInfo employmentInjuryInsuranceInsuredPersonBaseInfo
                            = new ZhejiangIndividualRecordSheet.InsuredPersonBaseInfo();
                    employmentInjuryInsurance.setInsuredPersonBaseInfo(employmentInjuryInsuranceInsuredPersonBaseInfo);
                    if (StringUtils.equals(cellList.get(0), "暂无数据")) {
                        break;
                    }
                    employmentInjuryInsuranceInsuredPersonBaseInfo.setSocialSecurityNumber(cellList.get(1));
                    employmentInjuryInsuranceInsuredPersonBaseInfo.setName(cellList.get(3));
                    employmentInjuryInsuranceInsuredPersonBaseInfo.setInsuranceStatus(rowList.get(i + 1).get(1));
                    employmentInjuryInsuranceInsuredPersonBaseInfo.setUnitName(rowList.get(i + 1).get(3));
                    i++; //NOSONAR
                    break;
            }
        }
        basicEndowmentInsurance.setPersonalPaymentInfoList(basicEndowmentPersonalPaymentInfoList);
        basicEndowmentInsurance.setPensionPaymentInfoList(basicEndowmentInsurancePensionPaymentInfoList);
        zhejiangIndividualRecordSheet.setBasicEndowmentInsurance(basicEndowmentInsurance);

        institutionalEndowmentInsurance.setPersonalPaymentInfoList(institutionalPersonalPaymentInfoList);
        institutionalEndowmentInsurance.setPensionPaymentInfoList(institutionalPensionPaymentInfoList);
        zhejiangIndividualRecordSheet.setInstitutionalEndowmentInsurance(institutionalEndowmentInsurance);

        urbanAndRuralResidentsEndowmentInsurance.setPersonalPaymentInfoList(urbanAndRuralResidentsPersonalPaymentInfoList);
        urbanAndRuralResidentsEndowmentInsurance.setPensionPaymentInformationList(urbanAndRuralResidentsPensionPaymentInformationList);
        zhejiangIndividualRecordSheet.setUrbanAndRuralResidentsEndowmentInsurance(urbanAndRuralResidentsEndowmentInsurance);

        zhejiangIndividualRecordSheet.setUnemploymentInsurance(unemploymentInsurance);
        zhejiangIndividualRecordSheet.setEmploymentInjuryInsurance(employmentInjuryInsurance);
    }

    public static void main(String[] args) {
//        String filePath = "D:\\data\\file\\socialsecurity\\浙江\\app-gjzwfw-dzsb_cbzm.pdf";
//        String json;
//        ZhejiangSocialSecurityPdfParser zhejiangSocialSecurityPdfParser = new ZhejiangSocialSecurityPdfParser();

//        json = zhejiangSocialSecurityPdfParser.parseZhejiangSocialSecurityPdfToJson("", filePath).getData();
//        System.out.println("json = " + json);

//        json = zhejiangSocialSecurityPdfParser.parseZhejiangSocialSecurityPdfToJson("", "D:\\data\\file\\socialsecurity\\浙江\\app-gjzwfw-dzsb_qyd.pdf").getData();
//        System.out.println(json);
    }

}
