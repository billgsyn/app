package com.file.parser.socialsecurity;

import com.file.bo.ResponseData;
import com.file.bo.socialsecurity.HebeiIndividualRecordSheet;
import com.file.bo.socialsecurity.HebeiInsuranceParticipation;
import com.file.constant.ErrorCode;
import com.file.parser.BasePdfParser;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import technology.tabula.*;
import technology.tabula.detectors.SpreadsheetDetectionAlgorithm;
import technology.tabula.extractors.SpreadsheetExtractionAlgorithm;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class HebeiSocialSecurityPdfParser extends BasePdfParser {

    public ResponseData<String> parseHebeiSocialSecurityPdfParser(String daId, String filePath) {
        log.info("parseHebeiSocialSecurityPdfParser started, daId:{}", daId);
        String json = null;
        try {
            if (filePath.contains("cbzm")) {
                HebeiInsuranceParticipation HebeiInsuranceParticipation = parseHebeiInsuranceParticipation(filePath);
                json = JsonUtils.convertObjectToJson(HebeiInsuranceParticipation);
            } else if (filePath.contains("qyd")) {
                HebeiIndividualRecordSheet HebeiIndividualRecordSheet = parseHebeiIndividualRecordSheet(filePath);
                json = JsonUtils.convertObjectToJson(HebeiIndividualRecordSheet);
            } else {
                log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseHebeiSocialSecurityPdfToJson failed, new type not supported");
                return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
            }
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseHebeiSocialSecurityPdfToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseHebeiSocialSecurityPdfToJson completed, daId:{}", daId);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private void parseListToBO(List<List<String>> rowList, HebeiInsuranceParticipation hebeiInsuranceParticipation) {
        String sectionName = "";
        List<HebeiInsuranceParticipation.EndowmentInsuranceInsuranceDetail> endowmentInsuranceInsuranceDetails = new ArrayList<>();
        List<HebeiInsuranceParticipation.WorkInjuryInsuranceInsuranceDetail> workInjuryInsuranceInsuranceDetails = new ArrayList<>();
        List<HebeiInsuranceParticipation.UnemploymentInsuranceInsuranceDetail> unemploymentInsuranceInsuranceDetails = new ArrayList<>();
        hebeiInsuranceParticipation.getEndowmentInsurance().setInsuranceDetails(endowmentInsuranceInsuranceDetails);
        hebeiInsuranceParticipation.getWorkInjuryInsurance().setInsuranceDetails(workInjuryInsuranceInsuranceDetails);
        hebeiInsuranceParticipation.getUnemploymentInsurance().setInsuranceDetails(unemploymentInsuranceInsuranceDetails);
        for (int i = 0; i < rowList.size(); i++) {
            List<String> cellList = rowList.get(i);
            if (StringUtils.equalsAny(cellList.get(0), "参保人缴费明细", "参保险种")) {
                sectionName = "养老明细";
                continue;
            } else if (StringUtils.equals(cellList.get(0), "工伤保险")) {
                sectionName = "工伤明细";
            } else if (StringUtils.equals(cellList.get(0), "失业保险")) {
                sectionName = "失业明细";
            }
            switch (sectionName) {  //NOSONAR
                case "养老明细":
                    if (!cellList.get(0).contains("养老保险")) {
                        continue;
                    }
                    HebeiInsuranceParticipation.EndowmentInsuranceInsuranceDetail detail = new HebeiInsuranceParticipation.EndowmentInsuranceInsuranceDetail();
                    detail.setInsuranceType(cellList.get(0));
                    detail.setStartDateAndEndDate(cellList.get(1));
                    detail.setContributionBase(cellList.get(2));
                    detail.setDueMonths(cellList.get(3));
                    detail.setActualMonths(cellList.get(4));
                    detail.setEnrolledCompany(cellList.get(5));
                    endowmentInsuranceInsuranceDetails.add(detail);

                    break;

                case "工伤明细":
                    if (!StringUtils.equals(cellList.get(0), "工伤保险")) {
                        continue;
                    }
                    HebeiInsuranceParticipation.WorkInjuryInsuranceInsuranceDetail detail1 = new HebeiInsuranceParticipation.WorkInjuryInsuranceInsuranceDetail();
                    detail1.setInsuranceType(cellList.get(0));
                    detail1.setStartDateAndEndDate(cellList.get(1));
                    detail1.setContributionBase(cellList.get(2));
                    detail1.setEnrolledCompany(cellList.get(3));

                    workInjuryInsuranceInsuranceDetails.add(detail1);

                    break;
                case "失业明细":
                    if (!StringUtils.equals(cellList.get(0), "失业保险")) {
                        continue;
                    }
                    HebeiInsuranceParticipation.UnemploymentInsuranceInsuranceDetail detail2 = new HebeiInsuranceParticipation.UnemploymentInsuranceInsuranceDetail();
                    detail2.setInsuranceType(cellList.get(0));
                    detail2.setStartDateAndEndDate(cellList.get(1));
                    detail2.setContributionBase(cellList.get(2));
                    detail2.setDueMonths(cellList.get(3));
                    detail2.setActualMonths(cellList.get(4));
                    detail2.setEnrolledCompany(cellList.get(5));

                    unemploymentInsuranceInsuranceDetails.add(detail2);
                    break;
            }
        }
    }

    private void parseListToBO(List<List<String>> rowList, HebeiIndividualRecordSheet hebeiIndividualRecordSheet) { //NOSONAR
        HebeiIndividualRecordSheet.PersonalInfo personalInfo = new HebeiIndividualRecordSheet.PersonalInfo();
        HebeiIndividualRecordSheet.Insurance insurance = new HebeiIndividualRecordSheet.Insurance();
        personalInfo.setFirstEnrollmentDate(insurance);
        hebeiIndividualRecordSheet.setPersonalInfo(personalInfo);
        HebeiIndividualRecordSheet.PaymentSituation paymentSituation = new HebeiIndividualRecordSheet.PaymentSituation();
        HebeiIndividualRecordSheet.PaymentInfo pensionPayment = new HebeiIndividualRecordSheet.PaymentInfo();
        HebeiIndividualRecordSheet.PaymentInfo medicalPayment = new HebeiIndividualRecordSheet.PaymentInfo();
        HebeiIndividualRecordSheet.PaymentInfo unemploymentPayment = new HebeiIndividualRecordSheet.PaymentInfo();
        paymentSituation.setPensionPayment(pensionPayment);
        paymentSituation.setMedicalPayment(medicalPayment);
        paymentSituation.setUnemploymentPayment(unemploymentPayment);
        HebeiIndividualRecordSheet.Insurance1 currentYearArrearsPaid = new HebeiIndividualRecordSheet.Insurance1();
        HebeiIndividualRecordSheet.Insurance1 pastYearsMonthsPaid = new HebeiIndividualRecordSheet.Insurance1();
        HebeiIndividualRecordSheet.Insurance1 actualMonthsPaidThisYear = new HebeiIndividualRecordSheet.Insurance1();
        HebeiIndividualRecordSheet.Insurance1 cumulativeArrearsMonths = new HebeiIndividualRecordSheet.Insurance1();
        paymentSituation.setCurrentYearArrearsPaid(currentYearArrearsPaid);
        paymentSituation.setPastYearsMonthsPaid(pastYearsMonthsPaid);
        paymentSituation.setActualMonthsPaidThisYear(actualMonthsPaidThisYear);
        paymentSituation.setCumulativeArrearsMonths(cumulativeArrearsMonths);
        HebeiIndividualRecordSheet.Insurance insurance1 = new HebeiIndividualRecordSheet.Insurance();
        personalInfo.setFirstEnrollmentDate(insurance1);
        paymentSituation.setIndividualContributionBase(insurance1);
        hebeiIndividualRecordSheet.setPaymentSituation(paymentSituation);

        HebeiIndividualRecordSheet.AccountStatus accountStatus = new HebeiIndividualRecordSheet.AccountStatus();
        hebeiIndividualRecordSheet.setAccountStatus(accountStatus);

        HebeiIndividualRecordSheet.PensionAccount basicPension = new HebeiIndividualRecordSheet.PensionAccount();
        accountStatus.setBasicPension(basicPension);
        HebeiIndividualRecordSheet.MedicalAccount basicMedical = new HebeiIndividualRecordSheet.MedicalAccount();
        HebeiIndividualRecordSheet.PensionReceipt pensionReceipt = new HebeiIndividualRecordSheet.PensionReceipt();
        accountStatus.setBasicMedical(basicMedical);
        accountStatus.setPensionReceipt(pensionReceipt);

        String sectionName = "";

        for (int i = 0; i < rowList.size(); i++) {
            List<String> cellList = rowList.get(i);
            if (StringUtils.equalsAny(cellList.get(0), "个人基本信息")) {
                sectionName = "个人基本信息";
                continue;
            } else if (StringUtils.equalsAny(cellList.get(0), "缴费情况")) {
                sectionName = "缴费情况";
            } else if (StringUtils.equals(cellList.get(0), "基本养老保险")) {
                sectionName = "基本养老保险";
            } else if (StringUtils.equals(cellList.get(0), "基本医疗保险")) {
                sectionName = "基本医疗保险";
            } else if (StringUtils.equals(cellList.get(0), "月养老金水平")) {
                sectionName = "月养老金水平";
            } else if (cellList.get(0).contains("社会保险经办机构名称")) {
                sectionName = "社会保险经办机构名称";
            } else if (cellList.get(9).equals("打印时间:")) {
                hebeiIndividualRecordSheet.setPrintTime(cellList.get(10).replaceAll(" ", ""));
            }

            switch (sectionName) {  //NOSONAR
                case "个人基本信息":
                    if (!StringUtils.equals(cellList.get(0), "姓名")) {
                        continue;
                    }
                    personalInfo.setName(cellList.get(1));
                    personalInfo.setCompanyName(cellList.get(3));
                    personalInfo.setSocialSecurityNumber(cellList.get(5).replaceAll(" ", ""));
                    personalInfo.setFirstEnrollmentDate(insurance);
                    cellList = rowList.get(i + 2);
                    if (!cellList.get(1).equals("--")) {
                        insurance.setPension(cellList.get(1).replaceAll(" ", ""));
                    }
                    if (!cellList.get(2).equals("--")) {
                        insurance.setMedical(cellList.get(2).replaceAll(" ", ""));
                    }
                    if (!cellList.get(3).equals("--")) {
                        insurance.setUnemployment(cellList.get(3).replaceAll(" ", ""));
                    }
                    if (!cellList.get(4).equals("--")) {
                        insurance.setInjury(cellList.get(4).replaceAll(" ", ""));
                    }
                    if (!cellList.get(5).equals("--")) {
                        insurance.setMaternity(cellList.get(5).replaceAll(" ", ""));
                    }
                    i += 2; //NOSONAR
                    break;

                case "缴费情况":
                    if (!StringUtils.equals(cellList.get(0), "缴费情况")) {
                        continue;
                    }
                    cellList = rowList.get(i + 3);
                    if (!cellList.get(0).equals("--")) {
                        insurance1.setPension(cellList.get(0).replaceAll(" ", ""));
                    }
                    if (!cellList.get(1).equals("--")) {
                        insurance1.setMedical(cellList.get(1).replaceAll(" ", ""));
                    }
                    if (!cellList.get(2).equals("--")) {
                        insurance1.setUnemployment(cellList.get(2).replaceAll(" ", ""));
                    }
                    if (!cellList.get(3).equals("--")) {
                        insurance1.setInjury(cellList.get(3).replaceAll(" ", ""));
                    }
                    if (!cellList.get(4).equals("--")) {
                        insurance1.setMaternity(cellList.get(4).replaceAll(" ", ""));
                    }
                    if (!cellList.get(5).equals("--")) {
                        pensionPayment.setCompanyContribution(cellList.get(5).replaceAll(" ", ""));
                    }
                    if (!cellList.get(6).equals("--")) {
                        pensionPayment.setIndividualContribution(cellList.get(6).replaceAll(" ", ""));
                    }
                    if (!cellList.get(7).equals("--")) {
                        medicalPayment.setCompanyContribution(cellList.get(7).replaceAll(" ", ""));
                    }
                    if (!cellList.get(8).equals("--")) {
                        medicalPayment.setIndividualContribution(cellList.get(8).replaceAll(" ", ""));
                    }
                    if (!cellList.get(9).equals("--")) {
                        unemploymentPayment.setCompanyContribution(cellList.get(9).replaceAll(" ", ""));
                    }
                    if (!cellList.get(10).equals("--")) {
                        unemploymentPayment.setIndividualContribution(cellList.get(10).replaceAll(" ", ""));
                    }
                    if (!cellList.get(11).equals("--")) {
                        paymentSituation.setInjuryPayment(cellList.get(11).replaceAll(" ", ""));
                    }
                    if (!cellList.get(12).equals("--")) {
                        paymentSituation.setMaternityPayment(cellList.get(12).replaceAll(" ", ""));
                    }
                    cellList = rowList.get(i + 6);
                    if (!cellList.get(0).equals("--")) {
                        currentYearArrearsPaid.setPension(cellList.get(0).replaceAll(" ", ""));
                    }
                    if (!cellList.get(1).equals("--")) {
                        currentYearArrearsPaid.setMedical(cellList.get(1).replaceAll(" ", ""));
                    }
                    if (!cellList.get(2).equals("--")) {
                        currentYearArrearsPaid.setUnemployment(cellList.get(2).replaceAll(" ", ""));
                    }

                    if (!cellList.get(3).equals("--")) {
                        pastYearsMonthsPaid.setPension(cellList.get(3).replaceAll(" ", ""));
                    }
                    if (!cellList.get(4).equals("--")) {
                        pastYearsMonthsPaid.setMedical(cellList.get(4).replaceAll(" ", ""));
                    }
                    if (!cellList.get(5).equals("--")) {
                        pastYearsMonthsPaid.setUnemployment(cellList.get(5).replaceAll(" ", ""));
                    }
                    if (!cellList.get(6).equals("--")) {
                        actualMonthsPaidThisYear.setPension(cellList.get(6).replaceAll(" ", ""));
                    }
                    if (!cellList.get(7).equals("--")) {
                        actualMonthsPaidThisYear.setMedical(cellList.get(7).replaceAll(" ", ""));
                    }
                    if (!cellList.get(8).equals("--")) {
                        actualMonthsPaidThisYear.setUnemployment(cellList.get(8).replaceAll(" ", ""));
                    }
                    if (!cellList.get(9).equals("--")) {
                        cumulativeArrearsMonths.setPension(cellList.get(9).replaceAll(" ", ""));
                    }
                    if (!cellList.get(10).equals("--")) {
                        cumulativeArrearsMonths.setMedical(cellList.get(10).replaceAll(" ", ""));
                    }
                    if (!cellList.get(11).equals("--")) {
                        cumulativeArrearsMonths.setUnemployment(cellList.get(11).replaceAll(" ", ""));
                    }
                    i += 6;  //NOSONAR
                    break;
                case "基本养老保险":
                    if (!StringUtils.equals(cellList.get(0), "基本养老保险")) {
                        continue;
                    }
                    cellList = rowList.get(i + 2);
                    basicPension.setPreviousYearEndBalance(cellList.get(0).replaceAll(" ", ""));
                    basicPension.setCurrentYearCreditAmount(cellList.get(1).replaceAll(" ", ""));
                    basicPension.setCurrentYearExpenseAmount(cellList.get(2).replaceAll(" ", ""));
                    basicPension.setCurrentYearInterest(cellList.get(3).replaceAll(" ", ""));
                    basicPension.setEndOfYearBalance(cellList.get(4).replaceAll(" ", ""));
                    i += 2;  //NOSONAR
                    break;
                case "基本医疗保险":
                    if (!StringUtils.equals(cellList.get(0), "基本医疗保险")) {
                        continue;
                    }
                    cellList = rowList.get(i + 2);
                    if (!cellList.get(0).equals("--")) {
                        basicMedical.setPreviousYearEndBalance(cellList.get(0).replaceAll(" ", ""));
                    }
                    if (!cellList.get(1).equals("--")) {
                        basicMedical.setCurrentYearCreditAmount(cellList.get(1).replaceAll(" ", ""));
                    }
                    if (!cellList.get(2).equals("--")) {
                        basicMedical.setCurrentYearExpenseAmount(cellList.get(2).replaceAll(" ", ""));
                    }
                    if (!cellList.get(3).equals("--")) {
                        basicMedical.setCurrentYearInterest(cellList.get(3).replaceAll(" ", ""));
                    }
                    if (!cellList.get(4).equals("--")) {
                        basicMedical.setEndOfYearBalance(cellList.get(4).replaceAll(" ", ""));
                    }
                    i += 2;  //NOSONAR
                    break;
                case "月养老金水平":
                    if (!StringUtils.equals(cellList.get(0), "月养老金水平")) {
                        continue;
                    }
                    pensionReceipt.setMonthlyPensionLevel(cellList.get(1).replaceAll(" ", ""));
                    pensionReceipt.setAdjustmentAmount(cellList.get(3).replaceAll(" ", ""));
                    break;
                case "社会保险经办机构名称":
                    if (!cellList.get(0).contains("社会保险经办机构名称")) {
                        continue;
                    }
                    String[] arr = cellList.get(0).split(":");
                    if (arr.length > 1) {
                        hebeiIndividualRecordSheet.setAgencyName(arr[1].replaceAll(" ", ""));
                    }
                    arr = cellList.get(1).split(":");
                    if (arr.length > 1) {
                        hebeiIndividualRecordSheet.setAddress(arr[1].replaceAll(" ", ""));
                    }
                    arr = cellList.get(2).split(":");
                    if (arr.length > 1) {
                        hebeiIndividualRecordSheet.setContactNumber(arr[1].replaceAll(" ", ""));
                    }
                    break;
            }
        }
    }

    private List<List<String>> parseFileToRowList(String filePath) {
        // 1. 读取文件
        File pdf = new File(filePath);

        //页面所有table的记录，每一个元素代表下面一条记录cellList
        List<List<String>> rowList = new ArrayList<>();

        // 2. pdfbox读取PDDocument
        try (PDDocument pdfDocument = PDDocument.load(pdf)) {
            // 3. tabula新建ObjectExtractor和NurminenDetectionAlgorithm，同时准备接收表格Rectangle的结构
            ObjectExtractor objectExtractor = new ObjectExtractor(pdfDocument);
            SpreadsheetDetectionAlgorithm detectionAlgorithm = new SpreadsheetDetectionAlgorithm();
            Map<Integer, List<Rectangle>> pageNumber2RectangleListMap = new HashMap<>();//key为页的序号， value为对应的Rectangle的list

            // 4. 获取每页的PageIterator
            PageIterator pageIterator = objectExtractor.extract();

            // 5. 解析每页的Rectangle
            // 如果单页pdf中有多个Rectangle，则解析出来的List<Rectangle>会有多个对象
            while (pageIterator.hasNext()) {
                Page page = pageIterator.next();
                List<Rectangle> rectangleList = detectionAlgorithm.detect(page);
                if (rectangleList.size() > 0) {
                    pageNumber2RectangleListMap.put(page.getPageNumber(), rectangleList);
                }
            }

            // 6.通过table位置获取表格具体内容
            SpreadsheetExtractionAlgorithm extractionAlgorithm = new SpreadsheetExtractionAlgorithm();

            // 如果单页pdf中有多个表格，则解析出来的List<Rectangle>会有多个对象
            for (Map.Entry<Integer, List<Rectangle>> entry : pageNumber2RectangleListMap.entrySet()) {
                Page page = objectExtractor.extract(entry.getKey());
                Rectangle rectangle = null;

                List<Rectangle> rectangleList = entry.getValue();
                for (Rectangle r : rectangleList) {
                    double rectangleHeight = r.getHeight();
                    if (Double.compare(rectangleHeight, 0) > 0) {
                        rectangle = r;
                        break;
                    }
                }
                if (rectangle == null) {
                    throw new RuntimeException("rectangle is null.");
                }

                if (entry.getKey() > 1) {
                    rectangle.setTop(rectangle.getTop());
                }
                rectangle.setBottom(rectangle.getBottom() + 500);
                Page area = page.getArea(rectangle);

                // 如果每页有多个表格，解析每一个table
                List<Table> tableList = extractionAlgorithm.extract(area);
                for (Table table : tableList) {
                    for (int i = 0; i < table.getRowCount(); i++) {
                        List<String> cellList = new ArrayList<>();//一条记录，每个单元格占一个元素
                        for (int j = 0; j < table.getColCount(); j++) {
                            cellList.add(table.getCell(i, j).getText(false));
                        }
                        rowList.add(cellList);
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }

        return rowList;
    }

    private HebeiInsuranceParticipation parseHebeiInsuranceParticipation(String filePath) {
        HebeiInsuranceParticipation hebeiInsuranceParticipation = new HebeiInsuranceParticipation();

        HebeiInsuranceParticipation.EndowmentInsurance endowmentInsurance = new HebeiInsuranceParticipation.EndowmentInsurance();
        HebeiInsuranceParticipation.WorkInjuryInsurance workInjuryInsurance = new HebeiInsuranceParticipation.WorkInjuryInsurance();
        HebeiInsuranceParticipation.UnemploymentInsurance unemploymentInsurance = new HebeiInsuranceParticipation.UnemploymentInsurance();

        hebeiInsuranceParticipation.setEndowmentInsurance(endowmentInsurance);
        hebeiInsuranceParticipation.setWorkInjuryInsurance(workInjuryInsurance);
        hebeiInsuranceParticipation.setUnemploymentInsurance(unemploymentInsurance);

        String pdfText = getPdfTextByStripper2(filePath).replace(System.getProperty("line.separator", "\n"), StringUtils.EMPTY);
        String text = "";
        String participationDate = pdfText.substring(pdfText.lastIndexOf("证明日期：") + 5 ).trim();
        if (pdfText.contains("养老保险")) {
            if (pdfText.contains("险种：工伤保险")) {
                text = pdfText.substring(0, pdfText.indexOf("险种：工伤保险"));
            } else if (pdfText.contains("失业保险")) {
                text = pdfText.substring(0, pdfText.indexOf("失业保险"));
            } else {
                text = pdfText; //NOSONAR
            }
            String agencyCode = text.substring(text.indexOf("机构代码：") + 5, text.indexOf("兹证明参保人")).trim();
            endowmentInsurance.setAgencyCode(agencyCode);
            String insuredName = text.substring(text.indexOf("姓名：") + 3, text.indexOf("社会保障号码")).trim();
            endowmentInsurance.setInsuredName(insuredName);
            String socialSecurityNumber = text.substring(text.indexOf("社会保障号码：") + 7, text.indexOf("个人社保编号")).trim();
            endowmentInsurance.setSocialSecurityNumber(socialSecurityNumber);
            String personalSocSecNum = text.substring(text.indexOf("个人社保编号：") + 7, text.indexOf("经办机构名称")).trim();
            endowmentInsurance.setPersonalSocSecNum(personalSocSecNum);
            String agencyName = text.substring(text.indexOf("机构名称：") + 5, text.indexOf("个人身份")).trim();
            endowmentInsurance.setAgencyName(agencyName);
            String personalIdentity = text.substring(text.indexOf("个人身份：") + 5, text.indexOf("参保单位名称：")).trim();
            endowmentInsurance.setPersonalIdentity(personalIdentity);
            String enrolledCompanyName = text.substring(text.indexOf("参保单位名称：") + 7, text.indexOf("首次参保日期：")).trim();
            endowmentInsurance.setEnrolledCompanyName(enrolledCompanyName);
            String firstEnrollmentDate = text.substring(text.indexOf("首次参保日期：") + 7, text.indexOf("本地登记日期：")).trim();
            endowmentInsurance.setFirstEnrollmentDate(firstEnrollmentDate);
            String localRegistrationDate = text.substring(text.indexOf("本地登记日期：") + 7, text.indexOf("个人参保状态：")).trim();
            endowmentInsurance.setLocalRegistrationDate(localRegistrationDate);
            String individualEnrollmentStatus = text.substring(text.indexOf("个人参保状态：") + 7, text.indexOf("累计缴费年限：")).trim();
            endowmentInsurance.setIndividualEnrollmentStatus(individualEnrollmentStatus);
            String accumulatedPaymentYears = text.substring(text.indexOf("累计缴费年限：") + 7, text.indexOf("参保人缴费明细")).trim();
            endowmentInsurance.setAccumulatedPaymentYears(accumulatedPaymentYears);
            endowmentInsurance.setParticipationDate(participationDate);
        }
        if (pdfText.contains("险种：工伤保险")) {
            if (pdfText.contains("失业保险")) {
                text = pdfText.substring(pdfText.indexOf("工伤保险"), pdfText.indexOf("失业保险"));
            } else {
                text = pdfText.substring(pdfText.indexOf("工伤保险"));
            }

            String agencyCode = text.substring(text.indexOf("机构代码：") + 5, text.indexOf("兹证明参保人")).trim();
            workInjuryInsurance.setAgencyCode(agencyCode);
            String insuredName = text.substring(text.indexOf("姓名：") + 3, text.indexOf("社会保障号码")).trim();
            workInjuryInsurance.setInsuredName(insuredName);
            String socialSecurityNumber = text.substring(text.indexOf("社会保障号码：") + 7, text.indexOf("个人社保编号")).trim();
            workInjuryInsurance.setSocialSecurityNumber(socialSecurityNumber);
            String personalSocSecNum = text.substring(text.indexOf("个人社保编号：") + 7, text.indexOf("经办机构名称")).trim();
            workInjuryInsurance.setPersonalSocSecNum(personalSocSecNum);
            String agencyName = text.substring(text.indexOf("机构名称：") + 5, text.indexOf("首次参保日期")).trim();
            workInjuryInsurance.setAgencyName(agencyName);
            String firstEnrollmentDate = text.substring(text.indexOf("首次参保日期：") + 7, text.indexOf("参保单位名称：")).trim();
            workInjuryInsurance.setFirstEnrollmentDate(firstEnrollmentDate);
            String enrolledCompanyName = text.substring(text.indexOf("参保单位名称：") + 7, text.indexOf("个人参保状态：")).trim();
            workInjuryInsurance.setEnrolledCompanyName(enrolledCompanyName);
            String individualEnrollmentStatus = text.substring(text.indexOf("个人参保状态：") + 7, text.indexOf("本地登记日期：")).trim();
            workInjuryInsurance.setIndividualEnrollmentStatus(individualEnrollmentStatus);
            String localRegistrationDate = text.substring(text.indexOf("本地登记日期：") + 7, text.indexOf("参保人缴费明细")).trim();
            workInjuryInsurance.setLocalRegistrationDate(localRegistrationDate);
            workInjuryInsurance.setParticipationDate(participationDate);
        }
        if (pdfText.contains("失业保险")) {
            text = pdfText.substring(pdfText.indexOf("失业保险"));
            String agencyCode = text.substring(text.indexOf("机构代码：") + 5, text.indexOf("兹证明参保人")).trim();
            unemploymentInsurance.setAgencyCode(agencyCode);
            String insuredName = text.substring(text.indexOf("姓名：") + 3, text.indexOf("社会保障号码")).trim();
            unemploymentInsurance.setInsuredName(insuredName);
            String socialSecurityNumber = text.substring(text.indexOf("社会保障号码：") + 7, text.indexOf("个人社保编号")).trim();
            unemploymentInsurance.setSocialSecurityNumber(socialSecurityNumber);
            String personalSocSecNum = text.substring(text.indexOf("个人社保编号：") + 7, text.indexOf("经办机构名称")).trim();
            unemploymentInsurance.setPersonalSocSecNum(personalSocSecNum);
            String agencyName = text.substring(text.indexOf("机构名称：") + 5, text.indexOf("个人身份")).trim();
            unemploymentInsurance.setAgencyName(agencyName);
            String personalIdentity = text.substring(text.indexOf("个人身份：") + 5, text.indexOf("参保单位名称：")).trim();
            unemploymentInsurance.setPersonalIdentity(personalIdentity);
            String enrolledCompanyName = text.substring(text.indexOf("参保单位名称：") + 7, text.indexOf("首次参保日期：")).trim();
            unemploymentInsurance.setEnrolledCompanyName(enrolledCompanyName);
            String firstEnrollmentDate = text.substring(text.indexOf("首次参保日期：") + 7, text.indexOf("本地登记日期：")).trim();
            unemploymentInsurance.setFirstEnrollmentDate(firstEnrollmentDate);
            String localRegistrationDate = text.substring(text.indexOf("本地登记日期：") + 7, text.indexOf("个人参保状态：")).trim();
            unemploymentInsurance.setLocalRegistrationDate(localRegistrationDate);
            String individualEnrollmentStatus = text.substring(text.indexOf("个人参保状态：") + 7, text.indexOf("累计缴费年限：")).trim();
            unemploymentInsurance.setIndividualEnrollmentStatus(individualEnrollmentStatus);
            String accumulatedPaymentYears = text.substring(text.indexOf("累计缴费年限：") + 7, text.indexOf("参保人缴费明细")).trim();
            unemploymentInsurance.setAccumulatedPaymentYears(accumulatedPaymentYears);
            unemploymentInsurance.setParticipationDate(participationDate);
        }
        List<List<String>> rowList = parseFileToRowList(filePath);
        parseListToBO(rowList, hebeiInsuranceParticipation);
        return hebeiInsuranceParticipation;
    }

    private HebeiIndividualRecordSheet parseHebeiIndividualRecordSheet(String filePath) {
        String pdfText = getPdfTextByStripper2(filePath).replace(System.getProperty("line.separator", "\n"), StringUtils.EMPTY);
        HebeiIndividualRecordSheet hebeiIndividualRecordSheet = new HebeiIndividualRecordSheet();

        String period = pdfText.substring(pdfText.indexOf("年度") - 4, pdfText.indexOf("年度")).trim();

//        String printTime = pdfText.substring(pdfText.lastIndexOf("打印时间：") + 5, pdfText.lastIndexOf("地址：")).replaceAll(" ", "");
        hebeiIndividualRecordSheet.setRecordPeriod(period + "年1月至" + period + "年12月");
//        hebeiIndividualRecordSheet.setPrintTime(printTime);
        List<List<String>> rowList = parseFileToRowList(filePath);
        parseListToBO(rowList, hebeiIndividualRecordSheet);
        return hebeiIndividualRecordSheet;
    }

    public static void main(String[] args) {
        HebeiSocialSecurityPdfParser hebeiSocialSecurityPdfParser = new HebeiSocialSecurityPdfParser();
        String json, filePath;
        // 参保证明
        filePath = "D:\\data\\file\\socialsecurity\\河北\\app-gjzwfw-dzsb_cbzm.pdf";
        json = hebeiSocialSecurityPdfParser.parseHebeiSocialSecurityPdfParser("", filePath).getData();
        System.out.println("json = " + json);
        // 权益单

//        filePath = "D:\\data\\file\\socialsecurity\\河北\\app-gjzwfw-dzsb_qyd.pdf";
//        json = hebeiSocialSecurityPdfParser.parseHebeiSocialSecurityPdfParser("", filePath).getData();
//        System.out.println("json = " + json);

    }

}
