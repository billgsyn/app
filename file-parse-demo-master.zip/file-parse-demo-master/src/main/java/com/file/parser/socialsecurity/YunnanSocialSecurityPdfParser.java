package com.file.parser.socialsecurity;


import com.file.bo.ResponseData;
import com.file.bo.socialsecurity.YunnanIndividualRecordSheet;
import com.file.bo.socialsecurity.YunnanInsuranceParticipation;
import com.file.constant.ErrorCode;
import com.file.parser.BasePdfParser;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import technology.tabula.*;
import technology.tabula.detectors.SpreadsheetDetectionAlgorithm;
import technology.tabula.extractors.SpreadsheetExtractionAlgorithm;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class YunnanSocialSecurityPdfParser extends BasePdfParser {

    public ResponseData<String> parseYunnanSocialSecurityPdfParser(String daId, String filePath) {
        log.info("parseYunnanSocialSecurityPdfParser started, daId:{}", daId);
        String json = null;
        try {
            if (filePath.contains("cbzm")) {
                YunnanInsuranceParticipation YunnanInsuranceParticipation = parseYunnanInsuranceParticipation(filePath);
                json = JsonUtils.convertObjectToJson(YunnanInsuranceParticipation);
            } else if (filePath.contains("qyd")) {
                YunnanIndividualRecordSheet YunnanIndividualRecordSheet = parseYunnanIndividualRecordSheet(filePath);
                json = JsonUtils.convertObjectToJson(YunnanIndividualRecordSheet);
            } else {
                log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseYunnanSocialSecurityPdfToJson failed, new type not supported");
                return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
            }
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseYunnanSocialSecurityPdfToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseYunnanSocialSecurityPdfToJson completed, daId:{}", daId);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private void parseListToBO(List<List<String>> rowList, YunnanInsuranceParticipation yunnanInsuranceParticipation) {
        String sectionName = "";

        YunnanInsuranceParticipation.WorkersInjuryInsuranceCertificate workersInjuryInsuranceCertificate = yunnanInsuranceParticipation.getWorkersInjuryInsuranceCertificate();
        YunnanInsuranceParticipation.UnemploymentInsuranceCertificate unemploymentInsuranceCertificate = yunnanInsuranceParticipation.getUnemploymentInsuranceCertificate();
        List<YunnanInsuranceParticipation.FeeDetail> feeDetails = new ArrayList<>();
        List<YunnanInsuranceParticipation.FeeDetail> feeDetails1 = new ArrayList<>();
        List<YunnanInsuranceParticipation.FeeDetail> institutionsFeeDetails = new ArrayList<>();
        List<YunnanInsuranceParticipation.FeeDetail> institutionsFeeDetails1 = new ArrayList<>();
        String insuranceParticipationType = "";
        for (int i = 0; i < rowList.size(); i++) {
            List<String> cellList = rowList.get(i);
            if (StringUtils.equals(cellList.get(0), "当前参保缴费状态")) {
                sectionName = "当前参保缴费状态";
            } else if (StringUtils.equals(cellList.get(0), "缴费年份")) {
                sectionName = "缴费明细";
                continue;
            } else if (StringUtils.equals(cellList.get(0), "身份证号")) {
                sectionName = "工伤保险参保证明";
            } else if (StringUtils.equals(cellList.get(0), "当前缴费状态")) {
                sectionName = "失业保险个人参保证明";
            }
            switch (sectionName) {  //NOSONAR
                case "当前参保缴费状态":

                    if (!StringUtils.equals(cellList.get(0), "当前参保缴费状态")) {
                        continue;
                    }
                    if (rowList.get(i + 2).get(4).equals("城镇职工基本养老保险")) {
                        insuranceParticipationType = "城镇职工基本养老保险";
                        YunnanInsuranceParticipation.PensionInsuranceCertificate pensionInsuranceCertificate = new YunnanInsuranceParticipation.PensionInsuranceCertificate();
                        yunnanInsuranceParticipation.setPensionInsuranceCertificate(pensionInsuranceCertificate);
                        List<String> preCellList = rowList.get(i - 1);
                        pensionInsuranceCertificate.setName(preCellList.get(1));
                        pensionInsuranceCertificate.setGender(preCellList.get(3));
                        pensionInsuranceCertificate.setPersonalId(preCellList.get(5));
                        pensionInsuranceCertificate.setIdCardNumber(preCellList.get(7));
                        pensionInsuranceCertificate.setCurrentInsuranceStatus(cellList.get(1));
                        pensionInsuranceCertificate.setPaymentMonths(cellList.get(3));
                        pensionInsuranceCertificate.setCurrentInsuranceCompany(cellList.get(5));
                        List<String> nextCellList = rowList.get(i + 2);
                        YunnanInsuranceParticipation.InsuranceDetail insuranceDetail = new YunnanInsuranceParticipation.InsuranceDetail();
                        insuranceDetail.setInsurancePeriod(nextCellList.get(1));
                        insuranceDetail.setInsuredCompany(nextCellList.get(2));
                        insuranceDetail.setHandlingAgency(nextCellList.get(3));
                        insuranceDetail.setInsuranceType(nextCellList.get(4));
                        pensionInsuranceCertificate.setInsuranceDetail(insuranceDetail);
                    }

                    if (rowList.get(i + 2).get(4).equals("机关事业单位基本养老保险")) {
                        insuranceParticipationType = "机关事业单位基本养老保险";
                        YunnanInsuranceParticipation.PensionInsuranceCertificate pensionInsuranceCertificate = new YunnanInsuranceParticipation.PensionInsuranceCertificate();
                        yunnanInsuranceParticipation.setInstitutionsPensionInsuranceCertificate(pensionInsuranceCertificate);
                        List<String> preCellList = rowList.get(i - 1);
                        pensionInsuranceCertificate.setName(preCellList.get(1));
                        pensionInsuranceCertificate.setGender(preCellList.get(3));
                        pensionInsuranceCertificate.setPersonalId(preCellList.get(5));
                        pensionInsuranceCertificate.setIdCardNumber(preCellList.get(7));
                        pensionInsuranceCertificate.setCurrentInsuranceStatus(cellList.get(1));
                        pensionInsuranceCertificate.setPaymentMonths(cellList.get(3));
                        pensionInsuranceCertificate.setCurrentInsuranceCompany(cellList.get(5));
                        List<String> nextCellList = rowList.get(i + 2);
                        YunnanInsuranceParticipation.InsuranceDetail insuranceDetail = new YunnanInsuranceParticipation.InsuranceDetail();
                        insuranceDetail.setInsurancePeriod(nextCellList.get(1));
                        insuranceDetail.setInsuredCompany(nextCellList.get(2));
                        insuranceDetail.setHandlingAgency(nextCellList.get(3));
                        insuranceDetail.setInsuranceType(nextCellList.get(4));
                        pensionInsuranceCertificate.setInsuranceDetail(insuranceDetail);
                    }
                    break;
                case "缴费明细":
                    if (!cellList.get(0).matches("\\d{4}")) {
                        continue;
                    }
                    YunnanInsuranceParticipation.FeeDetail feeDetail = new YunnanInsuranceParticipation.FeeDetail();
                    feeDetail.setPaymentYear(cellList.get(0));
                    feeDetail.setPaymentMonth(cellList.get(1));
                    feeDetail.setConsumptionBase(cellList.get(2));
                    feeDetail.setCompanyContribution(cellList.get(3));
                    feeDetail.setIndividualContribution(cellList.get(4));
                    feeDetail.setPaymentStatus(cellList.get(5));
                    YunnanInsuranceParticipation.FeeDetail feeDetail1 = new YunnanInsuranceParticipation.FeeDetail();
                    feeDetail1.setPaymentYear(cellList.get(6));
                    feeDetail1.setPaymentMonth(cellList.get(7));
                    feeDetail1.setConsumptionBase(cellList.get(8));
                    feeDetail1.setCompanyContribution(cellList.get(9));
                    feeDetail1.setIndividualContribution(cellList.get(10));
                    feeDetail1.setPaymentStatus(cellList.get(11));
                    if (insuranceParticipationType.equals("城镇职工基本养老保险")) {
                        feeDetails.add(feeDetail);
                        feeDetails1.add(feeDetail1);
                    } else {
                        institutionsFeeDetails.add(feeDetail);
                        institutionsFeeDetails1.add(feeDetail1);
                    }

                    break;
                case "工伤保险参保证明":
                    if (!StringUtils.equals(cellList.get(0), "身份证号")) {
                        break;
                    }
                    workersInjuryInsuranceCertificate.setIdCardNumber(cellList.get(1));
                    workersInjuryInsuranceCertificate.setDateOfBirth(cellList.get(3));
                    cellList = rowList.get(i - 1);
                    workersInjuryInsuranceCertificate.setName(cellList.get(1));
                    workersInjuryInsuranceCertificate.setGender(cellList.get(3));
                    workersInjuryInsuranceCertificate.setPersonalId(cellList.get(5));
                    cellList = rowList.get(i + 1);
                    workersInjuryInsuranceCertificate.setInsuranceCompany(cellList.get(1));
                    cellList = rowList.get(i + 2);
                    workersInjuryInsuranceCertificate.setInsuranceDate(cellList.get(1));
                    i += 2;  //NOSONAR
                    break;
                case "失业保险个人参保证明":
                    if (!StringUtils.equals(cellList.get(0), "当前缴费状态")) {
                        break;
                    }
                    unemploymentInsuranceCertificate.setCurrentPaymentStatus(cellList.get(1));
                    unemploymentInsuranceCertificate.setCurrentInsuranceCompany(cellList.get(3));
                    cellList = rowList.get(i - 1);
                    unemploymentInsuranceCertificate.setName(cellList.get(1));
                    unemploymentInsuranceCertificate.setGender(cellList.get(3));
                    unemploymentInsuranceCertificate.setPersonalId(cellList.get(5));
                    unemploymentInsuranceCertificate.setIdCardNumber(cellList.get(7));
                    cellList = rowList.get(i + 1);
                    unemploymentInsuranceCertificate.setInsuranceInstitution(cellList.get(1));
            }
        }

        if (!feeDetails.isEmpty()) {
            feeDetails.addAll(feeDetails1);
            yunnanInsuranceParticipation.getPensionInsuranceCertificate().setFeeDetails(feeDetails);
        }
        if (!institutionsFeeDetails.isEmpty()) {
            institutionsFeeDetails.addAll(institutionsFeeDetails1);
            yunnanInsuranceParticipation.getInstitutionsPensionInsuranceCertificate().setFeeDetails(institutionsFeeDetails);
        }
    }

    private void parseListToBO(List<List<String>> rowList, YunnanIndividualRecordSheet yunnanIndividualRecordSheet) {
        List<YunnanIndividualRecordSheet.EmployeeInsuranceInfo> employeeInsuranceInfos = new ArrayList<>();
        yunnanIndividualRecordSheet.setEmployeeInsuranceInfos(employeeInsuranceInfos);
        List<YunnanIndividualRecordSheet.PaymentItem> paymentItems = new ArrayList<>();
        yunnanIndividualRecordSheet.setPaymentDetails(paymentItems);
        String sectionName = "";

        for (int i = 0; i < rowList.size(); i++) {
            List<String> cellList = rowList.get(i);
            if (StringUtils.equalsAny(cellList.get(0), "业职工工伤保险参保信息", "个人编号")) {
                sectionName = "业职工工伤保险参保信息";
                continue;
            } else if (StringUtils.equalsAny(cellList.get(0), "参保日期")) {
                sectionName = "失业保险基本信息";
            } else if (StringUtils.equals(cellList.get(0), "业保险缴费明细")) {
                sectionName = "失业保险缴费明细";
                continue;
            } else if (StringUtils.equals(cellList.get(0), "关事业工伤保险参保信息")) {
                return;
            }
            switch (sectionName) { //NOSONAR
                case "业职工工伤保险参保信息":
                    if (!cellList.get(0).matches("\\d{10,}")) {
                        continue;
                    }
                    YunnanIndividualRecordSheet.EmployeeInsuranceInfo info = new YunnanIndividualRecordSheet.EmployeeInsuranceInfo();
                    info.setPersonalId(cellList.get(0));
                    info.setCompanyName(cellList.get(1));
                    info.setCompanyArea(cellList.get(2));
                    info.setInsuranceDate("");
                    info.setInsuranceStatus("");
                    employeeInsuranceInfos.add(info);
                    break;
                case "失业保险基本信息":
                    if (!StringUtils.equals(cellList.get(0), "参保日期")) {
                        continue;
                    }
                    YunnanIndividualRecordSheet.UnemploymentBasicInfo unemploymentBasicInfo = new YunnanIndividualRecordSheet.UnemploymentBasicInfo();
                    yunnanIndividualRecordSheet.setUnemploymentBasicInfo(unemploymentBasicInfo);

                    unemploymentBasicInfo.setInsuranceDate(cellList.get(1));
                    unemploymentBasicInfo.setCurrentPaymentMonths(cellList.get(3));
                    unemploymentBasicInfo.setAccumulatedTransferPaymentMonths(cellList.get(7));
                    cellList = rowList.get(i - 1);
                    unemploymentBasicInfo.setName(cellList.get(1));
                    unemploymentBasicInfo.setIdNumber(cellList.get(3));
                    unemploymentBasicInfo.setBirthDate(cellList.get(5));

                    cellList = rowList.get(i + 2);
                    unemploymentBasicInfo.setTotalPaymentMonths(cellList.get(1));
                    unemploymentBasicInfo.setTransferEntitlementMonths(cellList.get(3));
                    unemploymentBasicInfo.setTotalEntitlementMonths(cellList.get(5));
                    cellList = rowList.get(i + 5);
                    unemploymentBasicInfo.setIsReceivingInsurance(cellList.get(2));
                    unemploymentBasicInfo.setCompanyName(cellList.get(4));
                    break;
                case "失业保险缴费明细":
                    if (!cellList.get(0).matches("\\d{6}")) {
                        continue;
                    }
                    YunnanIndividualRecordSheet.PaymentItem paymentItem = new YunnanIndividualRecordSheet.PaymentItem();
                    paymentItem.setPaymentPeriod(cellList.get(0));
                    paymentItem.setPaymentCategory(cellList.get(1));
                    paymentItem.setRefundStartDate(cellList.get(2));
                    paymentItem.setRefundEndDate(cellList.get(3));
                    paymentItem.setPaymentBase(cellList.get(4));
                    paymentItem.setCompanyContributionAmount(cellList.get(5));
                    paymentItem.setIndividualContributionAmount(cellList.get(6));
                    paymentItem.setCompanyContributionFlag(cellList.get(7));
                    paymentItem.setIndividualContributionFlag(cellList.get(8));
                    paymentItems.add(paymentItem);

                    break;
            }
        }
    }

    private List<List<String>> parseFileToRowList(String filePath) {
        // 1. 读取文件
        File pdf = new File(filePath);

        //页面所有table的记录，每一个元素代表下面一条记录cellList
        List<List<String>> rowList = new ArrayList<>();

        // 2. pdfbox读取PDDocument
        try (PDDocument pdfDocument = PDDocument.load(pdf)) {
            // 3. tabula新建ObjectExtractor和NurminenDetectionAlgorithm，同时准备接收表格Rectangle的结构
            ObjectExtractor objectExtractor = new ObjectExtractor(pdfDocument);
            SpreadsheetDetectionAlgorithm detectionAlgorithm = new SpreadsheetDetectionAlgorithm();
            Map<Integer, List<Rectangle>> pageNumber2RectangleListMap = new HashMap<>();//key为页的序号， value为对应的Rectangle的list

            // 4. 获取每页的PageIterator
            PageIterator pageIterator = objectExtractor.extract();

            // 5. 解析每页的Rectangle
            // 如果单页pdf中有多个Rectangle，则解析出来的List<Rectangle>会有多个对象
            while (pageIterator.hasNext()) {
                Page page = pageIterator.next();
                List<Rectangle> rectangleList = detectionAlgorithm.detect(page);
                if (rectangleList.size() > 0) {
                    pageNumber2RectangleListMap.put(page.getPageNumber(), rectangleList);
                }
            }

            // 6.通过table位置获取表格具体内容
            SpreadsheetExtractionAlgorithm extractionAlgorithm = new SpreadsheetExtractionAlgorithm();

            // 如果单页pdf中有多个表格，则解析出来的List<Rectangle>会有多个对象
            for (Map.Entry<Integer, List<Rectangle>> entry : pageNumber2RectangleListMap.entrySet()) {
                Page page = objectExtractor.extract(entry.getKey());
                Rectangle rectangle = null;

                List<Rectangle> rectangleList = entry.getValue();
                for (Rectangle r : rectangleList) {
                    double rectangleHeight = r.getHeight();
                    if (Double.compare(rectangleHeight, 0) > 0) {
                        rectangle = r;
                        break;
                    }
                }
                if (rectangle == null) {
                    throw new RuntimeException("rectangle is null.");
                }

                if (entry.getKey() > 1) {
                    rectangle.setTop(rectangle.getTop());
                }
                rectangle.setBottom(rectangle.getBottom() + 500);
                Page area = page.getArea(rectangle);

                // 如果每页有多个表格，解析每一个table
                List<Table> tableList = extractionAlgorithm.extract(area);
                for (Table table : tableList) {
                    for (int i = 0; i < table.getRowCount(); i++) {
                        List<String> cellList = new ArrayList<>();//一条记录，每个单元格占一个元素
                        for (int j = 0; j < table.getColCount(); j++) {
                            cellList.add(table.getCell(i, j).getText(false));
                        }
                        rowList.add(cellList);
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }

        return rowList;
    }

    private YunnanInsuranceParticipation parseYunnanInsuranceParticipation(String filePath) {
        YunnanInsuranceParticipation yunnanInsuranceParticipation = new YunnanInsuranceParticipation();

        YunnanInsuranceParticipation.WorkersInjuryInsuranceCertificate workersInjuryInsuranceCertificate = new YunnanInsuranceParticipation.WorkersInjuryInsuranceCertificate();
        YunnanInsuranceParticipation.UnemploymentInsuranceCertificate unemploymentInsuranceCertificate = new YunnanInsuranceParticipation.UnemploymentInsuranceCertificate();
        yunnanInsuranceParticipation.setWorkersInjuryInsuranceCertificate(workersInjuryInsuranceCertificate);
        yunnanInsuranceParticipation.setUnemploymentInsuranceCertificate(unemploymentInsuranceCertificate);
        List<List<String>> rowList = parseFileToRowList(filePath);
        parseListToBO(rowList, yunnanInsuranceParticipation);

        String pdfText = getPdfTextByStripper(filePath).replace(System.getProperty("line.separator", "\n"), StringUtils.EMPTY);

        String explanation = pdfText.substring(pdfText.indexOf("打印日期：") + 5, pdfText.indexOf("说明")).trim();
        String tableCreator = pdfText.substring(pdfText.indexOf("制表人") + 4, pdfText.indexOf("1扫描二维码")).trim();
        String printDate = pdfText.substring(pdfText.indexOf("打印日期：") - 11, pdfText.indexOf("打印日期：")).replaceAll(" ", "");

        if (pdfText.contains("城镇职工基本养老保险")) {
            YunnanInsuranceParticipation.PensionInsuranceCertificate pensionInsuranceCertificate = yunnanInsuranceParticipation.getPensionInsuranceCertificate();
            pensionInsuranceCertificate.setExplanation(explanation);
            pensionInsuranceCertificate.setTableCreator(tableCreator);
            pensionInsuranceCertificate.setPrintDate(printDate);
        }
        if (pdfText.contains("机关事业单位")) {
            YunnanInsuranceParticipation.PensionInsuranceCertificate pensionInsuranceCertificate = yunnanInsuranceParticipation.getInstitutionsPensionInsuranceCertificate();
            pensionInsuranceCertificate.setExplanation(explanation);
            pensionInsuranceCertificate.setTableCreator(tableCreator);
            pensionInsuranceCertificate.setPrintDate(printDate);
        }

        return yunnanInsuranceParticipation;
    }

    private YunnanIndividualRecordSheet parseYunnanIndividualRecordSheet(String filePath) {
        YunnanIndividualRecordSheet yunnanIndividualRecordSheet = new YunnanIndividualRecordSheet();

        YunnanIndividualRecordSheet.EmploymentInjuryBasicInfo employmentInjuryBasicInfo = new YunnanIndividualRecordSheet.EmploymentInjuryBasicInfo();
        yunnanIndividualRecordSheet.setEmploymentInjuryBasicInfo(employmentInjuryBasicInfo);
        yunnanIndividualRecordSheet.setInstitutionEmploymentInjuryBasicInfo(employmentInjuryBasicInfo);


        String pdfText = getPdfTextByStripper2(filePath).replace(System.getProperty("line.separator", "\n"), StringUtils.EMPTY);

        String period = pdfText.substring(pdfText.indexOf("个人权益记录单") + 7, pdfText.indexOf("年度")).trim();
        String idCardNumber, name;
        if (pdfText.contains("身份证号")) {
            name = pdfText.substring(pdfText.indexOf("姓名") + 3, pdfText.indexOf("身份证号")).trim();
            idCardNumber = pdfText.substring(pdfText.indexOf("身份证号") + 4, pdfText.indexOf("性别")).trim();
        } else {
            name = pdfText.substring(pdfText.indexOf("姓名") + 3, pdfText.indexOf("证件证号")).trim();
            if (pdfText.contains("性别")) {
                idCardNumber = pdfText.substring(pdfText.indexOf("证件证号") + 4, pdfText.indexOf("性别")).trim();
            } else {
                idCardNumber = pdfText.substring(pdfText.lastIndexOf("证件证号") + 4, pdfText.lastIndexOf("机关事业工伤")).trim();

            }
        }
        employmentInjuryBasicInfo.setName(name);
        employmentInjuryBasicInfo.setIdCardNumber(idCardNumber);
        yunnanIndividualRecordSheet.setYear(period);

        List<List<String>> rowList = parseFileToRowList(filePath);
        parseListToBO(rowList, yunnanIndividualRecordSheet);

        String employeeInsuranceInfotext = pdfText.substring(pdfText.lastIndexOf("参保状态") + 4).trim();

        Pattern pattern = Pattern.compile("(暂停缴费\\（中断\\）|参保缴费)(?=.+)");
        Matcher matcher = pattern.matcher(employeeInsuranceInfotext);
        List<String> splitInputs = new ArrayList<>();
        int start = 0;
        while (matcher.find()) {
            if (start != matcher.start()) {

                splitInputs.add(employeeInsuranceInfotext.substring(start, matcher.end()).trim());
            }
            start = matcher.end();
        }
        if (start < employeeInsuranceInfotext.length()) {
            splitInputs.add(employeeInsuranceInfotext.substring(start).trim());
        }

        List<YunnanIndividualRecordSheet.EmployeeInsuranceInfo> employeeInsuranceInfos = yunnanIndividualRecordSheet.getEmployeeInsuranceInfos();
        for (int i = 0; i < employeeInsuranceInfos.size(); i++) {
            YunnanIndividualRecordSheet.EmployeeInsuranceInfo employeeInsuranceInfo = employeeInsuranceInfos.get(i);
            String[] row = splitInputs.get(i).split("\\s+");
            if (row[0].contains(employeeInsuranceInfo.getPersonalId())) {
                if (row.length > 2) {  //NOSONAR
                    employeeInsuranceInfo.setInsuranceDate(row[row.length - 2]);
                    employeeInsuranceInfo.setInsuranceStatus(row[row.length - 1]);
                }
            }
        }
        yunnanIndividualRecordSheet.setInstitutionEmploymentInjuryInfo(employeeInsuranceInfos);
        return yunnanIndividualRecordSheet;
    }

    public static void main(String[] args) {
        YunnanSocialSecurityPdfParser yunnanSocialSecurityPdfParser = new YunnanSocialSecurityPdfParser();
        String json, filePath;
        // 参保证明
//        filePath = "D:\\data\\file\\socialsecurity\\云南\\app-gjzwfw-dzsb_cbzm.pdf";
//        json = yunnanSocialSecurityPdfParser.parseYunnanSocialSecurityPdfParser("", filePath).getData();
//        System.out.println("json = " + json);

        // 权益单

        filePath = "D:\\data\\file\\socialsecurity\\云南\\app-gjzwfw-dzsb_qyd.pdf";
        json = yunnanSocialSecurityPdfParser.parseYunnanSocialSecurityPdfParser("", filePath).getData();
        System.out.println("json = " + json);
//        filePath = "D:\\data\\file\\socialsecurity\\云南\\app-gjzwfw-dzsb_qyd1.pdf";
//        json = yunnanSocialSecurityPdfParser.parseYunnanSocialSecurityPdfParser("", filePath).getData();
//        System.out.println("json = " + json);
    }

}
