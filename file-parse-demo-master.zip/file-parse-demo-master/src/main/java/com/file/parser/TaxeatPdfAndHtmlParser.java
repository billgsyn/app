package com.file.parser;

import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import lombok.extern.slf4j.Slf4j;

/**
 * 个税 + 任职单位 解析
 * @author anyspa
 */

@Slf4j
public class TaxeatPdfAndHtmlParser extends BaseDecryptPdfParser {

    private TaxeHtmlParser taxeHtmlParser = new TaxeHtmlParser();

    private IITPdfParser iitPdfParser = new IITPdfParser();

    public ResponseData<String> parseTaxeatPdfAndHtmlToJson(String daId, String filePath, String pdfPassword) {
        log.info("parseTaxeatPdfAndHtmlToJson started, daId:{}, filePath:{}", daId, filePath);
        String json = null;

        try {
            if (filePath.contains(".pdf")) {
                ResponseData<String> responseData1 = iitPdfParser.parseIITPdfToJson(daId, filePath, pdfPassword);
                if (responseData1.getErrorCode() == ErrorCode.SUCCESS.getCode()) {
                    json = responseData1.getData();
                } else {
                    return new ResponseData<>(null, responseData1.getErrorCode(), responseData1.getErrorMessage());
                }

            } else if (filePath.contains(".html")) {
                ResponseData<String> responseData2 = taxeHtmlParser.parseTaxeHtmlToJson(daId, filePath);
                if (responseData2.getErrorCode() == ErrorCode.SUCCESS.getCode()) {
                    json = responseData2.getData();
                } else {
                    return new ResponseData<>(null, responseData2.getErrorCode(), responseData2.getErrorMessage());
                }
            }
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseTaxeatPdfAndHtmlToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseTaxeatPdfAndHtmlToJson completed, daId:{}, filePath:{}, json:{}", daId, filePath, json);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    public static void main(String[] args) {

        String pdfFilePath = "D:\\data\\file\\taxeat\\de1x1wwn1532312506025029632_8e7b817ed75865954afbba24452f70fe_taxeat_nsjl.pdf";
        String htmlFilePath = "D:\\data\\file\\taxeat\\taxeat_employment.html";
        String passWord = "177918";

        TaxeatPdfAndHtmlParser taxeatPdfAndHtmlParser = new TaxeatPdfAndHtmlParser();
        ResponseData<String> responseData = taxeatPdfAndHtmlParser.parseTaxeatPdfAndHtmlToJson("dd", pdfFilePath, passWord);
        System.out.println(responseData.getData());

        TaxeHtmlParser taxeHtmlParser = new TaxeHtmlParser();
        responseData = taxeHtmlParser.parseTaxeHtmlToJson("dd", htmlFilePath);
        System.out.println(responseData.getData());

    }
}
