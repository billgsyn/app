package com.file.parser;


import com.file.bo.ResponseData;
import lombok.extern.slf4j.Slf4j;

/**
 * 交管12123APP行驶证、驾驶证、安全驾驶记录N合1解析
 * @author anyspa
 */

@Slf4j
public class AppTmriAnyParser {

    private AppTmriXszXmlParser appTmriXszXmlParser = new AppTmriXszXmlParser();

    private AppTmriJszHtmlParser appTmriJszHtmlParser = new AppTmriJszHtmlParser();

    private AppTmriJsjlPdfParser appTmriJsjlPdfParser = new AppTmriJsjlPdfParser();

    public ResponseData<String> parseAppTmriAnyToJson(String daId, String filePath) {
        if (filePath.contains("app-tmri-jsz")) {
            return appTmriJszHtmlParser.parseAppTmriJszHtmlToJson(daId, filePath);
        } else if (filePath.contains("tmri-xsz-car") || filePath.contains("tmri-xsz-jyhgbz") || filePath.contains("tmri-xsz-dzxsz")) {
            return appTmriXszXmlParser.parseAppTmriXszXmlToJson(daId, filePath);
        } else if (filePath.contains("app-tmri-jsjl")){
            return appTmriJsjlPdfParser.parseAppTmriJsjlPdfToJson(daId, filePath);
        } else {
            throw new RuntimeException("the file name is not supported");
        }
    }

//    public static void main(String[] args) {
//        AppTmriXszXmlParser appTmriXszXmlParser = new AppTmriXszXmlParser();
//        AppTmriJszHtmlParser appTmriJszHtmlParser = new AppTmriJszHtmlParser();
//        AppTmriJsjlPdfParser appTmriJsjlPdfParser = new AppTmriJsjlPdfParser();
//
//        // String filePath = "D:\\data\\file\\appTmriJsz\\app-tmri-jsz-dzjsz.html";
//        // String filePath = "D:\\data\\file\\appTmriXsz\\tmri-xsz-car.xml";
//        // String filePath = "D:\\data\\file\\appTmriXsz\\tmri-xsz-jyhgbz.xml";
//        String filePath = "D:\\data\\file\\appTmriJsjl\\app-tmri-jsjl_aqjsjl.pdf";
//        String json = "";
//
//        if (filePath.contains("app-tmri-jsz")) {
//            json = appTmriJszHtmlParser.parseAppTmriJszHtmlToJson("", filePath).getData();
//        } else if (filePath.contains("tmri-xsz-car") || filePath.contains("tmri-xsz-jyhgbz")){
//            json = appTmriXszXmlParser.parseAppTmriXszXmlToJson("", filePath).getData();
//        } else if (filePath.contains("app-tmri-jsjl")){
//            json = appTmriJsjlPdfParser.parseAppTmriJsjlPdfToJson("", filePath).getData();
//        }
//        System.out.println(json);
//    }
}