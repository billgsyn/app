package com.file.parser;

import com.file.bo.ResponseData;
import com.file.bo.mail.CITIC;
import com.file.bo.mail.CITICTran;
import com.file.constant.ErrorCode;
import com.file.parser.traprange.PDFTableExtractor;
import com.file.util.JsonUtils;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class CITICPdfParser extends BasePdfParser {

	private static final Integer CITIC_PDF_HEADER_LINE_NUMBER = 8;
	private static final Integer CITIC_PDF_FOOTER_LINE_NUMBER = 14;

	public ResponseData<String> parseCITICPdfToJson(String daId, String filePath) {
		log.info("parseCITICPdfToJson started, daId:{}", daId);
		String json = null;

		try {
			CITIC icbc = parseCITICPdf(filePath);
			json = JsonUtils.convertObjectToJson(icbc);
		} catch (Exception e) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseCITICPdfToJson failed", e);
			return new ResponseData<String>(json, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
					ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
		}

		log.info("parseCITICPdfToJson completed, daId:{}", daId);
		return new ResponseData<String>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
	}

	private CITIC parseCITICPdf(String filePath) {
		CITIC citic = parseCITICHeader(filePath);
		List<CITICTran> citicTrans = parseCITICTrans(filePath);
		try {
			citicTrans = parseRecipient(filePath, citicTrans);
		} catch (Exception e) {
			log.warn("parseRecipient failed", e);
		}
		citic.setCiticTrans(citicTrans);
		log.info("citic = " + citic);
		return citic;
	}

	private CITIC parseCITICHeader(String filePath) {
		CITIC citic = new CITIC();
		String pdfHeaderText = parsePdfHeaderText(filePath);
		String accountName = pdfHeaderText.substring(pdfHeaderText.indexOf("户名：") + 3, pdfHeaderText.indexOf("证件类型"))
				.trim();
		String idType = pdfHeaderText.substring(pdfHeaderText.indexOf("证件类型：") + 5, pdfHeaderText.indexOf("证件号码"))
				.trim();
		String idNumber = pdfHeaderText
				.substring(pdfHeaderText.indexOf("证件号码：") + 5, pdfHeaderText.indexOf("Account name")).trim();
		String accountNo = pdfHeaderText.substring(pdfHeaderText.indexOf("账号：") + 3, pdfHeaderText.indexOf("时间段"))
				.trim();
		String inquiryPeriod = pdfHeaderText.substring(pdfHeaderText.indexOf("时间段：") + 4, pdfHeaderText.indexOf("开立日期"))
				.trim();
		String issuanceDate = pdfHeaderText
				.substring(pdfHeaderText.indexOf("开立日期：") + 5, pdfHeaderText.indexOf("Account number")).trim();
		String inquireTheMinimumLimit = pdfHeaderText
				.substring(pdfHeaderText.indexOf("查询最低限额：") + 7, pdfHeaderText.indexOf("币种")).trim();
		String currency = pdfHeaderText
				.substring(pdfHeaderText.indexOf("币种：") + 3, pdfHeaderText.indexOf("Inquire the minimum limit")).trim();
		citic.setAccountName(accountName);
		citic.setIdType(idType);
		citic.setIdNumber(idNumber);
		citic.setAccountNo(accountNo);
		citic.setInquiryPeriod(inquiryPeriod);
		citic.setIssuanceDate(issuanceDate);
		citic.setInquireTheMinimumLimit(inquireTheMinimumLimit);
		citic.setCurrency(currency);

		return citic;
	}

	private List<CITICTran> parseCITICTrans(String filePath) {
		List<CITICTran> citicTrans = new ArrayList<>();

		String transText = parseTransToText(filePath);
		if (Strings.isNullOrEmpty(transText)) {
			return citicTrans;
		}

		List<List<String>> tranFieldsList = parseTransTextToTranFieldsList(transText);

		for (int i = 0; i < tranFieldsList.size(); i++) {
			List<String> strings = tranFieldsList.get(i);
			if (StringUtils.containsAny(strings.get(0), "交易日期", "Transaction", "date", "声明")
					|| StringUtils.contains(strings.get(3), "Account paid")) {
				continue;
			}
			if (strings.size() == 8) {
				if (StringUtils.isNotBlank(strings.get(0))) {
					CITICTran citicTran = new CITICTran();
					citicTran.setTransactionDate(strings.get(0));
					citicTran.setAccountSeqNo(strings.get(1));
					citicTran.setAccountReceivable(strings.get(2));
					citicTran.setAccountPaid(strings.get(3));
					citicTran.setAccountBalance(strings.get(4));
					citicTran.setDescription(strings.get(5));
					citicTran.setRecipient(strings.get(6));
					citicTran.setReversalFlag(strings.get(7));
					citicTrans.add(citicTran);
				}
			}
			// 账户余额交易摘要 粘到一起了
			else if (strings.size() == 7) {
				if (StringUtils.isNotBlank(strings.get(0))) {
					CITICTran citicTran = new CITICTran();
					citicTran.setTransactionDate(strings.get(0));
					citicTran.setAccountSeqNo(strings.get(1));
					citicTran.setAccountReceivable(strings.get(2));
					citicTran.setAccountPaid(strings.get(3));
					parseAccountBalanceAndDescription(strings.get(4), citicTran);
					citicTran.setRecipient(strings.get(5));
					citicTran.setReversalFlag(strings.get(6));
					citicTrans.add(citicTran);
				}
			}
		}

		return citicTrans;
	}

	private void parseAccountBalanceAndDescription(String text, CITICTran citicTran) {
		Pattern pattern = Pattern.compile("[A-Z]{2,5}\\s*\\d{1,9}.\\d{2}");
		Matcher matcher = pattern.matcher(text.trim());
		if (matcher.find()) {
			citicTran.setAccountBalance(matcher.group());
			citicTran.setDescription(text.substring(matcher.end()));
		} else {
			citicTran.setDescription(text);
		}
	}

	private String parseTransToText(String filePath) {
		PDFTableExtractor extractor = (new PDFTableExtractor()).setSource(filePath);
		int pdfPageNumber = getPdfPageNumber(filePath);
		// 去掉第一页的Header，
		int[] skipFirstPageHeaderLinesIndexes = new int[CITIC_PDF_HEADER_LINE_NUMBER];
		for (int i = 0; i < CITIC_PDF_HEADER_LINE_NUMBER; i++) {
			skipFirstPageHeaderLinesIndexes[i] = i;
		}
		extractor.exceptLine(0, skipFirstPageHeaderLinesIndexes);

		// 去掉Footer
		if (pdfPageNumber == 1) {
			int[] skipLastPageFooterLinesIndexes = new int[CITIC_PDF_FOOTER_LINE_NUMBER - 1];
			for (int j = 0; j < CITIC_PDF_FOOTER_LINE_NUMBER - 1; j++) {
				skipLastPageFooterLinesIndexes[j] = -(j + 1);
			}
			extractor.exceptLine(0, skipLastPageFooterLinesIndexes);
		} else {
			// 去掉非最后一页的Footer
			for (int i = 1; i < pdfPageNumber; i++) {
				int[] skipLinesInNoneLastPage = {-1};
				extractor.exceptLine(i - 1, skipLinesInNoneLastPage);
			}

			// 去掉最后一页的Footer,两种情况
			int lineNumberInLastPdf = getLineNumberInLastPage(filePath, pdfPageNumber);
			// 1.footer文本行完整展现在最后一页PDF,则直接排除最后一页的footer文本行
			if (lineNumberInLastPdf >= CITIC_PDF_FOOTER_LINE_NUMBER) {
				int[] skipLastPageFooterLinesIndexes = new int[CITIC_PDF_FOOTER_LINE_NUMBER];
				for (int j = 0; j < CITIC_PDF_FOOTER_LINE_NUMBER; j++) {
					skipLastPageFooterLinesIndexes[j] = -(j + 1);
				}
				extractor.exceptLine(pdfPageNumber - 1, skipLastPageFooterLinesIndexes);
			} else {
				// 2.footer文本行拆分在倒数第一页和倒数第二页，则直接排除最后一页和倒数第二页的WECHAT_FOOTER_LINE_NO-lineNumberInLastPdf
				extractor.exceptPage(pdfPageNumber - 1);

				// 由于第一页和倒数第二页都包含了页码, 而CITIC_PDF_FOOTER_LINE_NUMBER只计算了footer没有跨页的行数,
				// 所以此时要排除掉的FOOTER_LINE_NUMBER应该是 (CITIC_PDF_FOOTER_LINE_NUMBER + 1)
				int footerLinesNumberInlastSecondPage = (CITIC_PDF_FOOTER_LINE_NUMBER + 1) - lineNumberInLastPdf;
				int[] skipLastSecondPageFooterLinesIndexes = new int[footerLinesNumberInlastSecondPage];
				for (int k = 0; k < footerLinesNumberInlastSecondPage; k++) {
					skipLastSecondPageFooterLinesIndexes[k] = -(k + 1);
				}
				extractor.exceptLine(pdfPageNumber - 2, skipLastSecondPageFooterLinesIndexes);
			}
		}

		String text = extractPdfToText(extractor);
		return text;
	}

	public List<CITICTran> parseRecipient(String filePath, List<CITICTran> citicTrans) {
		String pdfText = getPdfTextByStripper(filePath);
		pdfText = pdfText.replace(System.getProperty("line.separator", "\n"), " ");

		// 此处一行的格式2021-09-01 000001 RMB 650.00 RMB 6.30
		Pattern pattern1 = Pattern
				.compile("\\d{4}-\\d{2}-\\d{2}\\s\\d{6}\\s\\S{1,5}\\s\\d{1,9}.\\d{2}\\s\\S{1,5}\\s\\d{1,9}.\\d{2}");
		Matcher matcher1 = pattern1.matcher(pdfText);

		// 每行交易记录的第一个字所在的index
		int tranIndex = 0;
		Map<Integer, Integer> tranTextStartIndexMap = new HashMap<>();

		while (matcher1.find()) {
			// log.info(
			// 		"Match \"" + matcher1.group() + "\" at positions " + matcher1.start() + "-" + (matcher1.end() - 1));
			tranTextStartIndexMap.put(tranIndex, matcher1.start());
			tranIndex++;
		}

		// 找出每行交易记录的文本
		List<String> tranTextList = new ArrayList<>();
		for (int i = 1; i < tranTextStartIndexMap.size(); i++) {
			String tranText = pdfText.substring(tranTextStartIndexMap.get(i - 1), tranTextStartIndexMap.get(i));
			if (tranText.contains("交易日期")) {
				tranText = tranText.substring(0, tranText.indexOf("/") - 4).trim();
			}
			log.info(tranText);
			tranTextList.add(tranText);
		}

		String lastTranText = pdfText.substring(tranTextStartIndexMap.get(tranTextStartIndexMap.size() - 1));
		lastTranText = lastTranText.substring(0, lastTranText.indexOf("声明：")).trim();
		tranTextList.add(lastTranText);

		// 找出每行交易里的对手信息的值
		// 此处一行除去对手户名的格式 2021-09-14 000001 RMB 50.00 RMB 52.15 支付宝
		Pattern pattern2 = Pattern
				.compile("\\d{4}-\\d{2}-\\d{2}\\s\\d{6}\\s\\S{1,5}\\s\\d{1,9}.\\d{2}\\s\\S{1,5}\\s\\d{1,9}.\\d{2}\\s\\S{0,20}");
		for (int i = 0; i < citicTrans.size(); i++) {
			Matcher matcher2 = pattern2.matcher(tranTextList.get(i));
			while (matcher2.find()) {
				// 对方户名 + 被冲账标识(N),
				String recipient = tranTextList.get(i).substring(matcher2.end()).trim();
				// 被冲账标识占最后一个字符位置
				recipient = recipient.substring(0, recipient.length() - 1).trim();
				citicTrans.get(i).setRecipient(recipient.replace(" ", ""));
			}
		}

		return citicTrans;
	}

	public static void main(String[] args) {
		CITICPdfParser citicPdfParser = new CITICPdfParser();
//		CITIC citic = citicPdfParser.parseCITICPdf("E:\\data\\files\\CITIC\\de1tuknz1544880316366438400_88b152c595005f6ee1233d0730935d43_beehive-citicb_jyls-0.pdf");
//		CITIC citic = citicPdfParser.parseCITICPdf("E:\\data\\files\\CITIC\\dc30ax5p1509137172253540352_0bd58a277d3548dff827dfcb9ce8c537_URCP_001_ECPS_ZXLS_b90a12fb1f1547fba2589ea1ae04c6f2_20220329.pdf");
		CITIC citic = citicPdfParser.parseCITICPdf("D:\\data\\files\\CITIC\\zd4g3dtt1579048133126680576_b5cab76533a10fd1c0f9cfe3a617a317_beehive-citicb_jyls-0.pdf");

		String json = JsonUtils.convertObjectToJson(citic);
		System.out.println(json);
	}

}
