package com.file.parser.socialsecurity;

import com.file.bo.ResponseData;
import com.file.bo.socialsecurity.ChongqingIndividualRecordSheet;
import com.file.bo.socialsecurity.ChongqingInsuranceParticipation;
import com.file.constant.ErrorCode;
import com.file.parser.BasePdfParser;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import technology.tabula.*;
import technology.tabula.detectors.SpreadsheetDetectionAlgorithm;
import technology.tabula.extractors.SpreadsheetExtractionAlgorithm;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Slf4j
public class ChongqingSocialSecurityPdfParser extends BasePdfParser {

    public ResponseData<String> parseCongqingSocialSecurityPdfToJson(String daId, String filePath) {
        log.info("parseCongqingSocialSecurityPdfToJson started, daId:{}", daId);
        String json = null;
        try {
            if (filePath.contains("cbzm")) {
                ChongqingInsuranceParticipation chongqingInsuranceParticipation = parseChongqingInsuranceParticipation(filePath);
                json = JsonUtils.convertObjectToJson(chongqingInsuranceParticipation);
            } else if (filePath.contains("qyd")) {
                ChongqingIndividualRecordSheet congqingIndividualRecordSheet = parseChongqingIndividualRecordSheet(filePath);
                json = JsonUtils.convertObjectToJson(congqingIndividualRecordSheet);
            } else {
                log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseCongqingSocialSecurityPdfToJson failed, new type not supported");
                return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
            }
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseCongqingSocialSecurityPdfToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseCongqingSocialSecurityPdfToJson completed, daId:{}", daId);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private ChongqingInsuranceParticipation parseChongqingInsuranceParticipation(String filePath) {
        ChongqingInsuranceParticipation chongqingInsuranceParticipation = parseInsuranceParticipationHeader(filePath);
        Map<Integer, List<List<String>>> rowMap = parseFileToRowList(filePath);
        List<List<String>> rowList = new ArrayList<>();
        rowMap.values().forEach(rowList::addAll);
        parseListToBO(rowList, chongqingInsuranceParticipation);

        return chongqingInsuranceParticipation;
    }

    private ChongqingIndividualRecordSheet parseChongqingIndividualRecordSheet(String filePath) {
        ChongqingIndividualRecordSheet congqingIndividualRecordSheet = parseIndividualRecordSheetHeader(filePath);
        Map<Integer, List<List<String>>> rowMap = parseFileToRowList(filePath);
        parseListToBO(rowMap, congqingIndividualRecordSheet);

        return congqingIndividualRecordSheet;
    }

    private ChongqingIndividualRecordSheet parseIndividualRecordSheetHeader(String filePath) {
        ChongqingIndividualRecordSheet congqingIndividualRecordSheet = new ChongqingIndividualRecordSheet();
        String pdfHeader = getPdfTextByStripper(filePath).replace(System.getProperty("line.separator", "\n"), StringUtils.EMPTY);
        ;

        String recordPeriod = pdfHeader.substring(pdfHeader.indexOf("权益记录（ ") + 5, pdfHeader.indexOf("）")).trim();
        recordPeriod = removeSpaces(recordPeriod);
        recordPeriod = recordPeriod.replaceAll("\\D", "");
        congqingIndividualRecordSheet.setRecordPeriod(recordPeriod + "年1月至" + recordPeriod + "年12月");
        String verifyDescription = pdfHeader.substring(pdfHeader.indexOf("说明：") + 3).trim();
        congqingIndividualRecordSheet.setVerifyDescription(verifyDescription);
        return congqingIndividualRecordSheet;
    }

    private void parseListToBO(List<List<String>> rowList, ChongqingInsuranceParticipation chongqingInsuranceParticipation) {
        String sectionName = "";
        List<ChongqingInsuranceParticipation.InsuranceBasicInfo> insuranceBasicInfos = new ArrayList<>();
        List<ChongqingInsuranceParticipation.InsuranceDetail> insuranceDetails = new ArrayList<>();

        for (List<String> cellList : rowList) {
            if (StringUtils.equalsAny(cellList.get(0), "险种")) {
                sectionName = "险种";
                continue;
            } else if (StringUtils.equalsAny(cellList.get(0), "缴费月份")) {
                sectionName = "缴费月份";
                continue;
            } else if (StringUtils.equalsAny(cellList.get(0), "(二)参保缴费明细", "说明")) {
                continue;
            }

            switch (sectionName) {//NOSONAR
                case "险种":
                    if (StringUtils.isBlank(cellList.get(0))) {
                        break;
                    }
                    ChongqingInsuranceParticipation.InsuranceBasicInfo insuranceBasicInfo = new ChongqingInsuranceParticipation.InsuranceBasicInfo();

                    insuranceBasicInfo.setInsuranceType(cellList.get(0));
                    insuranceBasicInfo.setCurrentPaymentStatus(cellList.get(1));
                    insuranceBasicInfo.setActualPaymentMonths(cellList.get(2));
                    insuranceBasicInfos.add(insuranceBasicInfo);
                    break;
                case "缴费月份":
                    if (StringUtils.isBlank(cellList.get(0)) || StringUtils.equals("说明:", cellList.get(0))) {
                        break;
                    }
                    ChongqingInsuranceParticipation.InsuranceDetail insuranceDetail = new ChongqingInsuranceParticipation.InsuranceDetail();
                    insuranceDetail.setPaymentMonth(cellList.get(0));

                    ChongqingInsuranceParticipation.PensionInsurance pensionInsurance = new ChongqingInsuranceParticipation.PensionInsurance();
                    insuranceDetail.setPensionInsurance(pensionInsurance);
                    pensionInsurance.setInsuranceType(cellList.get(1));
                    pensionInsurance.setUnitId(cellList.get(2));
                    pensionInsurance.setPaymentBase(cellList.get(3));
                    pensionInsurance.setIndividualContribution(cellList.get(4));
                    pensionInsurance.setUnitContribution(cellList.get(5));
                    pensionInsurance.setPaymentLocation(cellList.get(6));

                    ChongqingInsuranceParticipation.UnemploymentInsurance unemploymentInsurance = new ChongqingInsuranceParticipation.UnemploymentInsurance();
                    insuranceDetail.setUnemploymentInsurance(unemploymentInsurance);
                    unemploymentInsurance.setUnitId(cellList.get(7));
                    unemploymentInsurance.setPaymentBase(cellList.get(8));
                    unemploymentInsurance.setIndividualContribution(cellList.get(9));
                    unemploymentInsurance.setUnitContribution(cellList.get(10));
                    unemploymentInsurance.setPaymentLocation(cellList.get(11));

                    ChongqingInsuranceParticipation.WorkInjuryInsurance workInjuryInsurance = new ChongqingInsuranceParticipation.WorkInjuryInsurance();
                    insuranceDetail.setWorkInjuryInsurance(workInjuryInsurance);
                    workInjuryInsurance.setUnitId(cellList.get(12));
                    workInjuryInsurance.setPaymentBase(cellList.get(13));
                    workInjuryInsurance.setIndividualContribution(cellList.get(14));
                    workInjuryInsurance.setUnitContribution(cellList.get(15));
                    workInjuryInsurance.setPaymentLocation(cellList.get(16));
                    insuranceDetails.add(insuranceDetail);
                    break;
            }
        }
        chongqingInsuranceParticipation.setBasicInfos(insuranceBasicInfos);
        chongqingInsuranceParticipation.setInsuranceDetails(insuranceDetails);
    }

    private void parseListToBO(Map<Integer, List<List<String>>> rowMap, ChongqingIndividualRecordSheet congqingIndividualRecordSheet) {
        String sectionName = "";
        ChongqingIndividualRecordSheet.PersonalBasicInformation personalBasicInformation = new ChongqingIndividualRecordSheet.PersonalBasicInformation();
        List<ChongqingIndividualRecordSheet.WorkersYearPaymentStatusOfUrbanEmployeeInsuredPersons> workersYearPaymentList = new ArrayList<>();
        List<ChongqingIndividualRecordSheet.ResidentYearPaymentStatusOfUrbanEmployeeInsuredPersons> residentYearPaymentList = new ArrayList<>();
        List<ChongqingIndividualRecordSheet.PersonalAccountInformationOfPensionInsurance> personalAccountList = new ArrayList<>();
        congqingIndividualRecordSheet.setPersonalBasicInformation(personalBasicInformation);
        congqingIndividualRecordSheet.setWorkersYearPaymentList(workersYearPaymentList);
        congqingIndividualRecordSheet.setResidentYearPaymentList(residentYearPaymentList);
        congqingIndividualRecordSheet.setPersonalAccountList(personalAccountList);

        // 解析pdf第一页的表格
        for (int i = 0; i < rowMap.get(1).size(); i++) {
            List<String> cellList = rowMap.get(1).get(i);
            if (StringUtils.equals(cellList.get(0), "姓名")) {
                sectionName = "姓名";
            } else if (StringUtils.equalsAny(cellList.get(0), "证件类型")) {
                sectionName = "证件类型";
            } else if (StringUtils.equalsAny(cellList.get(0), "本地首次参保时间")) {
                sectionName = "本地首次参保时间";
                continue;
            } else if (StringUtils.equalsAny(cellList.get(0), "职工参保人员本年度缴费情况")) {
                sectionName = "职工参保人员本年度缴费情况";
                continue;
            } else if (StringUtils.equalsAny(cellList.get(0), "城乡居民参保人员本年度缴费情况")) {
                sectionName = "城乡居民参保人员本年度缴费情况";
                continue;
            } else if (StringUtils.equalsAny(cellList.get(0), "养老保险个人账户情况")) {
                sectionName = "养老保险个人账户情况";
                continue;
            } else if (StringUtils.equalsAny(cellList.get(0), "序号")) {
                continue;
            }

            switch (sectionName) {//NOSONAR
                case "姓名":
                    personalBasicInformation.setName(cellList.get(1));
                    personalBasicInformation.setGender(cellList.get(3));
                    personalBasicInformation.setSocialSecurityNumber(cellList.get(5));
                    break;
                case "证件类型":
                    personalBasicInformation.setIdType(cellList.get(1));
                    personalBasicInformation.setIdNo(removeSpaces(cellList.get(3)));
                    break;
                case "本地首次参保时间":
                    ChongqingIndividualRecordSheet.LocalInsuranceYearMonth localInsuranceYearMonth = new ChongqingIndividualRecordSheet.LocalInsuranceYearMonth();
                    localInsuranceYearMonth.setEnterpriseWorkPension(removeSpaces(cellList.get(1)));
                    localInsuranceYearMonth.setCauseWorkPension(removeSpaces(cellList.get(2)));
                    localInsuranceYearMonth.setUrbanResidentsPension(removeSpaces(cellList.get(3)));
                    localInsuranceYearMonth.setInjuryInsurance(removeSpaces(cellList.get(4)));
                    localInsuranceYearMonth.setUnemploymentInsurance(removeSpaces(cellList.get(5)));
                    personalBasicInformation.setLocalInsuranceYearMonth(localInsuranceYearMonth);
                    break;
                case "职工参保人员本年度缴费情况":
                    ChongqingIndividualRecordSheet.WorkersYearPaymentStatusOfUrbanEmployeeInsuredPersons workersYearPayment = new ChongqingIndividualRecordSheet.WorkersYearPaymentStatusOfUrbanEmployeeInsuredPersons();
                    if (StringUtils.isBlank(cellList.get(0))) {
                        break;
                    }

                    workersYearPayment.setId(cellList.get(0));
                    workersYearPayment.setType(cellList.get(1));
                    workersYearPayment.setPaymentBaseTotal(removeSpaces(cellList.get(2)));
                    workersYearPayment.setPersonalPaymentAmount(removeSpaces(cellList.get(3)));
                    workersYearPayment.setYearPaymentMonths(removeSpaces(cellList.get(4)));
                    workersYearPayment.setTotalPaymentMonths(removeSpaces(cellList.get(5)));
                    workersYearPaymentList.add(workersYearPayment);
                    break;
                case "城乡居民参保人员本年度缴费情况":
                    if (StringUtils.isBlank(cellList.get(0))) {
                        break;
                    }
                    ChongqingIndividualRecordSheet.ResidentYearPaymentStatusOfUrbanEmployeeInsuredPersons residentYearPayment = new ChongqingIndividualRecordSheet.ResidentYearPaymentStatusOfUrbanEmployeeInsuredPersons();
                    residentYearPayment.setId(cellList.get(0));
                    residentYearPayment.setType(cellList.get(1));
                    residentYearPayment.setPersonalPaymentAmount(removeSpaces(cellList.get(2)));
                    residentYearPayment.setTeamSubsidyAmount(removeSpaces(cellList.get(3)));
                    residentYearPayment.setGovernmentSubsidiesAmount(removeSpaces(cellList.get(4)));
                    residentYearPayment.setTotalPaymentYear(removeSpaces(cellList.get(5)));
                    residentYearPaymentList.add(residentYearPayment);
                    break;
                case "养老保险个人账户情况":
                    if (StringUtils.contains(cellList.get(0), "养老保险待遇享受情况")) {
                        return;
                    }
                    ChongqingIndividualRecordSheet.PersonalAccountInformationOfPensionInsurance personalAccount = new ChongqingIndividualRecordSheet.PersonalAccountInformationOfPensionInsurance();
                    personalAccount.setId(cellList.get(0));
                    personalAccount.setType(cellList.get(1));
                    personalAccount.setEndYearPrivateAccountTotalAmount(removeSpaces(cellList.get(2)));
                    personalAccount.setCurrentYearAccountingAmount(removeSpaces(cellList.get(3)));
                    personalAccount.setCurrentYearAccountingInterest(removeSpaces(cellList.get(4)));
                    personalAccount.setEndOfThisYearAccumulatedAccountStorageAmount(removeSpaces(cellList.get(5)));
                    personalAccountList.add(personalAccount);
                    break;
                default:

            }
        }

    }

    private String removeSpaces(String content) {
        if (StringUtils.isBlank(content)) {
            return "";
        }
        return content.replace(" ", "");
    }

    private ChongqingInsuranceParticipation parseInsuranceParticipationHeader(String filePath) {
        ChongqingInsuranceParticipation chongqingInsuranceParticipation = new ChongqingInsuranceParticipation();
        String pdfHeader = getPdfTextByStripper(filePath).replace(System.getProperty("line.separator", "\n"), StringUtils.EMPTY);
        String name = pdfHeader.substring(pdfHeader.indexOf("参保人姓名: ") + 6, pdfHeader.indexOf("性别"));
        chongqingInsuranceParticipation.setName(name);
        String gender = pdfHeader.substring(pdfHeader.indexOf("性别") + 3, pdfHeader.indexOf("社会保障号码")).trim();
        chongqingInsuranceParticipation.setGender(gender);
        String socialSecurityNumber = pdfHeader.substring(pdfHeader.indexOf("社会保障号码") + 7, pdfHeader.indexOf("(一)历年参保基本情况")).trim();
        chongqingInsuranceParticipation.setSocialSecurityNumber(socialSecurityNumber);
        String verifyDescription = pdfHeader.substring(pdfHeader.indexOf("说明:") + 3, pdfHeader.indexOf("请使用手机")).trim();
        chongqingInsuranceParticipation.setVerifyDescription(verifyDescription);
        String printTime = pdfHeader.substring(pdfHeader.indexOf("打印日期") + 5, pdfHeader.indexOf("说明")).trim();
        chongqingInsuranceParticipation.setPrintTime(printTime);
        return chongqingInsuranceParticipation;
    }

    private Map<Integer, List<List<String>>> parseFileToRowList(String filePath) {
        // 1. 读取文件
        File pdf = new File(filePath);

        //页面所有table的记录，每一个元素代表下面一条记录cellList
        Map<Integer, List<List<String>>> rowMap = new HashMap<>();

        // 2. pdfbox读取PDDocument
        try (PDDocument pdfDocument = PDDocument.load(pdf)) {
            // 3. tabula新建ObjectExtractor和NurminenDetectionAlgorithm，同时准备接收表格Rectangle的结构
            ObjectExtractor objectExtractor = new ObjectExtractor(pdfDocument);
            SpreadsheetDetectionAlgorithm detectionAlgorithm = new SpreadsheetDetectionAlgorithm();
            Map<Integer, List<Rectangle>> pageNumber2RectangleListMap = new HashMap<>();//key为页的序号， value为对应的Rectangle的list

            // 4. 获取每页的PageIterator
            PageIterator pageIterator = objectExtractor.extract();

            // 5. 解析每页的Rectangle
            // 如果单页pdf中有多个Rectangle，则解析出来的List<Rectangle>会有多个对象
            while (pageIterator.hasNext()) {
                Page page = pageIterator.next();
                List<Rectangle> rectangleList = detectionAlgorithm.detect(page);
                if (rectangleList.size() > 0) {
                    pageNumber2RectangleListMap.put(page.getPageNumber(), rectangleList);
                }
            }

            // 6.通过table位置获取表格具体内容
            SpreadsheetExtractionAlgorithm extractionAlgorithm = new SpreadsheetExtractionAlgorithm();

            // 如果单页pdf中有多个表格，则解析出来的List<Rectangle>会有多个对象
            for (Map.Entry<Integer, List<Rectangle>> entry : pageNumber2RectangleListMap.entrySet()) {
                List<List<String>> rowList = new ArrayList<>();
                Page page = objectExtractor.extract(entry.getKey());

                List<Rectangle> rectangleList = entry.getValue();
                for (Rectangle rectangle : rectangleList) {
                    if (Double.compare(rectangle.getHeight(), 0.0) == 0) {
                        continue;
                    }
                    rectangle.setBottom(rectangle.getBottom() + 10);
                    Page area = page.getArea(rectangle);
                    // 如果每页有多个表格，解析每一个table
                    List<Table> tableList = extractionAlgorithm.extract(area);
                    for (Table table : tableList) {
                        for (int i = 0; i < table.getRowCount(); i++) {
                            List<String> cellList = new ArrayList<>();//一条记录，每个单元格占一个元素
                            for (int j = 0; j < table.getColCount(); j++) {
                                cellList.add(table.getCell(i, j).getText(false));
                            }
                            rowList.add(cellList);
                        }
                    }
                    rowMap.put(page.getPageNumber(), rowList);
                }

            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }

        return rowMap;
    }

    public static void main(String[] args) {
        String filePath, json;
//        // 参保证明
//        filePath = "D:\\data\\files\\socialsecurity\\重庆\\zd47iaqw1767589620583682048_app-gjzwfw-dzsb_origins\\app-gjzwfw-dzsb_cbzm.pdf";
//        json = new ChongqingSocialSecurityPdfParser().parseCongqingSocialSecurityPdfToJson("daId", filePath).getData();
//        System.out.println(json);
//
//        filePath = "D:\\data\\files\\socialsecurity\\重庆\\zd47iaqw1767589620583682048_app-gjzwfw-dzsb_origins\\app-gjzwfw-dzsb_cbzm.pdf";
//        json = new ChongqingSocialSecurityPdfParser().parseCongqingSocialSecurityPdfToJson("daId", filePath).getData();
//        System.out.println(json);
//
//        filePath = "D:\\data\\files\\socialsecurity\\重庆\\zd47iaqw1767668528574717952_app-gjzwfw-dzsb_origins\\app-gjzwfw-dzsb_cbzm.pdf";
//        json = new ChongqingSocialSecurityPdfParser().parseCongqingSocialSecurityPdfToJson("daId", filePath).getData();
//        System.out.println(json);
//

        //  权益单
        filePath = "D:\\data\\files\\socialsecurity\\重庆\\zd47iaqw1768192069884129280_app-gjzwfw-dzsb_origins\\app-gjzwfw-dzsb_qyd.pdf";
        json = new ChongqingSocialSecurityPdfParser().parseCongqingSocialSecurityPdfToJson("daId", filePath).getData();
        System.out.println(json);
    }
}
