package com.file.parser;

import com.file.bo.ResponseData;
import com.file.bo.mail.BCM;
import com.file.bo.mail.BCMTran;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import technology.tabula.*;
import technology.tabula.detectors.NurminenDetectionAlgorithm;
import technology.tabula.extractors.BasicExtractionAlgorithm;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 交通银行(包含交易对手版)pdf流水解析
 *
 * @author anyspa
 */

@Slf4j
public class BCMPdfParser1 extends BasePdfParser {

    public ResponseData<String> parseBCMPdfToJson(String daId, String filePath) {
        log.info("parseBCMPdfToJson1 started, daId:{}", daId);
        String json;

        try {
            BCM bcm = parseBCMPdf(filePath);
            json = JsonUtils.convertObjectToJson(bcm);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseBCMPdfToJson1 failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseBCMPdfToJson1 completed, daId:{}", daId);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    public BCM parseBCMPdf(String filePath) {
        BCM bcm = parseBCMHeader(filePath);

        List<List<String>> rowList = parseBCMTransToRowList(filePath);
        List<BCMTran> bcmTrans = parseBCMTrans(rowList);
        // 一行解析不出来
        if (bcmTrans.size() == 0) {
            bcmTrans = parseOneBCMTrans(filePath);
        }

        bcm.setBcmTrans(bcmTrans);

        log.info("BCM = {}", bcm);
        return bcm;
    }

    private BCM parseBCMHeader(String filePath) {
        BCM bcm = new BCM();
        String pdfHeaderText = parsePdfHeaderText(filePath);

        String department = pdfHeaderText.substring(pdfHeaderText.indexOf("部门Department: ") + 14, pdfHeaderText.indexOf("柜员Search")).trim();
        String teller = pdfHeaderText.substring(pdfHeaderText.indexOf("柜员Search Teller: ") + 17, pdfHeaderText.indexOf("打印日期")).trim();
        String printingDate = pdfHeaderText.substring(pdfHeaderText.indexOf("打印日期Printing Date: ") + 19, pdfHeaderText.indexOf("打印时间")).trim();
        String printingTime = pdfHeaderText.substring(pdfHeaderText.indexOf("打印时间Printing Time: ") + 19, pdfHeaderText.indexOf("账号/卡号")).trim();
        String accountNo = pdfHeaderText.substring(pdfHeaderText.indexOf("账号/卡号Account/Card No: ") + 22, pdfHeaderText.indexOf("户名Account")).trim();
        String accountName = pdfHeaderText.substring(pdfHeaderText.indexOf("户名Account Name: ") + 16, pdfHeaderText.indexOf("查询起日Query")).trim();
        String queryStartingDate = pdfHeaderText.substring(pdfHeaderText.indexOf("查询起日Query Starting Date: ") + 25, pdfHeaderText.indexOf("查询止日Query")).trim();
        String queryEndingDate = pdfHeaderText.substring(pdfHeaderText.indexOf("查询止日Query Ending Date: ") + 23, pdfHeaderText.indexOf("查询时间Query")).trim();
        String queryTime = pdfHeaderText.substring(pdfHeaderText.indexOf("查询时间Query Time: ") + 16, pdfHeaderText.indexOf("查询柜员Search")).trim();
        String searchTeller = "";
        String idType = "";
        String idNo = "";
        String currency = "";
        if (pdfHeaderText.contains("证件种类 ID Type")) {
            if (pdfHeaderText.indexOf("证件种类 ID Type") < pdfHeaderText.indexOf("币种Currency")) {
                searchTeller = pdfHeaderText.substring(pdfHeaderText.indexOf("查询柜员Search Teller: ") + 19, pdfHeaderText.indexOf("证件种类 ID Type")).trim();
            } else {
                searchTeller = pdfHeaderText.substring(pdfHeaderText.indexOf("查询柜员Search Teller: ") + 19, pdfHeaderText.indexOf("币种Currency")).trim();
            }
            idType = pdfHeaderText.substring(pdfHeaderText.indexOf("证件种类 ID Type: ") + 14, pdfHeaderText.indexOf("证件号码 ID Number")).trim();
            if (pdfHeaderText.indexOf("币种Currency") < pdfHeaderText.indexOf("Serial Payment") && pdfHeaderText.indexOf("币种Currency") > pdfHeaderText.indexOf("证件号码 ID Number: ") + 16) {
                idNo = pdfHeaderText.substring(pdfHeaderText.indexOf("证件号码 ID Number: ") + 16, pdfHeaderText.indexOf("币种Currency")).trim();
            } else {
                idNo = pdfHeaderText.substring(pdfHeaderText.indexOf("证件号码 ID Number: ") + 16, pdfHeaderText.indexOf("Serial Payment")).trim();
            }
        }
        // 内容错位
        if (pdfHeaderText.indexOf("币种Currency: ") < pdfHeaderText.indexOf("证件种类")) {
            currency = pdfHeaderText.substring(pdfHeaderText.indexOf("币种Currency: ") + 12, pdfHeaderText.indexOf("证件种类")).trim();
        }
        if (pdfHeaderText.indexOf("币种Currency: ") > pdfHeaderText.indexOf("证件种类")) {
            currency = pdfHeaderText.substring(pdfHeaderText.indexOf("币种Currency: ") + 12, pdfHeaderText.indexOf("Serial Payment")).trim();
        }

        bcm.setDepartment(department);
        bcm.setTeller(teller);
        bcm.setPrintingDate(printingDate);
        bcm.setPrintingTime(printingTime);
        bcm.setAccountNo(accountNo);
        bcm.setAccountName(accountName);
        bcm.setQueryStartingDate(queryStartingDate);
        bcm.setQueryEndingDate(queryEndingDate);
        bcm.setQueryTime(queryTime);
        bcm.setSearchTeller(searchTeller);
        bcm.setIdType(idType);
        bcm.setIdNo(idNo);
        bcm.setCurrency(currency);

        return bcm;
    }

    private List<BCMTran> parseBCMTrans(List<List<String>> rowList) {
        List<BCMTran> bcmTrans = new ArrayList<>();
        rowList.forEach(row -> {
            if (row.size() > 6) {
                if (!row.get(1).trim().matches("\\d{4}-\\d{2}-\\d{2}")) {
                    return;
                }
                BCMTran bcmTran = new BCMTran();
                bcmTran.setSerialNum(row.get(0));
                bcmTran.setTransDate(row.get(1));
                bcmTran.setTransTime(row.get(2));
                bcmTran.setTradingType(row.get(3));
                if (row.get(5).matches("借 Dr|贷 Cr")) {
                    row.remove(4);
                }
                bcmTran.setDcFlg(row.get(4));
                bcmTran.setTransAmt(row.get(5));
                bcmTran.setBalance(row.get(6));


                if (row.size() > 7) {
                    bcmTran.setPaymentReceiptAccount(row.get(7));
                } else {
                    bcmTran.setPaymentReceiptAccount("");
                    bcmTran.setPaymentReceiptAccountName("");
                    bcmTran.setTradingPlace("");
                }
                if (row.size() > 8) {
                    bcmTran.setPaymentReceiptAccountName(row.get(8));
                } else {
                    bcmTran.setPaymentReceiptAccountName("");
                    bcmTran.setTradingPlace("");
                }
                if (row.size() > 9) {
                    bcmTran.setTradingPlace(row.get(9));
                } else {
                    bcmTran.setTradingPlace("");
                }
                bcmTran.setSummary("");
                bcmTrans.add(bcmTran);
            }
        });
        return bcmTrans;
    }

    private List<BCMTran> parseOneBCMTrans(String filePath) {
        List<BCMTran> list = new ArrayList<>();
        String transText = getPdfTextByStripper(filePath);
        if (Strings.isNullOrEmpty(transText)) {
            return list;
        }
        if (transText.indexOf("打印完毕") > transText.indexOf("摘要")) {
            // 生成从ASCII 32到126组成的随机字符串, 替换默认的分隔符";"
            String separator =  "~" + RandomStringUtils.randomAscii(8) + "~";
            List<List<String>> tranFieldsList = parseTransTextToTranFieldsList(transText, separator);
            for (int i = 0; i < tranFieldsList.size(); i++) {
                List<String> strings = tranFieldsList.get(i);
                String[] contents = strings.get(0).split(" ");
                if (StringUtils.isNotBlank(contents[0]) && contents[0].matches("-?\\d+(\\.\\d+)?")) {
                    // 1 19.67汇兑 借 Dr2024-04-16 18:39:18 4,600.00 手机银行6217857000031407545 许丽秀 转账
                    BCMTran bcmTran = new BCMTran();
                    bcmTran.setSerialNum(contents[0]);
                    String secondTxt = contents[1];
                    String balance = secondTxt.replaceAll("[\\u4e00-\\u9fa5]", "");
                    bcmTran.setBalance(balance);

                    bcmTran.setTradingType(secondTxt.replaceAll(balance, ""));
                    String thirdTxt = contents[3];
                    String transDateTxt = thirdTxt.replaceAll("[a-zA-Z]", "");
                    String dcFlg = contents[2] + " " + thirdTxt.replaceAll(transDateTxt, "");

                    bcmTran.setDcFlg(dcFlg);
                    bcmTran.setTransDate(transDateTxt);
                    bcmTran.setTransTime(contents[4]);
                    bcmTran.setTransAmt(contents[5]);

                    String fourthTxt = contents[6];
                    String paymentReceiptAccount = fourthTxt.replaceAll("[\\u4e00-\\u9fa5]", "");
                    String tradingPlace = fourthTxt.replaceAll(paymentReceiptAccount, "");
                    bcmTran.setPaymentReceiptAccount(paymentReceiptAccount);
                    bcmTran.setTradingPlace(tradingPlace);

                    if (contents.length > 7) {
                        bcmTran.setPaymentReceiptAccountName(contents[7]);
                    }
                    if (contents.length > 8) {
                        bcmTran.setSummary(contents[8]);
                    }
                    list.add(bcmTran);
                }
            }
        }

        return list;
    }

    private List<List<String>> parseBCMTransToRowList(String filePath) {
        //页面所有table的记录，每一个元素代表下面一条记录cellList
        List<List<String>> rowList = new ArrayList<>();

        // 1. 读取文件
        File pdf = new File(filePath);

        // 2. pdfbox读取PDDocument
        try (PDDocument pdfDocument = PDDocument.load(pdf)) {

            // 3. tabula新建ObjectExtractor和NurminenDetectionAlgorithm，同时准备接收表格Rectangle的结构
            ObjectExtractor objectExtractor = new ObjectExtractor(pdfDocument);
            NurminenDetectionAlgorithm detectionAlgorithm = new NurminenDetectionAlgorithm();
            Map<Integer, List<Rectangle>> detectedTables = new HashMap<>();

            // 4. 获取每页的PageIterator
            PageIterator pages = objectExtractor.extract();

            // 5. 解析每页的Rectangle(table的位置)
            while (pages.hasNext()) {
                Page page = pages.next();
                List<Rectangle> tablesOnPage = detectionAlgorithm.detect(page);
                if (tablesOnPage.size() > 0) {
                    detectedTables.put(page.getPageNumber(), tablesOnPage);
                }
            }

            // 6.通过table位置获取表格具体内容
            BasicExtractionAlgorithm bea = new BasicExtractionAlgorithm();

            // 如果单页pdf中有多个表格，则解析出来的List<Rectangle>会有多个对象
            for (Map.Entry<Integer, List<Rectangle>> entry : detectedTables.entrySet()) {
                Page page = objectExtractor.extract(entry.getKey());
                // 默认每页只有一个表格，因此获取第0个rectangle

                Rectangle rectangle = null; //NOSONAR
                List<Rectangle> rectangleList = entry.getValue();
                for (Rectangle r : rectangleList) {
                    double rectangleHeight = r.getHeight();
                    if (Double.compare(rectangleHeight, 0) > 0) {
                        rectangle = r;
                        break;
                    }
                }
                if (rectangle == null) {
                    throw new RuntimeException("rectangle is null.");
                }

                rectangle.setTop(rectangle.getTop() - 5);
                // 过滤掉"摘要"
                rectangle.setRight(rectangle.getRight() - 71);
                rectangle.setBottom(rectangle.getBottom() + 700);
//                Rectangle rectangle = getRectangle(detectedTables, entry, page, 0);

                Page area = page.getArea(rectangle);

                List<Table> tableList = null;
                try {
                    tableList = bea.extract(area);
                } catch (Exception e) {
                    log.info("rectangle extract table fail.");
                    continue;
                }
                for (Table table : tableList) {
//                        System.out.print("=================第:" + page.getPageNumber() + "页");
//                        System.out.println(", 第:" + (k + 1) + "个表格, 共有:"  + table.getColCount() + "列, " + table.getRows().size() + "条记录");
//                        List<List<RectangularTextContainer>> rows = table.getRows();
//                        for (List<RectangularTextContainer> cells : rows) {
//                            List<String> list = new ArrayList<>();
//                            for (RectangularTextContainer cell : cells) {
//                                list.add(cell.getText());
//                            }
//                            System.out.println(StringUtils.join(list, "|"));
//                        }

                    for (int i = 0; i < table.getRowCount(); i++) {

                        // 过滤掉表头
                        if (StringUtils.containsAny(table.getCell(i, 0).getText(false), "um", "erial", "号")
                                || StringUtils.containsAny(table.getCell(i, 1).getText(false),
                                "Date", "日期", "* * * * * *", "借方发生额汇总", "Total amount")) {
                            continue;
                        }

                        List<String> cellList = new ArrayList<>();
                        // 将table的每一行, 转成cellList, 最后将table转成rowList
                        if (i > 0 && i < table.getRowCount() - 1) {
                            // 当前行序号为空, 跳过
                            if (StringUtils.isBlank(table.getCell(i, 0).getText(false))) {
                                continue;
                            }

                            // 判断是否当前这笔交易是否跨行
                            if (isTranWrapLines(table, i)) {
                                mergeTranWrapLineToOneLine(table, i, cellList);
                                rowList.add(cellList);
                            } else {
                                splitTranUnWarpLine(table, i, cellList);
                                rowList.add(cellList);
                            }
                        } else {
                            if (StringUtils.isBlank(table.getCell(i, 0).getText(false))) {
                                continue;
                            }
                            splitTranUnWarpLine(table, i, cellList);
                            rowList.add(cellList);
                        }
                    }
                }

            }

            return rowList;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private Rectangle getRectangle(Map<Integer, List<Rectangle>> detectedTables,
                                   Map.Entry<Integer, List<Rectangle>> entry, Page page, int index) {
        Rectangle rectangle = entry.getValue().get(index);

        rectangle.setLeft(rectangle.getLeft() - 20);

        // 多个Rectangle
        if (entry.getValue().size() > 1) {
            if ((index == entry.getValue().size() - 1)) {
                if (page.getPageNumber() == detectedTables.size()) {
                    // 处理pdf最后一页最后一个table部分交易解析不到
                    rectangle.setBottom(rectangle.getBottom() + 90);
                } else {
                    // 除最后一页外, 每页最后一个table
                    rectangle.setBottom(rectangle.getBottom() + 5);
                }
            } else {
                // 每页第一个table
                rectangle.setTop(rectangle.getTop() - 5);
                rectangle.setBottom(rectangle.getBottom() + 5);
            }
        } else {
            // 只有一个Rectangle
            // 每页第一个table (解决第一条交易跨行拿不到跨行的上一行)
            rectangle.setTop(rectangle.getTop() - 5);
            rectangle.setBottom(rectangle.getBottom() + 5);
        }
        rectangle.setTop(rectangle.getTop() - 5);
        // 过滤掉"摘要"
        rectangle.setRight(rectangle.getRight() - 71);
        return rectangle;
    }

    private void splitTranUnWarpLine(Table table, int index, List<String> cellList) {//NOSONAR
        List<String> currentRowCellList = table.getRows().get(index).stream().map(RectangularTextContainer::getText).collect(Collectors.toList());

        if (currentRowCellList.size() == 10) {
            // 序号|交易日期 交易时间 ||交易类型 |借贷|交易金额|余额|对方账户|对方户名|交易地点
            // 序号|交易日期 交易时间 ||交易类型 |借贷|交易金额|余额|对方账户 对方户名||交易地点
            for (int i = 0; i < currentRowCellList.size(); i++) {
                if (i == 1) {
                    cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                } else if (i == 2) {
                    continue;
                } else if (i == 7) {
                    if (StringUtils.isBlank(currentRowCellList.get(i))) {
                        cellList.add(""); // 对方账号
                        cellList.add(currentRowCellList.get(i + 1));
                        cellList.add(currentRowCellList.get(i + 2));
                    } else if (currentRowCellList.get(i).split(" ").length == 1) {
                        // 393000680018018000000
                        if (currentRowCellList.get(i).length() < 21) {
                            cellList.add(currentRowCellList.get(i));  // 对方账号
                            cellList.add(currentRowCellList.get(i + 1)); // 对方户名
                            cellList.add(currentRowCellList.get(i + 2));  // 交易地点
                        }
                        // 393000680018018000000江阴市澄南
                        else {
                            cellList.add(currentRowCellList.get(i).substring(0, 21)); // 对方账号
                            cellList.add(currentRowCellList.get(i).substring(21)); // 对方户名
                            cellList.add(currentRowCellList.get(i + 2)); // 交易地点
                        }
                    } else if (currentRowCellList.get(i).split(" ").length == 2) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" "))); // 对方账号 对方户名
                        cellList.add(currentRowCellList.get(i + 2)); // 交易地点
                    }
                } else {
                    if (i < 7) {
                        cellList.add(currentRowCellList.get(i));
                    }
                }
            }
        } else if (currentRowCellList.size() == 9) {
            if (currentRowCellList.get(4).matches("借 Dr|贷 Cr")) {
                // case1: 序号 | 交易日期 交易时间 ||交易类型 |借贷|交易金额|余额|对方账号 对方户名   | 交易地点
                // case2: 序号 | 交易日期 交易时间 ||交易类型 |借贷|交易金额|余额|对方账号          | 对方户名 交易地点
                for (int i = 0; i < currentRowCellList.size(); i++) {
                    if (i == 1) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else if (i == 2) {
                        continue;
                    } else if (i == 7) {
                        if (StringUtils.isBlank(currentRowCellList.get(i))) {
                            cellList.add(""); // 对方账号
                            cellList.addAll(Arrays.asList(currentRowCellList.get(i + 1).split(" "))); // 对方户名 交易地点
                        } else if (currentRowCellList.get(i).split(" ").length == 1) {
                            // 393000680018018000000
                            if (currentRowCellList.get(i).length() < 21) {
                                cellList.add(currentRowCellList.get(i));  // 对方账号
                                cellList.addAll(Arrays.asList(currentRowCellList.get(i + 1).split(" "))); // 对方户名 交易地点
                            }
                            // 393000680018018000000江阴市澄南
                            else {
                                cellList.add(currentRowCellList.get(i).substring(0, 21)); // 对方账号
                                cellList.add(currentRowCellList.get(i).substring(21)); // 对方户名
                                cellList.add(currentRowCellList.get(i + 1)); // 交易地点
                            }
                        } else if (currentRowCellList.get(i).split(" ").length == 2) {
                            // 369|2022-08-05 15:05:53 |代发工资|贷 Cr|676.00|7,482.33|393000680018018000000江阴市澄南 企业网银|
                            if (currentRowCellList.get(i).split(" ")[0].length() > 21) {
                                cellList.add(currentRowCellList.get(i).split(" ")[0].substring(0, 21)); // 对方账号
                                cellList.add(currentRowCellList.get(i).split(" ")[0].substring(21)); // 对方户名
                                cellList.add(currentRowCellList.get(i).split(" ")[1]); // 交易地点
                            } else {
                                cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" "))); // 对方账号 对方户名
                                cellList.add(currentRowCellList.get(i + 1)); // 交易地点
                            }
                        }
                    } else {
                        if (i < 7) {
                            cellList.add(currentRowCellList.get(i));
                        }
                    }
                }
            } else {
                // case3: 序号 | 交易日期 交易时间 |交易类型  |借贷|交易金额|余额|对方账号 |对方户名 |交易地点
                // case4: 序号 | 交易日期 交易时间 |交易类型  |借贷|交易金额|余额|对方账号 对方户名  ||交易地点
                for (int i = 0; i < currentRowCellList.size(); i++) {
                    if (i == 1) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else if (i == 6) {
                        if (StringUtils.isBlank(currentRowCellList.get(i))) {
                            cellList.add(""); // 对方账号
                            cellList.add(currentRowCellList.get(i + 1));
                            cellList.add(currentRowCellList.get(i + 2));
                        } else if (currentRowCellList.get(i).split(" ").length == 1) {
                            // 393000680018018000000
                            if (currentRowCellList.get(i).length() < 21) {
                                cellList.add(currentRowCellList.get(i));  // 对方账号
                                cellList.add(currentRowCellList.get(i + 1)); // 对方户名
                                cellList.add(currentRowCellList.get(i + 2));  // 交易地点
                            }
                            // 393000680018018000000江阴市澄南
                            else {
                                cellList.add(currentRowCellList.get(i).substring(0, 21)); // 对方账号
                                cellList.add(currentRowCellList.get(i).substring(21)); // 对方户名
                                cellList.add(currentRowCellList.get(i + 2)); // 交易地点
                            }
                        } else if (currentRowCellList.get(i).split(" ").length == 2) {
                            // 369|2022-08-05 15:05:53 |代发工资|贷 Cr|676.00|7,482.33|393000680018018000000江阴市澄南 企业网银||
                            if (currentRowCellList.get(i).split(" ")[0].length() > 21) {
                                cellList.add(currentRowCellList.get(i).split(" ")[0].substring(0, 21)); // 对方账号
                                cellList.add(currentRowCellList.get(i).split(" ")[0].substring(21)); // 对方户名
                                cellList.add(currentRowCellList.get(i).split(" ")[1]); // 交易地点
                            } else {
                                cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" "))); // 对方账号 对方户名
                                cellList.add(currentRowCellList.get(i + 2)); // 交易地点
                            }
                        }
                    } else {
                        if (i < 6) {
                            cellList.add(currentRowCellList.get(i));
                        }
                    }
                }
            }
        } else if (currentRowCellList.size() == 8) {
            if (currentRowCellList.get(2).matches("借 Dr|贷 Cr")) {
                // case1: 序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号| 对方户名 |交易地点
                // case2: 序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号 对方户名  ||交易地点
                for (int i = 0; i < currentRowCellList.size(); i++) {
                    if (i == 1) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else if (i == 5) {
                        if (StringUtils.isBlank(currentRowCellList.get(i))) {
                            cellList.add(""); // 对方账号
                            cellList.addAll(Arrays.asList(currentRowCellList.get(i + 1).split(" "))); // 对方户名 交易地点
                        } else if (currentRowCellList.get(i).split(" ").length == 1) {
                            // 393000680018018000000
                            if (currentRowCellList.get(i).length() < 21) {
                                cellList.add(currentRowCellList.get(i));  // 对方账号
                                if (currentRowCellList.get(i + 1).split(" ").length == 2) {
                                    cellList.addAll(Arrays.asList(currentRowCellList.get(i + 1).split(" "))); // 对方户名 交易地点
                                } else {
                                    cellList.add(currentRowCellList.get(i + 1)); // 对方户名
                                    cellList.add(currentRowCellList.get(i + 2)); // 交易地点
                                }
                            }
                            // 393000680018018000000江阴市澄南
                            else {
                                cellList.add(currentRowCellList.get(i).substring(0, 21)); // 对方账号
                                cellList.add(currentRowCellList.get(i).substring(21)); // 对方户名
                                cellList.add(currentRowCellList.get(i + 1)); // 交易地点
                            }
                        } else if (currentRowCellList.get(i).split(" ").length == 2) {
                            // 369|2022-08-05 15:05:53 代发工资|贷 Cr|676.00|7,482.33|393000680018018000000江阴市澄南 企业网银||
                            if (currentRowCellList.get(i).split(" ")[0].length() > 21) {
                                cellList.add(currentRowCellList.get(i).split(" ")[0].substring(0, 21)); // 对方账号
                                cellList.add(currentRowCellList.get(i).split(" ")[0].substring(21)); // 对方户名
                                cellList.add(currentRowCellList.get(i).split(" ")[1]); // 交易地点
                            } else {
                                cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" "))); // 对方账号 对方户名
                                cellList.add(currentRowCellList.get(i + 2)); // 交易地点
                            }
                        }
                    } else {
                        if (i < 5) {
                            cellList.add(currentRowCellList.get(i));
                        }
                    }
                }
            }
            // case3: 序号|交易日期 交易时间||交易类型|借贷|交易金额|余额|对方账号 对方户名 交易地点
            else if (currentRowCellList.get(4).matches("借 Dr|贷 Cr")) {
                // 949|2023-03-06 15:21:04||跨行汇款|贷 Cr|20,000.00|20,010.97|6223246718000000000 朱* 网上银行
                for (int i = 0; i < currentRowCellList.size(); i++) {
                    if (i == 1) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else if (i == 2) {
                        continue;
                    } else if (i == 7) {
                        List<String> list = Arrays.asList(currentRowCellList.get(i).split(" "));
                        // 325973500000000000000李四 批处理
                        if (list.size() > 0 && list.get(0).length() > 21) {
                            cellList.add(list.get(0).substring(0, 21));
                            cellList.add(list.get(0).substring(21));
                            if (list.size() > 1) {
                                cellList.add(list.get(1));
                            } else {
                                cellList.add("");
                            }
                        } else {
                            if (list.size() == 1) {
                                cellList.add(list.get(0));  // 对方账号
                                cellList.add("");  // 对方户名
                                cellList.add("");  // 交易地点
                            } else {
                                cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                            }
                        }
                    } else {
                        cellList.add(currentRowCellList.get(i));
                    }
                }
            }
            // case4: 序号|交易日期 交易时间|交易类型|借贷|交易金额|余额|对方账号        |对方户名 交易地点
            // case5: 序号|交易日期 交易时间|交易类型|借贷|交易金额|余额|对方账号 对方户名 |交易地点
            else if (currentRowCellList.get(3).matches("借 Dr|贷 Cr")) {
                for (int i = 0; i < currentRowCellList.size(); i++) {
                    if (i == 1) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else if (i == 6) {
                        if (StringUtils.isBlank(currentRowCellList.get(i))) {
                            cellList.add(""); // 对方账号
                            cellList.addAll(Arrays.asList(currentRowCellList.get(i + 1).split(" "))); // 对方户名 交易地点
                        } else if (currentRowCellList.get(i).split(" ").length == 1) {
                            // 393000680018018000000
                            if (currentRowCellList.get(i).length() < 21) {
                                cellList.add(currentRowCellList.get(i));  // 对方账号
                                cellList.addAll(Arrays.asList(currentRowCellList.get(i + 1).split(" "))); // 对方户名 交易地点
                            }
                            // 393000680018018000000江阴市澄南
                            else {
                                cellList.add(currentRowCellList.get(i).substring(0, 21)); // 对方账号
                                cellList.add(currentRowCellList.get(i).substring(21)); // 对方户名
                                cellList.add(currentRowCellList.get(i + 1)); // 交易地点
                            }
                        } else if (currentRowCellList.get(i).split(" ").length == 2) {
                            // 369|2022-08-05 15:05:53 代发工资|贷 Cr|676.00|7,482.33|393000680018018000000江阴市澄南 企业网银|
                            if (currentRowCellList.get(i).split(" ")[0].length() > 21) {
                                cellList.add(currentRowCellList.get(i).split(" ")[0].substring(0, 21)); // 对方账号
                                cellList.add(currentRowCellList.get(i).split(" ")[0].substring(21)); // 对方户名
                                cellList.add(currentRowCellList.get(i).split(" ")[1]); // 交易地点
                            } else {
                                cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" "))); // 对方账号 对方户名
                                cellList.add(currentRowCellList.get(i + 1)); // 交易地点
                            }
                        }
                    } else {
                        if (i < 6) {
                            cellList.add(currentRowCellList.get(i));
                        }
                    }
                }
            }
        } else if (currentRowCellList.size() == 7) {
            // case1: 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号         |对方户名  交易地点
            // case2: 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 对方户名 |交易地点
            if (currentRowCellList.get(2).matches("借 Dr|贷 Cr")) {
                for (int i = 0; i < currentRowCellList.size(); i++) {
                    if (i == 1) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else if (i == 5) {
                        if (StringUtils.isBlank(currentRowCellList.get(i))) {
                            cellList.add(""); // 对方账号
                            cellList.addAll(Arrays.asList(currentRowCellList.get(i + 1).split(" "))); // 对方户名 交易地点
                        } else if (currentRowCellList.get(i).split(" ").length == 1) {
                            // 393000680018018000000
                            if (currentRowCellList.get(i).length() < 21) {
                                cellList.add(currentRowCellList.get(i));  // 对方账号
                                cellList.addAll(Arrays.asList(currentRowCellList.get(i + 1).split(" "))); // 对方户名 交易地点
                            }
                            // 393000680018018000000江阴市澄南
                            else {
                                cellList.add(currentRowCellList.get(i).substring(0, 21)); // 对方账号
                                cellList.add(currentRowCellList.get(i).substring(21)); // 对方户名
                                cellList.add(currentRowCellList.get(i + 1)); // 交易地点
                            }
                        } else if (currentRowCellList.get(i).split(" ").length == 2) {
                            // 369|2022-08-05 15:05:53 代发工资|贷 Cr|676.00|7,482.33|393000680018018000000江阴市澄南 企业网银|
                            if (currentRowCellList.get(i).split(" ")[0].length() > 21) {
                                cellList.add(currentRowCellList.get(i).split(" ")[0].substring(0, 21)); // 对方账号
                                cellList.add(currentRowCellList.get(i).split(" ")[0].substring(21)); // 对方户名
                                cellList.add(currentRowCellList.get(i).split(" ")[1]); // 交易地点
                            } else {
                                cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" "))); // 对方账号 对方户名
                                cellList.add(currentRowCellList.get(i + 1)); // 交易地点
                            }
                        }
                    } else {
                        if (i < 5) {
                            cellList.add(currentRowCellList.get(i));
                        }
                    }
                }
            }
            // case3: 序号|交易日期 交易时间 |交易类型|借贷|交易金额 |余额|对方账号 对方户名  交易地点
            else if (currentRowCellList.get(3).matches("借 Dr|贷 Cr")) {
                for (int i = 0; i < currentRowCellList.size(); i++) {
                    if (i == 1) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else if (i == 6) {
                        if (Objects.equals(currentRowCellList.get(6).trim(), "批处理")) {
                            cellList.add("");  // 对方账号
                            cellList.add("");  // 对方户名
                            cellList.add(currentRowCellList.get(i));  // 交易地点
                        } else {
                            List<String> list = Arrays.asList(currentRowCellList.get(i).split(" "));
                            // 325973500000000000000李四 批处理
                            if (list.size() > 0 && list.get(0).length() > 21) {
                                cellList.add(list.get(0).substring(0, 21));
                                cellList.add(list.get(0).substring(21));
                                if (list.size() > 1) {
                                    cellList.add(list.get(1));
                                } else {
                                    cellList.add("");
                                }
                            } else {
                                if (list.size() == 1) {
                                    cellList.add(list.get(0));  // 对方账号
                                    cellList.add("");  // 对方户名
                                    cellList.add("");  // 交易地点
                                } else {
                                    cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                                }
                            }
                        }
                    } else {
                        cellList.add(currentRowCellList.get(i));
                    }
                }
            }
        } else if (currentRowCellList.size() == 6) {
            //  序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号  对方户名  交易地点
            if (currentRowCellList.get(2).matches("借 Dr|贷 Cr")) {
                for (int i = 0; i < currentRowCellList.size(); i++) {
                    if (i == 1) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else if (i == 5) {
                        if (Objects.equals(currentRowCellList.get(i).trim(), "批处理")) {
                            cellList.add("");
                            cellList.add("");
                            cellList.add(currentRowCellList.get(i));
                        } else if (StringUtils.isBlank(currentRowCellList.get(i))) {
                            cellList.add("");
                            cellList.add("");
                            cellList.add("");
                        } else {
                            List<String> list = Arrays.asList(currentRowCellList.get(i).split(" "));
                            // 325973500000000000000李四 批处理
                            if (list.size() > 0 && list.get(0).length() > 21) {
                                cellList.add(list.get(0).substring(0, 21));
                                cellList.add(list.get(0).substring(21));
                                if (list.size() > 1) {
                                    cellList.add(list.get(1));
                                } else {
                                    cellList.add("");
                                }
                            } else {
                                if (list.size() == 1) {
                                    cellList.add(list.get(0));  // 对方账号
                                    cellList.add("");  // 对方户名
                                    cellList.add("");  // 交易地点
                                } else {
                                    cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                                }
                            }
                        }
                    } else {
                        cellList.add(currentRowCellList.get(i));
                    }
                }
            }
            //  序号|交易日期 交易时间 |交易类型|借贷|交易金额|余额
            else if (currentRowCellList.get(3).matches("借 Dr|贷 Cr")) {
                for (int i = 0; i < currentRowCellList.size(); i++) {
                    if (i == 1) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else if (i == 5) {
                        cellList.add(currentRowCellList.get(i));
                        cellList.add("");
                        cellList.add("");
                        cellList.add("");
                    } else {
                        cellList.add(currentRowCellList.get(i));
                    }
                }
            }
        }
    }

    // 合并当前行与上一行、下一行
    private void mergeTranWrapLineToOneLine(Table table, int index, List<String> cellList) {
        List<String> currentRowCellList = table.getRows().get(index).stream().map(RectangularTextContainer::getText).collect(Collectors.toList());
        List<String> preRowCellList = table.getRows().get(index - 1).stream().map(RectangularTextContainer::getText).collect(Collectors.toList());
        List<String> nextRowCellList = table.getRows().get(index + 1).stream().map(RectangularTextContainer::getText).collect(Collectors.toList());

        if (currentRowCellList.size() == 10) {
            // 序号|交易日期   交易时间 ||交易类型 |借贷|交易金额|余额|对方账户|对方户名|交易地点
            // 序号|交易日期   交易时间 ||交易类型 |借贷|交易金额|余额|对方账户 对方户名||交易地点
            parseTenCellsCase(preRowCellList, currentRowCellList, nextRowCellList, cellList);
        } else if (currentRowCellList.size() == 9) {
            // case1: 序号 | 交易日期 交易时间 ||交易类型 |借贷|交易金额|余额|对方账号 对方户名   | 交易地点
            // case2: 序号 | 交易日期 交易时间 ||交易类型 |借贷|交易金额|余额|对方账号          | 对方户名 交易地点
            // case3: 序号 | 交易日期 交易时间 |交易类型  |借贷|交易金额|余额|对方账号 |对方户名 |交易地点
            // case4: 序号 | 交易日期 交易时间 |交易类型  |借贷|交易金额|余额|对方账号 对方户名  ||交易地点
            parseNineCellsCase(preRowCellList, currentRowCellList, nextRowCellList, cellList);
        } else if (currentRowCellList.size() == 8) {
            // case1: 序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号| 对方户名 |交易地点
            // case2: 序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号 对方户名  ||交易地点
            // case3: 序号|交易日期 交易时间|交易类型|借贷|交易金额|余额|对方账号        |对方户名 交易地点
            // case4: 序号|交易日期 交易时间|交易类型|借贷|交易金额|余额|对方账号 对方户名 |交易地点
            // case5: 序号|交易日期 交易时间||交易类型|借贷|交易金额|余额|对方账号 对方户名 交易地点
            parseEightCellsCase(preRowCellList, currentRowCellList, nextRowCellList, cellList);
        } else if (currentRowCellList.size() == 7) {
            // case1: 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号         |对方户名  交易地点
            // case2: 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 对方户名 |交易地点
            // case3: 序号|交易日期 交易时间 |交易类型|借贷|交易金额 |余额|对方账号 对方户名 交易地点
            parseSevenCellsCase(preRowCellList, currentRowCellList, nextRowCellList, cellList);
        } else if (currentRowCellList.size() == 6) {
            // case1、序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号  对方户名  交易地点
            parseSixCellsCase(preRowCellList, currentRowCellList, nextRowCellList, cellList);
        }
    }

    private void parseTenCellsCase(List<String> preRowCellList,
                                   List<String> currentRowCellList,
                                   List<String> nextRowCellList,
                                   List<String> cellList) {
        // 序号|交易日期   交易时间 ||交易类型 |借贷|交易金额|余额|对方账户|对方户名|交易地点
        // 序号|交易日期   交易时间 ||交易类型 |借贷|交易金额|余额|对方账户 对方户名||交易地点
        //    |                   ||网上银行卡转  |     |        |        |              |        |财付通支付科技有限公
        // 129|2022-12-30 15:44:50||           |贷 Cr |2,405.00|2,494.95|AW*****BZ     |张三     |
        //    |                   ||入          |     |        |        |              |        |司

        //    |                    ||       |     |    |        |393280012710300100001应付个人活期储蓄存款 ||
        //1558|2023-03-21 00:00:00||存款利息|贷 Cr|6.83|4,750.51|                                       ||批处理
        //   |                    ||       |     |    |        |499 利息                                ||
        for (int i = 0; i < currentRowCellList.size(); i++) {
            if (i == 1) {
                cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
            } else if (i == 2) {
                continue;
            } else if (i == 3) {
                cellList.add(preRowCellList.get(i) + currentRowCellList.get(i) + nextRowCellList.get(i));
            } else if (i == 7) {
                parseAccountAndAccountNameAndPlaceInLastThreeCell(preRowCellList, currentRowCellList, nextRowCellList, i, cellList);
            } else {
                if (i < 7) {
                    cellList.add(currentRowCellList.get(i));
                }
            }
        }
    }

    private void parseNineCellsCase(List<String> preRowCellList,
                                    List<String> currentRowCellList,
                                    List<String> nextRowCellList,
                                    List<String> cellList) {
        //  1: 序号 | 交易日期 交易时间 ||交易类型 |借贷|交易金额|余额|对方账号 对方户名   | 交易地点
        //  2: 序号 | 交易日期 交易时间 ||交易类型 |借贷|交易金额|余额|对方账号          | 对方户名 交易地点
        if (currentRowCellList.get(4).matches("借 Dr|贷 Cr")) {
            //     |                   ||            |     |         |         |                  |财付通支付科技有限公
            // 294 |2023-02-05 18:52:26||网上支付     |借 Dr|50.00    |269.97   |1000050001 微信转账|
            //     |                   ||            |     |         |         |                  |司

            //     |                   ||            |     |         |         |AW8BAGYFokUn3DNImkcQd  |财付通支付科技有限公
            // 297 |2023-02-09 17:43:50||其他交易     |贷 Cr |200.00  |2,532.97 |王五                    |
            //     |                   ||            |     |         |         |9mQ7BDqcyBZ            |司-

            //     |                   ||网上银行卡转  |     |         |         |财付通支付科技有限公 财付通支付科技有限公 |
            // 296 |2023-02-09 17:43:22||            |贷 Cr |2,197.00 |2,332.97 |24*****33                            |
            //     |                   ||入          |      |         |         |司                                   |司


            for (int i = 0; i < currentRowCellList.size(); i++) {
                if (i == 1) {
                    cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                } else if (i == 2) {
                    continue;
                } else if (i == 3) {
                    cellList.add(preRowCellList.get(i) + currentRowCellList.get(i) + nextRowCellList.get(i));
                } else if (i == 7) {
                    //case1 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 |对方户名 交易地点
                    //case2 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 对方户名 |交易地点
                    parseAccountAndAccountNameAndPlaceInLastTwoCell(preRowCellList, currentRowCellList, nextRowCellList, i, cellList);
                } else {
                    if (i < 7) {
                        cellList.add(currentRowCellList.get(i));
                    }
                }
            }

        }
        //  3: 序号 | 交易日期 交易时间 |交易类型  |借贷|交易金额|余额|对方账号 |对方户名 |交易地点
        //  4: 序号 | 交易日期 交易时间 |交易类型  |借贷|交易金额|余额|对方账号 对方户名  ||交易地点
        else {
            //     |                   |             |      |         |         |                   |常州车到家汽车服务有|
            //738  |2023-01-21 08:11:00|汇兑         |借 Dr  |3,25000 |47,518.93|10600401040227625  |                    |手机银行
            //     |                   |            |      |         |         |                   |限公司              |

            //     |                   |网上银行卡转  |      |         |        |                    ||财付通支付科技有限公
            //79  |2022-12-12 01:43:36|            |贷 Cr |946.34    |5,497.97|AW*****BZ 王五       ||
            //    |                   |入          |      |         |        |                     ||司

            for (int i = 0; i < currentRowCellList.size(); i++) {
                if (i == 1) {
                    cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                } else if (i == 2) {
                    cellList.add(preRowCellList.get(i) + currentRowCellList.get(i) + nextRowCellList.get(i));
                } else if (i == 6) {
                    //case3 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号| 对方户名 |交易地点
                    //case4 序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号 对方户名  ||交易地点
                    parseAccountAndAccountNameAndPlaceInLastThreeCell(preRowCellList, currentRowCellList, nextRowCellList, i, cellList);
                } else {
                    if (i < 6) {
                        cellList.add(currentRowCellList.get(i));
                    }
                }
            }
        }
    }

    private void parseEightCellsCase(List<String> preRowCellList,
                                     List<String> currentRowCellList,
                                     List<String> nextRowCellList,
                                     List<String> cellList) {
        //     |                           |      |       |       |          |       |财付通支付科技有限公
        //31  |2022-11-26 16:02:56 网上支付 |借 Dr |800.00 |41.51  |1000050001|微信转账 |
        //    |                           |      |       |       |          |        |司

        //     |                           |      |       |         |AW8BAGYFokUn3DNImkcQd   ||财付通支付科技有限公
        //188 |2023-01-11 11:46:53 其他交易 |贷 Cr |500.00  |4,278.08 |王兵                    ||
        //    |                           |      |        |         |9mQ7BDqcyBZ            ||司-
        //case1 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号| 对方户名 |交易地点
        //case2 序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号 对方户名  ||交易地点
        if (currentRowCellList.get(2).matches("借 Dr|贷 Cr")) {
            for (int i = 0; i < currentRowCellList.size(); i++) {
                if (i == 1) { // 交易日期 交易时间 交易类型
                    if (StringUtils.isBlank(preRowCellList.get(1))) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                        cellList.add(preRowCellList.get(1) + nextRowCellList.get(1));
                    }
                } else if (i == 5) {
                    //case1 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号| 对方户名 |交易地点
                    //case2 序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号 对方户名  ||交易地点
                    parseAccountAndAccountNameAndPlaceInLastThreeCell(preRowCellList, currentRowCellList, nextRowCellList, i, cellList);
                } else {
                    if (i < 5) {
                        cellList.add(currentRowCellList.get(i));
                    }
                }
            }
        }
        //    |                   |         |      |         |          |             |财付通支付科技有限公
        //213 |2023-01-19 23:28:22|网上支付  |借 Dr |4,062.00 |17,241.62 |1000050001   |微信转账
        //    |                   |        |      |         |          |             |司
        //     |                  |        |      |       |        |                      |财付通支付科技有限公
        //4   |2022-11-17 13:33:09|网上支付 |借 Dr |37.00  |180.05  |1000049901 扫二维码付款 |
        //    |                   |       |      |       |        |                      |司
        // case3 序号|交易日期 交易时间|交易类型|借贷|交易金额|余额|对方账号        |对方户名 交易地点
        // case4 序号|交易日期 交易时间|交易类型|借贷|交易金额|余额|对方账号 对方户名 |交易地点
        else if (currentRowCellList.get(3).matches("借 Dr|贷 Cr")) {
            for (int i = 0; i < currentRowCellList.size(); i++) {
                if (i == 1) {
                    cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                } else if (i == 2) {
                    cellList.add(preRowCellList.get(i) + currentRowCellList.get(i) + nextRowCellList.get(i));
                } else if (i == 6) {
                    // case3 序号|交易日期 交易时间|交易类型|借贷|交易金额|余额|对方账号        |对方户名 交易地点
                    // case4 序号|交易日期 交易时间|交易类型|借贷|交易金额|余额|对方账号 对方户名 |交易地点
                    parseAccountAndAccountNameAndPlaceInLastTwoCell(preRowCellList, currentRowCellList, nextRowCellList, i, cellList);
                } else {
                    if (i < 6) {
                        cellList.add(currentRowCellList.get(i));
                    }
                }
            }
        }
        //case5 序号|交易日期 交易时间||交易类型|借贷|交易金额|余额|对方账号 对方户名 交易地点
        else {
            for (int i = 0; i < currentRowCellList.size(); i++) {
                if (i == 1) {
                    cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                } else if (i == 2) {
                    continue;
                } else if (i == 3) {
                    cellList.add(preRowCellList.get(i) + currentRowCellList.get(i) + nextRowCellList.get(i));
                } else if (i == 7) {
                    // case5 序号|交易日期 交易时间||交易类型|借贷|交易金额|余额|对方账号 对方户名 交易地点
                    parseAccountAndAccountNameAndPlaceInLastOneCell(preRowCellList, currentRowCellList, nextRowCellList, i, cellList);
                } else {
                    cellList.add(currentRowCellList.get(i));
                }
            }
        }
    }

    private void parseSevenCellsCase(List<String> preRowCellList,
                                     List<String> currentRowCellList,
                                     List<String> nextRowCellList,
                                     List<String> cellList) {
        //     |网上银行卡转          |      |         |          |           |财付通支付科技有限公 财付通支付科技有限公
        //45  |2022-12-02 10:20:38  |贷 Cr |1,234.00 |1,836.73  |24*****33  |
        //    |入                   |      |         |          |           |司 司

        //    |                           |      |         |       |                     |财付通支付科技有限公
        //4  |2022-11-17 13:33:09 网上支付 |借 Dr |37.00    |180.05 |1000049901 扫二维码付款 |
        //   |                           |      |         |       |                      |司

        //    |                     |网上银行卡转|     |        |         |财付通支付科技有限公 财付通支付科技有限公
        //472 |2022-09-26 08:31:33  |          |贷 Cr|9,990.84|9,991.17 |24*****33
        //    |                     |入        |     |        |         |司 司

        for (int i = 0; i < currentRowCellList.size(); i++) {
            //case1 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 |对方户名 交易地点
            //case2 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 对方户名 |交易地点
            if (currentRowCellList.get(2).matches("借 Dr|贷 Cr")) {
                if (i == 1) { // 交易日期 交易时间 交易类型
                    if (StringUtils.isBlank(preRowCellList.get(1))) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                        cellList.add(preRowCellList.get(1) + nextRowCellList.get(1));
                    }
                } else if (i == 5) {
                    //case1 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 |对方户名 交易地点
                    //case2 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 对方户名 |交易地点
                    parseAccountAndAccountNameAndPlaceInLastTwoCell(preRowCellList, currentRowCellList, nextRowCellList, i, cellList);
                } else {
                    if (i < 5) {
                        cellList.add(currentRowCellList.get(i));
                    }
                }
            }
            //case3 序号|交易日期 交易时间 |交易类型|借贷|交易金额 |余额|对方账号 对方户名 交易地点
            else if (currentRowCellList.get(3).matches("借 Dr|贷 Cr")) {
                if (i == 1) { // 交易日期 交易时间
                    if (StringUtils.isBlank(preRowCellList.get(1))) {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    } else {
                        cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                        cellList.add(preRowCellList.get(1) + nextRowCellList.get(1));
                    }
                } else if (i == 2) {
                    cellList.add(preRowCellList.get(2) + nextRowCellList.get(2));
                } else if (i == 6) {
                    //case3 序号|交易日期 交易时间 |交易类型|借贷|交易金额 |余额|对方账号 对方户名 交易地点
                    parseAccountAndAccountNameAndPlaceInLastOneCell(preRowCellList, currentRowCellList, nextRowCellList, i, cellList);
                } else {
                    cellList.add(currentRowCellList.get(i));
                }
            }
        }
    }

    private void parseSixCellsCase(List<String> preRowCellList,
                                   List<String> currentRowCellList,
                                   List<String> nextRowCellList,
                                   List<String> cellList) {
        //     |                                |      |         |          |辽宁振兴银行(商户资
        //15  |2022-11-20 11:48:28 其他交易      |贷 Cr |1,408.05 |1,460.90  |6236430716600000000 王兵
        //    |                                |      |         |          |金结算)-

        //     |网上银行卡转                    |      |         |          |支付宝(中国)网络技 支付宝(中国)网络技
        //17  |2022-11-22 11:02:20           |贷 Cr |258.44   |519.34    |21*****90
        //    |入                            |      |         |          |术有限公司 术有限公司

        for (int i = 0; i < currentRowCellList.size(); i++) {
            if (i == 1) { // 交易日期 交易时间 交易类型
                if (StringUtils.isBlank(preRowCellList.get(1))) {
                    cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                } else {
                    cellList.addAll(Arrays.asList(currentRowCellList.get(i).split(" ")));
                    cellList.add(preRowCellList.get(1) + nextRowCellList.get(1));
                }
            } else if (i == 5) { // 对方账号  对方户名  交易地点
                //case 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 对方户名 交易地点
                parseAccountAndAccountNameAndPlaceInLastOneCell(preRowCellList, currentRowCellList, nextRowCellList, i, cellList);
            } else {
                cellList.add(currentRowCellList.get(i));
            }
        }
    }

    // |对方账号| 对方户名 |交易地点
    // |对方账号 对方户名  ||交易地点
    private void parseAccountAndAccountNameAndPlaceInLastThreeCell(List<String> preRowCellList,
                                                                   List<String> currentRowCellList,
                                                                   List<String> nextRowCellList,
                                                                   int i,
                                                                   List<String> cellList) {
        String preRowCell = preRowCellList.get(i);
        String currentRowCell = currentRowCellList.get(i);
        String nextRowCell = nextRowCellList.get(i);
        //case1 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号| 对方户名 |交易地点
        if ((StringUtils.isNotBlank(currentRowCell) && currentRowCell.split(" ").length == 1 && StringUtils.isBlank(preRowCell) && StringUtils.isBlank(nextRowCell))
                || StringUtils.isBlank(currentRowCell) && preRowCell.split(" ").length == 1 && nextRowCell.split(" ").length == 1) {
            //  |             |         |财付通支付科技有限公
            //  |1000050001   |微信转账   |
            //  |             |         |司

            //   |          |支付宝(中国)网络技 支付宝(中国)网络技|
            //  |215500690|                                |
            //  |         |术有限公司                        |术有限公司

            //  |             |                                     |
            //  |21*****87    |上海汇付支付有限公司 上海汇付支付有限公司   |
            //  |             |                                     |
            if (preRowCell.length() <= 21) {
                cellList.add(preRowCell + currentRowCell + nextRowCell);  // 对方账号
                if (currentRowCellList.get(i + 1).split(" ").length == 2) {
                    cellList.addAll(Arrays.asList(currentRowCellList.get(i + 1).split(" ")));
                } else if (preRowCellList.get(i + 1).split(" ").length == 2) {
                    cellList.add(preRowCellList.get(i + 1).split(" ")[0] + nextRowCellList.get(i + 1));  // 对方户名
                    cellList.add(preRowCellList.get(i + 1).split(" ")[1] + nextRowCellList.get(i + 2));  // 交易地点
                } else {
                    cellList.add(preRowCellList.get(i + 1) + currentRowCellList.get(i + 1) + nextRowCellList.get(i + 1));  // 对方户名
                    cellList.add(preRowCellList.get(i + 2) + currentRowCellList.get(i + 2) + nextRowCellList.get(i + 2));  // 交易地点
                }
            } else {
                if (nextRowCell.split(" ").length == 2) {
                    cellList.add(preRowCell.substring(0, 21) + nextRowCell.split(" ")[0]); // 对方账号
                    cellList.add(preRowCell.substring(21) + nextRowCell.split(" ")[1]); // 对方户名
                } else {
                    cellList.add(preRowCell.substring(0, 21) + nextRowCell.split(" ")[0]); // 对方账号
                    cellList.add(preRowCell.substring(21)); // 对方户名
                }
                // 交易地点
                cellList.add(preRowCellList.get(preRowCellList.size() - 1)
                        + currentRowCellList.get(currentRowCellList.size() - 1)
                        + nextRowCellList.get(nextRowCellList.size() - 1));
            }
        }
        // 序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号 对方户名  ||交易地点
        else {
            //     |                            |      |        |         |AW8BAGYFokUn3DNImkcQd  ||财付通支付科技有限公
            // 188|2023-01-11 11:46:53 其他交易  |贷 Cr |500.00  |4,278.08 |王兵                   ||
            //    |                            |      |        |         |9mQ7BDqcyBZ             ||司-

            // 对方账号 没有跨行, 对方户名可能跨行
            if (currentRowCell.matches("(([A-Za-z0-9_\\-]{2}(\\*+)[A-Za-z0-9_\\-]{2})|[A-Za-z0-9_\\-]{8,21})\\s*\\S*")) {
                // |1000049901 扫二维码付款   ||
                if (StringUtils.isBlank(preRowCell) && StringUtils.isBlank(nextRowCell) && currentRowCell.split(" ").length == 2) {
                    cellList.addAll(Arrays.asList(currentRowCell.split(" ")));
                    cellList.add(preRowCellList.get(i + 2) + currentRowCellList.get(i + 2) + nextRowCellList.get(i + 2));  // 交易地点
                } else if (preRowCell.split(" ").length >= 1 && currentRowCell.split(" ").length == 1 && nextRowCell.split(" ").length == 1) {
                    // |财付通支付科技有限公 ||财付通支付科技有限公
                    // |24*****33        ||
                    // |司               ||司
                    if (preRowCell.split(" ").length == 1) {
                        cellList.add(currentRowCell); // 对方账号
                        cellList.add(preRowCell + nextRowCell); // 对方户名
                        cellList.add(preRowCellList.get(i + 2) + currentRowCellList.get(i + 2) + nextRowCellList.get(i + 2)); // 交易地点
                    }
                    // |财付通支付科技有限公 财付通支付科技有限公 ||
                    // |24*****33        ||
                    // |司               ||司
                    else if (preRowCell.split(" ").length == 2) {
                        cellList.add(currentRowCell); // 对方账号
                        cellList.add(preRowCell.split(" ")[0] + nextRowCell); // 对方户名
                        cellList.add(preRowCell.split(" ")[1] + nextRowCellList.get(i + 2)); // 交易地点
                    }
                }
            }
            //  对方账号 对方户名均为空
            else if (StringUtils.isBlank(preRowCell) && StringUtils.isBlank(currentRowCell) && StringUtils.isBlank(nextRowCell)) {
                cellList.add(""); // 对方账号
                cellList.add(""); // 对方户名
                cellList.add(preRowCellList.get(i + 2) + currentRowCellList.get(i + 2) + nextRowCellList.get(i + 2)); // 交易地点
            }
            // 对方账号跨行, 对方户名可能跨行
            else {
                // |AW8BAGYFokUn3DNImkcQd    |财付通支付科技有限公
                // |王兵                      |
                // |9mQ7BDqcyBZ              |司-
                if (StringUtils.isNotBlank(currentRowCell)) {
                    cellList.add(preRowCell.split(" ")[0] + nextRowCell); // 对方账号
                    cellList.add(currentRowCell); // 对方户名
                    cellList.add(preRowCellList.get(i + 2) + currentRowCellList.get(i + 2) + nextRowCellList.get(i + 2)); // 交易地点
                }
                // |AW8BAGYFokUn3DNImkcQd 财付通支付科技有限公  |财付通支付科技有限公
                // |                                        |
                // |9mQ7BDqcyBZ          司                 |司
                else if (preRowCell.split(" ").length == 2) {
                    if (nextRowCell.split(" ").length == 2) {
                        cellList.add(preRowCell.split(" ")[0] + nextRowCell.split(" ")[0]); // 对方账号
                        cellList.add(preRowCell.split(" ")[1] + nextRowCell.split(" ")[1]); // 对方户名
                    }
                    cellList.add(preRowCellList.get(i + 2) + currentRowCellList.get(i + 2) + nextRowCellList.get(i + 2)); // 交易地点
                } else if (preRowCell.split(" ").length == 1) {
                    // |384320012710300000000应付个人活期储蓄存款 /
                    //
                    // |399 利息

                    // if (preRowCell.matches("[A-Za-z0-9_\\-]{8,21}\\S+")) {
                    if (preRowCell.trim().length() > 21) {
                        if (nextRowCell.split(" ").length == 2) {
                            cellList.add(preRowCell.substring(0, 21) + nextRowCell.split(" ")[0]); // 对方账号
                            cellList.add(preRowCell.substring(21) + nextRowCell.split(" ")[1]); // 对方户名
                        } else {
                            cellList.add(preRowCell.substring(0, 21) + nextRowCell.split(" ")[0]); // 对方账号
                            cellList.add(preRowCell.substring(21)); // 对方户名
                        }
                    }
                    // 交易地点
                    cellList.add(preRowCellList.get(preRowCellList.size() - 1)
                            + currentRowCellList.get(currentRowCellList.size() - 1)
                            + nextRowCellList.get(nextRowCellList.size() - 1));
                }
            }
        }
    }

    // |对方账号 |对方户名 交易地点
    // |对方账号 对方户名 |交易地点
    private void parseAccountAndAccountNameAndPlaceInLastTwoCell(List<String> preRowCellList,
                                                                 List<String> currentRowCellList,
                                                                 List<String> nextRowCellList,
                                                                 int i,
                                                                 List<String> cellList) {
        String preRowCell = preRowCellList.get(i);
        String currentRowCell = currentRowCellList.get(i);
        String nextRowCell = nextRowCellList.get(i);

        //case1 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 |对方户名 交易地点
        if ((StringUtils.isNotBlank(currentRowCell) && currentRowCell.split(" ").length == 1 && StringUtils.isBlank(preRowCell) && StringUtils.isBlank(nextRowCell))
                || StringUtils.isBlank(currentRowCell) && preRowCell.split(" ").length == 1 && nextRowCell.split(" ").length == 1) {
            //     |网上银行卡转                  |      |         |          |                  |财付通支付科技有限公 财付通支付科技有限公
            //45  |2022-12-02 10:20:38          |贷 Cr |1,234.00 |1,836.73  |24*****33         |
            //    |入                           |      |         |          |                  |司 司
            //
            //    |                            |      |         |          |                  |财付通支付科技有限公
            //68  |2022-12-09 15:59:20 网上支付 |借 Dr |80.00    |407.04    |1000107101        |扫二维码付款
            //    |                           |      |         |          |                  |司
            cellList.add(preRowCell + currentRowCell + nextRowCell);  // 对方账号
            // 对方户名 交易地点
            if (StringUtils.isNotBlank(currentRowCellList.get(i + 1))) {
                if (currentRowCellList.get(i + 1).split(" ").length == 2) {
                    // |1000107101  |扫二维码付款  财付通支付科技有限司
                    cellList.addAll(Arrays.asList(currentRowCellList.get(i + 1).split(" ")));
                } else {
                    // |财付通支付科技有限公
                    // |扫二维码付款
                    // |司
                    cellList.add(currentRowCellList.get(i + 1)); // 对方户名
                    cellList.add(preRowCellList.get(i + 1) + nextRowCellList.get(i + 1)); // 交易地点
                }
            } else {
                // |           |武进区湖塘哩柠哩檬服 财付通支付科技有限公
                // |1500947831 |
                // |           |装店 司
                List<String> preRowNameAndPlaceCellList = Arrays.asList(preRowCellList.get(i + 1).split(" "));
                List<String> nextRowNameAndPlaceCellList = Arrays.asList(nextRowCellList.get(i + 1).split(" "));
                // nextRowNameAndPlaceCellList 正常情况下，size=2
                if (preRowNameAndPlaceCellList.size() == 1) {
                    if (nextRowNameAndPlaceCellList.size() == 1) {
                        cellList.add(preRowNameAndPlaceCellList.get(0) + nextRowNameAndPlaceCellList.get(0));
                        cellList.add("");  // 交易地点
                    } else if (nextRowNameAndPlaceCellList.size() == 2) {
                        cellList.add(preRowNameAndPlaceCellList.get(0) + nextRowNameAndPlaceCellList.get(0));
                        cellList.add(nextRowNameAndPlaceCellList.get(1));  // 交易地点
                    }
                } else if (preRowNameAndPlaceCellList.size() == 2) {
                    if (nextRowNameAndPlaceCellList.size() == 1) {
                        cellList.add(preRowNameAndPlaceCellList.get(0) + nextRowNameAndPlaceCellList.get(0));
                        cellList.add(preRowNameAndPlaceCellList.get(1));  // 交易地点
                    } else if (nextRowNameAndPlaceCellList.size() == 2) {
                        cellList.add(preRowNameAndPlaceCellList.get(0) + nextRowNameAndPlaceCellList.get(0));
                        cellList.add(preRowNameAndPlaceCellList.get(1) + nextRowNameAndPlaceCellList.get(1));  // 交易地点
                    }
                }
            }
        }
        //case2 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 对方户名 |交易地点
        else {
            //     |                                |      |         |          |                       |财付通支付科技有限公
            //  4 |2022-11-17 13:33:09 网上支付      |借 Dr |37.00    |180.05    |1000049901 扫二维码付款   |
            //    |                                |      |         |          |                        |司

            //     |                              |      |         |          |AW8BAGYFokUn3DNImkcQd    |财付通支付科技有限公
            //  1 |2022-11-17 02:17:47 其他交易    |贷 Cr |1,995.56 |1,995.56  |王兵                      |
            //    |                              |      |         |          |9mQ7BDqcyBZ               |司-

            //     |网上银行卡转                 |      |         |          |财付通支付科技有限公 财付通支付科技有限公  |
            //  7 |2022-11-18 22:25:32         |贷 Cr |466.00   |610.25    |24*****33                           |
            //    |入                          |      |         |          |司                                  |司
            // 对方账号 没有跨行, 对方户名可能跨行
            if (currentRowCell.matches("(([A-Za-z0-9_\\-]{2}(\\*+)[A-Za-z0-9_\\-]{2})|[A-Za-z0-9_\\-]{8,21})\\s*\\S*")) {
                // |1000049901 扫二维码付款   |
                if (StringUtils.isBlank(preRowCell) && StringUtils.isBlank(nextRowCell) && currentRowCell.split(" ").length == 2) {
                    cellList.addAll(Arrays.asList(currentRowCell.split(" ")));
                    cellList.add(preRowCellList.get(i + 1) + currentRowCellList.get(i + 1) + nextRowCellList.get(i + 1));  // 交易地点
                } else if (preRowCell.split(" ").length >= 1 && currentRowCell.split(" ").length == 1 && nextRowCell.split(" ").length == 1) {
                    // |财付通支付科技有限公 |财付通支付科技有限公
                    // |24*****33
                    // |司                |司
                    if (preRowCell.split(" ").length == 1) {
                        cellList.add(currentRowCell); // 对方账号
                        cellList.add(preRowCell + nextRowCell); // 对方户名
                        cellList.add(preRowCellList.get(i + 1) + currentRowCellList.get(i + 1) + nextRowCellList.get(i + 1)); // 交易地点
                    }
                    // |财付通支付科技有限公 财付通支付科技有限公  |
                    // |24*****33
                    // |司                                  |司
                    else if (preRowCell.split(" ").length == 2) {
                        cellList.add(currentRowCell); // 对方账号
                        cellList.add(preRowCell.split(" ")[0] + nextRowCell); // 对方户名
                        cellList.add(preRowCell.split(" ")[1] + nextRowCellList.get(i + 1)); // 交易地点
                    }
                }
            }
            // 对方账号跨行, 对方户名可能跨行
            else {
                // |AW8BAGYFokUn3DNImkcQd    |财付通支付科技有限公
                // |王兵                      |
                // |9mQ7BDqcyBZ              |司-
                if (StringUtils.isNotBlank(currentRowCell)) {
                    // 102002013020990600000
                    // 微银行(资金清算) 网上银行
                    // 30
                    if (currentRowCell.split(" ").length == 2) {
                        cellList.add(preRowCell.split(" ")[0] + nextRowCell); // 对方账号
                        cellList.add(currentRowCell.split(" ")[0]); // 对方户名
                        cellList.add(currentRowCell.split(" ")[1]); // 交易地点
                    } else {
                        cellList.add(preRowCell.split(" ")[0] + nextRowCell); // 对方账号
                        cellList.add(currentRowCell); // 对方户名
                        cellList.add(preRowCellList.get(i + 1) + currentRowCellList.get(i + 1) + nextRowCellList.get(i + 1)); // 交易地点
                    }
                }
                // |AW8BAGYFokUn3DNImkcQd 财付通支付科技有限公  |财付通支付科技有限公
                // |                                        |
                // |9mQ7BDqcyBZ          司                 |司

                else if (preRowCell.split(" ").length == 2) {
                    if (nextRowCell.split(" ").length == 2) {
                        // 900001270103900100116马上消费金融股份有限 通联支付网络服务股
                        if (preRowCell.split(" ")[0].length() > 21) {
                            cellList.add(preRowCell.split(" ")[0].substring(0, 21) + nextRowCell.split(" ")[0]); // 对方账号
                            cellList.add(preRowCell.split(" ")[0].substring(21) + nextRowCell.split(" ")[1]); // 对方户名
                            cellList.add(preRowCell.split(" ")[1] + nextRowCellList.get(i + 1)); // 交易地点
                        } else {
                            cellList.add(preRowCell.split(" ")[0] + nextRowCell.split(" ")[0]); // 对方账号
                            cellList.add(preRowCell.split(" ")[1] + nextRowCell.split(" ")[1]); // 对方户名
                            cellList.add(preRowCellList.get(i + 1) + currentRowCellList.get(i + 1) + nextRowCellList.get(i + 1)); // 交易地点
                        }
                    } else {
                        // 900001270103900100116马上消费金融股份有限 通联支付网络服务股
                        if (preRowCell.split(" ")[0].length() > 21) {
                            cellList.add(preRowCell.split(" ")[0].substring(0, 21) + nextRowCell.split(" ")[0]); // 对方账号
                            cellList.add(preRowCell.split(" ")[0].substring(21)); // 对方户名
                            cellList.add(preRowCell.split(" ")[1] + nextRowCellList.get(i + 1)); // 交易地点
                        } else {
                            cellList.add(preRowCell.split(" ")[0] + nextRowCell.split(" ")[0]); // 对方账号
                            cellList.add(preRowCell.split(" ")[1]); // 对方户名
                            cellList.add(preRowCellList.get(i + 1) + currentRowCellList.get(i + 1) + nextRowCellList.get(i + 1)); // 交易地点
                        }
                    }
                } else if (preRowCell.split(" ").length == 1) {
                    // |384320012710300000000应付个人活期储蓄存款 /
                    //
                    // |399 利息

                    // if (preRowCell.matches("[A-Za-z0-9_\\-]{8,21}\\S+")) {
                    if (preRowCell.trim().length() > 21) {
                        if (nextRowCell.split(" ").length == 2) {
                            cellList.add(preRowCell.substring(0, 21) + nextRowCell.split(" ")[0]); // 对方账号
                            cellList.add(preRowCell.substring(21) + nextRowCell.split(" ")[1]); // 对方户名
                        } else {
                            cellList.add(preRowCell.substring(0, 21) + nextRowCell.split(" ")[0]); // 对方账号
                            cellList.add(preRowCell.substring(21)); // 对方户名
                        }
                    }
                    // 交易地点
                    cellList.add(preRowCellList.get(preRowCellList.size() - 1)
                            + currentRowCellList.get(currentRowCellList.size() - 1)
                            + nextRowCellList.get(nextRowCellList.size() - 1));
                }
            }
        }
    }

    // |对方账号 对方户名 交易地点
    private void parseAccountAndAccountNameAndPlaceInLastOneCell(List<String> preRowCellList,
                                                                 List<String> currentRowCellList,
                                                                 List<String> nextRowCellList,
                                                                 int i,
                                                                 List<String> cellList) {
        List<String> preAccountAndNameAndPlaceList = Arrays.asList(preRowCellList.get(i).split(" "));
        List<String> currentAccountAndNameAndPlaceList = Arrays.asList(currentRowCellList.get(i).split(" "));
        List<String> nextAccountAndNameAndPlaceList = Arrays.asList(nextRowCellList.get(i).split(" "));

        // case1.1: 对方账号、对方户名、交易地点三个字段, 至少有一个没有跨行
        if (currentAccountAndNameAndPlaceList.size() > 0) {
            String currentAccountAndNameAndPlaceListFirstText = currentAccountAndNameAndPlaceList.get(0);
            // 21*****90
            // 6236430716600000000 王兵
            // 6228480049000000000 张三 手机银行
            if (currentAccountAndNameAndPlaceListFirstText.matches("([A-Za-z0-9_\\-]{2}(\\*+)[A-Za-z0-9_\\-]{2})|[A-Za-z0-9_\\-]{8,21}")) {
                // 支付宝(中国)网络技 支付宝(中国)网络技
                // 21*****90
                // 术有限公司 术有限公司
                // case1.1.1 :对方账号没有跨行
                if (currentAccountAndNameAndPlaceList.size() == 1) {
                    cellList.add(currentAccountAndNameAndPlaceListFirstText); // 对方账号
                    if (preAccountAndNameAndPlaceList.size() == 2) {
                        if (nextAccountAndNameAndPlaceList.size() == 2) {
                            cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 对方户名
                            cellList.add(preAccountAndNameAndPlaceList.get(1) + nextAccountAndNameAndPlaceList.get(1)); // 交易地点
                        } else if (nextAccountAndNameAndPlaceList.size() == 1) {
                            cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 对方户名
                            cellList.add(preAccountAndNameAndPlaceList.get(1)); // 交易地点
                        }
                    } else if (preAccountAndNameAndPlaceList.size() == 1) {
                        if (nextAccountAndNameAndPlaceList.size() == 2) {
                            cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 对方户名
                            cellList.add(nextAccountAndNameAndPlaceList.get(1)); // 交易地点
                        } else if (nextAccountAndNameAndPlaceList.size() == 1) {
                            cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 对方户名
                            cellList.add(""); // 交易地点
                        }
                    }
                }
                // 辽宁振兴银行(商户资
                // 6236430716600000000 王兵
                // 金结算)-
                // case1.1.2 :对方账号、对方户名 没有跨行
                else if (currentAccountAndNameAndPlaceList.size() == 2) {
                    cellList.add(currentAccountAndNameAndPlaceListFirstText); // 对方账号
                    cellList.add(currentAccountAndNameAndPlaceList.get(1)); // 对方户名
                    if (preAccountAndNameAndPlaceList.size() == 1 && nextAccountAndNameAndPlaceList.size() == 1) {
                        cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 交易地点
                    }
                }
                // 6228480049000000000 张三 手机银行
                // case1.1.3 :对方账号、对方户名 交易地点都没有跨行
                else if (currentAccountAndNameAndPlaceList.size() == 3) {
                    cellList.add(currentAccountAndNameAndPlaceListFirstText); // 对方账号
                    cellList.add(currentAccountAndNameAndPlaceList.get(1)); // 对方户名
                    cellList.add(currentAccountAndNameAndPlaceList.get(2)); // 交易地点
                }
            }
            // AW8BAGYFokUn3DNImkcQd 财付通支付科技有限公
            // 王五
            // 9mQ7BDqcyBZ          司-
            else {
                // 对方账号 和 对方户名 都为空
                // case1.2.1 : 对方账号和对方户名对方账号都为空 交易地点没有跨行
                if (preAccountAndNameAndPlaceList.size() == 0) {
                    cellList.add(""); // 对方账号
                    cellList.add(""); // 对方户名
                    cellList.add(currentAccountAndNameAndPlaceListFirstText); // 交易地点
                }
                // case1.2.2 : 对方账号跨行 对方户名没有跨行、交易地点为空
                else if (preAccountAndNameAndPlaceList.size() == 1) {
                    String preAccountAndNameAndPlaceListFirstText = preAccountAndNameAndPlaceList.get(0);
                    if (preAccountAndNameAndPlaceListFirstText.matches("[A-Za-z0-9_\\-]{8,21}")) {
                        cellList.add(preAccountAndNameAndPlaceListFirstText + nextAccountAndNameAndPlaceList.get(0)); // 对方账号
                        cellList.add(currentAccountAndNameAndPlaceListFirstText); // 对方户名
                        cellList.add(""); // 交易地点
                    }
                    // 325350012890100100092暂收结算款项-公积金中交通银行江苏自贸试
                    else if (preAccountAndNameAndPlaceListFirstText.length() > 21) {
                        cellList.add(preAccountAndNameAndPlaceListFirstText.substring(0, 21) + nextAccountAndNameAndPlaceList.get(0)); // 对方账号
                        if (nextAccountAndNameAndPlaceList.size() == 2) {
                            cellList.add(preAccountAndNameAndPlaceListFirstText.substring(21) + nextAccountAndNameAndPlaceList.get(1)); // 对方户名
                            cellList.add(""); // 交易地点
                        } else if (nextAccountAndNameAndPlaceList.size() == 3) {
                            cellList.add(preAccountAndNameAndPlaceListFirstText.substring(21) + nextAccountAndNameAndPlaceList.get(1)); // 对方户名
                            cellList.add(nextAccountAndNameAndPlaceList.get(2)); // 对方户名
                        }
                    }
                }
                // case1.2.2 : 对方账号跨行 对方户名没有跨行、交易地点跨行
                else if (preAccountAndNameAndPlaceList.size() == 2) {
                    String preAccountAndNameAndPlaceListFirstText = preAccountAndNameAndPlaceList.get(0);
                    if (preAccountAndNameAndPlaceListFirstText.matches("[A-Za-z0-9_\\-]{8,21}")) {
                        cellList.add(preAccountAndNameAndPlaceListFirstText + nextAccountAndNameAndPlaceList.get(0));  // 对方账号
                        cellList.add(currentAccountAndNameAndPlaceListFirstText);  // 对方户名
                        if (nextAccountAndNameAndPlaceList.size() == 2) {
                            cellList.add(preAccountAndNameAndPlaceList.get(1) + nextAccountAndNameAndPlaceList.get(1)); // 交易地点
                        } else {
                            cellList.add(preAccountAndNameAndPlaceList.get(1)); // 交易地点
                        }
                    }
                }
            }
        }
        // 对方账号、对方户名、交易地点都跨行
        // 对方账号、对方户名都为空, 交易地点都跨行
        else {
            if (preAccountAndNameAndPlaceList.size() == 1 && nextAccountAndNameAndPlaceList.size() == 1) {
                cellList.add(""); // 对方账号
                cellList.add(""); // 对方户名
                cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 交易地点
            } else if (preAccountAndNameAndPlaceList.size() == 2) {
                if (nextAccountAndNameAndPlaceList.size() == 1) {
                    cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 对方户名
                    cellList.add(preAccountAndNameAndPlaceList.get(1)); // 对方账号
                    cellList.add(""); // 交易地点
                } else if (nextAccountAndNameAndPlaceList.size() == 2) {
                    cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 对方户名
                    cellList.add(preAccountAndNameAndPlaceList.get(1) + nextAccountAndNameAndPlaceList.get(1)); // 对方账号
                    cellList.add(""); // 交易地点
                } else if (nextAccountAndNameAndPlaceList.size() == 3) {
                    cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 对方户名
                    cellList.add(preAccountAndNameAndPlaceList.get(1) + nextAccountAndNameAndPlaceList.get(1)); // 对方账号
                    cellList.add(nextAccountAndNameAndPlaceList.get(2)); // 交易地点
                }
            } else if (preAccountAndNameAndPlaceList.size() == 3) {
                if (nextAccountAndNameAndPlaceList.size() == 1) {
                    cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 对方户名
                    cellList.add(preAccountAndNameAndPlaceList.get(1)); // 对方账号
                    cellList.add(preAccountAndNameAndPlaceList.get(2)); // 交易地点
                } else if (nextAccountAndNameAndPlaceList.size() == 2) {
                    cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 对方户名
                    cellList.add(preAccountAndNameAndPlaceList.get(1) + nextAccountAndNameAndPlaceList.get(1)); // 对方账号
                    cellList.add(preAccountAndNameAndPlaceList.get(2)); // 交易地点
                } else if (nextAccountAndNameAndPlaceList.size() == 3) {
                    cellList.add(preAccountAndNameAndPlaceList.get(0) + nextAccountAndNameAndPlaceList.get(0)); // 对方户名
                    cellList.add(preAccountAndNameAndPlaceList.get(1) + nextAccountAndNameAndPlaceList.get(1)); // 对方账号
                    cellList.add(preAccountAndNameAndPlaceList.get(2) + nextAccountAndNameAndPlaceList.get(2)); // 交易地点
                }
            }
        }
    }

    private boolean isTranWrapLines(Table table, int index) {
        // 当前行序号不为空, 且上一行序号也不为空&上一行序号的值正则匹配数字  or
        // 当前行序号不为空, 且下一行序号也不为空&上一行序号的值正则匹配数字
        // ===> 那么可以断定当前行的这笔交易, 没有跨行
        if ((StringUtils.isNotBlank(table.getCell(index - 1, 0).getText(false))
                && table.getCell(index - 1, 0).getText(false).trim().matches("\\d+|序号"))
                || StringUtils.isNotBlank(table.getCell(index + 1, 0).getText(false))
                && table.getCell(index + 1, 0).getText(false).trim().matches("\\d+")) {
            return false;
        }

        // 当前行序号不为空, 且上一行、下一行的序号均为空   两种情况:
        // case1、当前行的这笔交易跨行了 (交易类型、对方账号、对方户名、交易地点这几个字段都有可能跨行)
        // case2、当前行的这笔交易没有跨行, 当前行的上一笔交易、下一笔交易均跨行了
        List<String> currentRowCellList = table.getRows().get(index).stream().map(RectangularTextContainer::getText).collect(Collectors.toList());
        List<String> preRowCellList = table.getRows().get(index - 1).stream().map(RectangularTextContainer::getText).collect(Collectors.toList());

        if (currentRowCellList.size() == 10) {
            // 序号|交易日期   交易时间||交易类型|借贷|交易金额|余额|对方账户|对方户名|交易地点
            // 109|2022-12-26 12:12:09||其他交易|贷 Cr|3,819.94|8,976.58|991584000000|科技-备付金账户|科技有限公司-
            if (StringUtils.isAnyBlank(currentRowCellList.get(3), currentRowCellList.get(7), currentRowCellList.get(8), currentRowCellList.get(9))) {
                return true;
            } else {
                return false;
            }
        } else if (currentRowCellList.size() == 9) {
            // 序号|交易日期 交易时间||交易类型|借贷|交易金额|余额|对方账号 对方户名|交易地点
            // 298|2023-02-09 17:47:02||其他交易|贷 Cr|3,403.42 |5,936.39|991584000000 科技-备付金账户|科技有限公司-
            if (currentRowCellList.get(4).matches("借 Dr|贷 Cr")) {
                // 交易类型、交易地点为空 or
                // 对方账号 对方户名 有一个为空 && 交易地点不是"批处理" (批处理的交易, 对方账号和对方户名均为空)
                return StringUtils.isAnyBlank(currentRowCellList.get(3), currentRowCellList.get(8))
                        || (currentRowCellList.get(8).trim().split(" ").length < 2 && !currentRowCellList.get(8).contains("批处理"));
            }
            // 序号|交易日期 交易时间|交易类型 |借贷|交易金额|余额|对方账号|对方户名|交易地点
            // 序号|交易日期 交易时间|交易类型 |借贷|交易金额|余额|对方账号 对方户名||交易地点
            else {
                // 交易类型为空
                if (StringUtils.isBlank(currentRowCellList.get(2))) {
                    return true;
                }

                List<String> lastThreeCellList = Stream.of(currentRowCellList.get(6), currentRowCellList.get(7), currentRowCellList.get(8))
                        .flatMap(cellText -> Arrays.stream(cellText.split(" "))).filter(StringUtils::isNotBlank).collect(Collectors.toList());

                // 批处理的交易, 对方账号和对方户名均为空
                // 排除掉批处理的交易, 对方账号、对方户名、交易地点 有一个字段为空就是跨行
                if (lastThreeCellList.size() == 1 && lastThreeCellList.get(0).trim().equals("批处理")) {
                    return preRowCellList.stream().anyMatch(cellText -> cellText.contains("应付个人活期储蓄存款"));
                }
                // 325973500000000000000李四 ||批处理
                if (lastThreeCellList.size() == 2 && lastThreeCellList.get(0).length() > 21) {
                    return false;
                }
                return lastThreeCellList.size() < 3;
            }
        } else if (currentRowCellList.size() == 8) {
            // 序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号| 对方户名|交易地点
            if (currentRowCellList.get(2).matches("借 Dr|贷 Cr")) {
                // 交易类型为空  2022-06-18 17:07:53
                // if (!currentRowCellList.get(1).matches("\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\s([\u4e00-\u9fa5]{2,10})")) {
                if (currentRowCellList.get(1).trim().length() <= 20) {
                    return true;
                }
                List<String> lastThreeCellList = Stream.of(currentRowCellList.get(5), currentRowCellList.get(6), currentRowCellList.get(7))
                        .flatMap(cellText -> Arrays.stream(cellText.split(" "))).filter(StringUtils::isNotBlank).collect(Collectors.toList());
                // 批处理的交易, 对方账号和对方户名均为空
                // 排除掉批处理的交易, 对方账号、对方户名、交易地点 有一个字段为空就是跨行
                if (lastThreeCellList.size() == 1 && lastThreeCellList.get(0).trim().equals("批处理")) {
                    return false;
                }
                return lastThreeCellList.size() < 3;
            } else if (currentRowCellList.get(4).matches("借 Dr|贷 Cr")) {
                // 949|2023-03-06 15:21:04||跨行汇款|贷 Cr|20,000.00|20,010.97|6223246718000000000 朱* 网上银行
                List<String> lastThreeCellList = Stream.of(currentRowCellList.get(7))
                        .flatMap(cellText -> Arrays.stream(cellText.split(" "))).filter(StringUtils::isNotBlank).collect(Collectors.toList());
                // 批处理的交易, 对方账号和对方户名均为空
                // 排除掉批处理的交易, 对方账号、对方户名、交易地点 有一个字段为空就是跨行
                if (lastThreeCellList.size() == 1 && lastThreeCellList.get(0).trim().equals("批处理")) {
                    return preRowCellList.stream().anyMatch(cellText -> cellText.contains("应付个人活期储蓄存款"));
                }

                // 325973500000000000000李四 批处理
                if (lastThreeCellList.size() == 2 && lastThreeCellList.get(0).length() > 21) {
                    return false;
                }
                return lastThreeCellList.size() < 3;
            }
            // 序号|交易日期 交易时间|交易类型|借贷|交易金额|余额|对方账号        |对方户名 交易地点
            // 序号|交易日期 交易时间|交易类型|借贷|交易金额|余额|对方账号 对方户名 |交易地点
            else {
                // 交易类型为空
                if (StringUtils.isBlank(currentRowCellList.get(2))) {
                    return true;
                }

                List<String> lastThreeCellList = Stream.of(currentRowCellList.get(6), currentRowCellList.get(7))
                        .flatMap(cellText -> Arrays.stream(cellText.split(" "))).filter(StringUtils::isNotBlank).collect(Collectors.toList());

                // 批处理的交易, 对方账号和对方户名均为空
                // 排除掉批处理的交易, 对方账号、对方户名、交易地点 有一个字段为空就是跨行
                if (lastThreeCellList.size() == 1 && lastThreeCellList.get(0).trim().equals("批处理")) {
                    return preRowCellList.stream().anyMatch(cellText -> cellText.contains("应付个人活期储蓄存款"));
                }

                // 325973500000000000000李四 |批处理
                if (lastThreeCellList.size() == 2 && lastThreeCellList.get(0).length() > 21) {
                    return false;
                }
                return lastThreeCellList.size() < 3;
            }
        } else if (currentRowCellList.size() == 7) {
            // 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号 对方户名 |交易地点
            // 序号|交易日期 交易时间 交易类型|借贷|交易金额 |余额|对方账号         |对方户名  交易地点
            // 序号|交易日期 交易时间 |交易类型|借贷|交易金额 |余额|对方账号 对方户名 交易地点

            // 交易类型为空
            // if (!currentRowCellList.get(1).matches("\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\s([\u4e00-\u9fa5]{2,10})")) {
            if (currentRowCellList.get(2).matches("借 Dr|贷 Cr")) {
                if (currentRowCellList.get(1).trim().length() <= 20) {
                    return true;
                }
                List<String> lastThreeCellList = Stream.of(currentRowCellList.get(5), currentRowCellList.get(6))
                        .flatMap(cellText -> Arrays.stream(cellText.split(" "))).filter(StringUtils::isNotBlank).collect(Collectors.toList());

                // 批处理的交易, 对方账号和对方户名均为空
                // 排除掉批处理的交易, 对方账号、对方户名、交易地点 有一个字段为空就是跨行
                if (lastThreeCellList.size() == 1 && lastThreeCellList.get(0).trim().equals("批处理")) {
                    return preRowCellList.stream().anyMatch(cellText -> cellText.contains("应付个人活期储蓄存款"));
                }

                // 325973500000000000000李四 批处理
                if (lastThreeCellList.size() == 2 && lastThreeCellList.get(0).length() > 21) {
                    return false;
                }
                return lastThreeCellList.size() < 3;
            } else if (currentRowCellList.get(3).matches("借 Dr|贷 Cr")) {
                if (StringUtils.isBlank(currentRowCellList.get(2))) {
                    return true;
                }

                List<String> lastThreeCellList = Stream.of(currentRowCellList.get(6))
                        .flatMap(cellText -> Arrays.stream(cellText.split(" "))).filter(StringUtils::isNotBlank).collect(Collectors.toList());

                // 批处理的交易, 对方账号和对方户名均为空
                // 排除掉批处理的交易, 对方账号、对方户名、交易地点 有一个字段为空就是跨行
                if (lastThreeCellList.size() == 1 && lastThreeCellList.get(0).trim().equals("批处理")) {
                    return preRowCellList.stream().anyMatch(cellText -> cellText.contains("应付个人活期储蓄存款"));
                }
                // 325973500000000000000李四 批处理
                if (lastThreeCellList.size() == 2 && lastThreeCellList.get(0).length() > 21) {
                    return false;
                }
                return lastThreeCellList.size() < 3;
            }

        } else if (currentRowCellList.size() == 6) {
            // 序号|交易日期 交易时间 交易类型|借贷|交易金额|余额|对方账号  对方户名  交易地点

            // 交易类型为空
            // if (!currentRowCellList.get(1).matches("\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\s([\u4e00-\u9fa5]{2,10})")) {
            if (currentRowCellList.get(1).trim().length() <= 20) {
                return true;
            }

            List<String> lastThreeCellList = Stream.of(currentRowCellList.get(5))
                    .flatMap(cellText -> Arrays.stream(cellText.split(" "))).filter(StringUtils::isNotBlank).collect(Collectors.toList());

            // 批处理的交易, 对方账号和对方户名均为空
            // 排除掉批处理的交易, 对方账号、对方户名、交易地点 有一个字段为空就是跨行
            if (lastThreeCellList.size() == 1 && lastThreeCellList.get(0).trim().equals("批处理")) {
                return preRowCellList.stream().anyMatch(cellText -> cellText.contains("应付个人活期储蓄存款"));
            }

            // 325973500000000000000李四 批处理
            if (lastThreeCellList.size() == 2 && lastThreeCellList.get(0).length() > 21) {
                return false;
            }
            return lastThreeCellList.size() < 3;
        }
        return false;
    }

    public static void main(String[] args) throws IOException {
        BCMPdfParser1 bcmPdfParser = new BCMPdfParser1();
        BCM bcm = null;
        String json = "";
//        bcm = bcmPdfParser.parseBCMPdf("D:\\data\\files\\BCM\\zd4g3dtt1588068715243712512_8e0186f1c54fe0d92463bdbfa62b9ddd_beehive-bcm_jyls-0.pdf");
//        bcm = bcmPdfParser.parseBCMPdf("D:\\data\\files\\BCM\\zd42yfkm1598216866508230656_c993f249452f873930f3938c14f688a4_beehive-bcm_jyls-0.pdf");
//        bcm = bcmPdfParser.parseBCMPdf("D:\\data\\files\\BCM\\zd20kldt1730118022795399168_e4b084a3fa9e8a8f8067d79e07636f53_beehive-bcm_jyls-0.pdf");
//        bcm = bcmPdfParser.parseBCMPdf("D:\\data\\files\\BCM\\zd4oen1t1731549647452069888_dddad0ed9381baa45e96112b73797f96_beehive-bcm_jyls-0.pdf");
        bcm = bcmPdfParser.parseBCMPdf("D:\\data\\CgBRbWaTUXqAC5bPAARAiCZ5OXM035 (1).pdf");
        json = JsonUtils.convertObjectToJson(bcm);
        System.out.println(json);

//        File filePathDir = new File("D:\\data\\files\\BCM");
//        File[] files = filePathDir.listFiles();
//        for (File file : files) {
//            String fileName = file.getAbsoluteFile().getName();
//            // System.out.println(fileName.substring(0, 27));
//            System.out.println(fileName);
//            if (fileName.contains(".pdf")) {
//                json = bcmPdfParser.parseBCMPdfToJson("", file.getAbsolutePath()).getData();
//                System.out.println(json);
//            }
//        }
    }
}