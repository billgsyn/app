package com.file.parser;

import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * 交通银行pdf流水解析
 * @author anyspa
 */

@Slf4j
public class BCMPdfParser extends BasePdfParser {

    private BCMPdfParser1 bcmPdfParser1 = new BCMPdfParser1();

    private BCMPdfParser2 bcmPdfParser2 = new BCMPdfParser2();

    public ResponseData<String> parseBCMPdfToJson(String daId, String filePath) {
        log.info("parseBCMPdfToJson started, daId:{}", daId);

        try {
            String pdfHeaderText = parsePdfHeaderText(filePath);
            if (pdfHeaderText.contains("对方账户") || pdfHeaderText.contains("对方户名")) {
                return bcmPdfParser1.parseBCMPdfToJson(daId, filePath);
            } else {
                return bcmPdfParser2.parseBCMPdfToJson(daId, filePath);
            }
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseBCMPdfToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }
    }


    public static void main(String[] args) {
        BCMPdfParser bcmPdfParser = new BCMPdfParser();
        String filePath = "D:\\data\\files\\BCM\\交行-有交易对手.pdf";
//        String filePath = "D:\\data\\files\\BCM\\交行-无交易对手.pdf";
        String json = null;
        String pdfHeaderText = bcmPdfParser.parsePdfHeaderText(filePath);
        if (StringUtils.isNotBlank(pdfHeaderText)) {
            if (pdfHeaderText.contains("对方账户") || pdfHeaderText.contains("对方户名")) {
                json = new BCMPdfParser1().parseBCMPdfToJson("dd", filePath).getData();
            } else {
                json = new BCMPdfParser2().parseBCMPdfToJson("dd", filePath).getData();
            }
        }
        System.out.println(json);
    }

}
