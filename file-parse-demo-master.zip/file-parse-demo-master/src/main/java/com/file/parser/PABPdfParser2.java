package com.file.parser;

import com.file.bo.ResponseData;
import com.file.bo.mail.PAB2;
import com.file.bo.mail.PABTran2;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class PABPdfParser2 extends BasePdfParser {

    public ResponseData<String> parsePABPdfToJson(String daId, String filePath) {
		log.info("parsePABPdfToJson started, daId:{}", daId);
        String json = null;

        try {
            PAB2 pab = parsePABPdf(filePath);
            json = JsonUtils.convertObjectToJson(pab);
        } catch (Exception e) {
			log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parsePABPdfToJson failed", e);
            return new ResponseData<String>(json, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

		log.info("parsePABPdfToJson completed, daId:{}", daId);
        return new ResponseData<String>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private PAB2 parsePABPdf(String filePath) {
        PAB2 pab = parsePABHeader(filePath);
        List<PABTran2> pabTrans = parsePabTrans(filePath, pab.getInventoryNumber());
        try {
            parseCounterParty(filePath, pabTrans);
        } catch (Exception e) {
			log.warn("parseConterparty failed", e);
        }

        pab.setPabTrans(pabTrans);
        return pab;
    }

    private PAB2 parsePABHeader(String filePath) {
        PAB2 pab = new PAB2();
        String pdfHeaderText = parsePdfHeaderText(filePath);
        String inventoryNumber = pdfHeaderText.substring(pdfHeaderText.indexOf("清单编号：") + 5, pdfHeaderText.indexOf("开立日期")).trim();
        pdfHeaderText = parsePdfHeaderText2(filePath);

        if (StringUtils.isBlank(inventoryNumber)) {
            throw new RuntimeException("parsePABHeader failed, inventoryNumber is null");
        }

        if (pdfHeaderText.contains("清单编号") && pdfHeaderText.contains("户名：")) {
            pdfHeaderText = pdfHeaderText.substring(pdfHeaderText.indexOf(inventoryNumber), pdfHeaderText.indexOf("户名："));
            String[] pdfHeader = pdfHeaderText.split(" ");

            String issuanceDate = pdfHeader[1] + " " + pdfHeader[2].substring(0, pdfHeader[2].lastIndexOf(":") + 3);
            String name = pdfHeader[2].substring(pdfHeader[2].lastIndexOf(":") + 3);
            String accountNumber = pdfHeader[3];
            String depositType = pdfHeader[4].replaceAll("[^\\u4e00-\\u9fa5]", "");
            String currency = pdfHeader[4].substring(pdfHeader[4].indexOf(depositType) + 2);
            String accountBank = pdfHeader[5];
            String receivingBank = pdfHeader[6].replaceAll("[^\\u4e00-\\u9fa5]", "");
            String transactionDate = pdfHeader[6].substring(pdfHeader[6].indexOf(receivingBank) + 6) + " " + pdfHeader[7] + " " + pdfHeader[8];
            String detailRange = pdfHeader[9];

            pab.setInventoryNumber(inventoryNumber);
            pab.setIssuanceDate(issuanceDate);
            pab.setName(name);
            pab.setAccountNumber(accountNumber);
            pab.setDepositType(depositType);
            pab.setCurrency(currency);
            pab.setAccountBank(accountBank);
            pab.setReceivingBank(receivingBank);
            pab.setTransactionDate(transactionDate);
            pab.setDetailRange(detailRange);
        } else {
            pdfHeaderText = pdfHeaderText.substring(pdfHeaderText.indexOf(inventoryNumber), pdfHeaderText.indexOf("平安银行（银行签章）"));
            String[] pdfHeader = pdfHeaderText.split(" ");

            String issuanceDate = pdfHeader[1] + " " + pdfHeader[2];
            pab.setInventoryNumber(inventoryNumber);
            pab.setIssuanceDate(issuanceDate);
        }

        return pab;
    }

    private List<PABTran2> parsePabTrans(String filePath, String inventoryNumber) {
        List<PABTran2> pabTrans = new ArrayList<>();

        String transText = getPdfTextByStripper(filePath);
        if (Strings.isNullOrEmpty(transText)) {
            return pabTrans;
        }

        List<List<String>> tranFieldsList = parseTransTextToTranFieldsList2(transText);

        // 序号
        String id = "";
        // 交易日期
        String transactionTime = "";
        // 交易金额
        String transactionAmount = "";
        // 余额
        String balance = "";
        // 交易地点
        String tradingPlace = "";
        Boolean tradingPlaceStatus = false;
        // 摘要
        String transactionType = "";
        Boolean transactionTypeStatus = false;
        // 备注
        String comment = "";
        Boolean commentStatus = false;
        // 交易对手信息
        String counterParty = "";
        // 每行的记录是否读取完成
        Boolean rowResult = false;
        for (int i = 0; i < tranFieldsList.size(); i++) {
            List<String> strings = tranFieldsList.get(i);
            if (StringUtils.isBlank(strings.get(0)) || strings.get(0).contains("PAB PAB PAB PAB")  || Objects.equals("SCAN THE QR CODE BELOW.", strings.get(0)) || strings.get(0).contains("平安银行个人账户交易明细清单") || strings.get(0).contains("Operator Sub branch:交易起止日期：") || strings.get(0).contains(inventoryNumber)) {
                continue;
            }

            String[] contents = strings.get(0).split(" ");
            if (StringUtils.isBlank(contents[0]) || StringUtils.equals(contents[0], "PAB") || StringUtils.equals(contents[0], "Page") || StringUtils.equals(contents[0], "List")) {
                continue;
            }

            if (contents.length > 3 && (!contents[2].startsWith("-") && !contents[2].startsWith("+"))) {
                continue;
            }

            // 完整的解析
            if (contents.length == 8) {
                id = contents[0];
                transactionTime = contents[1];
                transactionAmount = contents[2];
                balance = contents[3];
                tradingPlace = contents[4];
                transactionType = contents[5];
                comment = contents[6];
                counterParty = contents[7];
                rowResult = true;
            } else if (contents.length == 4) {
                id = contents[0];
                transactionTime = contents[1];
                transactionAmount = contents[2];
                balance = contents[3];
            } else if (contents.length == 5) {
                id = contents[0];
                transactionTime = contents[1];
                transactionAmount = contents[2];
                balance = contents[3];
                tradingPlace = contents[4];
                tradingPlaceStatus = true;
            } else if (contents.length == 6) {
                id = contents[0];
                transactionTime = contents[1];
                transactionAmount = contents[2];
                balance = contents[3];
                tradingPlace = contents[4];
                transactionType = contents[5];
                tradingPlaceStatus = true;
                transactionTypeStatus = true;
            } else if (contents.length == 7) {
                id = contents[0];
                transactionTime = contents[1];
                transactionAmount = contents[2];
                balance = contents[3];
                tradingPlace = contents[4];
                transactionType = contents[5];
                tradingPlaceStatus = true;
                transactionTypeStatus = true;
                comment = contents[6];
                commentStatus = true;
                // 如果没有交易对手信息这列就不用继续解析这行的数据
                if (!transText.contains("交易对手信息")) {
                    rowResult = true;
                }
            } else {
                // 下一行的数据
                List<String> nextStrings = tranFieldsList.get(i + 1);

                // 交易地点
                if (StringUtils.isNotBlank(id) && Boolean.FALSE.equals(tradingPlaceStatus)) {
                    tradingPlace += strings.get(0);
                    tradingPlaceStatus = true;
                    continue;

                }

                // 摘要
                if (Boolean.TRUE.equals(tradingPlaceStatus) && Boolean.FALSE.equals(transactionTypeStatus)) {
                    transactionType += strings.get(0);
                    if (contents[0].contains("）") || StringUtils.equals(nextStrings.get(0), "/")) {
                        transactionTypeStatus = true;
                        continue;
                    }
                    if (contents[0].length() >= 8) {
                        if (!transText.contains("交易对手信息")) {
                            continue;
                        }
                        transactionTypeStatus = true;
                    }

                    if ((transactionType.length() > 8 || contents[0].length() == 1) && (contents[0].length() < nextStrings.get(0).length() || nextStrings.get(0).length() == 4)) {
                        transactionTypeStatus = true;
                        continue;
                    }
                }

                // 备注
                if (Boolean.TRUE.equals(transactionTypeStatus) && Boolean.FALSE.equals(commentStatus)) {
                    comment += strings.get(0);
                    if (contents[0].length() >= 11 && transText.contains("交易对手信息")) {
                        commentStatus = true;
                        continue;
                    }

                    if (contents[0].contains("）;") || StringUtils.equals(nextStrings.get(0), "/")) {
                        if (!transText.contains("交易对手信息")) {
                            rowResult = true;
                        } else {
                            commentStatus = true;
                            continue;
                        }
                    }

                    if (!CollectionUtils.isEmpty(nextStrings) && nextStrings.get(0).length() > 10 && transText.contains("交易对手信息")) {
                        commentStatus = true;
                        continue;
                    }

                    if (!CollectionUtils.isEmpty(nextStrings) && nextStrings.get(0).length() > 22 && !transText.contains("交易对手信息")) {
                        rowResult = true;
                    }
                }

                // 交易对手信息
                if (Boolean.TRUE.equals(commentStatus)) {
                    counterParty += strings.get(0);

                    if (!CollectionUtils.isEmpty(nextStrings) && nextStrings.get(0).length() > 24) {
                        rowResult = true;
                    }

                }

            }


            // 解析完成
            if (Boolean.TRUE.equals(rowResult) && StringUtils.isNotBlank(id)) {
                PABTran2 pabTran = new PABTran2();
                pabTran.setId(id);
                pabTran.setTransactionTime(transactionTime);
                pabTran.setTransactionAmount(transactionAmount);
                pabTran.setBalance(balance);
                pabTran.setTradingPlace(tradingPlace);
                pabTran.setTransactionType(transactionType);
                pabTran.setComment(comment);
                pabTran.setCounterParty(counterParty);
                pabTrans.add(pabTran);
                rowResult = false;
                tradingPlaceStatus = false;
                transactionTypeStatus = false;
                commentStatus = false;
                id = "";
                transactionTime = "";
                transactionAmount = "";
                balance = "";
                tradingPlace = "";
                transactionType = "";
                comment = "";
                counterParty = "";
            }

        }
        return pabTrans;
    }

    public List<List<String>> parseTransTextToTranFieldsList2(String transText) {
        // 这个List每个元素代表一条记录的文本字符串
        List<String> tranTextList = Splitter.on(System.getProperty("line.separator", "\n")).splitToList(transText);
        List<List<String>> tranFieldsList = new ArrayList<List<String>>();

        for (int i = 0; i < tranTextList.size() - 1; i++) {
            // 每一个wechatTranFieldList代表一条记录的所有字段，一个List一条记录
            List<String> wechatTranFields = new ArrayList<>();
            wechatTranFields.add(tranTextList.get(i));
            Collections.addAll(tranFieldsList, wechatTranFields);
        }

        return tranFieldsList;
    }

    public String getPdfTextByStripper(String filePath) {
        String pdfText = "";
        try (PDDocument pdDocument = PDDocument.load(new File(filePath))) {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(false);
            stripper.setStartPage(1);
            stripper.setEndPage(pdDocument.getNumberOfPages());
            pdfText = stripper.getText(pdDocument);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "getPdfTextByStripper failed", e);
            throw new RuntimeException(e);
        }
        return pdfText;
    }

    private void parseCounterParty(String filePath, List<PABTran2> pabTrans) {
        String pdfText = getPdfTextByStripper(filePath);
        pdfText = pdfText.replace(System.getProperty("line.separator", "\n"), " ");

        // 此处一行的格式1 20210916 -0.01 0.66 转账 招商银行股份有限公司-张三 -6214861021000077
        Pattern pattern1 = Pattern.compile("\\d{1,5}\\s\\d{8}\\s([-+]([0-9]{1,3}(,[0-9]{3})*)(.[0-9]{1,2}))\\s([0-9]{1,3}(,[0-9]{3})*)(.[0-9]{1,2})");
        Matcher matcher1 = pattern1.matcher(pdfText);

        // 每行交易记录的第一个字所在的index
        int tranIndex = 0;
        Map<Integer, Integer> tranTextStartIndexMap = new HashMap<>();

        while (matcher1.find()) {
//			log.info(
//			"Match \"" + matcher1.group() + "\" at positions " + matcher1.start() + "-" + (matcher1.end() - 1));
//			System.out.println("Match \"" + matcher1.group() + "\" at positions " + matcher1.start() + "-" + (matcher1.end() - 1));
            tranTextStartIndexMap.put(tranIndex, matcher1.start());
            tranIndex++;
        }

        // 找出每行交易记录的文本
        List<String> tranTextList = new ArrayList<>();
        for (int i = 1; i < tranTextStartIndexMap.size(); i++) {
            String tranText = pdfText.substring(tranTextStartIndexMap.get(i - 1), tranTextStartIndexMap.get(i));
            if (tranText.contains("平安银行个人账户交易明细清单")) {
                tranText = tranText.substring(0, tranText.indexOf("平安银行个人账户交易明细清单")).trim();
            }
            tranTextList.add(tranText.trim());
        }

        String lastTranText = pdfText.substring(tranTextStartIndexMap.get(tranTextStartIndexMap.size() - 1));
        lastTranText = lastTranText.substring(0, lastTranText.indexOf("平安银行个人账户交易明细清单")).trim();
        tranTextList.add(lastTranText);

        // 找出每行交易里的对手信息的值
        // 此处一行除去对手户名的格式 此处一行的格式1 20210916 -0.01 0.66 转账 招商银行股份有限公司-张三
        // -6214861021000077
        Pattern pattern2 = Pattern.compile("\\d{1,5}\\s\\d{8}\\s([-+]([0-9]{1,3}(,[0-9]{3})*)(.[0-9]{1,2}))\\s([0-9]{1,3}(,[0-9]{3})*)(.[0-9]{1,2})\\s\\S{1,15}\\s");
        for (int i = 0; i < pabTrans.size(); i++) {
            Matcher matcher2 = pattern2.matcher(tranTextList.get(i));
            while (matcher2.find()) {
//				log.info(
//				"Match \"" + matcher2.group() + "\" at positions " + matcher2.start() + "-" + (matcher2.end() - 1));
                String counterParty = tranTextList.get(i).substring(matcher2.end()).trim();
                pabTrans.get(i).setCounterParty(counterParty.replace(" ", ""));
            }
        }
    }

    public static void main(String[] args) {
        PABPdfParser2 pabPdfParser = new PABPdfParser2();
        PAB2 pab = pabPdfParser.parsePABPdf("D:\\data\\file\\beehive-pabc\\zd4y7qpv1732283841081430016_30873ee74ee26832ff48f7b3d5cc3a5d_beehive-pabc_jyls-0.pdf");
        String json = JsonUtils.convertObjectToJson(pab);
        System.out.println(json);
    }

}
