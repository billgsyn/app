package com.file.parser;

import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.parser.socialsecurity.*;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class SocialSecurityPdfParser {
    private static final String PROVINCE = "province";
    private static final String CITY = "city";

    private GuangdongSocialSecurityPdfParser guangdongSocialSecurityPdfParser = new GuangdongSocialSecurityPdfParser();

    private BeijingSocialSecurityPdfParser beijingSocialSecurityPdfParser = new BeijingSocialSecurityPdfParser();


    private ZhejiangSocialSecurityPdfParser zhejiangSocialSecurityPdfParser = new ZhejiangSocialSecurityPdfParser();

    private JiangsuSocialSecurityPdfParser jiangsuSocialSecurityPdfParser = new JiangsuSocialSecurityPdfParser();

    private HenanSocialSecurityPdfParser henanSocialSecurityPdfParser = new HenanSocialSecurityPdfParser();

    private ShanxiSocialSecurityPdfParser shanxiSocialSecurityPdfParser = new ShanxiSocialSecurityPdfParser();


    private HubeiSocialSecurityPdfParser hubeiSocialSecurityPdfParser = new HubeiSocialSecurityPdfParser();

    private ShandongSocialSecurityPdfParser shandongSocialSecurityPdfParser = new ShandongSocialSecurityPdfParser();

    private GuizhouSocialSecurityPdfParser guizhouSocialSecurityPdfParser = new GuizhouSocialSecurityPdfParser();

    private SichuangSocialSecurityPdfParser sichuangSocialSecurityPdfParser = new SichuangSocialSecurityPdfParser();

    private FujianSocialSecurityPdfParser fujianSocialSecurityPdfParser = new FujianSocialSecurityPdfParser();

    private HunanSocialSecurityPdfParser hunanSocialSecurityPdfParser = new HunanSocialSecurityPdfParser();

    private ShanghaiSocialSecurityPdfParser shanghaiSocialSecurityPdfParser = new ShanghaiSocialSecurityPdfParser();
    private ChongqingSocialSecurityPdfParser chongqingSocialSecurityPdfParser = new ChongqingSocialSecurityPdfParser();

    private LiaoningSocialSecurityPdfParser liaoningSocialSecurityPdfParser = new LiaoningSocialSecurityPdfParser();

    private AnhuiSocialSecurityPdfParser anhuiSocialSecurityPdfParser = new AnhuiSocialSecurityPdfParser();

    private Shanxi2SocialSecurityPdfParser shanxi2SocialSecurityPdfParser = new Shanxi2SocialSecurityPdfParser();

    private GuangxiSocialSecurityPdfParser guangxiSocialSecurityPdfParser = new GuangxiSocialSecurityPdfParser();


    private TianjinSocialSecurityPdfParser tianjinSocialSecurityPdfParser = new TianjinSocialSecurityPdfParser();

    private JilinSocialSecurityPdfParser jilinSocialSecurityPdfParser = new JilinSocialSecurityPdfParser();

    private JiangxiSocialSecurityPdfParser jiangxiSocialSecurityPdfParser = new JiangxiSocialSecurityPdfParser();

    private YunnanSocialSecurityPdfParser yunnanSocialSecurityPdfParser = new YunnanSocialSecurityPdfParser();

    private HebeiSocialSecurityPdfParser hebeiSocialSecurityPdfParser = new HebeiSocialSecurityPdfParser();

    private HeilongjiangSocialSecurityPdfParser heilongjiangSocialSecurityPdfParser = new HeilongjiangSocialSecurityPdfParser();

    public ResponseData<String> parseSocialSecurityPdfToJson(String daId, String filePath, String downloadEventExtJson) {//NOSONAR
        log.info("parseSocialSecurityPdfToJson started, daId:{}, downloadEventExtJson:{}", daId, downloadEventExtJson);
        ResponseData<String> responseData = null;
        if (StringUtils.isBlank(downloadEventExtJson)) {
            return new ResponseData<>(null, ErrorCode.NO_PROVINCE_DATA_EXCEPTION.getCode(), ErrorCode.NO_PROVINCE_DATA_EXCEPTION.getMsg());
        }

        String province = JsonUtils.convertJsonToJsonNode(downloadEventExtJson).get(PROVINCE).textValue();
//        String city = JsonUtils.convertJsonToJsonNode(downloadEventExtJson).get(CITY).textValue();
        if (StringUtils.isNotBlank(province)) {
            switch (province) {
                case "广东省":
                    responseData = guangdongSocialSecurityPdfParser.parseGuangdongSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "北京市":
                    responseData = beijingSocialSecurityPdfParser.parseBeijingSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "浙江省":
                    responseData = zhejiangSocialSecurityPdfParser.parseZhejiangSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "江苏省":
                    responseData = jiangsuSocialSecurityPdfParser.parseJiangsuSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "河南省":
                    responseData = henanSocialSecurityPdfParser.parseHenanSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "陕西省":
                    responseData = shanxiSocialSecurityPdfParser.parseShanxiSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "湖北省":
                    responseData = hubeiSocialSecurityPdfParser.parseHubeiSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "山东省":
                    responseData = shandongSocialSecurityPdfParser.parseShandongSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "贵州省":
                    responseData = guizhouSocialSecurityPdfParser.parseGuizhouSocialSecurityPdfParser(daId, filePath);
                    break;
                case "四川省":
                    responseData = sichuangSocialSecurityPdfParser.parseSichuangSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "福建省":
                    responseData = fujianSocialSecurityPdfParser.parseFujianSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "湖南省":
                    responseData = hunanSocialSecurityPdfParser.parseHunanSocialSecurityPdfParser(daId, filePath);
                    break;
                case "上海市":
                    responseData = shanghaiSocialSecurityPdfParser.parseShanghaiSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "辽宁省":
                    responseData = liaoningSocialSecurityPdfParser.parseLiaoNingSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "重庆市":
                    responseData = chongqingSocialSecurityPdfParser.parseCongqingSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "安徽省":
                    responseData = anhuiSocialSecurityPdfParser.parseAnhuiSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "山西省":
                    responseData = shanxi2SocialSecurityPdfParser.parseShanxi2SocialSecurityPdfToJson(daId, filePath);
                    break;
                case "广西省":
                    responseData = guangxiSocialSecurityPdfParser.parseGuangxiSocialSecurityPdfParser(daId, filePath);
                    break;
                case "天津市":
                    responseData = tianjinSocialSecurityPdfParser.parseTianjinSocialSecurityPdfParser(daId, filePath);
                    break;
                case "吉林省":
                    responseData = jilinSocialSecurityPdfParser.parseJilinSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "江西省":
                    responseData = jiangxiSocialSecurityPdfParser.parseJiangxiSocialSecurityPdfToJson(daId, filePath);
                    break;
                case "云南省":
                    responseData = yunnanSocialSecurityPdfParser.parseYunnanSocialSecurityPdfParser(daId, filePath);
                    break;
                case "河北省":
                    responseData = hebeiSocialSecurityPdfParser.parseHebeiSocialSecurityPdfParser(daId, filePath);
                    break;
                case "黑龙江省":
                    responseData = heilongjiangSocialSecurityPdfParser.parseHeilongjiangSocialSecurityPdfToJson(daId, filePath);
                    break;
                default:
                    log.error("|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseSocialSecurityPdfToJson failed, the province is not supported");
                    responseData = new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
            }
        } else {
            log.error("|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseSocialSecurityPdfToJson failed, the province is empty");
            responseData = new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseSocialSecurityPdfToJson completed, daId:{}, downloadEventExtJson:{}", daId, downloadEventExtJson);
        return responseData;
    }

    public static void main(String[] args) {
        String downloadEventExtJson = "{\"province\":\"广东省\",\"city\":\"广州市\"}";
        String filePath = "D:\\data\\file\\socialsecurity\\广州市社会保险个人权益记录单20230322110224_cbzm.pdf";
        // String filePath = "D:\\data\\file\\socialsecurity\\2021年个人权益记录单20230322110339_qyd.pdf";
        // String downloadEventExtJson = "{\"province\":\"广东省\",\"city\":\"深圳市\"}";
        // String filePath = "D:\\data\\file\\socialsecurity\\zd1tuknz1673280392783970304_ebabbb66edadee2650361d37ce5b9b76_app-gjzwfw-dzsb_cbzm.pdf";
        // String filePath = "D:\\data\\file\\socialsecurity\\zd1tuknz1673280392783970304_ebabbb66edadee2650361d37ce5b9b76_app-gjzwfw-dzsb_qyd.pdf";
        // String downloadEventExtJson = "{\"province\":\"湖北省\",\"city\":\"武汉市\"}";
        // String filePath = "D:\\data\\file\\socialsecurity\\zd20kldt1672799229694951424_f1e3be7bf68d07ceb6f46517f3824ff5_app-gjzwfw-dzsb_cbzm.pdf";

        GuangdongSocialSecurityPdfParser guangdongSocialSecurityPdfParser = new GuangdongSocialSecurityPdfParser();
        BeijingSocialSecurityPdfParser beijingSocialSecurityPdfParser = new BeijingSocialSecurityPdfParser();

        String province = JsonUtils.convertJsonToJsonNode(downloadEventExtJson).get(PROVINCE).textValue();
        String city = JsonUtils.convertJsonToJsonNode(downloadEventExtJson).get(CITY).textValue();
        ResponseData<String> responseData = null;
        if (StringUtils.equals(province, "广东省")) {
            responseData = guangdongSocialSecurityPdfParser.parseGuangdongSocialSecurityPdfToJson("", filePath);
        } else if (StringUtils.equals(city, "北京市")) {
            responseData = beijingSocialSecurityPdfParser.parseBeijingSocialSecurityPdfToJson("", filePath);
        } else {
            throw new RuntimeException("the city is not supported");
        }
        System.out.println(responseData.getData());
    }

}
