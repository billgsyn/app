package com.file.parser;


import com.file.bo.AppGjzwfwHyzjDetail;
import com.file.bo.AppGjzwfwHyzjIndex;
import com.file.bo.AppGjzwfwHyzjOriginal;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 国家政务APP-婚姻证件xml解析
 * @author anyspa
 */

@Slf4j
public class AppGjzwfwHyzjXmlParser extends BaseXmlParser {

    public ResponseData<String> parseAppGjzwfwHyzjXmlToJson(String daId, String filePath, String idNo) {
        log.info("parseAppGjzwfwHyzjXmlToJson started, daId:{}, filePath:{}, idNo:{}", daId, filePath, idNo);
        String json;

        try {
            if (filePath.contains("app-gjzwfw-hyzj-jhz-original") || filePath.contains("app-gjzwfw-hyzj-lhz-original")) {
                AppGjzwfwHyzjOriginal appGjzwfwHyzjOriginal = parseAppGjzwfwHyzjOriginalXml(filePath, idNo);
                json = JsonUtils.convertObjectToJson(appGjzwfwHyzjOriginal);
            } else if (filePath.contains("app-gjzwfw-hyzj-jhz-index") || filePath.contains("app-gjzwfw-hyzj-lhz-index")) {
                AppGjzwfwHyzjIndex appGjzwfwHyzjIndexXml = parseAppGjzwfwHyzjIndexXml(filePath);
                json = JsonUtils.convertObjectToJson(appGjzwfwHyzjIndexXml);
            }  else if (filePath.contains("app-gjzwfw-hyzj-jhz") || filePath.contains("app-gjzwfw-hyzj-lhz")) {
                AppGjzwfwHyzjDetail appGjzwfwHyzjDetail = parseAppGjzwfwHyzjDetailXml(filePath);
                json = JsonUtils.convertObjectToJson(appGjzwfwHyzjDetail);
            } else {
                throw new RuntimeException("the file name is not supported");
            }
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseAppGjzwfwHyzjXmlToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseAppGjzwfwHyzjXmlToJson completed, daId:{}, filePath:{}, idNo:{}", daId, filePath, idNo);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private AppGjzwfwHyzjDetail parseAppGjzwfwHyzjDetailXml(String filePath) throws DocumentException {
        AppGjzwfwHyzjDetail appGjzwfwHyzjDetail = new AppGjzwfwHyzjDetail();
        List<String> nodeTextList = getNodeTextList(filePath);
        for (int i = 0; i < nodeTextList.size(); i++) {
            if (i < (nodeTextList.size() - 1)) {
                if (nodeTextList.get(i).contains("证件名称")) {
                    appGjzwfwHyzjDetail.setCertificateName(nodeTextList.get(i + 1));
                } else if (StringUtils.containsAny(nodeTextList.get(i), "证件编号", "证照号码")) {
                    appGjzwfwHyzjDetail.setCertificateNo(nodeTextList.get(i + 1));
                } else if (nodeTextList.get(i).contains("持有人名称")) {
                    appGjzwfwHyzjDetail.setOwnerName(nodeTextList.get(i + 1));
                } else if (nodeTextList.get(i).contains("持有人身份证")) {
                    appGjzwfwHyzjDetail.setOwnerIdNo(nodeTextList.get(i + 1));
                } else if (nodeTextList.get(i).contains("签发机构")) {
                    appGjzwfwHyzjDetail.setIssuingAuthority(nodeTextList.get(i + 1));
                } else if (nodeTextList.get(i).contains("发证机构唯一")) {
                    appGjzwfwHyzjDetail.setIssuingAuthorityUniqueIdentification(nodeTextList.get(i + 1));
                } else if (nodeTextList.get(i).contains("发证机构所属")) {
                    appGjzwfwHyzjDetail.setIssuingAuthorityAdministrativeRegionCode(nodeTextList.get(i + 1));
                } else if (nodeTextList.get(i).contains("发证日期")) {
                    appGjzwfwHyzjDetail.setIssuingDate(nodeTextList.get(i + 1));
                }
            }
        }

        return appGjzwfwHyzjDetail;
    }

    private AppGjzwfwHyzjIndex parseAppGjzwfwHyzjIndexXml(String filePath) throws DocumentException {
        AppGjzwfwHyzjIndex appGjzwfwHyzjIndex = new AppGjzwfwHyzjIndex();
        SAXReader reader = new SAXReader();
        Document document = reader.read(new File(filePath));

        Element certificateNameElement = (Element) document.selectSingleNode("//android.widget.TextView[@resource-id='com.service.android.gov.cn:id/tv_licence_name']");
        appGjzwfwHyzjIndex.setCertificateName(certificateNameElement.attributeValue("text"));

        Element nameElement = (Element) document.selectSingleNode("//android.widget.TextView[@resource-id='com.service.android.gov.cn:id/tv_owner']");
        appGjzwfwHyzjIndex.setName(nameElement.attributeValue("text"));

        Element certificateNumberElement = (Element) document.selectSingleNode("//android.widget.TextView[@resource-id='com.service.android.gov.cn:id/tv_licence_id']");
        appGjzwfwHyzjIndex.setCertificateNumber(certificateNumberElement.attributeValue("text"));

        Element certificateIssuingAgencyElement = (Element) document.selectSingleNode("//android.widget.TextView[@resource-id='com.service.android.gov.cn:id/tv_issuing_authority']");
        appGjzwfwHyzjIndex.setCertificateIssuingAgency(certificateIssuingAgencyElement.attributeValue("text"));

        Element certificateIssuingDateElement = (Element) document.selectSingleNode("//android.widget.TextView[@resource-id='com.service.android.gov.cn:id/tv_issuing_date']");
        appGjzwfwHyzjIndex.setCertificateIssuingDate(certificateIssuingDateElement.attributeValue("text"));

        return appGjzwfwHyzjIndex;
    }

    private AppGjzwfwHyzjOriginal parseAppGjzwfwHyzjOriginalXml(String filePath, String holderIdNo) throws DocumentException {
        // 中华人民共和国结婚证证照文件预览1234张三2019年03月25日J440305-2019-003597张三男中国1986年05月00日400000198605000031李四女中国1984年12月08日4000001984120816270034
        List<String> nodeTextList = getNodeTextList(filePath).stream()
                .filter(text -> !StringUtils.equalsAny(text.trim(), "男", "女"))
                .collect(Collectors.toList());

        // 中华人民共和国结婚证证照文件预览1234张三2019-03-25J440305-2019-003597张三中国1986-05-00400000198605000031李四中国1984-12-084000001984120816270034
        List<String> simplifyNodeTextList = new ArrayList<>();
        if (nodeTextList.contains("年") && nodeTextList.contains("月")) {
            for (int i = 0; i < nodeTextList.size(); i++) {
                String text = nodeTextList.get(i);
                if (nodeTextList.get(i).matches("\\d{4}")
                        && nodeTextList.get(i + 2).matches("\\d{1,2}")
                        && nodeTextList.get(i + 4).matches("\\d{1,2}")) {
                    String date = nodeTextList.get(i).concat("-").concat(nodeTextList.get(i + 2).length() == 1 ? "0" + nodeTextList.get(i + 2) : nodeTextList.get(i + 2)).concat("-").concat(nodeTextList.get(i + 4).length() == 1 ? "0" + nodeTextList.get(i + 4) : nodeTextList.get(i + 4));
                    simplifyNodeTextList.add(date);
                    i += 5; //NOSONAR
                } else if (nodeTextList.get(i).matches("\\d{4}")
                        && nodeTextList.get(i + 2).matches("\\d{1,2}")
                        && nodeTextList.get(i + 4).matches("\\d{1,2}日")) {
                    String date = nodeTextList.get(i).concat("-").concat(nodeTextList.get(i + 2).length() == 1 ? "0" + nodeTextList.get(i + 2) : nodeTextList.get(i + 2)).concat("-").concat(nodeTextList.get(i + 4).length() == 1 ? "0" + nodeTextList.get(i + 4) : nodeTextList.get(i + 4));
                    if (date.contains("日")) {
                        date = date.replace("日", "");
                    }
                    simplifyNodeTextList.add(date);
                    i += 4; //NOSONAR
                } else {
                    simplifyNodeTextList.add(text);
                }
            }
        } else {
            simplifyNodeTextList.addAll(nodeTextList);
        }

        AppGjzwfwHyzjOriginal appGjzwfwHyzjOriginal = new AppGjzwfwHyzjOriginal();
        appGjzwfwHyzjOriginal.setHolderIdNo(holderIdNo);

        List<String> idNoList = simplifyNodeTextList.stream()
                .filter(text -> text.trim().matches("(\\d{15}(\\d{2}[0-9xX])?)|[0-9a-zA-Z]{8,9}"))
                .distinct()
                .collect(Collectors.toList());
        if (idNoList.size() != 2) {
            throw new RuntimeException("there are no 2 idNo found!");
        }
        Optional<String> partnerIdNoOptional = idNoList.stream()
                .filter(idNo -> (!StringUtils.equals(idNo, holderIdNo)))
                .findFirst();
        if (!partnerIdNoOptional.isPresent()) {
            throw new RuntimeException("partner idNo is not found");
        }

        String partnerIdNo = partnerIdNoOptional.get();
        appGjzwfwHyzjOriginal.setPartnerIdNo(partnerIdNo);

        // 中华人民共和国结婚证证照文件预览|1|2|3|4|张三|2019-03-25|J440305-2019-003597|张三|中国|1986-05-00|400000198605000031|李四|中国|1984-12-08|4000001984120816270034
        String nodeTextString = String.join("|", simplifyNodeTextList);
        System.out.println("nodeTextString = " + nodeTextString);   //NOSONAR
        List<List<String>> list = new ArrayList<>();
        // 张三|中国|1986-05-00|400000198605000031
        // 张三|中国|400000198412081627
        // 张三|中国|1986-05-00
        Pattern pattern = Pattern.compile("((([\\u4E00-\\u9FA5]{2,}|([a-zA-Z]{3,}\\s*+)+)\\|[\\u4E00-\\u9FA5]{2,}\\|)" + //NOSONAR
                                                        "(((\\d{4}-\\d{2}-\\d{2})(\\|((\\d{15}(\\d{2}[0-9xX])?)|[0-9a-zA-Z]{8,9}))?)" +
                                                        "|((\\d{15}(\\d{2}[0-9xX])?)|[0-9a-zA-Z]{8,9})))");
        Matcher matcher = pattern.matcher(nodeTextString);
        while (matcher.find()) {
            String group = matcher.group();
            List<String> textList = Arrays.asList(group.split("\\|"));
            list.add(textList);
        }

        for (List<String> textList : list) {
            if (textList.contains(holderIdNo) || containBirthDay(holderIdNo, textList)) {
                // 张三|中国|1986-05-00|400000198605000031
                if (StringUtils.isBlank(appGjzwfwHyzjOriginal.getHolderName())) { //NOSONAR
                    appGjzwfwHyzjOriginal.setHolderName(textList.get(0));
                }
            } else if (textList.contains(partnerIdNo) || containBirthDay(partnerIdNo, textList)) {
                // 李四|中国|1984-12-08|4000001984120816270034
                if (StringUtils.isBlank(appGjzwfwHyzjOriginal.getPartnerName())) { //NOSONAR
                    appGjzwfwHyzjOriginal.setPartnerName(textList.get(0));
                }
            }
        }

        //遇到特殊用力，不匹配上面格式
        if (StringUtils.isAnyEmpty(appGjzwfwHyzjOriginal.getHolderIdNo(), appGjzwfwHyzjOriginal.getHolderName(),
                appGjzwfwHyzjOriginal.getPartnerIdNo(), appGjzwfwHyzjOriginal.getPartnerName())) {
            //|吴世凤|2020-04-08|J340122-2020-001584|官永华|中国|吴世凤|中国|1986-12-29|350427198612294512|1990-04-07|340123199004071105|合肥市肥东县民政局婚姻登记处|杨严冬
            Pattern pattern2 = Pattern.compile("[\\u4E00-\\u9FA5]{2,}\\|中国\\|[\\u4E00-\\u9FA5]{2,}\\|中国");
            Matcher matcher2 = pattern2.matcher(nodeTextString);
            List<String> textList2 = new ArrayList<>();
            while (matcher2.find()) {
                String group = matcher2.group();
                textList2 = Arrays.asList(group.split("\\|"));
            }
            if (nodeTextString.contains("点击查看电子签章验证信息|" + textList2.get(2))) {
                appGjzwfwHyzjOriginal.setHolderName(textList2.get(2));
                appGjzwfwHyzjOriginal.setPartnerName(textList2.get(0));
            } else {
                appGjzwfwHyzjOriginal.setHolderName(textList2.get(0));
                appGjzwfwHyzjOriginal.setPartnerName(textList2.get(2));
            }

        }

        if (StringUtils.isAnyEmpty(appGjzwfwHyzjOriginal.getHolderIdNo(), appGjzwfwHyzjOriginal.getHolderName(),
                appGjzwfwHyzjOriginal.getPartnerIdNo(), appGjzwfwHyzjOriginal.getPartnerName())) {
            throw new RuntimeException("the 4 parse fields are not completely parsed");
        }
        return appGjzwfwHyzjOriginal;
    }

    private boolean containBirthDay(String idNo, List<String> textList) {
        return idNo.length() >= 15 &&
                textList.contains(idNo.substring(6, 10).concat("-").concat(idNo.substring(10, 12).concat("-").concat(idNo.substring(12, 14))));
    }

    public static void main(String[] args) {
        AppGjzwfwHyzjXmlParser appGjzwfwHyzjXmlParser = new AppGjzwfwHyzjXmlParser();
        String json = "";

//        json = appGjzwfwHyzjXmlParser.parseAppGjzwfwHyzjXmlToJson("", "D:\\data\\file\\app-gjzwfw-hyzj\\app-gjzwfw-hyzj-jhz-1.xml", "").getData();
//        System.out.println(json);
//
//        json = appGjzwfwHyzjXmlParser.parseAppGjzwfwHyzjXmlToJson("", "D:\\data\\file\\app-gjzwfw-hyzj\\app-gjzwfw-hyzj-jhz-2.xml", "").getData();
//        System.out.println(json);
//
//        json = appGjzwfwHyzjXmlParser.parseAppGjzwfwHyzjXmlToJson("", "D:\\data\\file\\app-gjzwfw-hyzj\\app-gjzwfw-hyzj-lhz-1.xml", "").getData();
//        System.out.println(json);

        json = appGjzwfwHyzjXmlParser.parseAppGjzwfwHyzjXmlToJson("", "D:\\data\\file\\app-gjzwfw-hyzj\\20240311\\app-gjzwfw-hyzj-jhz-original-1.xml", "350427198612294512").getData();
        System.out.println(json);
    }
}
