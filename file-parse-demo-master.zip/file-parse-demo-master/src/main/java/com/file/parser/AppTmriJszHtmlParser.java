package com.file.parser;

import com.file.bo.AppTmriJsz;
import com.file.bo.ResponseData;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.File;
import java.io.IOException;

/**
 * 交管12123APP电子驾驶证html解析
 * @author anyspa
 */

@Slf4j
public class AppTmriJszHtmlParser {
    public ResponseData<String> parseAppTmriJszHtmlToJson(String daId, String filePath) {
        log.info("parseAppTmriJszHtmlToJson started, daId:{}, filePath:{}", daId, filePath);
        String json;

        try {
            AppTmriJsz appTmriJsz = parseAppTmriJszHtml(filePath);
            json = JsonUtils.convertObjectToJson(appTmriJsz);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseAppTmriJszHtmlToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseAppTmriJszHtmlToJson completed, daId:{}, filePath:{}", daId, filePath);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private AppTmriJsz parseAppTmriJszHtml(String filePath) throws IOException {
        log.info("parseAppTmriJszHtml started, filePath:{}", filePath);
        AppTmriJsz appTmriJsz = new AppTmriJsz();
        AppTmriJsz.AppTmriJszPositivePage appTmriJszPositivePage = new AppTmriJsz.AppTmriJszPositivePage();
        AppTmriJsz.AppTmriJszSecondaryPage appTmriJszSecondaryPage = new AppTmriJsz.AppTmriJszSecondaryPage();

        File input = new File(filePath);
        Document doc = Jsoup.parse(input, "UTF-8");
        String name = getValueByCssQuery(doc, ".xm");
        String quasiDrivingModel = getValueByCssQuery(doc, ".zjcx");
        String score = getValueByCssQuery(doc, ".ljjfSpan");
        String initialApplicationDate = getValueByCssQuery(doc, ".cclzrq");
        String status = getValueByCssQuery(doc, ".ztStr");
        String certificateNumber = getValueByCssQuery(doc, ".sfzmhm");
        String sex = getValueByCssQuery(doc, ".xbStr");
        String birthDay = getValueByCssQuery(doc, ".csrq");
        String nationality = getValueByCssQuery(doc, ".gjStr");
        String archivesNo = getValueByCssQuery(doc, ".dabh");
        String validityPeriod = getValueByCssQuery(doc, ".yxqs")
                .concat(" 至").concat(getValueByCssQuery(doc, ".yxqz"));
        String generationTime = getValueByCssQuery(doc, ".scsj");
        String currentTime = getValueByCssQuery(doc, "#nowTime");
        String coreNumber = getValueByCssQuery(doc, "#zxbhDiv");
        if (coreNumber.trim().startsWith("*") && coreNumber.endsWith("*")) {
            coreNumber = coreNumber.trim().substring(1, coreNumber.length() -1);
        }
        appTmriJszPositivePage.setName(name);
        appTmriJszPositivePage.setQuasiDrivingModel(quasiDrivingModel);
        appTmriJszPositivePage.setScore(score);
        appTmriJszPositivePage.setInitialApplicationDate(initialApplicationDate);
        appTmriJszPositivePage.setStatus(status);
        appTmriJszPositivePage.setCertificateNumber(certificateNumber);
        appTmriJszPositivePage.setSex(sex);
        appTmriJszPositivePage.setBirthDay(birthDay);
        appTmriJszPositivePage.setNationality(nationality);
        appTmriJszPositivePage.setArchivesNo(archivesNo);
        appTmriJszPositivePage.setValidityPeriod(validityPeriod);
        appTmriJszPositivePage.setGenerationTime(generationTime);
        appTmriJszPositivePage.setCurrentTime(currentTime);
        appTmriJszPositivePage.setCoreNumber(coreNumber);
        appTmriJsz.setAppTmriJszPositivePage(appTmriJszPositivePage);

        String address = getValueByCssQuery(doc, ".djzsxxdz");
        String issuingAuthority = getValueByCssQuery(doc, ".fzjgStr");
        String record = getValueByCssQuery(doc, "#records");
        appTmriJszSecondaryPage.setAddress(address);
        appTmriJszSecondaryPage.setIssuingAuthority(issuingAuthority);
        appTmriJszSecondaryPage.setRecord(record);
        appTmriJsz.setAppTmriJszSecondaryPage(appTmriJszSecondaryPage);

        return appTmriJsz;
    }

    private String getValueByCssQuery(Document doc, String cssQuery) {
        Element element = doc.select(cssQuery).first();
        if (element != null) {
            return element.text();
        }
        return "";
    }
    public static void main(String[] args) {
        AppTmriJszHtmlParser appTmriJszHtmlParser = new AppTmriJszHtmlParser();
        String json = appTmriJszHtmlParser.parseAppTmriJszHtmlToJson("", "D:\\data\\file\\appTmriJsz\\app-tmri-jsz-dzjsz.html").getData();
        System.out.println(json);
    }
}