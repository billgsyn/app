package com.file.parser;

import com.file.bo.ResponseData;
import com.file.bo.Taxe;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 任职单位 解析
 * @author anyspa
 */

@Slf4j
public class TaxeHtmlParser extends BaseDecryptPdfParser {

    public ResponseData<String> parseTaxeHtmlToJson(String daId, String filePath) {
        log.info("parseTaxeToJson started, daId:{}", daId);
        String json;

        try {
            Taxe taxe = parseTaxeHtml(filePath);
            json = JsonUtils.convertObjectToJson(taxe);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseTaxeToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(),
                    ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseTaxeToJson completed, daId:{}, json:{}", daId, json);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private Taxe parseTaxeHtml(String filePath) throws IOException {
        File input = new File(filePath);
        Taxe taxe = new Taxe();
        List<Taxe.EmploymentInfo> employmentInfoList = new ArrayList<>();

        Document doc = Jsoup.parse(input, "UTF-8");

        taxe.setName(doc.select(".uncommon-word-tag").text());

        Elements employmentElements = doc.select(".employment-body > .employment-item");

        for (Element element : employmentElements) {
            Taxe.EmploymentInfo employmentInfo = new Taxe.EmploymentInfo();
            String employedCompany = element.select(".employment-title").text();
            employmentInfo.setEmployedCompany(employedCompany);

            // 统一社会信用代码：91440300590730176J 任职受雇日期：2018-06-01
            String employmentGroupText = element.select(".employment-group").text();
            String unifiedSocialCreditCode = employmentGroupText.substring(employmentGroupText.indexOf("统一社会信用代码：") + 9,
                    employmentGroupText.indexOf("任职受雇日期")).trim();
            String employedPeriod = employmentGroupText.substring(employmentGroupText.indexOf("任职受雇日期：") + 7).trim();
            employmentInfo.setUnifiedSocialCreditCode(unifiedSocialCreditCode);
            employmentInfo.setEmployedPeriod(employedPeriod);

            // 职务：未填写 离职日期：未填写
            String employmentGroupRightText = element.select(".employment-group-right").text();
            String position = employmentGroupRightText.substring(employmentGroupRightText.indexOf("职务：") + 3,
                    employmentGroupRightText.indexOf("离职日期")).trim();
            String reasonDate = employmentGroupRightText.substring(employmentGroupRightText.indexOf("离职日期：") + 5).trim();
            employmentInfo.setPosition(position);
            employmentInfo.setReasonDate(reasonDate);

            employmentInfoList.add(employmentInfo);
        }
        taxe.setEmploymentInfoList(employmentInfoList);

        log.info(taxe.toString());
        return taxe;

    }

    public boolean hasEmploymentData(String filePath) {
        boolean hasEmploymentData = true;

        try {
            File input = new File(filePath);
            Document doc = Jsoup.parse(input, "UTF-8");
            Elements employmentElements = doc.select(".employment-body > .employment-item");
            if (employmentElements.size() == 0) {
                hasEmploymentData = false;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return hasEmploymentData;
    }

    public static void main(String[] args) {
//        String filePath = "E:\\data\\file\\taxe\\zd1tuknz1565517340614049792_5c5b2eb0164fe8d7a1e4c8bcebf43b4d_taxe_employment.html";
        String filePath = "D:\\data\\file\\taxe\\taxeat_employment.html";

        TaxeHtmlParser taxeParser = new TaxeHtmlParser();
        boolean hasEmploymentData = taxeParser.hasEmploymentData(filePath);
        System.out.println(hasEmploymentData);

//        String json = taxeParser.parseTaxeHtmlToJson("", filePath).getData();
//        System.out.println(json);
    }
}
