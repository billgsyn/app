package com.file.parser;

import com.file.bo.ResponseData;
import com.file.bo.SHBDC;
import com.file.constant.ErrorCode;
import com.file.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import technology.tabula.*;
import technology.tabula.detectors.NurminenDetectionAlgorithm;
import technology.tabula.extractors.SpreadsheetExtractionAlgorithm;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 上海不动产pdf解析
 *
 * @author anyspa
 */

@Slf4j
public class SHBDCPdfParser extends BasePdfParser {

    public ResponseData<String> parseSHBDCPdfToJson(String daId, String filePath) {
        log.info("parseSHBDCPdfToJson started, daId:{}", daId);
        String json;

        try {
            SHBDC shbdc = parseSHBDCPdf(daId, filePath);
            json = JsonUtils.convertObjectToJson(shbdc);
        } catch (Exception e) {
            log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), daId, "", "", "parseSHBDCPdfToJson failed", e);
            return new ResponseData<>(null, ErrorCode.FILE_PARSE_EXCEPTION.getCode(), ErrorCode.FILE_PARSE_EXCEPTION.getMsg());
        }

        log.info("parseSHBDCPdfToJson completed, daId:{}", daId);
        return new ResponseData<>(json, ErrorCode.SUCCESS.getCode(), ErrorCode.SUCCESS.getMsg());
    }

    private SHBDC parseSHBDCPdf(String daId, String filePath) {
        SHBDC shbdc = new SHBDC();
        shbdc.setHouseStatusAndOwnerInfo(new SHBDC.HouseStatusAndOwnerInfo());
        shbdc.setLandStatusInfo(new SHBDC.LandStatusInfo());
        shbdc.setEstateMortgageInfos(new ArrayList<>());
        shbdc.setDocumentRegistrationInfos(new ArrayList<>());

        String pdfHeaderText = getPdfTextByStripper2(filePath);
        if (pdfHeaderText.contains("未查到房屋登记信息")) {
            log.info("未查到房屋登记信息, daId:{}", daId);
            shbdc.getEstateMortgageInfos().add(new SHBDC.RealEstateMortgageInfo());
            shbdc.getDocumentRegistrationInfos().add(new SHBDC.DocumentRegistrationInfo());
            return shbdc;
        }

        Map<String, String> map = parseSHBDCHeader(shbdc, pdfHeaderText);
        parseSHBDC(filePath, shbdc);
        shbdc.getEstateMortgageInfos().forEach(realEstateMortgageInfo -> realEstateMortgageInfo.setNo(map.get("estateMortgageNo")));
        shbdc.getDocumentRegistrationInfos().forEach(documentRegistrationInfo -> documentRegistrationInfo.setNo(map.get("documentRegistrationNo")));
        return shbdc;
    }

    public boolean hasShbdcData(String filePath) {
        boolean hasShbdcData = true;
        String pdfHeaderText = getPdfTextByStripper2(filePath);
        if (pdfHeaderText.contains("未查到房屋登记信息")) {
            hasShbdcData = false;
        }
        return hasShbdcData;
    }

    private Map<String, String> parseSHBDCHeader(SHBDC shbdc, String pdfHeaderText) {
        int startIndex = pdfHeaderText.indexOf("房屋状况及产权人信息 N") + 14;
        String houseStatusInfoNo = pdfHeaderText.substring(startIndex, startIndex + 12);

        startIndex = pdfHeaderText.indexOf("土地状况信息 N") + 10;
        String landStatusInfoNo = pdfHeaderText.substring(startIndex, startIndex + 12);
        shbdc.getHouseStatusAndOwnerInfo().setNo(houseStatusInfoNo.trim());
        shbdc.getLandStatusInfo().setNo(landStatusInfoNo.trim());

        Map<String, String> map = new HashMap<>();
        if (pdfHeaderText.contains("房地产抵押状况信息 N")) {
            startIndex = pdfHeaderText.indexOf("房地产抵押状况信息 N") + 13;
            String estateMortgageNo = pdfHeaderText.substring(startIndex, startIndex + 12);
            map.put("estateMortgageNo", estateMortgageNo);
        } else {
            map.put("estateMortgageNo", null);
        }

        if (pdfHeaderText.contains("文件登记信息 N")) {
            startIndex = pdfHeaderText.indexOf("文件登记信息 N") + 10;
            String documentRegistrationNo = pdfHeaderText.substring(startIndex, startIndex + 12);
            map.put("documentRegistrationNo", documentRegistrationNo);
        } else {
            map.put("documentRegistrationNo", null);
        }
        return map;
    }

    private void parseSHBDC(String filePath, SHBDC shbdc) {
        // 1. 读取文件
        File pdf = new File(filePath);

        // 2. pdfbox读取PDDocument
        try (PDDocument pdfDocument = PDDocument.load(pdf)) {

            // 3. tabula新建ObjectExtractor和NurminenDetectionAlgorithm，同时准备接收表格Rectangle的结构
            ObjectExtractor objectExtractor = new ObjectExtractor(pdfDocument);
            NurminenDetectionAlgorithm detectionAlgorithm = new NurminenDetectionAlgorithm();
            Map<Integer, List<Rectangle>> detectedTables = new HashMap<>();

            // 4. 获取每页的PageIterator
            PageIterator pages = objectExtractor.extract();

            // 5. 解析每页的Rectangle(table的位置)
            while (pages.hasNext()) {
                Page page = pages.next();
                List<Rectangle> tablesOnPage = detectionAlgorithm.detect(page);
                if (tablesOnPage.size() > 0) {
                    detectedTables.put(page.getPageNumber(), tablesOnPage);
                }
            }

            // 6.通过table位置获取表格具体内容
            SpreadsheetExtractionAlgorithm bea = new SpreadsheetExtractionAlgorithm();

            // 正常情况下, pdf文件中至少包含"房屋状况及产权人信息" 和 "土地状况信息" 两个section, 且分别分布在两个page页中
            if (detectedTables.size() < 2) {
                log.error("OnError|{}||{}|{}|{}|{}", ErrorCode.FILE_PARSE_EXCEPTION.getCode(), "", "", "", "SHBDC Pdf pages changed");
                throw new RuntimeException();
            }

            // 如果单页pdf中有多个表格，则解析出来的List<Rectangle>会有多个对象
            for (Map.Entry<Integer, List<Rectangle>> entry : detectedTables.entrySet()) {
                Page page = objectExtractor.extract(entry.getKey());

                List<TextElement> list = page.getText();
                StringBuilder text = new StringBuilder();
                list.forEach(textElement -> text.append(textElement.getText()));

                // 默认每页只有一个表格，因此获取第0个rectangle
                Rectangle rectangle = entry.getValue().get(0);
                Page area = page.getArea(rectangle.getTop(), rectangle.getLeft(), rectangle.getBottom(), rectangle.getRight());

                List<Table> table = bea.extract(area);

                // 默认每页只有一个表格，因此获取第0个table
                Table t = table.get(0);
                String queryDate = text.substring(text.lastIndexOf("查询日期：") + 5).trim();
                if (text.toString().contains("房屋状况及产权人信息N")) {
                    shbdc.getHouseStatusAndOwnerInfo().setQueryDate(queryDate);
                    for (int i = 0; i < t.getRowCount(); i++) {
                        parseHouseInfo(t, i, shbdc.getHouseStatusAndOwnerInfo());
                    }
                } else if (text.toString().contains("土地状况信息N")) {
                    shbdc.getLandStatusInfo().setQueryDate(queryDate);
                    for (int i = 0; i < t.getRowCount(); i++) {
                        parseLandStatusInfo(t, i, shbdc.getLandStatusInfo());
                    }
                } else if (text.toString().contains("房地产抵押状况信息N")) {
                    // 正常情况下每条记录占9行
                    int recordSize = t.getRowCount() / 9;
                    for (int i = 0; i < recordSize; i++) {
                        SHBDC.RealEstateMortgageInfo realEstateMortgageInfo = new SHBDC.RealEstateMortgageInfo();
                        for (int j = 0; j < 9; j++) {
                            parseRealEstateMortgageInfo(t, j + (i * 9), realEstateMortgageInfo);
                        }
                        realEstateMortgageInfo.setQueryDate(queryDate);
                        shbdc.getEstateMortgageInfos().add(realEstateMortgageInfo);
                    }
                } else if (text.toString().contains("文件登记信息N")) {
                    // 正常情况下每条记录占6行
                    int recordSize = t.getRowCount() / 6;
                    for (int i = 0; i < recordSize; i++) {
                        SHBDC.DocumentRegistrationInfo documentRegistrationInfo = new SHBDC.DocumentRegistrationInfo();
                        for (int j = 0; j < 6; j++) {
                            parseDocumentRegistrationInfo(t, j + (i * 6), documentRegistrationInfo);
                        }
                        documentRegistrationInfo.setQueryDate(queryDate);
                        shbdc.getDocumentRegistrationInfos().add(documentRegistrationInfo);
                    }
                }
            }

            if (shbdc.getEstateMortgageInfos().isEmpty()) {
                shbdc.getEstateMortgageInfos().add(new SHBDC.RealEstateMortgageInfo());
            }
            if (shbdc.getDocumentRegistrationInfos().isEmpty()) {
                shbdc.getDocumentRegistrationInfos().add(new SHBDC.DocumentRegistrationInfo());
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void parseHouseInfo(Table t, int i, SHBDC.HouseStatusAndOwnerInfo houseStatusInfo) {
        if (i == 0) {
            if (t.getCell(i, 0).getText(false).contains("房屋坐落")) {
                houseStatusInfo.setHouseLocation(t.getCell(i, 1).getText(false));
            }
        } else if (i == 1) {
            if (t.getCell(i, 0).getText(false).contains("幢号")) {
                houseStatusInfo.setBuildingNo(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("部位")) {
                houseStatusInfo.setPosition(t.getCell(i, 3).getText(false));
            }
        } else if (i == 2) {
            if (t.getCell(i, 0).getText(false).contains("建筑面积")) {
                houseStatusInfo.setFloorArea(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("其中地下建筑面积")) {
                houseStatusInfo.setUndergroundFloorArea(t.getCell(i, 3).getText(false));
            }
        } else if (i == 3) {
            if (t.getCell(i, 0).getText(false).contains("房屋类型")) {
                houseStatusInfo.setHouseType(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("房屋结构")) {
                houseStatusInfo.setHouseStructure(t.getCell(i, 3).getText(false));
            }
        } else if (i == 4) {
            if (t.getCell(i, 0).getText(false).contains("所有权来源")) {
                houseStatusInfo.setSourceOfOwnership(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("竣工日期")) {
                houseStatusInfo.setCompletionDate(t.getCell(i, 3).getText(false));
            }
        } else if (i == 5) {
            if (t.getCell(i, 0).getText(false).contains("房屋用途")) {
                houseStatusInfo.setHousePurposes(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("总层数")) {
                houseStatusInfo.setTotalFloors(t.getCell(i, 3).getText(false));
            }
        } else if (i == 6) {
            if (t.getCell(i, 0).getText(false).contains("权利人")) {
                houseStatusInfo.setObligee(t.getCell(i, 1).getText(false));
            }
        } else if (i == 7) {
            if (t.getCell(i, 0).getText(false).contains("共有人及共有情况")) {
                houseStatusInfo.setCoOwnersAndCoOwnership(t.getCell(i, 1).getText(false));
            }
        } else if (i == 8) {
            if (t.getCell(i, 0).getText(false).contains("房地产权证号")) {
                houseStatusInfo.setRealEstateOwnershipCertificateNo(t.getCell(i, 1).getText(false));
            }
        } else if (i == 9) {
            if (t.getCell(i, 0).getText(false).contains("受理日期")) {
                houseStatusInfo.setAcceptanceDate(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("核准日期")) {
                houseStatusInfo.setApprovalDate(t.getCell(i, 3).getText(false));
            }
        } else if (i == 10) {
            if (t.getCell(i, 0).getText(false).contains("备注")) {//NOSONAR
                houseStatusInfo.setComment(t.getCell(i, 1).getText(false));
            }
        }
    }

    private void parseLandStatusInfo(Table t, int i, SHBDC.LandStatusInfo landStatusInfo) {
        if (i == 0) {
            if (t.getCell(i, 0).getText(false).contains("土地坐落")) {
                landStatusInfo.setLandLocation(t.getCell(i, 1).getText(false));
            }
        } else if (i == 1) {
            if (t.getCell(i, 0).getText(false).contains("土地宗地号")) {
                landStatusInfo.setLandParcelNo(t.getCell(i, 1).getText(false));
            }
        } else if (i == 2) {
            if (t.getCell(i, 0).getText(false).contains("使用期限")) {
                landStatusInfo.setServiceLife(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("土地权属性质")) {
                landStatusInfo.setNatureOfLandOwnership(t.getCell(i, 3).getText(false));
            }
        } else if (i == 3) {
            if (t.getCell(i, 0).getText(false).contains("使用权取得方式")) {
                landStatusInfo.setAcquisitionMethodOfUseRight(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("土地用途")) {
                landStatusInfo.setLandUse(t.getCell(i, 3).getText(false));
            }
        } else if (i == 4) {
            if (t.getCell(i, 0).getText(false).contains("宗地(丘)面积")) {
                landStatusInfo.setLandArea(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("使用权面积")) {
                landStatusInfo.setAreaOfUseRight(t.getCell(i, 3).getText(false));
            }
        } else if (i == 5) {
            if (t.getCell(i, 0).getText(false).contains("独用面积")) {
                landStatusInfo.setExclusiveUseArea(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("分摊面积")) {
                landStatusInfo.setAllocatedArea(t.getCell(i, 3).getText(false));
            }
        } else if (i == 6) {
            if (t.getCell(i, 0).getText(false).contains("权利人")) {
                landStatusInfo.setObligee(t.getCell(i, 1).getText(false));
            }
        } else if (i == 7) {
            if (t.getCell(i, 0).getText(false).contains("共有人及共有情况")) {
                landStatusInfo.setCoOwnersAndCoOwnership(t.getCell(i, 1).getText(false));
            }
        } else if (i == 8) {
            if (t.getCell(i, 0).getText(false).contains("房地产权证号")) {
                landStatusInfo.setRealEstateOwnershipCertificateNo(t.getCell(i, 1).getText(false));
            }
        } else if (i == 9) {
            if (t.getCell(i, 0).getText(false).contains("受理日期")) {
                landStatusInfo.setAcceptanceDate(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("核准日期")) {
                landStatusInfo.setApprovalDate(t.getCell(i, 3).getText(false));
            }
        } else if (i == 10) {
            if (t.getCell(i, 0).getText(false).contains("备注")) {//NOSONAR
                landStatusInfo.setComment(t.getCell(i, 1).getText(false));
            }
        }
    }

    private void parseRealEstateMortgageInfo(Table t, int i, SHBDC.RealEstateMortgageInfo realEstateMortgageInfo) {
        if (i % 9 == 0) {
            if (t.getCell(i, 0).getText(false).contains("房地产坐落")) {
                realEstateMortgageInfo.setRealEstateLocation(t.getCell(i, 1).getText(false));
            }
        } else if (i % 9 == 1) {
            if (t.getCell(i, 0).getText(false).contains("幢号")) {
                realEstateMortgageInfo.setBuildingNo(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("部位")) {
                realEstateMortgageInfo.setPosition(t.getCell(i, 3).getText(false));
            }
        } else if (i % 9 == 2) {
            if (t.getCell(i, 0).getText(false).contains("抵押权人")) {
                realEstateMortgageInfo.setMortgagee(t.getCell(i, 1).getText(false));
            }
        } else if (i % 9 == 3) {
            if (t.getCell(i, 0).getText(false).contains("登记证明号")) {
                realEstateMortgageInfo.setRegistrationCertificateNo(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("债权数额")) {
                realEstateMortgageInfo.setAmountOfCredit(t.getCell(i, 3).getText(false));
            }
        } else if (i % 9 == 4) {
            if (t.getCell(i, 0).getText(false).contains("债务履行期限")) {
                realEstateMortgageInfo.setDebtPerformancePeriod(t.getCell(i, 1).getText(false));
            }
        } else if (i % 9 == 5) {
            if (t.getCell(i, 0).getText(false).contains("受理日期")) {
                realEstateMortgageInfo.setAcceptanceDate(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("核准日期")) {
                realEstateMortgageInfo.setApprovalDate(t.getCell(i, 3).getText(false));
            }
        } else if (i % 9 == 6) {
            if (t.getCell(i, 0).getText(false).contains("抵押担保范围")) {
                realEstateMortgageInfo.setMortgageGuaranteeScope(t.getCell(i, 1).getText(false));
            }
        } else if (i % 9 == 7) {
            if (t.getCell(i, 0).getText(false).contains("关于不动产转让的约定")) {
                realEstateMortgageInfo.setRealEstateTransferAgreement(t.getCell(i, 1).getText(false));
            }
        } else if (i % 9 == 8) {
            if (t.getCell(i, 0).getText(false).contains("备注")) {//NOSONAR
                realEstateMortgageInfo.setComment(t.getCell(i, 1).getText(false));
            }
        }
    }

    private void parseDocumentRegistrationInfo(Table t, int i, SHBDC.DocumentRegistrationInfo documentRegistrationInfo) {
        if (i % 6 == 0) {
            if (t.getCell(i, 0).getText(false).contains("申请人")) {
                documentRegistrationInfo.setApplicant(t.getCell(i, 1).getText(false));
            }
        } else if (i % 6 == 1) {
            if (t.getCell(i, 0).getText(false).contains("房地产坐落")) {
                documentRegistrationInfo.setRealEstateLocation(t.getCell(i, 1).getText(false));
            }
        } else if (i % 6 == 2) {
            if (t.getCell(i, 0).getText(false).contains("文件名称")) {
                documentRegistrationInfo.setDocumentName(t.getCell(i, 1).getText(false));
            }
            if (t.getCell(i, 2).getText(false).contains("文件号")) {
                documentRegistrationInfo.setDocumentNo(t.getCell(i, 3).getText(false));
            }
        } else if (i % 6 == 3) {
            if (t.getCell(i, 0).getText(false).contains("登记证明号")) {
                documentRegistrationInfo.setRegistrationCertificateNo(t.getCell(i, 1).getText(false));
            }
        } else if (i % 6 == 4) {
            if (t.getCell(i, 0).getText(false).contains("受理日期")) {
                documentRegistrationInfo.setAcceptanceDate(t.getCell(i, 1).getText(false));
            }
        } else if (i % 6 == 5) {
            if (t.getCell(i, 0).getText(false).contains("备注")) {//NOSONAR
                documentRegistrationInfo.setComment(t.getCell(i, 1).getText(false));
            }
        }
    }

    public static void main(String[] args) {
        SHBDCPdfParser shbdcPdfParser = new SHBDCPdfParser();
        String json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1570367581280419840_31a207b36d4b2dbd97deb3b30e350b0d_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1570367581280419840_f186386439a6befaa8c321bd4dfe3242_shbdc_bdcsj2.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1570367581280419840_ae2119b9f5bcdbd41c92fb2b8208b832_shbdc_bdcsj3.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1570367581280419840_7d2138a93cfebe5c70c3db638ff7cb1f_shbdc_bdcsj4.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zd1tuknz1579359486148329472_609becea0ad9e44777742180e464672b_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1585119959007326208_baffe3208076c0f491a8d6f70dc335fb_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1585191997705252864_bc8433d022c0a4016043444e8f52d973_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1585475404460965888_7f13519143a1dca3e3ae53ebb3d78947_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1585523226652667904_087994ede34bda79d9d8e465c1b49e71_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1585574681329688576_966ac7d3e5d04c476b35890a5cdcc7d5_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1585574681329688576_1fa56d7eb510467a53d5a1b8ac3a7f30_shbdc_bdcsj2.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1585574681329688576_bd4a6df397a39ba0eb20d7b5d82894da_shbdc_bdcsj3.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1586300808482504704_47e701bbd428f7a882aa57570f66c58a_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1586927959204413440_51fcc3c02199ea2e969defd38b4fccb9_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1586910429999939584_51603c0a6bd64381cc4c2b9c3d7abdb6_shbdc_bdcsj2.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1586910429999939584_79e42988ba597f67255ebe5502e071d4_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1586893835374575616_b4e5ff778362fcf73e4e295643d6135e_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);

        json = shbdcPdfParser.parseSHBDCPdfToJson("", "D:\\data\\files\\SHBDC\\zddbcvaq1586880108168364032_fdb4a3fc9a98c8f243b128f42e63f02c_shbdc_bdcsj1.pdf").getData();
        System.out.println(json);
    }
}
