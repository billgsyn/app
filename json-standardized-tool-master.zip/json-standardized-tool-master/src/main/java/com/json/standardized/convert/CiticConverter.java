package com.json.standardized.convert;

import com.json.mapping.util.JsonUtil;
import com.json.standardized.bo.*;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 浦发流水标准化字段输出
 */
public class CiticConverter {

	public String convert(String json) throws Exception {
		CITIC citic = JsonUtil.json2Object(json, CITIC.class);
		String standardizedJson = "";

		StandardizedBank standardizedBank = new StandardizedBank();
		standardizedBank.setAccountName(citic.getAccountName());
		standardizedBank.setCardNumber(citic.getAccountNo());
		standardizedBank.setIdNumber(citic.getIdNumber());
		// Assuming startDate and endDate are extracted from inquiryPeriod
		String[] dates = citic.getInquiryPeriod().split("-");
		if (dates.length == 2) {
			String startDate = dates[0];
			standardizedBank.setStartDate(startDate.substring(0, 4) + "-" + startDate.substring(4, 6) + "-" + startDate.substring(6, 8));
			String endDate = dates[1];
			standardizedBank.setEndDate(endDate.substring(0, 4) + "-" + endDate.substring(4, 6) + "-" + endDate.substring(6, 8));
		}
		// Assuming printTime is not available in CITIC, set it to null or a default value
		standardizedBank.setPrintTime(citic.getIssuanceDate());

		List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
		for (CITICTran citicTran : citic.getCiticTrans()) {
			StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
			String tranDate = citicTran.getTransactionDate();
			standardizedBankTran.setTranDate(tranDate.substring(0, 4) + "-" + tranDate.substring(4, 6) + "-" + tranDate.substring(6, 8));
			// Assuming tranTime is not available in CITICTran, set it to null or a default value
			standardizedBankTran.setTranTime(null);
			standardizedBankTran.setCurrency(citic.getCurrency());
			// Assuming amount is the sum of accountReceivable and accountPaid
			String amount = StringUtils.isNotEmpty(citicTran.getAccountReceivable())? citicTran.getAccountReceivable().replace("RMB", "").trim() : "-" + citicTran.getAccountPaid().replace("RMB", "").trim();
			standardizedBankTran.setAmount(amount);
			standardizedBankTran.setBalance(citicTran.getAccountBalance().replace("RMB", "").trim());
			standardizedBankTran.setTranName(citicTran.getDescription());
			standardizedBankTran.setChannel(null); // Assuming channel is not available in CITICTran
			standardizedBankTran.setCounterpartInfo(citicTran.getRecipient());
			standardizedBankTran.setPostscript(null); // Assuming postscript is not available in CITICTran
			standardizedBankTrans.add(standardizedBankTran);

		}
		standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

		standardizedJson = JsonUtil.object2Json(standardizedBank);
		return standardizedJson;
	}

	public static void main(String[] args) throws Exception {
		CiticConverter citicConverter = new CiticConverter();
		String citicJson = "{\n" +
				"\"户名\": \"刘艺\",\n" +
				"\"证件类型\": \"居民身份证\",\n" +
				"\"证件号码\": \"422802199712035410\",\n" +
				"\"账号\": \"6217711507694121\",\n" +
				"\"时间段\": \"20220802-20230801\",\n" +
				"\"开立日期\": \"2023-08-02\",\n" +
				"\"查询最低限额\": \"0\",\n" +
				"\"币种\": \"全部\",\n" +
				"\"交易明细\": [\n" +
				"{\n" +
				"\"交易日期\": \"20220802\",\n" +
				"\"账户序号\": \"000001\",\n" +
				"\"收入金额\": \"RMB 50.00\",\n" +
				"\"支出金额\": \"\",\n" +
				"\"账户余额\": \"RMB 1922.71\",\n" +
				"\"交易摘要\": \"支付宝\",\n" +
				"\"对方户名\": \"\",\n" +
				"\"被冲账标识\": \"N\"\n" +
				"},\n" +
				"{\n" +
				"\"交易日期\": \"20220802\",\n" +
				"\"账户序号\": \"000001\",\n" +
				"\"收入金额\": \"\",\n" +
				"\"支出金额\": \"RMB 22.45\",\n" +
				"\"账户余额\": \"RMB 1900.26\",\n" +
				"\"交易摘要\": \"京东支付\",\n" +
				"\"对方户名\": \"\",\n" +
				"\"被冲账标识\": \"N\"\n" +
				"}]\n" +
				"}";
		String standardizedJson = citicConverter.convert(citicJson);
		System.out.println(standardizedJson);
	}
}
