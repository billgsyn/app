package com.json.standardized.convert;


public class GeneralConverter {

    private ABCConverter abcConverter = new ABCConverter();

    private CCBConverter ccbConverter = new CCBConverter();

    private CMBConverter cmbConverter = new CMBConverter();

    private SPDConverter spdConverter = new SPDConverter();

    private PABConverter pabConverter = new PABConverter();

    private CGBConverter cgbConverter = new CGBConverter();

    private ICBCConverter icbcConverter = new ICBCConverter();

    private CiticConverter citicConverter = new CiticConverter();

    private CMBCConverter cmbcConverter = new CMBCConverter();

    private BCMConverter bcmConverter = new BCMConverter();

    private BOCConverter bocConverter = new BOCConverter();

    private PSBCConverter psbcConverter = new PSBCConverter();

    private BJRCBConverter bjrcbConverter = new BJRCBConverter();
    private BOBConverter bobConverter = new BOBConverter();
    private CZBConverter czbConverter = new CZBConverter();
    private HNNXConverter hnnxConverter = new HNNXConverter();
    private JsBankConverter jsBankConverter = new JsBankConverter();
    private NJCBConverter njcbConverter = new NJCBConverter();
    private SCRCUConverter scrcuCConverter = new SCRCUConverter();
    private ZYBConverter zybConverter = new ZYBConverter();

    public String parse(String site, String originalJson) throws Exception {
        String targetJson = "";
        switch (site) {
            case "beehive-abc": //农行
                targetJson = abcConverter.convert(originalJson);
                break;
            case "beehive-ccb": //建行
                targetJson = ccbConverter.convert(originalJson);
                break;
            case "beehive-cmb": //招行
                targetJson = cmbConverter.convert(originalJson);
                break;
            case "beehive-spdb": //浦发
                targetJson = spdConverter.convert(originalJson);
                break;
            case "beehive-pabc": //平安
                targetJson = pabConverter.convert(originalJson);
                break;
            case "beehive-gdb": //广发
                targetJson = cgbConverter.convert(originalJson);
                break;
            case "beehive-icbc": //工商
                targetJson = icbcConverter.convert(originalJson);
                break;
            case "beehive-citicb": //中信
                targetJson = citicConverter.convert(originalJson);
                break;
            case "beehive-cmbc": //民生
                targetJson = cmbcConverter.convert(originalJson);
                break;
            case "beehive-bcm": //交行
                targetJson = bcmConverter.convert(originalJson);
                break;
            case "beehive-boc": //中行
                targetJson = bocConverter.convert(originalJson);
                break;
            case "beehive-psbc": //邮储
                targetJson = psbcConverter.convert(originalJson);
                break;
            case "beehive-czb": // 浙商
                targetJson = czbConverter.convert(originalJson);
                break;
            case "beehive-zyb": // 中原银行
                targetJson = zybConverter.convert(originalJson);
                break;
            case "beehive-jsbank": // 江苏银行
                targetJson = jsBankConverter.convert(originalJson);
                break;
            case "beehive-hnnx": // 海南农信
                targetJson = hnnxConverter.convert(originalJson);
                break;
            case "beehive-bjrcb": // 北京农商行
                targetJson = bjrcbConverter.convert(originalJson);
                break;
            case "beehive-bob": // 北京银行
                targetJson = bobConverter.convert(originalJson);
                break;
            case "beehive-njcb": // 南京银行
                targetJson = njcbConverter.convert(originalJson);
                break;
            case "beehive-scrcu": // 四川农信
                targetJson = scrcuCConverter.convert(originalJson);
                break;

        }
        return targetJson;
    }

    public static void main(String[] args) throws Exception {
        String ccbJson = "{\"卡号/账号\":\"6217002870088479298\",\"客户名称\":\"朱**\",\"起始日期\":\"20220430\",\"结束日期\":\"20220530\",\"交易明细\":[{\"序号\":\"1\",\"摘要\":\"银联入账\",\"币别\":\"人民币元\",\"钞汇\":\"钞\",\"交易日期\":\"20220521\",\"交易金额\":\"100.00\",\"账户余额\":\"101.66\",\"交易地点/附言\":\"（云闪付APP）\",\"对方账号与户名\":\"6214835734747353/朱**\"},{\"序号\":\"2\",\"摘要\":\"ETC欠费补扣\",\"币别\":\"人民币元\",\"钞汇\":\"钞\",\"交易日期\":\"20220521\",\"交易金额\":\"-2.85\",\"账户余额\":\"98.81\",\"交易地点/附言\":\"高速ETC记账卡批量扣款\",\"对方账号与户名\":\"034201420000000000001/湖北记账卡清算户\"}]}";

        GeneralConverter generalConverter = new GeneralConverter();
        String targetJson = generalConverter.parse("beehive-ccb", ccbJson);
        System.out.println(targetJson);

    }
}
