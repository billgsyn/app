package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class BOC {

    @JsonProperty("交易区间")
    private String tradeRange;

    @JsonProperty("客户姓名")
    private String customerName;

    @JsonProperty("打印时间")
    private String printTime;

    @JsonProperty("借记卡号")
    private String debitCardNo;

    @JsonProperty("账号")
    private String accountNumber;

    @JsonProperty("按收支筛选")
    private String filterByRevenueAndExpense;

    @JsonProperty("按币种筛选")
    private String filterByCurrency;

    @JsonProperty("交易明细")
    private List<BOCTran> bocTrans;

}
