package com.json.standardized.convert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.standardized.bo.JsBank;
import com.json.standardized.bo.JsBankTran;
import com.json.standardized.bo.StandardizedBank;
import com.json.standardized.bo.StandardizedBankTran;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class JsBankConverter {
    private static final String DATE_FORMAT = "yyyy-MM-dd";

    public String convert(String json) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JsBank jsBank = mapper.readValue(json, JsBank.class);
        StandardizedBank standardizedBank = new StandardizedBank();

        standardizedBank.setAccountName(jsBank.getName());
        standardizedBank.setCardNumber(jsBank.getCardNo());
        standardizedBank.setIdNumber(null); // No direct mapping

        standardizedBank.setStartDate(formatDate(jsBank.getStartDate()));
        standardizedBank.setEndDate(formatDate(jsBank.getEndDate()));

        standardizedBank.setPrintTime(jsBank.getApplyDateTime());

        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        for (JsBankTran jsBankTran : jsBank.getJsBankTrans()) {
            StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
            standardizedBankTran.setTranDate(formatDate(jsBankTran.getDate()));
            standardizedBankTran.setTranTime(null); // No direct mapping
            standardizedBankTran.setCurrency(jsBankTran.getCurrency());
            standardizedBankTran.setAmount(formatAmount(jsBankTran.getTranAmt(), jsBankTran.getTranType()));
            standardizedBankTran.setBalance(jsBankTran.getBalance());
            standardizedBankTran.setChannel(null); // No direct mapping
            standardizedBankTran.setPostscript(null); // No direct mapping
            standardizedBankTran.setCounterpartInfo(mergeCounterpartyInfo(jsBankTran));
            standardizedBankTrans.add(standardizedBankTran);
        }
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        return mapper.writeValueAsString(standardizedBank);
    }

    private String formatDate(String dateStr) {
        if (StringUtils.isEmpty(dateStr)) {
            return null;
        }
        return dateStr.substring(0, 4) + "-" + dateStr.substring(4, 6) + "-" + dateStr.substring(6, 8);
    }

    private String formatAmount(String amountStr, String tranType) {
        if (StringUtils.isEmpty(amountStr)) {
            return null;
        }
        return tranType.equals("支出") ? "-" + amountStr : amountStr;
    }

    private String mergeCounterpartyInfo(JsBankTran jsBankTran) {
        StringBuilder counterpartInfo = new StringBuilder();
        if (jsBankTran.getCounterPartyAccountName() != null) {
            counterpartInfo.append(jsBankTran.getCounterPartyAccountName());
        }
        if (jsBankTran.getCounterPartyAccountNumber() != null) {
            if (counterpartInfo.length() > 0) {
                counterpartInfo.append("/");
            }
            counterpartInfo.append(jsBankTran.getCounterPartyAccountNumber());
        }
        return counterpartInfo.toString();
    }

    public static void main(String[] args) throws Exception {
        JsBankConverter converter = new JsBankConverter();
        String czbJson = "{\"卡号\":\"6228000000000000000\",\"客户名称\":\"张三\",\"开始日期\":\"20221026\",\"结束日期\":\"20231026\",\"申请时间\":\"2023-10-26 18:52:09\",\"交易明细\":[{\"序号\":\"1\",\"摘要/附言\":\"0WL#20231008\",\"币别\":\"人民币\",\"交易日期\":\"20231008\",\"交易类型\":\"支出\",\"交易金额\":\"995.33\",\"账户余额\":\"0.01\",\"对方账号\":\"215500000\",\"对方户名\":\"支付宝(中国)网络技术有限公司\"},{\"序号\":\"2\",\"摘要/附言\":\"张三8877,转账\",\"币别\":\"人民币\",\"交易日期\":\"20231008\",\"交易类型\":\"收入\",\"交易金额\":\"995.33\",\"账户余额\":\"995.34\",\"对方账号\":\"6214861000000000\",\"对方户名\":\"张三\"}]}";
        String standardizedJson = converter.convert(czbJson);
        System.out.println(standardizedJson);
    }
}