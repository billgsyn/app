package com.json.standardized.convert;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.standardized.bo.StandardizedBank;
import com.json.standardized.bo.StandardizedBankTran;
import com.json.standardized.bo.ZYB;
import com.json.standardized.bo.ZYBTran;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class ZYBConverter {

    public String convert(String json) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        ZYB zyb = mapper.readValue(json, ZYB.class);
        StandardizedBank standardizedBank = new StandardizedBank();

        standardizedBank.setAccountName(zyb.getAccountName());
        standardizedBank.setCardNumber(zyb.getAccountNumber());
        standardizedBank.setIdNumber(null); // No direct mapping

        standardizedBank.setStartDate(formatDate(zyb.getStartDate()));
        standardizedBank.setEndDate(formatDate(zyb.getEndDate()));

        standardizedBank.setPrintTime(zyb.getApplyDateTime()); // No direct mapping

        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        for (ZYBTran zybTran : zyb.getZybTrans()) {
            StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
            standardizedBankTran.setTranDate(formatDate(zybTran.getTranDate()));
            standardizedBankTran.setTranTime(zybTran.getTranTime());
            standardizedBankTran.setCurrency(zybTran.getCurrency());
            standardizedBankTran.setAmount(formatAmount(zybTran.getAmount(), zybTran.getRevenueExpenditureStatus()));
            standardizedBankTran.setBalance(zybTran.getBalance());
            standardizedBankTran.setTranName(zybTran.getTradeType());
            standardizedBankTran.setChannel(zybTran.getTradeChannel());
            standardizedBankTran.setPostscript(null); // No direct mapping
            standardizedBankTran.setCounterpartInfo(mergeCounterpartyInfo(zybTran));
            standardizedBankTrans.add(standardizedBankTran);
        }
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        return mapper.writeValueAsString(standardizedBank);
    }

    private String formatDate(String dateStr) {
        if (StringUtils.isEmpty(dateStr)) {
            return null;
        }
        return dateStr.substring(0, 4) + "-" + dateStr.substring(4, 6) + "-" + dateStr.substring(6, 8);
    }

    private String formatAmount(String amountStr, String revenueExpenditureStatus) {
        if (StringUtils.isEmpty(amountStr)) {
            return null;
        }
        return revenueExpenditureStatus.equals("支出") ? "-" + amountStr : amountStr;
    }

    private String mergeCounterpartyInfo(ZYBTran zybTran) {
        StringBuilder counterpartInfo = new StringBuilder();
        if (zybTran.getCounterPartyAccountName() != null) {
            counterpartInfo.append(zybTran.getCounterPartyAccountName());
        }
        if (zybTran.getCounterPartyAccountNumber() != null) {
            if (counterpartInfo.length() > 0) {
                counterpartInfo.append("/");
            }
            counterpartInfo.append(zybTran.getCounterPartyAccountNumber());
        }
        return counterpartInfo.toString();
    }

    public static void main(String[] args) throws Exception {
        ZYBConverter czbConverter = new ZYBConverter();
        String zybJson = "{\"起始日期\":\"20220322\",\"结束日期\":\"20230322\",\"申请时间\":\"2023-03-23 10:20:44\",\"账户名称\":\"张三\",\"账号\":\"6236********0000\",\"验证码\":\"MNDL4XXX\",\"交易明细\":[{\"交易日期\":\"20230322\",\"交易时间\":\"21:12:16\",\"金额\":\"20.00\",\"收支状态\":\"支出\",\"余额\":\"254.84\",\"对方行名\":null,\"对方户名\":null,\"对方账号\":null,\"交易渠道\":\"银联\",\"交易类型\":\"消费\",\"币种\":\"人民币\"}]}";
        String standardizedJson = czbConverter.convert(zybJson);
        System.out.println(standardizedJson);
    }
}
