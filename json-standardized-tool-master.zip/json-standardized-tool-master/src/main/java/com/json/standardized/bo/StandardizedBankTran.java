package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


@Data
public class StandardizedBankTran {

	@JsonProperty("交易日期")
	private String tranDate;

	@JsonProperty("交易时间")
	private String tranTime;

	@JsonProperty("币别")
	private String currency;

	@JsonProperty("金额")
	private String amount;

	@JsonProperty("余额")
	private String balance;

	@JsonProperty("交易名称")
	private String tranName;

	@JsonProperty("渠道")
	private String channel;

	@JsonProperty("附言")
	private String postscript;

	@JsonProperty("对手信息")
	private String counterpartInfo;

}
