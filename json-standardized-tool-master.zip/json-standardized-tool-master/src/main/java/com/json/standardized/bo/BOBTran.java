package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BOBTran {

    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String tranDate;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 钞汇
     */
    @JsonProperty("钞汇")
    private String cashRemit;

    /**
     * 业务摘要
     */
    @JsonProperty("业务摘要")
    private String businessSummary;

    /**
     * 账户余额
     */
    @JsonProperty("发生额")
    private String tranAmount;

    /**
     * 余额
     */
    @JsonProperty("余额")
    private String balance;

    /**
     * 对方户名
     */
    @JsonProperty("对方户名")
    private String counterPartyAccountName;

    /**
     * 对方账号
     */
    @JsonProperty("对方账号")
    private String counterPartyAccountNumber;

}
