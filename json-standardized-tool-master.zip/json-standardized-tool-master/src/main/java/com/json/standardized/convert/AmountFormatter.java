package com.json.standardized.convert;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class AmountFormatter {

    public static String formatCurrency(String amountStr) {
        String formattedAmount = amountStr;

        try {
            // 将String转换为BigDecimal
            BigDecimal amount = new BigDecimal(amountStr);

            // 创建一个DecimalFormat实例来格式化数字
            DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");

            // 使用format方法格式化BigDecimal并返回String
            formattedAmount = decimalFormat.format(amount);
        } catch (Exception e) {
            System.err.println("Error parsing the amount string: " + e.getMessage());
        }
        return formattedAmount;
    }

    public static void main(String[] args) {
        String amountStr = "1500000000.00";
        String formattedAmount = formatCurrency(amountStr);
        System.out.println(formattedAmount); // 输出: 15,000.00
    }

}
