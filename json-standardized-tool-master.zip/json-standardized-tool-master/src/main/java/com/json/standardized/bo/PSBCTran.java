package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PSBCTran {
    @JsonProperty("交易日期")
    private String transactionDate;

    @JsonProperty("子账号")
    private String subAccount;

    @JsonProperty("储种")
    private String accountType;

    @JsonProperty("币种")
    private String currency;

    @JsonProperty("钞汇")
    private String cashExchange;

    @JsonProperty("交易金额")
    private String transactionBalance;

    @JsonProperty("账户余额")
    private String accountBalance;

    @JsonProperty("对方户名")
    private String counterPartyAccountName;

    @JsonProperty("对方账号")
    private String counterPartyAccountNumber;

    @JsonProperty("摘要")
    private String summary;

    @JsonProperty("交易渠道")
    private String transactionChannel;

    @JsonProperty("外部系统流水")
    private String outsideSysSeq;
}
