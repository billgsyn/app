package com.json.standardized.convert;

import com.json.standardized.bo.*;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 平安流水标准化字段输出
 */
public class PABConverter {

    public String convert1(List<String> jsonList) throws Exception {
        String standardizedJson = "";
        StandardizedBank standardizedBank = new StandardizedBank();
        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        for (int i = 0; i < jsonList.size(); i++) {
            String json = jsonList.get(i);
            PAB pab = com.json.mapping.util.JsonUtil.json2Object(json, PAB.class);

            //解析header
            if (StringUtils.isEmpty(standardizedBank.getAccountName())) {
                standardizedBank.setAccountName(pab.getName());
                standardizedBank.setCardNumber(pab.getCardNo());
                standardizedBank.setIdNumber(null); // Assuming idNumber is not available in PAB
                // Assuming startDate and endDate are extracted from transactionRange
                String[] dates = pab.getTransactionDate().split("-");
                if (dates.length == 2) {
                    standardizedBank.setStartDate(dates[0].substring(0, 4) + "-" + dates[0].substring(4, 6) + "-" + dates[0].substring(6, 8));
                    standardizedBank.setEndDate(dates[1].substring(0, 4) + "-" + dates[1].substring(4, 6) + "-" + dates[1].substring(6, 8));
                }
                standardizedBank.setPrintTime(pab.getPrintDate());
            }

            for (PABTran pabTran : pab.getPabTrans()) {
                StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
                standardizedBankTran.setTranDate(pabTran.getTransactionTime());
                // Assuming tranTime is not available in PABTran, set it to null or a default value
                standardizedBankTran.setTranTime(null);
                standardizedBankTran.setCurrency(pab.getCurrency()); // Assuming currency is not available in PABTran
                standardizedBankTran.setAmount(pabTran.getTransactionAmount().replace("+", ""));
                standardizedBankTran.setBalance(pabTran.getBalance());
                standardizedBankTran.setTranName(pabTran.getTransactionType());
                standardizedBankTran.setChannel(null); // Assuming channel is not available in PABTran
                standardizedBankTran.setCounterpartInfo(pabTran.getCounterParty());
                standardizedBankTran.setPostscript(null); // Assuming postscript is not available in PABTran

                standardizedBankTrans.add(standardizedBankTran);
            }
            standardizedBank.setStandardizedBankTrans(standardizedBankTrans);
        }

        standardizedJson = com.json.mapping.util.JsonUtil.object2Json(standardizedBank);
        return standardizedJson;
    }

    public String convert2(List<String> jsonList) throws Exception {
        String standardizedJson = "";
        StandardizedBank standardizedBank = new StandardizedBank();
        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        for (int i = 0; i < jsonList.size(); i++) {
            String json = jsonList.get(i);
            PAB2 pab2 = com.json.mapping.util.JsonUtil.json2Object(json, PAB2.class);

            //解析header
            if (StringUtils.isEmpty(standardizedBank.getAccountName())) {
                standardizedBank.setAccountName(pab2.getName());
                standardizedBank.setCardNumber(pab2.getAccountNumber());
                standardizedBank.setIdNumber(null); // Assuming idNumber is not available in PAB2
                // Assuming startDate and endDate are extracted from transactionDate
                String[] dates = pab2.getTransactionDate().split(" - ");
                if (dates.length == 2) {
                    standardizedBank.setStartDate(dates[0].substring(0, 4) + "-" + dates[0].substring(4, 6) + "-" + dates[0].substring(6, 8));
                    standardizedBank.setEndDate(dates[1].substring(0, 4) + "-" + dates[1].substring(4, 6) + "-" + dates[1].substring(6, 8));
                }
                standardizedBank.setPrintTime(pab2.getIssuanceDate()); //
            }

            for (PABTran2 pabTran2 : pab2.getPabTrans()) {
                StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
                standardizedBankTran.setTranDate(pabTran2.getTransactionTime());
                // Assuming tranTime is not available in PABTran2, set it to null or a default value
                standardizedBankTran.setTranTime(null);
                standardizedBankTran.setCurrency(pab2.getCurrency()); // Assuming currency is not available in PABTran2
                standardizedBankTran.setAmount(pabTran2.getTransactionAmount());
                standardizedBankTran.setBalance(pabTran2.getBalance());
                standardizedBankTran.setTranName(pabTran2.getTransactionType());
                standardizedBankTran.setChannel(null); // Assuming channel is not available in PABTran2
                standardizedBankTran.setCounterpartInfo(pabTran2.getCounterParty());
                standardizedBankTran.setPostscript(pabTran2.getComment());

                standardizedBankTrans.add(standardizedBankTran);
            }
            standardizedBank.setStandardizedBankTrans(standardizedBankTrans);
        }

        standardizedJson = com.json.mapping.util.JsonUtil.object2Json(standardizedBank);
        return standardizedJson;
    }

    public String convert1(String json) throws Exception {
        PAB pab = com.json.mapping.util.JsonUtil.json2Object(json, PAB.class);
        String standardizedJson = "";

        StandardizedBank standardizedBank = new StandardizedBank();
        standardizedBank.setAccountName(pab.getName());
        standardizedBank.setCardNumber(pab.getCardNo());
        standardizedBank.setIdNumber(null); // Assuming idNumber is not available in PAB
        // Assuming startDate and endDate are extracted from transactionRange
        String[] dates = pab.getTransactionDate().split("-");
        if (dates.length == 2) {
            standardizedBank.setStartDate(dates[0].substring(0, 4) + "-" + dates[0].substring(4, 6) + "-" + dates[0].substring(6, 8));
            standardizedBank.setEndDate(dates[1].substring(0, 4) + "-" + dates[1].substring(4, 6) + "-" + dates[1].substring(6, 8));
        }
        standardizedBank.setPrintTime(pab.getPrintDate());

        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        for (PABTran pabTran : pab.getPabTrans()) {
            StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
            standardizedBankTran.setTranDate(pabTran.getTransactionTime());
            // Assuming tranTime is not available in PABTran, set it to null or a default value
            standardizedBankTran.setTranTime(null);
            standardizedBankTran.setCurrency(pab.getCurrency()); // Assuming currency is not available in PABTran
            standardizedBankTran.setAmount(pabTran.getTransactionAmount());
            standardizedBankTran.setBalance(pabTran.getBalance());
            standardizedBankTran.setTranName(pabTran.getTransactionType());
            standardizedBankTran.setChannel(null); // Assuming channel is not available in PABTran
            standardizedBankTran.setCounterpartInfo(pabTran.getCounterParty());
            standardizedBankTran.setPostscript(null); // Assuming postscript is not available in PABTran

            standardizedBankTrans.add(standardizedBankTran);
        }
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        standardizedJson = com.json.mapping.util.JsonUtil.object2Json(standardizedBank);
        return standardizedJson;
    }

    public String convert2(String json) throws Exception {
        PAB2 pab2 = com.json.mapping.util.JsonUtil.json2Object(json, PAB2.class);
        String standardizedJson = "";

        StandardizedBank standardizedBank = new StandardizedBank();
        standardizedBank.setAccountName(pab2.getName());
        standardizedBank.setCardNumber(pab2.getAccountNumber());
        standardizedBank.setIdNumber(null); // Assuming idNumber is not available in PAB2
        // Assuming startDate and endDate are extracted from transactionDate
        String[] dates = pab2.getTransactionDate().split(" - ");
        if (dates.length == 2) {
            standardizedBank.setStartDate(dates[0].substring(0, 4) + "-" + dates[0].substring(4, 6) + "-" + dates[0].substring(6, 8));
            standardizedBank.setEndDate(dates[1].substring(0, 4) + "-" + dates[1].substring(4, 6) + "-" + dates[1].substring(6, 8));
        }
        standardizedBank.setPrintTime(pab2.getIssuanceDate()); //

        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        for (PABTran2 pabTran2 : pab2.getPabTrans()) {
            StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
            standardizedBankTran.setTranDate(pabTran2.getTransactionTime());
            // Assuming tranTime is not available in PABTran2, set it to null or a default value
            standardizedBankTran.setTranTime(null);
            standardizedBankTran.setCurrency(pab2.getCurrency()); // Assuming currency is not available in PABTran2
            standardizedBankTran.setAmount(pabTran2.getTransactionAmount());
            standardizedBankTran.setBalance(pabTran2.getBalance());
            standardizedBankTran.setTranName(pabTran2.getTransactionType());
            standardizedBankTran.setChannel(null); // Assuming channel is not available in PABTran2
            standardizedBankTran.setCounterpartInfo(pabTran2.getCounterParty());
            standardizedBankTran.setPostscript(pabTran2.getComment());

            standardizedBankTrans.add(standardizedBankTran);
        }
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        standardizedJson = com.json.mapping.util.JsonUtil.object2Json(standardizedBank);
        return standardizedJson;
    }

    public String convert(String json) throws Exception {
        if (json.contains("清单编号")) {
            return convert2(json);
        } else {
            return convert1(json);
        }
    }

    public String convert(List<String> jsonList) throws Exception {
        String json = jsonList.get(0);
        if (json.contains("清单编号")) {
            return convert2(json);
        } else {
            return convert1(json);
        }
    }

    public static void main(String[] args) throws Exception {
        PABConverter pabConverter = new PABConverter();
        String pabJson1 = "{\n" +
                "    \"户名\":\"张三\",\n" +
                "    \"账号\":\"16004446381685\",\n" +
                "    \"卡号\":\"6230584000002283985\",\n" +
                "    \"币种\":\"CNY\",\n" +
                "    \"存款类型\":\"活期\",\n" +
                "    \"交易日期\":\"20200916-20210916\",\n" +
                "    \"开户行\":\"平安银行深圳科技园支行\",\n" +
                "    \"受理行\":\"平安银行总行\",\n" +
                "    \"打印日期\":\"2021.09.16 16:08:33\",\n" +
                "    \"流水范围\":\"全部交易\",\n" +
                "    \"交易明细\":[\n" +
                "        {\n" +
                "            \"序号\":\"1\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.66\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"2\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.67\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"3\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.68\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"4\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.04\",\n" +
                "            \"账户余额\":\"0.69\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-李四-6217921196443322\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"5\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.65\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"6\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.06\",\n" +
                "            \"账户余额\":\"0.66\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-李四-6217921196443322\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"7\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.08\",\n" +
                "            \"账户余额\":\"0.60\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-李四-6217921196443322\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"8\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.11\",\n" +
                "            \"账户余额\":\"0.52\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-李四-6217921196443322\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"9\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.09\",\n" +
                "            \"账户余额\":\"0.41\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-李四-6217921196443322\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"10\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.03\",\n" +
                "            \"账户余额\":\"0.32\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-李四-6217921196443322\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"11\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.04\",\n" +
                "            \"账户余额\":\"0.29\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-李四-6217921196443322\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"12\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.02\",\n" +
                "            \"账户余额\":\"0.25\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-李四-6217921196443322\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"13\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.23\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"14\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.24\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"15\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"-0.02\",\n" +
                "            \"账户余额\":\"0.25\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"16\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.27\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"17\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.28\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"18\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.29\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"19\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.30\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"20\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.04\",\n" +
                "            \"账户余额\":\"0.31\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"交通银行深圳分行-李四-6222621310042733523\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"21\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.02\",\n" +
                "            \"账户余额\":\"0.27\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"交通银行深圳分行-李四-6222621310042733523\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"22\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.01\",\n" +
                "            \"账户余额\":\"0.25\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"交通银行深圳分行-李四-6222621310042733523\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"23\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.06\",\n" +
                "            \"账户余额\":\"0.24\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"交通银行深圳分行-李四-6222621310042733523\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"24\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.02\",\n" +
                "            \"账户余额\":\"0.18\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"交通银行深圳分行-李四-6222621310042733523\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"25\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.03\",\n" +
                "            \"账户余额\":\"0.16\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"交通银行深圳分行-李四-6222621310042733523\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"26\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.02\",\n" +
                "            \"账户余额\":\"0.13\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"交通银行深圳分行-李四-6222621310042733523\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"27\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.01\",\n" +
                "            \"账户余额\":\"0.11\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"交通银行深圳分行-李四-6222621310042733523\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"28\",\n" +
                "            \"交易时间\":\"20210916\",\n" +
                "            \"交易金额\":\"+0.10\",\n" +
                "            \"账户余额\":\"0.10\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"交通银行深圳分行-李四-6222621310042733523\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"29\",\n" +
                "            \"交易时间\":\"20210628\",\n" +
                "            \"交易金额\":\"-3.98\",\n" +
                "            \"账户余额\":\"0.00\",\n" +
                "            \"摘要\":\"账户管理费\",\n" +
                "            \"交易对手信息\":null\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"30\",\n" +
                "            \"交易时间\":\"20210625\",\n" +
                "            \"交易金额\":\"-1.01\",\n" +
                "            \"账户余额\":\"3.98\",\n" +
                "            \"摘要\":\"微信支付\",\n" +
                "            \"交易对手信息\":\"财付通-深圳市地铁相关运营主体\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"31\",\n" +
                "            \"交易时间\":\"20210625\",\n" +
                "            \"交易金额\":\"+4.00\",\n" +
                "            \"账户余额\":\"4.99\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"32\",\n" +
                "            \"交易时间\":\"20210625\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.99\",\n" +
                "            \"摘要\":\"微信支付\",\n" +
                "            \"交易对手信息\":\"财付通-多品网络\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"33\",\n" +
                "            \"交易时间\":\"20210625\",\n" +
                "            \"交易金额\":\"+1.00\",\n" +
                "            \"账户余额\":\"1.00\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"34\",\n" +
                "            \"交易时间\":\"20210320\",\n" +
                "            \"交易金额\":\"-3.16\",\n" +
                "            \"账户余额\":\"0.00\",\n" +
                "            \"摘要\":\"扫码支付\",\n" +
                "            \"交易对手信息\":\"招商银行-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"35\",\n" +
                "            \"交易时间\":\"20210320\",\n" +
                "            \"交易金额\":\"-26.90\",\n" +
                "            \"账户余额\":\"3.16\",\n" +
                "            \"摘要\":\"美团点评支付\",\n" +
                "            \"交易对手信息\":\"美团-猫眼电影—票务代理\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"36\",\n" +
                "            \"交易时间\":\"20210320\",\n" +
                "            \"交易金额\":\"+30.00\",\n" +
                "            \"账户余额\":\"30.06\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"37\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.06\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-张三-6217921974784251\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"38\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.07\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"39\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.08\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"40\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.09\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"41\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.10\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-张三-6217921974784251\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"42\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.11\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-张三-6217921974784251\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"43\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.12\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"44\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.13\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-张三-6217921974784251\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"45\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.14\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"46\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.15\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"47\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.16\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行股份有限公司-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"48\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.17\",\n" +
                "            \"摘要\":\"支付宝\",\n" +
                "            \"交易对手信息\":\"支付宝-支付宝-消费\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"49\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.18\",\n" +
                "            \"摘要\":\"支付宝\",\n" +
                "            \"交易对手信息\":\"支付宝-支付宝-消费\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"50\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.19\",\n" +
                "            \"摘要\":\"支付宝\",\n" +
                "            \"交易对手信息\":\"支付宝-支付宝-消费\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"51\",\n" +
                "            \"交易时间\":\"20210311\",\n" +
                "            \"交易金额\":\"-0.01\",\n" +
                "            \"账户余额\":\"0.20\",\n" +
                "            \"摘要\":\"支付宝\",\n" +
                "            \"交易对手信息\":\"支付宝-支付宝-消费\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"52\",\n" +
                "            \"交易时间\":\"20201217\",\n" +
                "            \"交易金额\":\"+0.21\",\n" +
                "            \"账户余额\":\"0.21\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"53\",\n" +
                "            \"交易时间\":\"20201216\",\n" +
                "            \"交易金额\":\"-10.00\",\n" +
                "            \"账户余额\":\"0.00\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"上海浦东发展银行-张三-6217921974784251\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"54\",\n" +
                "            \"交易时间\":\"20201216\",\n" +
                "            \"交易金额\":\"+10.00\",\n" +
                "            \"账户余额\":\"10.00\",\n" +
                "            \"摘要\":\"赎回工资理财\",\n" +
                "            \"交易对手信息\":\"网上基金直销平安银行总行务暂挂款-网上基金直销业务暂挂款-262031005\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"55\",\n" +
                "            \"交易时间\":\"20201215\",\n" +
                "            \"交易金额\":\"-10.00\",\n" +
                "            \"账户余额\":\"0.00\",\n" +
                "            \"摘要\":\"购买工资理财\",\n" +
                "            \"交易对手信息\":\"网上基金直销平安银行总行务暂挂款-网上基金直销业务暂挂款-262031005\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"56\",\n" +
                "            \"交易时间\":\"20201215\",\n" +
                "            \"交易金额\":\"+10.00\",\n" +
                "            \"账户余额\":\"10.00\",\n" +
                "            \"摘要\":\"他行卡转入\",\n" +
                "            \"交易对手信息\":\"浦发银行-张三-6217921974784251\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"57\",\n" +
                "            \"交易时间\":\"20201120\",\n" +
                "            \"交易金额\":\"-311.00\",\n" +
                "            \"账户余额\":\"0.00\",\n" +
                "            \"摘要\":\"扫码支付\",\n" +
                "            \"交易对手信息\":\"招商银行-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"58\",\n" +
                "            \"交易时间\":\"20201120\",\n" +
                "            \"交易金额\":\"+311.00\",\n" +
                "            \"账户余额\":\"311.00\",\n" +
                "            \"摘要\":\"账户管理费\",\n" +
                "            \"交易对手信息\":null\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"59\",\n" +
                "            \"交易时间\":\"20201119\",\n" +
                "            \"交易金额\":\"-311.00\",\n" +
                "            \"账户余额\":\"0.00\",\n" +
                "            \"摘要\":\"账户管理费\",\n" +
                "            \"交易对手信息\":null\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"60\",\n" +
                "            \"交易时间\":\"20201119\",\n" +
                "            \"交易金额\":\"+311.00\",\n" +
                "            \"账户余额\":\"311.00\",\n" +
                "            \"摘要\":\"快捷支付退款\",\n" +
                "            \"交易对手信息\":\"京东支付-网银在线(北京)科技有限公司\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"61\",\n" +
                "            \"交易时间\":\"20201116\",\n" +
                "            \"交易金额\":\"-311.00\",\n" +
                "            \"账户余额\":\"0.00\",\n" +
                "            \"摘要\":\"京东支付\",\n" +
                "            \"交易对手信息\":\"京东支付-网银在线(北京)科技有限公司\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"62\",\n" +
                "            \"交易时间\":\"20201116\",\n" +
                "            \"交易金额\":\"+1.00\",\n" +
                "            \"账户余额\":\"311.00\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行-张三-6214861021778877\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"序号\":\"63\",\n" +
                "            \"交易时间\":\"20201116\",\n" +
                "            \"交易金额\":\"+310.00\",\n" +
                "            \"账户余额\":\"310.00\",\n" +
                "            \"摘要\":\"转账\",\n" +
                "            \"交易对手信息\":\"招商银行-张三-6214861021778877\"\n" +
                "        }\n" +
                "    ]\n" +
                "}\n" +
                "\n";
        String pabJson2 = "{\"清单编号\":\"JYLS231206001421\",\"开立日期\":\"2023-12-06 14:16:24\",\"户名\":\"李肃\",\"卡号/账号\":\"6230580000390912728\",\"存款类型\":\"活期\",\"币种\":\"RMB\",\"开户行\":\"平安银行深圳中心城支行\",\"受理行\":\"平安银行总行\",\"交易起止日期\":\"20221206 - 20231206\",\"明细范围\":\"全部交易\",\"交易明细\":[{\"序号\":\"1\",\"交易时间\":\"2023-12-05\",\"交易金额\":\"+80000.0\",\"余额\":\"385413.8\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"转账\",\"交易对手信息\":\"招商银行股份有限公司-周志刚-6214830200288131\"},{\"序号\":\"2\",\"交易时间\":\"2023-12-05\",\"交易金额\":\"+92000.0\",\"余额\":\"305413.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"平安银行-邹才华-6230582000053711753\"},{\"序号\":\"3\",\"交易时间\":\"2023-12-05\",\"交易金额\":\"-167300.0\",\"余额\":\"213413.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中国工商银行总行清算中心-谢刚-6222083602016426808\"},{\"序号\":\"4\",\"交易时间\":\"2023-12-04\",\"交易金额\":\"+75450.0\",\"余额\":\"380713.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"平安银行-吴胜桥-6230580000018434071\"},{\"序号\":\"5\",\"交易时间\":\"2023-12-04\",\"交易金额\":\"+31130.0\",\"余额\":\"305263.8\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行股份有限公司-余科-6228480089306452270\"},{\"序号\":\"6\",\"交易时间\":\"2023-12-04\",\"交易金额\":\"-13000.0\",\"余额\":\"274133.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"平安银行-邹才华-6230582000053711753\"},{\"序号\":\"7\",\"交易时间\":\"2023-12-04\",\"交易金额\":\"-155450.0\",\"余额\":\"287133.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"招商银行-周志刚-6214830200288131\"},{\"序号\":\"8\",\"交易时间\":\"2023-12-04\",\"交易金额\":\"-28000.0\",\"余额\":\"442583.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"平安银行-沈龙-6230580000386870955\"},{\"序号\":\"9\",\"交易时间\":\"2023-12-04\",\"交易金额\":\"-3130.0\",\"余额\":\"470583.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"货款\",\"交易对手信息\":\"平安银行-沈龙-6230580000386870955\"},{\"序号\":\"10\",\"交易时间\":\"2023-12-04\",\"交易金额\":\"+7000.0\",\"余额\":\"473713.8\",\"交易地点\":\"平安银行\",\"摘要\":\"其他费用\",\"备注\":\"网上代发代扣\",\"交易对手信息\":\"招商银行股份有限公司惠州惠阳支行-广东珩基建筑工程有限公司-752901193710201\"},{\"序号\":\"11\",\"交易时间\":\"2023-12-01\",\"交易金额\":\"+100.0\",\"余额\":\"466713.8\",\"交易地点\":\"平安银行广州中石化大厦支\",\"摘要\":\"行\",\"备注\":\"现钞机存款广东省广州市天河区体育西路191号中石化大厦B塔首层334344\",\"交易对手信息\":\"广东省广州市天河区体育西路191号中石化大厦B塔首层-广东省广州市天河区体育西路191号中石化大?-\"},{\"序号\":\"12\",\"交易时间\":\"2023-12-01\",\"交易金额\":\"+300.0\",\"余额\":\"466613.8\",\"交易地点\":\"平安银行广州中石化大厦支\",\"摘要\":\"行\",\"备注\":\"现钞机存款广东省广州市天河区体育西路191号中石化大厦B塔首层334342\",\"交易对手信息\":\"广东省广州市天河区体育西路191号中石化大厦B塔首层-广东省广州市天河区体育西路191号中石化大?-\"},{\"序号\":\"13\",\"交易时间\":\"2023-12-01\",\"交易金额\":\"+45400.0\",\"余额\":\"466313.8\",\"交易地点\":\"平安银行广州中石化大厦支\",\"摘要\":\"行\",\"备注\":\"现钞机存款广东省广州市天河区体育西路191号中石化大厦B塔首层334340\",\"交易对手信息\":\"广东省广州市天河区体育西路191号中石化大厦B塔首层-广东省广州市天河区体育西路191号中石化大?-\"},{\"序号\":\"14\",\"交易时间\":\"2023-11-30\",\"交易金额\":\"-1970.0\",\"余额\":\"420913.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行股份有限公司-邹才华-6228480086975130476\"},{\"序号\":\"15\",\"交易时间\":\"2023-11-30\",\"交易金额\":\"+66000.0\",\"余额\":\"422883.8\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行股份有限公司-余科-6228480089306452270\"},{\"序号\":\"16\",\"交易时间\":\"2023-11-29\",\"交易金额\":\"+1000.0\",\"余额\":\"356883.8\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行股份有限公司-郑勇-6228480086976380971\"},{\"序号\":\"17\",\"交易时间\":\"2023-11-28\",\"交易金额\":\"-113000.0\",\"余额\":\"355883.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行资金清算中心-余科-6228480089306452270\"},{\"序号\":\"18\",\"交易时间\":\"2023-11-27\",\"交易金额\":\"-21150.0\",\"余额\":\"468883.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中国银行总行-王梅蝶-6217857000092609435\"},{\"序号\":\"19\",\"交易时间\":\"2023-11-25\",\"交易金额\":\"-10000.0\",\"余额\":\"490033.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行股份有限公司-赖金山-6228481133550810012\"},{\"序号\":\"20\",\"交易时间\":\"2023-11-25\",\"交易金额\":\"+500000.0\",\"余额\":\"500033.8\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"转账\",\"交易对手信息\":\"交通银行股份有限公司-吴超凡-6222620710042004398\"},{\"序号\":\"21\",\"交易时间\":\"2023-11-24\",\"交易金额\":\"-1.0\",\"余额\":\"33.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"平安银行-邹才华-6230582000053711753\"},{\"序号\":\"22\",\"交易时间\":\"2023-11-22\",\"交易金额\":\"-100000.0\",\"余额\":\"34.8\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"购房定金\",\"交易对手信息\":\"中国银行总行-钟志华-6217867000003221112\"},{\"序号\":\"23\",\"交易时间\":\"2023-11-22\",\"交易金额\":\"+300.0\",\"余额\":\"100034.8\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行股份有限公司-赖金山-6228481133550810012\"},{\"序号\":\"24\",\"交易时间\":\"2023-11-22\",\"交易金额\":\"+28600.0\",\"余额\":\"99734.8\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行股份有限公司-赖金山-6228481133550810012\"},{\"序号\":\"25\",\"交易时间\":\"2023-11-22\",\"交易金额\":\"+5000.0\",\"余额\":\"71134.8\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行股份有限公司-李肃-6228480606754988271\"},{\"序号\":\"26\",\"交易时间\":\"2023-11-21\",\"交易金额\":\"+12000.0\",\"余额\":\"66134.8\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行股份有限公司-赖金山-6228481133550810012\"},{\"序号\":\"27\",\"交易时间\":\"2023-11-21\",\"交易金额\":\"-6958.92\",\"余额\":\"54134.8\",\"交易地点\":\"平安银行惠州惠东支行\",\"摘要\":\"贷款还款\",\"备注\":\"RL20231121046314\",\"交易对手信息\":\"/\"},{\"序号\":\"28\",\"交易时间\":\"2023-11-21\",\"交易金额\":\"-3906.28\",\"余额\":\"61093.72\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"上海农村商业银行-李肃-90100004244108757001109133\"},{\"序号\":\"29\",\"交易时间\":\"2023-11-21\",\"交易金额\":\"+65000.0\",\"余额\":\"65000.0\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国银行总行-赖金山-6217867000020531683\"},{\"序号\":\"30\",\"交易时间\":\"2023-11-21\",\"交易金额\":\"-9.46\",\"余额\":\"0.0\",\"交易地点\":\"平安银行\",\"摘要\":\"贷款扣款\",\"备注\":\"批量还款\",\"交易对手信息\":\"平安银行-银行内部账户-4031503\"},{\"序号\":\"31\",\"交易时间\":\"2023-10-21\",\"交易金额\":\"-6968.38\",\"余额\":\"9.46\",\"交易地点\":\"平安银行\",\"摘要\":\"贷款扣款\",\"备注\":\"批量还款\",\"交易对手信息\":\"平安银行-银行内部账户-4031503\"},{\"序号\":\"32\",\"交易时间\":\"2023-10-20\",\"交易金额\":\"+6968.38\",\"余额\":\"6977.84\",\"交易地点\":\"平安银行\",\"摘要\":\"付款业务\",\"备注\":\"微信向银行卡转账\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信向银行卡转账-243300133\"},{\"序号\":\"33\",\"交易时间\":\"2023-09-28\",\"交易金额\":\"-7000.0\",\"余额\":\"9.46\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信转账-243300133\"},{\"序号\":\"34\",\"交易时间\":\"2023-09-27\",\"交易金额\":\"+7000.0\",\"余额\":\"7009.46\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国工商银行-广东珩基建筑工程有限公司-2008023409200160685\"},{\"序号\":\"35\",\"交易时间\":\"2023-09-21\",\"交易金额\":\"-6958.92\",\"余额\":\"9.46\",\"交易地点\":\"平安银行惠州惠东支行\",\"摘要\":\"贷款还款\",\"备注\":\"RL20230921300322\",\"交易对手信息\":\"/\"},{\"序号\":\"36\",\"交易时间\":\"2023-09-21\",\"交易金额\":\"+6968.38\",\"余额\":\"6968.38\",\"交易地点\":\"平安银行\",\"摘要\":\"银联贷记交易入账\",\"备注\":\"微信向银行卡转账;财付通支付科技有限公司;微信向银行卡转账;微信向银行卡转账\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-9915840000495800\"},{\"序号\":\"37\",\"交易时间\":\"2023-09-21\",\"交易金额\":\"-9.46\",\"余额\":\"0.0\",\"交易地点\":\"平安银行\",\"摘要\":\"贷款扣款\",\"备注\":\"批量还款\",\"交易对手信息\":\"平安银行-银行内部账户-4031503\"},{\"序号\":\"38\",\"交易时间\":\"2023-09-21\",\"交易金额\":\"+1.57\",\"余额\":\"9.46\",\"交易地点\":\"平安银行深圳中心城支行\",\"摘要\":\"支付利息\",\"备注\":\"/\",\"交易对手信息\":\"/\"},{\"序号\":\"39\",\"交易时间\":\"2023-09-05\",\"交易金额\":\"-17.0\",\"余额\":\"7.89\",\"交易地点\":\"平安银行\",\"摘要\":\"新银联无卡快捷支付-协议支付\",\"备注\":\"/\",\"交易对手信息\":\"财付通支付科技有限公司-微信转账-微信支付-1000050001\"},{\"序号\":\"40\",\"交易时间\":\"2023-09-05\",\"交易金额\":\"-30.0\",\"余额\":\"24.89\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-扫二维码付款-243300133\"},{\"序号\":\"41\",\"交易时间\":\"2023-09-03\",\"交易金额\":\"-150.0\",\"余额\":\"54.89\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-惠州市新华职业技术学校-243300133\"},{\"序号\":\"42\",\"交易时间\":\"2023-09-03\",\"交易金额\":\"-1600.0\",\"余额\":\"204.89\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信转账-243300133\"},{\"序号\":\"43\",\"交易时间\":\"2023-08-31\",\"交易金额\":\"-11312.0\",\"余额\":\"1804.89\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-惠阳水围实验学校-243300133\"},{\"序号\":\"44\",\"交易时间\":\"2023-08-30\",\"交易金额\":\"-6905.0\",\"余额\":\"13116.89\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-惠州市新华职业技术学校-243300133\"},{\"序号\":\"45\",\"交易时间\":\"2023-08-30\",\"交易金额\":\"+20000.0\",\"余额\":\"20021.89\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行股份有限公司-赖金山-6228481133550810012\"},{\"序号\":\"46\",\"交易时间\":\"2023-08-24\",\"交易金额\":\"-45.0\",\"余额\":\"21.89\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-扫二维码付款-243300133\"},{\"序号\":\"47\",\"交易时间\":\"2023-08-22\",\"交易金额\":\"-50.0\",\"余额\":\"66.89\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信红包-243300133\"},{\"序号\":\"48\",\"交易时间\":\"2023-08-21\",\"交易金额\":\"-3320.0\",\"余额\":\"116.89\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"长沙银行股份有限公司-广东珩基建筑工程有限公司-810000393798688888\"},{\"序号\":\"49\",\"交易时间\":\"2023-08-21\",\"交易金额\":\"+3320.0\",\"余额\":\"3436.89\",\"交易地点\":\"平安银行\",\"摘要\":\"付款业务\",\"备注\":\"梁柱伟支付宝转账\",\"交易对手信息\":\"支付宝（中国）网络技术有限公司-梁柱伟-梁柱伟支付宝转账-20881329724571210156\"},{\"序号\":\"50\",\"交易时间\":\"2023-08-21\",\"交易金额\":\"-7700.0\",\"余额\":\"116.89\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"长沙银行股份有限公司-广东珩基建筑工程有限公司-810000393798688888\"},{\"序号\":\"51\",\"交易时间\":\"2023-08-21\",\"交易金额\":\"+2700.0\",\"余额\":\"7816.89\",\"交易地点\":\"平安银行惠州分行\",\"摘要\":\"ATM存款\",\"备注\":\"广东省惠州市惠阳区淡水开城大道中86号924657\",\"交易对手信息\":\"广东省惠州市惠阳区淡水开城大道中86号-广东省惠州市惠阳区淡水开城大道中86号-\"},{\"序号\":\"52\",\"交易时间\":\"2023-08-21\",\"交易金额\":\"+4990.0\",\"余额\":\"5116.89\",\"交易地点\":\"平安银行\",\"摘要\":\"付款业务\",\"备注\":\"微信向银行卡转账\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信向银行卡转账-243300133\"},{\"序号\":\"53\",\"交易时间\":\"2023-08-21\",\"交易金额\":\"-906.83\",\"余额\":\"126.89\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"上海农村商业银行-李肃-90100004244108757001109133\"},{\"序号\":\"54\",\"交易时间\":\"2023-08-21\",\"交易金额\":\"-6966.28\",\"余额\":\"1033.72\",\"交易地点\":\"平安银行惠州惠东支行\",\"摘要\":\"贷款还款\",\"备注\":\"RL20230821871503\",\"交易对手信息\":\"/\"},{\"序号\":\"55\",\"交易时间\":\"2023-08-21\",\"交易金额\":\"+8000.0\",\"余额\":\"8000.0\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"平安银行-陈转科-6230580000240592027\"},{\"序号\":\"56\",\"交易时间\":\"2023-08-21\",\"交易金额\":\"-2.1\",\"余额\":\"0.0\",\"交易地点\":\"平安银行\",\"摘要\":\"贷款扣款\",\"备注\":\"批量还款\",\"交易对手信息\":\"平安银行-银行内部账户-4031503\"},{\"序号\":\"57\",\"交易时间\":\"2023-08-17\",\"交易金额\":\"-10000.0\",\"余额\":\"2.1\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中国工商银行-广东珩基建筑工程有限公司-2008023409200160685\"},{\"序号\":\"58\",\"交易时间\":\"2023-08-17\",\"交易金额\":\"+200.0\",\"余额\":\"10002.1\",\"交易地点\":\"平安银行惠州分行\",\"摘要\":\"ATM存款\",\"备注\":\"广东省惠州市惠阳区淡水开城大道中86号920883\",\"交易对手信息\":\"广东省惠州市惠阳区淡水开城大道中86号-广东省惠州市惠阳区淡水开城大道中86号-\"},{\"序号\":\"59\",\"交易时间\":\"2023-08-17\",\"交易金额\":\"+9800.0\",\"余额\":\"9802.1\",\"交易地点\":\"平安银行惠州分行\",\"摘要\":\"ATM存款\",\"备注\":\"广东省惠州市惠阳区淡水开城大道中86号920881\",\"交易对手信息\":\"广东省惠州市惠阳区淡水开城大道中86号-广东省惠州市惠阳区淡水开城大道中86号-\"},{\"序号\":\"60\",\"交易时间\":\"2023-08-17\",\"交易金额\":\"-47.0\",\"余额\":\"2.1\",\"交易地点\":\"平安银行\",\"摘要\":\"新银联无卡快捷支付-协议支付\",\"备注\":\"/\",\"交易对手信息\":\"财付通支付科技有限公司-扫二维码付款-微信支付-1000107101\"},{\"序号\":\"61\",\"交易时间\":\"2023-08-16\",\"交易金额\":\"-28.0\",\"余额\":\"49.1\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-扫二维码付款-243300133\"},{\"序号\":\"62\",\"交易时间\":\"2023-08-15\",\"交易金额\":\"-150000.0\",\"余额\":\"77.1\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中信银行总行管理部（不受理储蓄业务）-梁柱基-6217680912268088\"},{\"序号\":\"63\",\"交易时间\":\"2023-08-15\",\"交易金额\":\"-22.9\",\"余额\":\"150077.1\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-拼多多平台商户-243300133\"},{\"序号\":\"64\",\"交易时间\":\"2023-08-15\",\"交易金额\":\"+2900.0\",\"余额\":\"150100.0\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"线上开立账户只允许划入同名账户或名单账户\",\"交易对手信息\":\"珠海华润银行股份有限公司清算中心-广东珩基建筑工程有限公司-213255963821400001\"},{\"序号\":\"65\",\"交易时间\":\"2023-08-15\",\"交易金额\":\"-6000.0\",\"余额\":\"147200.0\",\"交易地点\":\"平安银行惠州分行\",\"摘要\":\"ATM取款\",\"备注\":\"广东省惠州市惠阳区淡水开城大道中86号918619\",\"交易对手信息\":\"广东省惠州市惠阳区淡水开城大道中86号-广东省惠州市惠阳区淡水开城大道中86号-\"},{\"序号\":\"66\",\"交易时间\":\"2023-08-15\",\"交易金额\":\"-9000.0\",\"余额\":\"153200.0\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中国工商银行-广东珩基建筑工程有限公司-2008023409200160685\"},{\"序号\":\"67\",\"交易时间\":\"2023-08-14\",\"交易金额\":\"+17.0\",\"余额\":\"162200.0\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信转账-243300133\"},{\"序号\":\"68\",\"交易时间\":\"2023-08-14\",\"交易金额\":\"+135000.0\",\"余额\":\"162183.0\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国工商银行-广东珩基建筑工程有限公司-2008023409200160685\"},{\"序号\":\"69\",\"交易时间\":\"2023-08-14\",\"交易金额\":\"-2900.0\",\"余额\":\"27183.0\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"珠海华润银行股份有限公司清算中心-广东珩基建筑工程有限公司-213255963821400001\"},{\"序号\":\"70\",\"交易时间\":\"2023-08-14\",\"交易金额\":\"-40000.0\",\"余额\":\"30083.0\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行资金清算中心-赖金山-6228481133550810012\"},{\"序号\":\"71\",\"交易时间\":\"2023-08-14\",\"交易金额\":\"-50000.0\",\"余额\":\"70083.0\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中信银行股份有限公司-梁柱基-6217680912268088\"},{\"序号\":\"72\",\"交易时间\":\"2023-08-14\",\"交易金额\":\"-30000.0\",\"余额\":\"120083.0\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行资金清算中心-赖金山-6228481133550810012\"},{\"序号\":\"73\",\"交易时间\":\"2023-08-14\",\"交易金额\":\"+150000.0\",\"余额\":\"150083.0\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国工商银行-广东珩基建筑工程有限公司-2008023409200160685\"},{\"序号\":\"74\",\"交易时间\":\"2023-08-14\",\"交易金额\":\"-13900.0\",\"余额\":\"83.0\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行股份有限公司-赖金山-6228481133550810012\"},{\"序号\":\"75\",\"交易时间\":\"2023-08-14\",\"交易金额\":\"-11000.0\",\"余额\":\"13983.0\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"平安银行-陈转科-6230580000240592027\"},{\"序号\":\"76\",\"交易时间\":\"2023-08-13\",\"交易金额\":\"-46000.0\",\"余额\":\"24983.0\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"中国农业银行资金清算中心-赖金山-6228481133550810012\"},{\"序号\":\"77\",\"交易时间\":\"2023-08-13\",\"交易金额\":\"-17.0\",\"余额\":\"70983.0\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信转账-243300133\"},{\"序号\":\"78\",\"交易时间\":\"2023-08-13\",\"交易金额\":\"-5000.0\",\"余额\":\"71000.0\",\"交易地点\":\"平安银行\",\"摘要\":\"网银转款本金\",\"备注\":\"/\",\"交易对手信息\":\"平安银行-陈转科-6230580000240592027\"},{\"序号\":\"79\",\"交易时间\":\"2023-08-12\",\"交易金额\":\"-4000.0\",\"余额\":\"76000.0\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信转账-243300133\"},{\"序号\":\"80\",\"交易时间\":\"2023-08-12\",\"交易金额\":\"-20000.0\",\"余额\":\"80000.0\",\"交易地点\":\"平安银行\",\"摘要\":\"快捷支付\",\"备注\":\"财付通\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信转账-243300133\"},{\"序号\":\"81\",\"交易时间\":\"2023-08-12\",\"交易金额\":\"+65000.0\",\"余额\":\"100000.0\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国工商银行-广东珩基建筑工程有限公司-2008023409200160685\"},{\"序号\":\"82\",\"交易时间\":\"2023-08-12\",\"交易金额\":\"+35000.0\",\"余额\":\"35000.0\",\"交易地点\":\"平安银行\",\"摘要\":\"跨行转账\",\"备注\":\"/\",\"交易对手信息\":\"中国工商银行惠州市分行核算中心-广东珩基建筑工程有限公司-2008023409200160685\"},{\"序号\":\"83\",\"交易时间\":\"2023-07-21\",\"交易金额\":\"-6968.38\",\"余额\":\"0.0\",\"交易地点\":\"平安银行\",\"摘要\":\"贷款扣款\",\"备注\":\"批量还款\",\"交易对手信息\":\"平安银行-银行内部账户-4031503\"},{\"序号\":\"84\",\"交易时间\":\"2023-07-21\",\"交易金额\":\"+6968.38\",\"余额\":\"6968.38\",\"交易地点\":\"平安银行\",\"摘要\":\"付款业务\",\"备注\":\"微信向银行卡转账\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信向银行卡转账-243300133\"},{\"序号\":\"85\",\"交易时间\":\"2023-06-21\",\"交易金额\":\"-6968.38\",\"余额\":\"0.0\",\"交易地点\":\"平安银行惠州惠东支行\",\"摘要\":\"贷款还款\",\"备注\":\"RL20230621993504\",\"交易对手信息\":\"/\"},{\"序号\":\"86\",\"交易时间\":\"2023-06-21\",\"交易金额\":\"+6968.38\",\"余额\":\"6968.38\",\"交易地点\":\"平安银行\",\"摘要\":\"银联贷记交易入账\",\"备注\":\"微信向银行卡转账;财付通支付科技有限公司;微信向银行卡转账;微信向银行卡转账\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-9915840000495800\"},{\"序号\":\"87\",\"交易时间\":\"2023-05-21\",\"交易金额\":\"-6966.36\",\"余额\":\"0.0\",\"交易地点\":\"平安银行惠州惠东支行\",\"摘要\":\"贷款还款\",\"备注\":\"RL20230521459133\",\"交易对手信息\":\"/\"},{\"序号\":\"88\",\"交易时间\":\"2023-05-21\",\"交易金额\":\"+6966.36\",\"余额\":\"6966.36\",\"交易地点\":\"平安银行\",\"摘要\":\"付款业务\",\"备注\":\"微信向银行卡转账\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信向银行卡转账-243300133\"},{\"序号\":\"89\",\"交易时间\":\"2023-05-21\",\"交易金额\":\"-2.02\",\"余额\":\"0.0\",\"交易地点\":\"平安银行\",\"摘要\":\"贷款扣款\",\"备注\":\"批量还款\",\"交易对手信息\":\"平安银行-银行内部账户-4031503\"},{\"序号\":\"90\",\"交易时间\":\"2023-04-21\",\"交易金额\":\"-6966.36\",\"余额\":\"2.02\",\"交易地点\":\"平安银行惠州惠东支行\",\"摘要\":\"贷款还款\",\"备注\":\"RL20230421026807\",\"交易对手信息\":\"/\"},{\"序号\":\"91\",\"交易时间\":\"2023-04-21\",\"交易金额\":\"+6968.38\",\"余额\":\"6968.38\",\"交易地点\":\"平安银行\",\"摘要\":\"银联贷记交易入账\",\"备注\":\"微信向银行卡转账;财付通支付科技有限公司;微信向银行卡转账;微信向银行卡转账\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-9915840000495800\"},{\"序号\":\"92\",\"交易时间\":\"2023-04-21\",\"交易金额\":\"-2.02\",\"余额\":\"0.0\",\"交易地点\":\"平安银行\",\"摘要\":\"贷款扣款\",\"备注\":\"批量还款\",\"交易对手信息\":\"平安银行-银行内部账户-4031503\"},{\"序号\":\"93\",\"交易时间\":\"2023-03-21\",\"交易金额\":\"-6968.38\",\"余额\":\"2.02\",\"交易地点\":\"平安银行\",\"摘要\":\"贷款扣款\",\"备注\":\"批量还款\",\"交易对手信息\":\"平安银行-银行内部账户-4031503\"},{\"序号\":\"94\",\"交易时间\":\"2023-03-21\",\"交易金额\":\"+0.15\",\"余额\":\"6970.4\",\"交易地点\":\"/\",\"摘要\":\"支付利息\",\"备注\":\"/\",\"交易对手信息\":\"/\"},{\"序号\":\"95\",\"交易时间\":\"2023-03-20\",\"交易金额\":\"+6968.38\",\"余额\":\"6970.25\",\"交易地点\":\"平安银行\",\"摘要\":\"付款业务\",\"备注\":\"微信向银行卡转账\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信向银行卡转账-243300133\"},{\"序号\":\"96\",\"交易时间\":\"2023-02-21\",\"交易金额\":\"-6968.38\",\"余额\":\"1.87\",\"交易地点\":\"平安银行\",\"摘要\":\"贷款扣款\",\"备注\":\"批量还款\",\"交易对手信息\":\"平安银行-银行内部账户-4031503\"},{\"序号\":\"97\",\"交易时间\":\"2023-02-20\",\"交易金额\":\"+6968.38\",\"余额\":\"6970.25\",\"交易地点\":\"平安银行\",\"摘要\":\"银联贷记交易入账\",\"备注\":\"微信向银行卡转账;财付通支付科技有限公司;微信向银行卡转账;微信向银行卡转账\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-9915840000495800\"},{\"序号\":\"98\",\"交易时间\":\"2023-01-21\",\"交易金额\":\"-6968.38\",\"余额\":\"1.87\",\"交易地点\":\"平安银行\",\"摘要\":\"贷款扣款\",\"备注\":\"批量还款\",\"交易对手信息\":\"平安银行-银行内部账户-4031503\"},{\"序号\":\"99\",\"交易时间\":\"2023-01-20\",\"交易金额\":\"+6968.38\",\"余额\":\"6970.25\",\"交易地点\":\"平安银行\",\"摘要\":\"银联贷记交易入账\",\"备注\":\"微信向银行卡转账;财付通支付科技有限公司;微信向银行卡转账;微信向银行卡转账\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-9915840000495800\"},{\"序号\":\"100\",\"交易时间\":\"2022-12-21\",\"交易金额\":\"-6968.38\",\"余额\":\"1.87\",\"交易地点\":\"平安银行\",\"摘要\":\"贷款扣款\",\"备注\":\"批量还款\",\"交易对手信息\":\"平安银行-银行内部账户-4031503\"},{\"序号\":\"101\",\"交易时间\":\"2022-12-21\",\"交易金额\":\"+0.15\",\"余额\":\"6970.25\",\"交易地点\":\"平安银行深圳中心城支行\",\"摘要\":\"支付利息\",\"备注\":\"/\",\"交易对手信息\":\"/\"},{\"序号\":\"102\",\"交易时间\":\"2022-12-20\",\"交易金额\":\"+6968.38\",\"余额\":\"6970.1\",\"交易地点\":\"平安银行\",\"摘要\":\"付款业务\",\"备注\":\"微信向银行卡转账\",\"交易对手信息\":\"财付通支付科技有限公司-财付通支付科技有限公司-微信向银行卡转账-243300133\"}]}";

//        String standardizedJson = pabConverter.convert(pabJson1);// pabConverter.convert(pabJson1);
//        System.out.println(standardizedJson);

//        standardizedJson = pabConverter.convert(pabJson2);
//        System.out.println(standardizedJson);

        List<String> jsonList = new ArrayList<>();
        jsonList.add(pabJson1);
        String standardizedJson = pabConverter.convert(jsonList);// pabConverter.convert(pabJson1);
        System.out.println(standardizedJson);
    }

}
