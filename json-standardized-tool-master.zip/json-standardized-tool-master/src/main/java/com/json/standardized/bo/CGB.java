package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class CGB {
	
	@JsonProperty("账号")
	private String accountNo;
	
	@JsonProperty("户名")
	private String accountName;
	
	@JsonProperty("起止日期")
	private String inquiryPeriod;
	
    @JsonProperty("交易明细")
    private List<CGBTran> cgbTrans;

}
