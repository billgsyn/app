package com.json.standardized.convert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.standardized.bo.BJRCB;
import com.json.standardized.bo.BJRCBTran;
import com.json.standardized.bo.StandardizedBank;
import com.json.standardized.bo.StandardizedBankTran;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BJRCBConverter {

    private static final String DATE_FORMAT = "yyyy-MM-dd";
    private static final String DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    private static final String INPUT_DATE_FORMAT = "yyyy年M月d日";
    private static final String INPUT_DATETIME_FORMAT = "yyyy年MM月dd日 HH:mm:ss";
    private static final String INPUT_TRANSACTION_TIME_FORMAT = "yyyy/M/d";

    public String convert(String json) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        BJRCB bjrcb = mapper.readValue(json, BJRCB.class);
        StandardizedBank standardizedBank = new StandardizedBank();

        standardizedBank.setAccountName(bjrcb.getAccountName());
        standardizedBank.setCardNumber(bjrcb.getAccountNo());
        standardizedBank.setIdNumber(""); // No direct mapping

        String[] dateRange = bjrcb.getTransactionDate().split("-");
        standardizedBank.setStartDate(formatDate(INPUT_DATE_FORMAT, dateRange[0]));
        standardizedBank.setEndDate(formatDate(INPUT_DATE_FORMAT, dateRange[1]));
        standardizedBank.setPrintTime(formatDateTime(bjrcb.getSystemQueryDate()));

        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        for (BJRCBTran bjrcbTran : bjrcb.getBjrcbTrans()) {
            StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
            String[] parts = bjrcbTran.getTransactionTime().split(" ");

            standardizedBankTran.setTranDate(formatDate(INPUT_TRANSACTION_TIME_FORMAT, parts[0]));
            standardizedBankTran.setTranTime(parts[1]);

            standardizedBankTran.setCurrency(bjrcb.getCurrency());
            standardizedBankTran.setAmount(formatAmount(bjrcbTran.getTransactionAmount()));
            standardizedBankTran.setBalance(bjrcbTran.getBalance());
            standardizedBankTran.setTranName(bjrcbTran.getSummary());
            standardizedBankTran.setChannel(null); // No direct mapping
            standardizedBankTran.setPostscript(bjrcbTran.getPostscript());
            standardizedBankTran.setCounterpartInfo(mergeCounterpartyInfo(bjrcbTran));
            standardizedBankTrans.add(standardizedBankTran);
        }
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        return mapper.writeValueAsString(standardizedBank);
    }

    private String formatDate(String inputFormat, String dateStr) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(inputFormat);
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(DATE_FORMAT);

        LocalDate date = LocalDate.parse(dateStr, inputFormatter);
        return date.format(outputFormatter);
    }

    private String formatDateTime(String dateTimeStr) {
        if (StringUtils.isEmpty(dateTimeStr)) {
            return null;
        }

        SimpleDateFormat sdf = new SimpleDateFormat(INPUT_DATETIME_FORMAT);
        try {
            Date date = sdf.parse(dateTimeStr);
            return new SimpleDateFormat(DATETIME_FORMAT).format(date);
        } catch (ParseException e) {
            throw new RuntimeException("Error parsing datetime: " + dateTimeStr, e);
        }
    }

    private String formatAmount(String amountStr) {
        if (StringUtils.isEmpty(amountStr)) {
            return null;
        }
        return amountStr.replace("+", "");
    }

    private String mergeCounterpartyInfo(BJRCBTran bjrcbTran) {
        if (StringUtils.isEmpty(bjrcbTran.getCounterPartyAccountName())) {
            return "";
        }
        return bjrcbTran.getCounterPartyAccountName() + "/" + bjrcbTran.getCounterPartyAccountNumber();
    }

    public static void main(String[] args) throws JsonProcessingException {
        BJRCBConverter converter = new BJRCBConverter();
        String json = "{\"账户名称\":\"张三\",\"客户申请日期\":\"2024年4月28日 10:19:48\",\"查询机构\":\"业务处理监督中心\",\"系统查询日期\":\"2024年4月28日 10:20:09\",\"收入金额合计\":\"7,614.88\",\"支出金额合计\":\"3,500.00\",\"查询区间期末余额\":\"6,022.77\",\"交易明细合计\":\"22 条\",\"账号\":\"110500000123456\",\"币种\":\"人民币\",\"交易起止日期\":\"2023年4月29日-2024年4月28日\",\"交易金额\":\"全部\",\"交易类型\":\"全部\",\"交付日期\":\"2024年4月28日 10:20:09\",\"查询索引号\":\"24042810194834123456\",\"交易明细\":[{\"交易时间\":\"2023/12/21 00:31:15\",\"交易流水号\":\"0S0001180793123456\",\"交易金额\":\"+0.95\",\"账户余额\":\"1,908.84\",\"摘要\":\"入息\",\"附言\":\"\",\"对方户名\":\"\",\"对方账号\":\"\",\"对方银行名称\":\"\"},{\"交易时间\":\"2024/1/8 16:10:40\",\"交易流水号\":\"000058A00016123456\",\"交易金额\":\"+0.10\",\"账户余额\":\"1,908.94\",\"摘要\":\"超网来账\",\"附言\":\"转账\",\"对方户名\":\"李四\",\"对方账号\":\"6214******1234\",\"对方银行名称\":\"招商银行股份有限公司\"}]}";

        String standardizedJson = converter.convert(json);
        System.out.println(standardizedJson);
    }
}
