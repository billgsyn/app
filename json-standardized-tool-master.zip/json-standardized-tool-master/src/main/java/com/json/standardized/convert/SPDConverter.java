package com.json.standardized.convert;

import com.json.mapping.util.JsonUtil;
import com.json.standardized.bo.SPD;
import com.json.standardized.bo.SPDTran;
import com.json.standardized.bo.StandardizedBank;
import com.json.standardized.bo.StandardizedBankTran;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 浦发流水标准化字段输出
 */
public class SPDConverter {

	public String convert(String json) throws Exception {
		SPD spd = JsonUtil.json2Object(json, SPD.class);
		String standardizedJson = "";

		StandardizedBank standardizedBank = new StandardizedBank();
		standardizedBank.setAccountName(spd.getName());
		standardizedBank.setCardNumber(spd.getAccountNo());
		// Assuming startDate and endDate are extracted from startEndData
		String[] dates = spd.getStartEndData().split("-");
		if (dates.length == 2) {
			String startDate = dates[0];
			String endDate = dates[1];
			standardizedBank.setStartDate(startDate.substring(0, 4) + "-" + startDate.substring(4, 6) + "-" + startDate.substring(6, 8));
			standardizedBank.setEndDate(endDate.substring(0, 4) + "-" + endDate.substring(4, 6) + "-" + endDate.substring(6, 8));
		}
		// Assuming printTime is not available in SPD, set it to null or a default value
		standardizedBank.setPrintTime(null);

		List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
		for (SPDTran spdTran : spd.getSpdTrans()) {
			StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
			String date = spdTran.getDate();
			standardizedBankTran.setTranDate(date.substring(0, 4) + "-" + date.substring(4, 6) + "-" + date.substring(6, 8));
			String time = spdTran.getTime();
			if (StringUtils.isNotEmpty(time) && time.length() == 6) {
				time = time.substring(0, 2) + ":" + time.substring(2, 4) + ":" + time.substring(4, 6);
			}
			standardizedBankTran.setTranTime(time);
			standardizedBankTran.setCurrency(spd.getCurrency()); // Assuming currency is not available in SPDTran
			standardizedBankTran.setAmount(spdTran.getTransactionAmount());
			standardizedBankTran.setBalance(spdTran.getBalance());
			standardizedBankTran.setTranName(spdTran.getTransactionName());
			standardizedBankTran.setChannel(null); // Assuming channel is not available in SPDTran
			standardizedBankTran.setCounterpartInfo(spdTran.getCounterParty() + "/" + spdTran.getOpponentAccount());
			standardizedBankTran.setPostscript(spdTran.getSummary());

			standardizedBankTrans.add(standardizedBankTran);

		}
		standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

		standardizedJson = JsonUtil.object2Json(standardizedBank);
		return standardizedJson;
	}

	public static void main(String[] args) throws Exception {
		SPDConverter spdConverter = new SPDConverter();
		String spdJson = "{\"户名\":\"雷晓萍\",\"账号\":\"6225211112155584\",\"起止日期\":\"20200708-20220707\",\"币种\":\"人民币\",\"钞汇标志\":\"钞户\",\"交易类型\":\"全部\",\"交易明细\":[{\"交易日期\":\"20200921\",\"交易时间\":\"30230\",\"交易账号\":\"6225211112155584\",\"交易名称\":\"20季息\",\"交易金额\":\"0.01\",\"可用余额\":\"7.87\",\"对手姓名\":\"\",\"对手账号\":\"\",\"交易摘要\":\"\"},{\"交易日期\":\"20201107\",\"交易时间\":\"85742\",\"交易账号\":\"6225211112155584\",\"交易名称\":\"银联入账:赵志刚\",\"交易金额\":\"100.00\",\"可用余额\":\"107.87\",\"对手姓名\":\"赵志刚\",\"对手账号\":\"6230947200005161897\",\"交易摘要\":\"\"},{\"交易日期\":\"20201107\",\"交易时间\":\"120901\",\"交易账号\":\"6225211112155584\",\"交易名称\":\"网上支付-财付通\",\"交易金额\":\"-5.00\",\"可用余额\":\"102.87\",\"对手姓名\":\"微信零钱充值账户\",\"对手账号\":\"1000054101\",\"交易摘要\":\"\"},{\"交易日期\":\"20201107\",\"交易时间\":\"125658\",\"交易账号\":\"6225211112155584\",\"交易名称\":\"网上支付-支付宝\",\"交易金额\":\"-59.00\",\"可用余额\":\"43.87\",\"对手姓名\":\"深圳市幸福商城科技股份有限公司\",\"对手账号\":\"2088122872046491\",\"交易摘要\":\"\"},{\"交易日期\":\"20201221\",\"交易时间\":\"30306\",\"交易账号\":\"6225211112155584\",\"交易名称\":\"20季息\",\"交易金额\":\"0.02\",\"可用余额\":\"43.89\",\"对手姓名\":\"\",\"对手账号\":\"\",\"交易摘要\":\"\"},{\"交易日期\":\"20201225\",\"交易时间\":\"194708\",\"交易账号\":\"6225211112155584\",\"交易名称\":\"网上支付-财付通\",\"交易金额\":\"-3.50\",\"可用余额\":\"40.39\",\"对手姓名\":\"汉堡王食品(深圳)有限公司\",\"对手账号\":\"1413340802\",\"交易摘要\":\"\"},{\"交易日期\":\"20210321\",\"交易时间\":\"30800\",\"交易账号\":\"6225211112155584\",\"交易名称\":\"21季息\",\"交易金额\":\"0.03\",\"可用余额\":\"40.42\",\"对手姓名\":\"\",\"对手账号\":\"\",\"交易摘要\":\"\"},{\"交易日期\":\"20210502\",\"交易时间\":\"202655\",\"交易账号\":\"6225211112155584\",\"交易名称\":\"网上支付-财付通\",\"交易金额\":\"-40.00\",\"可用余额\":\"0.42\",\"对手姓名\":\"黑泷堂\",\"对手账号\":\"1500947831\",\"交易摘要\":\"\"},{\"交易日期\":\"20210621\",\"交易时间\":\"31800\",\"交易账号\":\"6225211112155584\",\"交易名称\":\"21季息\",\"交易金额\":\"0.01\",\"可用余额\":\"0.43\",\"对手姓名\":\"\",\"对手账号\":\"\",\"交易摘要\":\"\"}]}";
		String standardizedJson = spdConverter.convert(spdJson);
		System.out.println(standardizedJson);
	}
}
