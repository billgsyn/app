package com.json.standardized.convert;

import com.json.mapping.util.JsonUtil;
import com.json.standardized.bo.ABC;
import com.json.standardized.bo.ABCTran;
import com.json.standardized.bo.StandardizedBank;
import com.json.standardized.bo.StandardizedBankTran;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 农行流水标准化字段输出
 */
public class ABCConverter {

	public String convert(String json) throws Exception {
		ABC abc = JsonUtil.json2Object(json, ABC.class);
		String standardizedJson = "";

		StandardizedBank standardizedBank = new StandardizedBank();
		standardizedBank.setAccountName(abc.getName());
		standardizedBank.setCardNumber(abc.getAccount());
		standardizedBank.setIdNumber(null); // Assuming there is no direct mapping
		String[] dateRange = abc.getTransDetailPeriod().split("-");
		standardizedBank.setStartDate(dateRange.length > 0 ? dateRange[0] : null);
		standardizedBank.setEndDate(dateRange.length > 1 ? dateRange[1] : null);
		String startDate = standardizedBank.getStartDate();
		if (StringUtils.isNotEmpty(startDate) && startDate.length() == 8) {
			standardizedBank.setStartDate(startDate.substring(0, 4) + "-" + startDate.substring(4, 6) + "-" + startDate.substring(6, 8));
		}
		String endDate = standardizedBank.getEndDate();
		if (StringUtils.isNotEmpty(endDate) && endDate.length() == 8) {
			standardizedBank.setEndDate(endDate.substring(0, 4) + "-" + endDate.substring(4, 6) + "-" + endDate.substring(6, 8));
		}
		standardizedBank.setPrintTime(null); // Assuming there is no direct mapping

		List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
		for (ABCTran abcTran : abc.getAbcTrans()) {
			StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
			String tranDate = abcTran.getTranDate();
			if (StringUtils.isNotEmpty(tranDate) && tranDate.length() == 8) {
				standardizedBankTran.setTranDate(tranDate.substring(0, 4) + "-" + tranDate.substring(4, 6) + "-" + tranDate.substring(6, 8));
			}
			String tranTime = abcTran.getTranTime();
			if (StringUtils.isNotEmpty(tranTime) && tranTime.length() == 6) {
				standardizedBankTran.setTranTime(tranTime.substring(0, 2) + ":" + tranTime.substring(2, 4) + ":" + tranTime.substring(4, 6));
			}
			standardizedBankTran.setCurrency(abc.getCurrency());
			String tranAmt = abcTran.getTranAmt();
			if (StringUtils.isNotEmpty(tranAmt) && tranAmt.contains("+")) {
				tranAmt = tranAmt.replace("+", "");
			}
			standardizedBankTran.setAmount(tranAmt);
			standardizedBankTran.setBalance(abcTran.getBalance());
			standardizedBankTran.setTranName(abcTran.getTranSummary());
			standardizedBankTran.setChannel(abcTran.getTranChannel());
			standardizedBankTran.setPostscript(abcTran.getTranComment());
			standardizedBankTran.setCounterpartInfo(abcTran.getCounterPartyInfo());
			standardizedBankTrans.add(standardizedBankTran);
		}
		standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

		standardizedJson = JsonUtil.object2Json(standardizedBank);
		return standardizedJson;
	}

	public static void main(String[] args) throws Exception {
		ABCConverter abcConverter = new ABCConverter();
		String abcJson = "{\"户名\":\"徐伟丹\",\"账户\":\"6228480039162583973\",\"币种\":\"⼈⺠币\",\"钞汇标识\":\"本币\",\"起止日期\":\"20240430-20240730\",\"电子流水号\":\"2407301347056200855\",\"交易明细\":[{\"交易日期\":\"20240515\",\"交易时间\":\"155415\",\"交易摘要\":\"转存\",\"交易金额\":\"+252.00\",\"本次余额\":\"256.23\",\"对手信息\":\"徐伟丹\",\"日志号\":\"0521081128\",\"交易渠道\":\"超级网银\",\"交易附言\":\"\"},{\"交易日期\":\"20240515\",\"交易时间\":\"155436\",\"交易摘要\":\"学杂费\",\"交易金额\":\"-252.00\",\"本次余额\":\"4.23\",\"对手信息\":\"上海市浦东新区竹园小学\",\"日志号\":\"0521296895\",\"交易渠道\":\"电子商务\",\"交易附言\":\"电商支付-JF240515155308147137上海市浦东新区竹园小学学杂费(账\"},{\"交易日期\":\"20240621\",\"交易时间\":\"\",\"交易摘要\":\"结息\",\"交易金额\":\"+0.00\",\"本次余额\":\"4.23\",\"对手信息\":\"--\",\"日志号\":\"0000000001\",\"交易渠道\":\"\",\"交易附言\":\"个人活期结息\"},{\"交易日期\":\"20240621\",\"交易时间\":\"\",\"交易摘要\":\"利息税\",\"交易金额\":\"+0.00\",\"本次余额\":\"4.23\",\"对手信息\":\"--\",\"日志号\":\"0000000001\",\"交易渠道\":\"\",\"交易附言\":\"\"},{\"交易日期\":\"20240624\",\"交易时间\":\"174318\",\"交易摘要\":\"银联入账\",\"交易金额\":\"+216.00\",\"本次余额\":\"220.23\",\"对手信息\":\"徐伟丹\",\"日志号\":\"0553397680\",\"交易渠道\":\"\",\"交易附言\":\"\"},{\"交易日期\":\"20240624\",\"交易时间\":\"174338\",\"交易摘要\":\"学杂费\",\"交易金额\":\"-216.00\",\"本次余额\":\"4.23\",\"对手信息\":\"上海市浦东新区竹园小学\",\"日志号\":\"0553592389\",\"交易渠道\":\"电子商务\",\"交易附言\":\"电商支付-JF240624174234124344上海市浦东新区竹园小学学杂费(账\"}]}";
		String standardizedJson = abcConverter.convert(abcJson);
		System.out.println(standardizedJson);
	}
}
