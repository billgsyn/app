package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CMBCTran {

    /**
     * 凭证类型
     */
    @JsonProperty("凭证类型")
    private String certificateType;

    /**
     * 凭证号码
     */
    @JsonProperty("凭证号码")
    private String certificateNo;

    /**
     * 交易时间
     */
    @JsonProperty("交易时间")
    private String transactionTime;

    /**
     * 摘要
     */
    @JsonProperty("摘要")
    private String summary;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String transactionAmount;

    /**
     * 账户余额
     */
    @JsonProperty("账户余额")
    private String balance;

    /**
     * 现转标志
     */
    @JsonProperty("现转标志")
    private String cashTransfer;

    /**
     * 交易渠道
     */
    @JsonProperty("交易渠道")
    private String transactionChannel;

    /**
     * 交易机构
     */
    @JsonProperty("交易机构")
    private String transactionInstitution;

    /**
     * 对方户名/账号
     */
    @JsonProperty("对方户名/账号")
    private String counterPartyAccountName;

    /**
     * 对方行名
     */
    @JsonProperty("对方行名")
    private String counterBankName;
}
