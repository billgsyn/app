package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;


@Data
public class PSBC {
    @JsonProperty("卡号/账号")
    private String accountNumber;

    @JsonProperty("户名")
    private String accountName;

    @JsonProperty("起止日期")
    private String transDetailPeriod;

    @JsonProperty("查询时间内总收入")
    private String totalIncome;

    @JsonProperty("查询时间内总支出")
    private String totalExpense;

    @JsonProperty("交易明细")
    private List<PSBCTran> psbcTrans;
}
