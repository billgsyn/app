package com.json.mapping.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {

	private static ObjectMapper OBJECT_MAPPER;

	static {
		OBJECT_MAPPER = new ObjectMapper();

		// Include.NON_NULL Property is NULL and not serialized
		// OBJECT_MAPPER.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
		// DO NOT convert inconsistent fields
		OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	public static <T> T json2Object(String jsonString, Class<T> valueType) throws JsonProcessingException {
		return OBJECT_MAPPER.readValue(jsonString, valueType);
	}


	public static String object2Json(Object object) throws JsonProcessingException {
		return OBJECT_MAPPER.writeValueAsString(object);
	}
}
