package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class BCM {

    /**
     * 部门
     */
    @JsonProperty("部门")
    private String department;

    /**
     * 柜员
     */
    @JsonProperty("柜员")
    private String teller;

    /**
     * 打印日期
     */
    @JsonProperty("打印日期")
    private String printingDate;

    /**
     * 打印时间
     */
    @JsonProperty("打印时间")
    private String printingTime;

    /**
     * 账号/卡号
     */
    @JsonProperty("账号/卡号")
    private String accountNo;

    /**
     * 户名
     */
    @JsonProperty("户名")
    private String accountName;

    /**
     * 查询起日
     */
    @JsonProperty("查询起日")
    private String queryStartingDate;

    /**
     * 查询止日
     */
    @JsonProperty("查询止日")
    private String queryEndingDate;

    /**
     * 查询时间
     */
    @JsonProperty("查询时间")
    private String queryTime;

    /**
     * 查询柜员
     */
    @JsonProperty("查询柜员")
    private String searchTeller;

    /**
     * 证件种类
     */
    @JsonProperty("证件种类")
    private String idType;

    /**
     * 证件号码
     */
    @JsonProperty("证件号码")
    private String idNo;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<BCMTran> bcmTrans;
}
