package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;

import java.util.List;

@Data
public class CMBCorp {

    @JsonProperty("表头")
    private String title;

    @JsonInclude(Include.NON_NULL)
    @JsonProperty("起始日期")
    private String startDate;

    @JsonInclude(Include.NON_NULL)
    @JsonProperty("结束日期")
    private String endDate;

    @JsonProperty("交易明细")
    private List<CMBCorpTran> cmbCorpTrans;

    @JsonProperty("交易汇总")
    private CMBCorpSummary cmbCorpSummary;


}
