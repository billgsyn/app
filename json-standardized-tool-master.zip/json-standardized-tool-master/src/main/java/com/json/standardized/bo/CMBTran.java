package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CMBTran {

    //记账日期
    @JsonProperty("记账日期")
    private String date;

    //货币
    @JsonProperty("货币")
    private String currency;

    //交易金额
    @JsonProperty("交易金额")
    private String transactionAmount;

    //联机余额
    @JsonProperty("联机余额")
    private String balance;

    //交易摘要
    @JsonProperty("交易摘要")
    private String transactionType;

    //交易对方
    @JsonProperty("对手信息")
    private String counterParty;
}
