package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class JsBankTran {

    /**
     * 序号
     */
    @JsonProperty("序号")
    private String id;


    /**
     * 摘要/附言
     */
    @JsonProperty("摘要/附言")
    private String summary;

    /**
     * 币别
     */
    @JsonProperty("币别")
    private String currency;

    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String date;

    /**
     * 交易类型
     */
    @JsonProperty("交易类型")
    private String tranType;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String tranAmt;

    /**
     * 账户余额
     */
    @JsonProperty("账户余额")
    private String balance;

    /**
     * 对方账号
     */
    @JsonProperty("对方账号")
    private String counterPartyAccountNumber;

    /**
     * 对方户名
     */
    @JsonProperty("对方户名")
    private String counterPartyAccountName;
}
