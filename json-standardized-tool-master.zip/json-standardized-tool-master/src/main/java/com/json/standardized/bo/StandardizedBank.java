package com.json.standardized.bo;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;


@Data
public class StandardizedBank {

	@JsonProperty("户名")
	private String accountName;

	@JsonProperty("卡号")
	private String cardNumber;

	@JsonProperty("证件号码")
	private String idNumber;

	@JsonProperty("起始日期")
	private String startDate;

	@JsonProperty("结束日期")
	private String endDate;

	@JsonProperty("打印时间")
	private String printTime;

	/**
	 * 交易明细
	 */
	@JsonProperty("交易明细")
	private List<StandardizedBankTran> standardizedBankTrans;

}
