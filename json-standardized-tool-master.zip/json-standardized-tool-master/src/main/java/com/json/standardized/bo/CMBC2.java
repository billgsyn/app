package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class CMBC2 {

    /**
     * 客户姓名
     */
    @JsonProperty("客户姓名")
    private String customerName;

    /**
     * 客户账号
     */
    @JsonProperty("客户账号")
    private String customerAccount;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 账户账号
     */
    @JsonProperty("账户账号")
    private String accountNo;

    /**
     * 开户机构
     */
    @JsonProperty("开户机构")
    private String accountOpeningInstitution;

    /**
     * 证件号码
     */
    @JsonProperty("证件号码")
    private String idNo;

    /**
     * 起止日期
     */
    @JsonProperty("起止日期")
    private String transDetailPeriod;

    /**
     * 地址
     */
    @JsonProperty("地址")
    private String address;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<CMBCTran2> cmbcTrans;

}
