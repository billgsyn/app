package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BOCTran {

    @JsonProperty("记账日期")
    private String bookkeepingDate;

    @JsonProperty("记账时间")
    private String bookkeepingTime;

    @JsonProperty("币别")
    private String currency;

    @JsonProperty("金额")
    private String amount;

    @JsonProperty("余额")
    private String balance;

    @JsonProperty("交易名称")
    private String transactionName;

    @JsonProperty("渠道")
    private String channel;

    @JsonProperty("网点名称")
    private String outletName;

    @JsonProperty("附言")
    private String postscript;

    @JsonProperty("对方账户名")
    private String oppositeAccountName;

    @JsonProperty("对方卡号/账号")
    private String OppositeCardNo;

    @JsonProperty("对方开户行")
    private String OppositeBankOfDeposit;

}
