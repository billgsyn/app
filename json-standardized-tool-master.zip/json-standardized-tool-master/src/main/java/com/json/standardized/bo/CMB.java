package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class CMB {

    /**
     * "交易流水对应的期间
     */
    @JsonProperty("交易流水对应的期间")
    private String transDetailPeriod;

    /**
     * 户名
     */
    @JsonProperty("户名")
    private String name;

    /**
     * 账号
     */
    @JsonProperty("账号")
    private String accountNo;

    /**
     * 账户类型
     */
    @JsonProperty("账户类型")
    private String accountType;

    /**
     * 开户行
     */
    @JsonProperty("开户行")
    private String subBranch;

    /**
     * 申请时间
     */
    @JsonProperty("申请时间")
    private String date;

    /**
     * 验证码
     */
    @JsonProperty("验证码")
    private String verificationCode;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<CMBTran> cmbTrans;
}
