package com.json.standardized.convert;

import com.json.standardized.bo.BOB;
import com.json.standardized.bo.BOBTran;
import com.json.standardized.bo.StandardizedBank;
import com.json.standardized.bo.StandardizedBankTran;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class BOBConverter {

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");


    public String convert(String json) throws Exception {
        BOB bob = com.json.mapping.util.JsonUtil.json2Object(json, BOB.class);
        StandardizedBank standardizedBank = new StandardizedBank();

        // Copy properties
        standardizedBank.setAccountName(bob.getName());
        standardizedBank.setCardNumber(bob.getAccountNumber());
        // Parse and set date range
        String[] dates = bob.getDateRange().split("—");
        standardizedBank.setStartDate(parseDate(dates[0]));
        standardizedBank.setEndDate(parseDate(dates[1]));

        // Convert transactions
        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        for (BOBTran bobTran : bob.getBobTrans()) {
            StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
            standardizedBankTran.setTranDate(parseDate(bobTran.getTranDate()));
            standardizedBankTran.setCurrency(bobTran.getCurrency());
            standardizedBankTran.setAmount(bobTran.getTranAmount());
            standardizedBankTran.setBalance(bobTran.getBalance());
            standardizedBankTran.setTranName(bobTran.getBusinessSummary());
            standardizedBankTran.setChannel(""); // Channel is not provided in the original data
            standardizedBankTran.setPostscript(""); // Postscript is not provided in the original data
            standardizedBankTran.setCounterpartInfo(mergeCounterpartyInfo(bobTran));
            standardizedBankTrans.add(standardizedBankTran);
        }
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);
        return com.json.mapping.util.JsonUtil.object2Json(standardizedBank);
    }

    private static String parseDate(String dateStr) throws Exception {
        return DATE_FORMAT.format(DATE_FORMAT.parse(dateStr));
    }

    private String mergeCounterpartyInfo(BOBTran tran) {
        if (StringUtils.isBlank(tran.getCounterPartyAccountName().trim())) {
            return "";
        }
        return tran.getCounterPartyAccountName() + "/" + tran.getCounterPartyAccountNumber();
    }

    public static void main(String[] args) throws Exception {

        BOBConverter converter = new BOBConverter();
        String json = "{\"客户名称\":\"张三\",\"日期范围\":\"2024-03-17—2024-04-17\",\"卡/账号\":\"：6210300000000000\",\"币种\":\"人民币\",\"流水单号\":\"AOFC001000000000000\",\"交易明细\":[{\"交易日期\":\"2024-03-28\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"业务摘要\":\"还款\",\"发生额\":\"-25\",\"余额\":\"1,250.93\",\"对方户名\":\" \",\"对方账号\":\"\"},{\"交易日期\":\"2024-03-21\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"业务摘要\":\"利息\",\"发生额\":\"+0.67\",\"余额\":\"1,275.93\",\"对方户名\":\" 活期储蓄存款利息支出\",\"对方账号\":\"521000000\"}]}";


        String standardizedJson = converter.convert(json);
        System.out.println(standardizedJson);
    }
}
