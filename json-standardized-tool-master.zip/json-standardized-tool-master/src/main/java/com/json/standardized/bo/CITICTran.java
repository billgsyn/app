package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CITICTran {

    @JsonProperty("交易日期")
    private String transactionDate;

    @JsonProperty("账户序号")
    private String accountSeqNo;

    @JsonProperty("收入金额")
    private String accountReceivable;

    @JsonProperty("支出金额")
    private String accountPaid;

    @JsonProperty("账户余额")
    private String accountBalance;

    @JsonProperty("交易摘要")
    private String description;

    @JsonProperty("对方户名")
    private String recipient;

    @JsonProperty("被冲账标识")
    private String reversalFlag;

}
