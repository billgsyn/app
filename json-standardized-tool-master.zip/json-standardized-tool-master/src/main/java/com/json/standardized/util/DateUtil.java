package com.json.mapping.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

	/**
	 * 将yyyyMMdd格式的日期转换成yyyy-MM-dd
	 * @param date 日期
	 * @return 转换后的日期
	 */
	public static String convertDate(String date) {
		try {
			Date format = new SimpleDateFormat("yyyyMMdd").parse(date);
			return new SimpleDateFormat("yyyy-MM-dd").format(format);
		} catch (ParseException e) {
			System.out.println(e.getMessage());
		}
		return "";
	}
}
