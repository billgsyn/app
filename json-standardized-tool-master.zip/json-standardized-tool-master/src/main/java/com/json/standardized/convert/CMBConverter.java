package com.json.standardized.convert;

import com.json.mapping.util.JsonUtil;
import com.json.standardized.bo.CMB;
import com.json.standardized.bo.CMBTran;
import com.json.standardized.bo.StandardizedBank;
import com.json.standardized.bo.StandardizedBankTran;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 招行流水标准化字段输出
 */
public class CMBConverter {

	public String convert(String json) throws Exception {
		CMB cmb = JsonUtil.json2Object(json, CMB.class);
		String standardizedJson = "";

		StandardizedBank standardizedBank = new StandardizedBank();
		standardizedBank.setAccountName(cmb.getName());
		standardizedBank.setCardNumber(cmb.getAccountNo());
		// Assuming startDate and endDate are extracted from transDetailPeriod
		String[] dates = cmb.getTransDetailPeriod().split(" -- ");
		if (dates.length == 2) {
			standardizedBank.setStartDate(dates[0]);
			standardizedBank.setEndDate(dates[1]);
		}
		// Assuming printTime is not available in CMB, set it to null or a default value
		standardizedBank.setPrintTime(cmb.getDate());

		List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
		Pattern pattern = Pattern.compile("\\d");
		for (CMBTran cmbTran : cmb.getCmbTrans()) {
			StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
			standardizedBankTran.setTranDate(cmbTran.getDate());
			// Assuming tranTime is not available in CMBTran, set it to null or a default value
			standardizedBankTran.setTranTime(null);
			standardizedBankTran.setCurrency(cmbTran.getCurrency());
			standardizedBankTran.setAmount(cmbTran.getTransactionAmount());
			standardizedBankTran.setBalance(cmbTran.getBalance());
			standardizedBankTran.setTranName(cmbTran.getTransactionType());
			standardizedBankTran.setChannel(null); // Assuming channel is not available in CMBTran
			String counterParty = cmbTran.getCounterParty();
			Matcher matcher = pattern.matcher(counterParty);
			if (matcher.find()) {
				int index = matcher.start();
                counterParty = counterParty.substring(0, index) + "/" + counterParty.substring(index);
			}
			standardizedBankTran.setCounterpartInfo(counterParty);
			standardizedBankTran.setPostscript(null); // Assuming postscript is not available in CMBTran
			standardizedBankTrans.add(standardizedBankTran);

		}
		standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

		standardizedJson = JsonUtil.object2Json(standardizedBank);
		return standardizedJson;
	}

	public static void main(String[] args) throws Exception {
		CMBConverter cmbConverter = new CMBConverter();
		String cmbJson = "{\"交易流水对应的期间\":\"2024-01-28 -- 2024-02-28\",\"户名\":\"金汉生\",\"账号\":\"6214837834511531\",\"账户类型\":\"ALL/全币种\",\"开户行\":\"深圳安联支行\",\"申请时间\":\"2024-07-30 17:45:58\",\"验证码\":\"47CH3KEM\",\"交易明细\":[{\"记账日期\":\"2024-01-30\",\"货币\":\"CNY\",\"交易金额\":\"10.50\",\"联机余额\":\"5,454.53\",\"交易摘要\":\"网联收款\",\"对手信息\":\"金汉生1630022024010318034420\"},{\"记账日期\":\"2024-01-30\",\"货币\":\"CNY\",\"交易金额\":\"-199.99\",\"联机余额\":\"5,254.54\",\"交易摘要\":\"快捷支付\",\"对手信息\":\"蚂蚁（杭州）基金销售有限公司2088411594066781\"},{\"记账日期\":\"2024-02-01\",\"货币\":\"CNY\",\"交易金额\":\"-471.69\",\"联机余额\":\"4,782.85\",\"交易摘要\":\"快捷支付\",\"对手信息\":\"还款00000000\"},{\"记账日期\":\"2024-02-05\",\"货币\":\"CNY\",\"交易金额\":\"13,530.40\",\"联机余额\":\"18,313.25\",\"交易摘要\":\"代发工资\",\"对手信息\":\"中电金信软件（上海）有限公司121930763210902\"},{\"记账日期\":\"2024-02-07\",\"货币\":\"CNY\",\"交易金额\":\"-247.92\",\"联机余额\":\"18,065.33\",\"交易摘要\":\"快捷支付\",\"对手信息\":\"还款2088041645634735\"},{\"记账日期\":\"2024-02-09\",\"货币\":\"CNY\",\"交易金额\":\"19.21\",\"联机余额\":\"18,084.54\",\"交易摘要\":\"银联代付\",\"对手信息\":\"金汉生817102660510000\"},{\"记账日期\":\"2024-02-09\",\"货币\":\"CNY\",\"交易金额\":\"24.45\",\"联机余额\":\"18,108.99\",\"交易摘要\":\"银联代付\",\"对手信息\":\"金汉生817102660510000\"},{\"记账日期\":\"2024-02-09\",\"货币\":\"CNY\",\"交易金额\":\"-18,000.00\",\"联机余额\":\"108.99\",\"交易摘要\":\"银联快捷支付\",\"对手信息\":\"蚂蚁（杭州）基金销售有限公司20884215443049330156\"},{\"记账日期\":\"2024-02-09\",\"货币\":\"CNY\",\"交易金额\":\"10,000.00\",\"联机余额\":\"10,108.99\",\"交易摘要\":\"网联收款\",\"对手信息\":\"支付宝（中国）网络技术有限公司215500690\"},{\"记账日期\":\"2024-02-10\",\"货币\":\"CNY\",\"交易金额\":\"3.20\",\"联机余额\":\"10,112.19\",\"交易摘要\":\"网联收款\",\"对手信息\":\"金汉生11866746313\"},{\"记账日期\":\"2024-02-13\",\"货币\":\"CNY\",\"交易金额\":\"3.42\",\"联机余额\":\"10,115.61\",\"交易摘要\":\"银联代付\",\"对手信息\":\"金汉生991584000049XXX\"},{\"记账日期\":\"2024-02-15\",\"货币\":\"CNY\",\"交易金额\":\"-1,775.00\",\"联机余额\":\"8,340.61\",\"交易摘要\":\"转账汇款\",\"对手信息\":\"金鸿生6228480078156848570\"},{\"记账日期\":\"2024-02-16\",\"货币\":\"CNY\",\"交易金额\":\"-15.79\",\"联机余额\":\"8,324.82\",\"交易摘要\":\"快捷支付\",\"对手信息\":\"拼多多平台商户80901900018430003857\"},{\"记账日期\":\"2024-02-17\",\"货币\":\"CNY\",\"交易金额\":\"-930.00\",\"联机余额\":\"7,394.82\",\"交易摘要\":\"快捷支付\",\"对手信息\":\"**强215500690\"},{\"记账日期\":\"2024-02-17\",\"货币\":\"CNY\",\"交易金额\":\"-15.80\",\"联机余额\":\"7,379.02\",\"交易摘要\":\"快捷支付\",\"对手信息\":\"抖音电商商家8020230504192800\"},{\"记账日期\":\"2024-02-18\",\"货币\":\"CNY\",\"交易金额\":\"-1,147.04\",\"联机余额\":\"6,231.98\",\"交易摘要\":\"银联无卡自助消费\",\"对手信息\":\"华夏银行信用卡中心304980094985840\"},{\"记账日期\":\"2024-02-19\",\"货币\":\"CNY\",\"交易金额\":\"50,000.00\",\"联机余额\":\"56,231.98\",\"交易摘要\":\"汇入汇款\",\"对手信息\":\"广发银行股份有限公司信用卡中心17100215616111017545001\"},{\"记账日期\":\"2024-02-19\",\"货币\":\"CNY\",\"交易金额\":\"-11,082.36\",\"联机余额\":\"45,149.62\",\"交易摘要\":\"银联快捷支付\",\"对手信息\":\"还款8888888599228986\"},{\"记账日期\":\"2024-02-19\",\"货币\":\"CNY\",\"交易金额\":\"-30,072.00\",\"联机余额\":\"15,077.62\",\"交易摘要\":\"银联快捷支付\",\"对手信息\":\"还款8888888599228986\"},{\"记账日期\":\"2024-02-20\",\"货币\":\"CNY\",\"交易金额\":\"-1,812.84\",\"联机余额\":\"13,264.78\",\"交易摘要\":\"个贷交易\",\"对手信息\":\"招商银行股份有限公司6655570134700001\"},{\"记账日期\":\"2024-02-20\",\"货币\":\"CNY\",\"交易金额\":\"-999.49\",\"联机余额\":\"12,265.29\",\"交易摘要\":\"个贷交易\",\"对手信息\":\"招商银行股份有限公司6655570134700002\"},{\"记账日期\":\"2024-02-22\",\"货币\":\"CNY\",\"交易金额\":\"-8,000.00\",\"联机余额\":\"4,265.29\",\"交易摘要\":\"个贷交易\",\"对手信息\":\"招商银行股份有限公司6655570134700002\"},{\"记账日期\":\"2024-02-23\",\"货币\":\"CNY\",\"交易金额\":\"8,001.24\",\"联机余额\":\"12,266.53\",\"交易摘要\":\"银联代付\",\"对手信息\":\"蚂蚁（杭州）基金销售有限公司302102289990013\"},{\"记账日期\":\"2024-02-23\",\"货币\":\"CNY\",\"交易金额\":\"-8,000.00\",\"联机余额\":\"4,266.53\",\"交易摘要\":\"个贷交易\",\"对手信息\":\"招商银行股份有限公司6655570134700002\"},{\"记账日期\":\"2024-02-28\",\"货币\":\"CNY\",\"交易金额\":\"-77.96\",\"联机余额\":\"4,188.57\",\"交易摘要\":\"快捷支付\",\"对手信息\":\"拼多多平台商户80901900018430003857\"}]}";
		String standardizedJson = cmbConverter.convert(cmbJson);
		System.out.println(standardizedJson);
	}
}
