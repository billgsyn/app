package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class WechatPay {

	@JsonProperty("编号")
	private String number;

	@JsonProperty("姓名")
	private String name;

	@JsonProperty("身份证")
	private String idNumber;

	@JsonProperty("微信号")
	private String wechatAccount;

	@JsonProperty("币种")
	private String currency;

	@JsonProperty("单位")
	private String unit;

	@JsonProperty("交易明细对应时间段")
	private String transDetailPeriod;

	@JsonProperty("具体交易明细")
	private List<WechatPayTran> wechatPayTrans;

}
