package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ICBCCorp {

    @JsonProperty("账号")
    private String accountNo;

    @JsonProperty("币种")
    private String currency;

    @JsonProperty("单位")
    private String unit;

    @JsonProperty("本方账号户名")
    private String accountName;

    @JsonProperty("本方账号开户行")
    private String accountBank;

    @JsonProperty("时间范围")
    private String timeRange;

    @JsonProperty("交易明细")
    private List<ICBCCorpTran> icbcCorpTrans;

    @JsonProperty("交易汇总")
    private ICBCCorpSummary icbcCorpSummary;

}
