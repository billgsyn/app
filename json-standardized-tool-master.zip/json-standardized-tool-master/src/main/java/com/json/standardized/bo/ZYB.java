package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ZYB {

    @JsonProperty("起始日期")
    private String startDate;

    @JsonProperty("结束日期")
    private String endDate;

    @JsonProperty("申请时间")
    private String applyDateTime;

    @JsonProperty("账户名称")
    private String accountName;

    @JsonProperty("账号")
    private String accountNumber;

    @JsonProperty("验证码")
    private String verificationCode;

    @JsonProperty("交易明细")
    private List<ZYBTran> zybTrans;

}
