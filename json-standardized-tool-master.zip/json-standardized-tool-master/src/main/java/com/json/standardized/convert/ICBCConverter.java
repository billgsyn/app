package com.json.standardized.convert;

import com.json.standardized.bo.*;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 工行流水标准化字段输出
 */
public class ICBCConverter {

    public String convert(List<String> jsonList) throws Exception {
        String standardizedJson = "";
        StandardizedBank standardizedBank = new StandardizedBank();
        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        for (int i = 0; i < jsonList.size(); i++) {
            String json = jsonList.get(i);
            ICBC icbc = com.json.mapping.util.JsonUtil.json2Object(json, ICBC.class);

            //解析header
            if (StringUtils.isEmpty(standardizedBank.getAccountName())) {
                standardizedBank.setAccountName(icbc.getName());
                standardizedBank.setCardNumber(icbc.getCardNo());
                standardizedBank.setIdNumber(null); // Assuming there is no direct mapping for ID number
                String[] dateRange = icbc.getTransDetailPeriod().split(" — ");
                standardizedBank.setStartDate(dateRange.length > 0 ? dateRange[0].trim() : null);
                standardizedBank.setEndDate(dateRange.length > 1 ? dateRange[1].trim() : null);
                standardizedBank.setPrintTime(null); // Assuming there is no direct mapping for print time
            }

            //解析交易明细
            for (ICBCTran icbcTran : icbc.getIcbcTrans()) {
                StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
                standardizedBankTran.setTranDate(icbcTran.getTranDate().substring(0, 10));
                standardizedBankTran.setTranTime(icbcTran.getTranDate().substring(10, 18)); // Assuming there is no direct mapping for tranTime
                standardizedBankTran.setCurrency(icbcTran.getCurrency());
                standardizedBankTran.setAmount(icbcTran.getIncomeExpenseAmt().replace("+", ""));
                standardizedBankTran.setBalance(icbcTran.getBalance());
                standardizedBankTran.setTranName(icbcTran.getComment());
                standardizedBankTran.setChannel(icbcTran.getChannel());
                standardizedBankTran.setPostscript(null); // Assuming there is no direct mapping for postscript
                standardizedBankTran.setCounterpartInfo(icbcTran.getCounterpartyName() + "/" + icbcTran.getConterpartyAccountNo());
                standardizedBankTrans.add(standardizedBankTran);
            }
        }

        standardizedJson = com.json.mapping.util.JsonUtil.object2Json(standardizedBank);
        return standardizedJson;
    }

    public String convert(String json) throws Exception {
        ICBC icbc = com.json.mapping.util.JsonUtil.json2Object(json, ICBC.class);
        String standardizedJson = "";

        StandardizedBank standardizedBank = new StandardizedBank();
        standardizedBank.setAccountName(icbc.getName());
        standardizedBank.setCardNumber(icbc.getCardNo());
        standardizedBank.setIdNumber(null); // Assuming there is no direct mapping for ID number
        String[] dateRange = icbc.getTransDetailPeriod().split(" — ");
        standardizedBank.setStartDate(dateRange.length > 0 ? dateRange[0].trim() : null);
        standardizedBank.setEndDate(dateRange.length > 1 ? dateRange[1].trim() : null);
        standardizedBank.setPrintTime(null); // Assuming there is no direct mapping for print time

        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        for (ICBCTran icbcTran : icbc.getIcbcTrans()) {
            StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
            standardizedBankTran.setTranDate(icbcTran.getTranDate().substring(0, 10));
            standardizedBankTran.setTranTime(icbcTran.getTranDate().substring(10, 18)); // Assuming there is no direct mapping for tranTime
            standardizedBankTran.setCurrency(icbcTran.getCurrency());
            standardizedBankTran.setAmount(icbcTran.getIncomeExpenseAmt());
            standardizedBankTran.setBalance(icbcTran.getBalance());
            standardizedBankTran.setTranName(icbcTran.getComment());
            standardizedBankTran.setChannel(icbcTran.getChannel());
            standardizedBankTran.setPostscript(null); // Assuming there is no direct mapping for postscript
            standardizedBankTran.setCounterpartInfo(icbcTran.getCounterpartyName() + "/" + icbcTran.getConterpartyAccountNo());
            standardizedBankTrans.add(standardizedBankTran);
        }
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        standardizedJson = com.json.mapping.util.JsonUtil.object2Json(standardizedBank);
        return standardizedJson;
    }

    public static void main(String[] args) throws Exception {
        ICBCConverter icbcConverter = new ICBCConverter();
        String icbcJson1 = "{\"卡号\":\"6222031001024038346\",\"户名\":\"金汉生\",\"起止日期\":\"2024-06-30 — 2024-07-30\",\"交易明细\":[{\"交易日期\":\"2024-07-0112:33:24\",\"账号\":\"1001034701219277391\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"汇款\",\"地区\":\"1001\",\"收入支出金额\":\"+9,000.00\",\"余额\":\"9,002.44\",\"对方户名\":null,\"对方账号\":null,\"渠道\":\"柜面\"},{\"交易日期\":\"2024-07-0113:22:06\",\"账号\":\"1001034701219277391\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"金融付款\",\"地区\":\"1001\",\"收入支出金额\":\"-9,000.00\",\"余额\":\"2.44\",\"对方户名\":null,\"对方账号\":null,\"渠道\":\"快捷支付\"},{\"交易日期\":\"2024-07-1503:10:45\",\"账号\":\"1001034701219277391\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"工资\",\"地区\":\"1001\",\"收入支出金额\":\"+3,046.59\",\"余额\":\"3,049.03\",\"对方户名\":null,\"对方账号\":null,\"渠道\":\"其他\"},{\"交易日期\":\"2024-07-1511:09:25\",\"账号\":\"1001034701219277391\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"他行汇入\",\"地区\":\"1001\",\"收入支出金额\":\"+7,232.18\",\"余额\":\"10,281.21\",\"对方户名\":null,\"对方账号\":null,\"渠道\":\"其他\"},{\"交易日期\":\"2024-07-1515:11:48\",\"账号\":\"1001034701219277391\",\"储种\":\"活期\",\"序号\":\"00000\",\"币种\":\"人民币\",\"钞汇\":\"钞\",\"摘要\":\"金融付款\",\"地区\":\"1001\",\"收入支出金额\":\"-10,000.00\",\"余额\":\"281.21\",\"对方户名\":null,\"对方账号\":null,\"渠道\":\"快捷支付\"}]}";
        List<String> jsonList = new ArrayList<>();
        jsonList.add(icbcJson1);
        String standardizedJson = icbcConverter.convert(jsonList);
        System.out.println(standardizedJson);
    }

}
