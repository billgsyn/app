package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class JsBank {

    /**
     * 卡号
     */
    @JsonProperty("卡号")
    private String cardNo;

    /**
     * 客户名称
     */
    @JsonProperty("客户名称")
    private String name;

    /**
     * 开始日期
     */
    @JsonProperty("开始日期")
    private String startDate;

    /**
     * 结束日期
     */
    @JsonProperty("结束日期")
    private String endDate;

    /**
     * 申请时间
     */
    @JsonProperty("申请时间")
    private String applyDateTime;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<JsBankTran> jsBankTrans;
}
