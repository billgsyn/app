package com.json.standardized.convert;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.standardized.bo.NJCB;
import com.json.standardized.bo.NJCBTran;
import com.json.standardized.bo.StandardizedBank;
import com.json.standardized.bo.StandardizedBankTran;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class NJCBConverter {
    public String convert(String json) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        NJCB njcb = mapper.readValue(json, NJCB.class);
        StandardizedBank standardizedBank = new StandardizedBank();

        standardizedBank.setAccountName(njcb.getAccountName());
        standardizedBank.setCardNumber(njcb.getAccountNo()); // Assuming the account number is used as the card number
        standardizedBank.setIdNumber(null); // No direct mapping

        String[] dateRange = njcb.getTransDetailPeriod().split(" — ");
        standardizedBank.setStartDate(dateRange[0].trim());
        standardizedBank.setEndDate(dateRange[1].trim());

        standardizedBank.setPrintTime(njcb.getApplyDateTime()); // No direct mapping

        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        for (NJCBTran njcbTran : njcb.getNjcbTrans()) {
            StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
            standardizedBankTran.setTranDate(formatDate(njcbTran.getTranDate()));
            standardizedBankTran.setTranTime(null); // No direct mapping
            standardizedBankTran.setCurrency(njcbTran.getCurrency());
            standardizedBankTran.setAmount(formatAmount(njcbTran.getTranAmt()));
            standardizedBankTran.setBalance(njcbTran.getBalance());
            standardizedBankTran.setTranName(njcbTran.getTranSummary());
            standardizedBankTran.setChannel(null); // No direct mapping
            standardizedBankTran.setPostscript(null); // No direct mapping
            standardizedBankTran.setCounterpartInfo(njcbTran.getCounterPartyInfo());
            standardizedBankTrans.add(standardizedBankTran);
        }
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        return mapper.writeValueAsString(standardizedBank);
    }

    private String formatDate(String dateStr) {
        if (StringUtils.isEmpty(dateStr)) {
            return null;
        }
        return dateStr.substring(0, 4) + "-" + dateStr.substring(4, 6) + "-" + dateStr.substring(6, 8);
    }

    private String formatAmount(String amountStr) {
        if (StringUtils.isEmpty(amountStr)) {
            return null;
        }
        return amountStr.startsWith("+") ? amountStr.substring(1) : amountStr; // Remove '+' and keep '-'
    }

    public static void main(String[] args) throws Exception {
        NJCBConverter converter = new NJCBConverter();
        String njcbJson = "{\"户名\":\" 张三 \",\"账号\":\" 62125900000000000\",\"账户类型\":\" 人民币 \",\"开户行\":\"珠江支行\",\"起止日期\":\" 2023-05-27 — 2023-11-27 \",\"申请时间\":\"2023-11-27 18:10:00\",\"交易明细\":[{\"交易日期\":\"20231117\",\"币种\":\"人民币\",\"交易金额\":\"+12.34\",\"余额\":\"12.34\",\"交易摘要\":\"电子账户充值\",\"对手信息\":\"张三\"},{\"交易日期\":\"20231120\",\"币种\":\"人民币\",\"交易金额\":\"+15.23\",\"余额\":\"27.57\",\"交易摘要\":\"电子账户充值\",\"对手信息\":\"张三\"}]}";
        String standardizedJson = converter.convert(njcbJson);
        System.out.println(standardizedJson);
    }
}
