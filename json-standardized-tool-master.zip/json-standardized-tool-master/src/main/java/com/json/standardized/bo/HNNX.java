package com.json.standardized.bo;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class HNNX {

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;
    /**
     * 账号
     */
    @JsonProperty("账号")
    private String accountNo;

    /**
     * 户名
     */
    @JsonProperty("户名")
    private String accountName;

    /**
     * 起止日期
     */
    @JsonProperty("起止日期")
    private String transDetailPeriod;

    /**
     * 生成时间
     */
    @JsonProperty("生成时间")
    private String generationTime;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<HNNXTran> hnnxTrans;
}
