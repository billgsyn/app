package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class NJCBTran {

    /**
     * 交易日期
     */
    @JsonProperty("交易日期")
    private String tranDate;

    /**
     * 币种
     */
    @JsonProperty("币种")
    private String currency;

    /**
     * 交易金额
     */
    @JsonProperty("交易金额")
    private String tranAmt;

    /**
     * 余额
     */
    @JsonProperty("余额")
    private String balance;

    /**
     * 交易摘要
     */
    @JsonProperty("交易摘要")
    private String tranSummary;

    /**
     * 对手信息
     */
    @JsonProperty("对手信息")
    private String counterPartyInfo;
}
