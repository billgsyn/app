package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;


@Data
public class CCB {

    /**
     * 卡号/账号
     */
    @JsonProperty("卡号/账号")
    private String accountNo;

    /**
     * 客户名称
     */
    @JsonProperty("客户名称")
    private String name;

    /**
     * 起始日期
     */
    @JsonProperty("起始日期")
    private String startDate;

    /**
     * 结束日期
     */
    @JsonProperty("结束日期")
    private String endDate;

    /**
     * 交易明细
     */
    @JsonProperty("交易明细")
    private List<CCBTran> ccbTrans;

}
