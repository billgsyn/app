package com.json.standardized.bo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CMBCorpTran {

    @JsonProperty("付方账户")
    private String payerAccount;

    @JsonProperty("付方名称")
    private String payerName;

    @JsonProperty("付方开户行")
    private String payerBank;

    @JsonProperty("付方账户币种")
    private String payerAccountCurrency;

    @JsonProperty("收方账户")
    private String payeeAccount;

    @JsonProperty("收方名称")
    private String payeeName;

    @JsonProperty("收方开户银行")
    private String payeeBank;

    @JsonProperty("收方账户币种")
    private String payeeAccountCurrency;

    @JsonProperty("交易金额")
    private String tranAmt;

    @JsonProperty("余额")
    private String balance;

    @JsonProperty("交易时间")
    private String tranTime;

    @JsonProperty("交易流水号")
    private String tranSerialNo;

    @JsonProperty("交易类型")
    private String tranType;

    @JsonProperty("摘要")
    private String summary;
}
