package com.json.standardized.convert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.json.standardized.bo.SCRCU;
import com.json.standardized.bo.SCRCUTran;
import com.json.standardized.bo.StandardizedBank;
import com.json.standardized.bo.StandardizedBankTran;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class SCRCUConverter {


    public String convert(String json) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        SCRCU srcu = mapper.readValue(json, SCRCU.class);
        StandardizedBank standardizedBank = new StandardizedBank();

        standardizedBank.setAccountName(srcu.getAccountName());
        standardizedBank.setCardNumber(srcu.getAccountNo());
        standardizedBank.setIdNumber(null); // No direct mapping

        String[] dateRange = srcu.getTransDetailPeriod().split("至");
        standardizedBank.setStartDate(dateRange[0]);
        standardizedBank.setEndDate(dateRange[1]);

        standardizedBank.setPrintTime(null); // No direct mapping

        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        for (SCRCUTran srcuTran : srcu.getScrcuTrans()) {
            StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
            standardizedBankTran.setTranDate(formatDate(srcuTran.getTransactionDate()));
            standardizedBankTran.setTranTime(srcuTran.getTime());
            standardizedBankTran.setCurrency(srcuTran.getCurrency());
            standardizedBankTran.setAmount(formatAmount(srcuTran.getTransactionAmount()));
            standardizedBankTran.setBalance(srcuTran.getBalance());
            standardizedBankTran.setTranName(null);
            standardizedBankTran.setChannel(null); // No direct mapping
            standardizedBankTran.setPostscript(srcuTran.getComment());
            standardizedBankTran.setCounterpartInfo(mergeCounterpartyInfo(srcuTran));
            standardizedBankTrans.add(standardizedBankTran);
        }
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        return mapper.writeValueAsString(standardizedBank);
    }

    private String formatDate(String dateStr) {
        if (StringUtils.isEmpty(dateStr)) {
            return null;
        }
        return dateStr.substring(0, 4) + "-" + dateStr.substring(4, 6) + "-" + dateStr.substring(6, 8);
    }

    private String formatAmount(String amountStr) {
        if (StringUtils.isEmpty(amountStr)) {
            return null;
        }
        return amountStr.replace("+", "");
    }

    private String mergeCounterpartyInfo(SCRCUTran srcuTran) {
        return srcuTran.getCounterPartyAccountName() + "/" + srcuTran.getCounterPartyAccountNo();
    }

    public static void main(String[] args) throws JsonProcessingException {
        SCRCUConverter converter = new SCRCUConverter();
        String json = "{\"交易明细\":[{\"交易日期\":\"20230822\",\"交易时间\":\"05:21:08\",\"币种\":\"人民币\",\"交易金额\":\"-10.00\",\"账户余额\":\"70154.49\",\"对方户名\":\"扫二维码付款\",\"对方账号\":\"+1000000000\",\"对方银行\":\"无\",\"用途\":\"财付通\",\"备注\":\"其他渠道取款--跨行取款来帐\",\"记账日期\":\"20230822\"},{\"交易日期\":\"20231023\",\"交易时间\":\"10:54:53\",\"币种\":\"人民币\",\"交易金额\":\"21.00\",\"账户余额\":\"3407.92\",\"对方户名\":\"牛肉店\",\"对方账号\":\"5706000000000000000\",\"对方银行\":\"无\",\"用途\":\"商户57000000000000入账\",\"备注\":\"惠支付收单实时入账\",\"记账日期\":\"20231023\"}],\"账号\":\"6214000000000000000\",\"户名\":\"张三\",\"开户行\":\"四川XX农村商业银行股份有限公司XX分理处\",\"起止日期\":\"2023-08-22至2023-10-23\",\"收入合计\":\"1583429.49\",\"支出合计\":\"1577970.06\",\"备注\":\"抹账交易未纳入账户收支统计。\"}";
        String standardizedJson = converter.convert(json);
        System.out.println(standardizedJson);
    }
}
