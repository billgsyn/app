package com.json.standardized.convert;


import com.json.mapping.util.JsonUtil;
import com.json.standardized.bo.CZB;
import com.json.standardized.bo.CZBTran;
import com.json.standardized.bo.StandardizedBank;
import com.json.standardized.bo.StandardizedBankTran;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class CZBConverter {

    private static final String DATE_FORMAT = "yyyyMMdd";

    public String convert(String json) throws Exception {
        CZB czb = JsonUtil.json2Object(json, CZB.class);
        StandardizedBank standardizedBank = new StandardizedBank();

        standardizedBank.setAccountName(czb.getName());
        standardizedBank.setCardNumber(czb.getAccountNo());
        standardizedBank.setIdNumber(null); // No direct mapping

        String[] dateRange = czb.getTransDetailPeriod().split("--");
        standardizedBank.setStartDate(dateRange[0]);
        standardizedBank.setEndDate(dateRange[1]);

        standardizedBank.setPrintTime(czb.getQueryDate());

        List<StandardizedBankTran> standardizedBankTrans = new ArrayList<>();
        for (CZBTran czbTran : czb.getCzbTrans()) {
            StandardizedBankTran standardizedBankTran = new StandardizedBankTran();
            String[] parts = czbTran.getTranDate().split("-");
            String datePart = parts[0] + "-" + parts[1] + "-" + parts[2];
            String timePart = parts[3];

            standardizedBankTran.setTranDate(datePart);
            standardizedBankTran.setTranTime(timePart);
            standardizedBankTran.setCurrency(null); // No direct mapping
            standardizedBankTran.setAmount(formatAmount(czbTran.getTranAmount()));
            standardizedBankTran.setBalance(czbTran.getBalance());
            standardizedBankTran.setTranName(czbTran.getSummary());
            standardizedBankTran.setChannel(null); // No direct mapping
//            standardizedBankTran.setPostscript(czbTran.getRemark());
            standardizedBankTran.setCounterpartInfo(mergeCounterpartyInfo(czbTran));
            standardizedBankTrans.add(standardizedBankTran);
        }
        standardizedBank.setStandardizedBankTrans(standardizedBankTrans);

        return JsonUtil.object2Json(standardizedBank);
    }

    private String formatAmount(String amountStr) {
        if (StringUtils.isEmpty(amountStr)) {
            return null;
        }
        return amountStr.replace("+", "");
    }

    private String mergeCounterpartyInfo(CZBTran czbTran) {
        return czbTran.getCounterPartyAccountName() + "/" + czbTran.getCounterPartyAccountNumber();
    }

    public static void main(String[] args) throws Exception {
        CZBConverter czbConverter = new CZBConverter();
        String czbJson = "{\"户名\":\"张三\",\"账号\":\"6223***********2826\",\"起止日期\":\"2022-01-01--2022-04-14\",\"查询时间\":\"2022-04-14 14:41:33\",\"交易明细\":[{\"交易时间\":\"2022-03-24-15:24\",\"发生额(元)\":\"-0.03\",\"当前余额\":\"0.47\",\"当前可用余额 (元)\":\"0.47\",\"摘要\":\"e转出\",\"对方账号\":\"6217857500009163681\",\"对方户名\":\"李四\",\"对方开户行\":\"中国银行总行\",\"备注\":\"-\"},{\"交易时间\":\"2022-03-24-15:24\",\"发生额(元)\":\"-0.01\",\"当前余额\":\"0.50\",\"当前可用余额 (元)\":\"0.50\",\"摘要\":\"e转出\",\"对方账号\":\"6217857500009163681\",\"对方户名\":\"李四\",\"对方开户行\":\"中国银行总行\",\"备注\":\"-\"}]}";
        String standardizedJson = czbConverter.convert(czbJson);
        System.out.println(standardizedJson);
    }
}
